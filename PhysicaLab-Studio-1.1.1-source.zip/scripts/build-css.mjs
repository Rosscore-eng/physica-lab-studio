/**
 * Genera styles.css (el que carga Obsidian) uniendo src/styles/base.css y
 * las hojas propias de cada preset (src/presets/<modo>/*.css), en orden
 * alfabético para que el resultado sea estable.
 */
import { readdirSync, readFileSync, statSync, writeFileSync } from 'node:fs';
import { join, relative } from 'node:path';

const root = new URL('..', import.meta.url).pathname.replace(/^\/([A-Za-z]:)/, '$1');
const parts = [join(root, 'src/styles/base.css')];

function walk(dir) {
	for (const name of readdirSync(dir).sort()) {
		const p = join(dir, name);
		if (statSync(p).isDirectory()) walk(p);
		else if (name.endsWith('.css')) parts.push(p);
	}
}
walk(join(root, 'src/presets'));

const out = parts
	.map((p) => `/* ── ${relative(root, p).replace(/\\/g, '/')} ── */\n${readFileSync(p, 'utf8').trim()}\n`)
	.join('\n');
writeFileSync(join(root, 'styles.css'), out);
console.log(`styles.css ← ${parts.length} hoja(s)`);
