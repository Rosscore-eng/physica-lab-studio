/** Reproducible classic browser bundles: no CDN, module imports, or font requests at runtime. */
import { build } from 'esbuild';
import { copyFile, mkdir, readFile, writeFile } from 'node:fs/promises';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const out = join(root, 'vendor');
const threeDir = join(root, 'node_modules/three');
const katexDir = join(root, 'node_modules/katex');
const three = JSON.parse(await readFile(join(threeDir, 'package.json'), 'utf8'));
const katex = JSON.parse(await readFile(join(katexDir, 'package.json'), 'utf8'));
if (three.version !== '0.186.1') throw new Error(`Expected pinned three@0.186.1; found ${three.version}. Run npm ci.`);
await mkdir(out, { recursive: true });
await build({
	stdin: {
		contents: "import * as THREE from 'three'; import { OrbitControls } from 'three/addons/controls/OrbitControls.js'; window.THREE = THREE; window.OrbitControls = OrbitControls;",
		resolveDir: root,
		sourcefile: 'physlab-three-entry.js',
	},
	bundle: true,
	format: 'iife',
	platform: 'browser',
	target: ['chrome100', 'safari15'],
	minify: true,
	legalComments: 'inline',
	banner: { js: `/* PhysicaLab offline three@${three.version} + matching OrbitControls; MIT. */` },
	outfile: join(out, 'three.js'),
});
await copyFile(join(katexDir, 'dist/katex.min.js'), join(out, 'katex.js'));
let css = await readFile(join(katexDir, 'dist/katex.min.css'), 'utf8');
// Keep exactly the WOFF2 face which matches KaTeX's font metrics. Avoid file://
// and Obsidian resource URLs: the opaque sandbox allows data: font sources.
const faces = [...css.matchAll(/src:([^;}]+)/g)];
for (const face of faces) {
	const woff = face[1].match(/url\((?:["'])?(fonts\/[^)"']+\.woff2)(?:["'])?\)\s*format\(["']woff2["']\)/);
	if (!woff) throw new Error('A KaTeX font face has no WOFF2 source.');
	const bytes = await readFile(join(katexDir, 'dist', woff[1]));
	css = css.replace(face[0], `src:url(data:font/woff2;base64,${bytes.toString('base64')}) format("woff2")`);
}
const latinModern = await readFile(join(root, 'assets/fonts/lmroman10-regular.otf'));
css = `/* KaTeX ${katex.version}, MIT; Latin Modern Roman, GUST Font License. */\n@font-face{font-family:"Latin Modern Roman";src:url(data:font/otf;base64,${latinModern.toString('base64')}) format("opentype");font-style:normal;font-weight:400;font-display:swap}:root{--pl-font-serif:"Latin Modern Roman","KaTeX_Main",serif}\n${css}`;
if (/url\((?!["']?data:)/.test(css)) throw new Error('A non-embedded CSS URL remains.');
await writeFile(join(out, 'katex.css'), css);
await copyFile(join(threeDir, 'LICENSE'), join(out, 'THREE-LICENSE.txt'));
await copyFile(join(katexDir, 'LICENSE'), join(out, 'KATEX-LICENSE.txt'));
await copyFile(join(root, 'assets/fonts/GUST-FONT-LICENSE.txt'), join(out, 'GUST-FONT-LICENSE.txt'));
await copyFile(join(root, 'assets/fonts/LPPL-1.3c.txt'), join(out, 'LPPL-1.3c.txt'));
await writeFile(join(out, 'versions.json'), JSON.stringify({ three: three.version, OrbitControls: three.version, katex: katex.version, latinModern: 'lmroman10-regular.otf (unmodified)' }, null, 2) + '\n');
console.log(`Offline vendor bundles: Three.js ${three.version}, OrbitControls ${three.version}, KaTeX ${katex.version}, Latin Modern Roman + embedded WOFF2 math fonts.`);
