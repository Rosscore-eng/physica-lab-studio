/**
 * Crea un laboratorio nuevo del plugin a partir de una especificación JSON.
 *
 *   node scripts/nuevo-lab.mjs labs/mi-lab.json [--build] [--install <vault>]
 *
 * Genera src/presets/math/generated/<nombre>.ts con el motor genérico,
 * lo registra en src/presets/index.ts y, si se pide, compila e instala.
 * No hay código por laboratorio: solo datos.
 */
import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const args = process.argv.slice(2);
const specPath = args.find((a) => !a.startsWith('--'));
const doBuild = args.includes('--build');
const installAt = args.indexOf('--install');
const vault = installAt >= 0 ? args[installAt + 1] : null;

if (!specPath) {
	console.error('Uso: node scripts/nuevo-lab.mjs <spec.json> [--build] [--install <vault>]');
	process.exit(1);
}

const spec = JSON.parse(readFileSync(resolve(specPath), 'utf8'));
const id = String(spec.id ?? '');
if (!/^math\.[a-z][a-z0-9-]*$/.test(id)) {
	console.error(`id no válido: «${id}» (formato math.nombre-en-kebab)`);
	process.exit(1);
}
if (!Array.isArray(spec.params) || spec.params.length === 0) {
	console.error('El laboratorio necesita al menos un parámetro.');
	process.exit(1);
}
if (!Array.isArray(spec.curves) || spec.curves.length === 0) {
	console.error('El laboratorio necesita al menos una curva.');
	process.exit(1);
}

const name = id.slice('math.'.length);
const camel = name.replace(/-([a-z0-9])/g, (_m, c) => c.toUpperCase()) + 'Preset';
const rel = `math/generated/${name}`;
const file = join(root, 'src', 'presets', rel + '.ts');
mkdirSync(dirname(file), { recursive: true });

const body = `import { genericPlotPreset } from '../generic-plot';

/**
 * Generado por scripts/nuevo-lab.mjs desde ${specPath.replace(/\\/g, '/')}.
 * Edita el JSON y vuelve a ejecutar el script; no edites este archivo a mano.
 */
export const ${camel} = genericPlotPreset(${JSON.stringify(spec, null, '\t')});
`;
writeFileSync(file, body, 'utf8');

// Registro en src/presets/index.ts (idempotente).
const indexPath = join(root, 'src', 'presets', 'index.ts');
let index = readFileSync(indexPath, 'utf8');
const importLine = `import { ${camel} } from './${rel}';`;
if (!index.includes(importLine)) {
	const lastImport = index.lastIndexOf('\nimport ');
	const endOfLine = index.indexOf('\n', lastImport + 1);
	index = index.slice(0, endOfLine + 1) + importLine + '\n' + index.slice(endOfLine + 1);
}
if (!index.includes(`${camel},`)) {
	const close = index.indexOf('\n];');
	if (close < 0) {
		console.error('No se encontró la lista BUILTIN_PRESETS en src/presets/index.ts');
		process.exit(1);
	}
	index = index.slice(0, close) + `\n\t${camel},` + index.slice(close);
}
writeFileSync(indexPath, index, 'utf8');

console.log(`Preset ${id} → ${file.replace(root + '\\', '')}`);

if (doBuild) {
	const { execSync } = await import('node:child_process');
	execSync('npm run build', { cwd: root, stdio: 'inherit' });
	if (vault) execSync(`node scripts/install.mjs "${vault}"`, { cwd: root, stdio: 'inherit' });
} else if (vault) {
	const { execSync } = await import('node:child_process');
	execSync(`node scripts/install.mjs "${vault}"`, { cwd: root, stdio: 'inherit' });
}
if (!existsSync(file)) process.exit(1);
