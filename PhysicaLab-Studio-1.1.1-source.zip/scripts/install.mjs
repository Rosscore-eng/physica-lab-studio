/**
 * Copia el plugin compilado a un vault:
 *
 *   node scripts/install.mjs <ruta-del-vault>      (por defecto: demo-vault)
 *   node scripts/install.mjs --dist                 (carpeta dist/physica-lab-studio para distribuir)
 *
 * Copia main.js, manifest.json, styles.css, vendor/ y documentación. Nunca toca data.json
 * (los ajustes del usuario) ni ningún otro archivo del vault.
 */
import { copyFileSync, cpSync, existsSync, mkdirSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const arg = process.argv[2];
const target = arg === '--dist' ? join(root, 'dist', 'physica-lab-studio') : join(resolve(arg ?? join(root, 'demo-vault')), '.obsidian', 'plugins', 'physica-lab-studio');

if (arg && arg !== '--dist' && !existsSync(join(resolve(arg), '.obsidian'))) {
	console.error(`No parece un vault de Obsidian (falta .obsidian): ${resolve(arg)}`);
	process.exit(1);
}
for (const f of ['main.js', 'manifest.json', 'styles.css']) {
	if (!existsSync(join(root, f))) {
		console.error(`Falta ${f}: ejecuta antes «npm run build».`);
		process.exit(1);
	}
}

mkdirSync(target, { recursive: true });
const copied = [];
for (const f of ['main.js', 'manifest.json', 'styles.css']) {
	copyFileSync(join(root, f), join(target, f));
	copied.push(f);
}
if (!existsSync(join(root, 'vendor', 'three.js'))) throw new Error('Faltan bundles locales: ejecuta npm run vendor.');
cpSync(join(root, 'vendor'), join(target, 'vendor'), { recursive: true });
copied.push('vendor/ (KaTeX, Three.js, OrbitControls, fuentes y licencias)');
for (const file of ['README.md','SKILL.md','RUNTIME_ARCHITECTURE.md','3D_RUNTIME_CONTRACT.md','LICENSE']) {
 if (existsSync(join(root,file))) { copyFileSync(join(root,file),join(target,file)); copied.push(file); }
}
mkdirSync(join(target, 'docs'), { recursive: true });
for (const file of ['crear-laboratorios.md', 'VALIDACION-RUNTIME.md', 'AMPLIAR-1.1.1.md', 'INSTALACION-WINDOWS.md', 'INSTALACION-ANDROID.md']) {
 copyFileSync(join(root, 'docs', file), join(target, 'docs', file));
}
mkdirSync(join(target, 'demo-vault', 'PhysicaLab', 'labs'), { recursive: true });
for (const file of ['riemann-x2.html', 'thevenin-norton.html', 'bridge-rectifier.html', 'sine-surface-3d.html', 'sistema-tres-masas-resortes.html']) {
 copyFileSync(join(root, 'demo-vault', 'PhysicaLab', 'labs', file), join(target, 'demo-vault', 'PhysicaLab', 'labs', file));
}
copyFileSync(join(root, 'demo-vault', 'PhysicaLab Runtime V1.md'), join(target, 'demo-vault', 'PhysicaLab Runtime V1.md'));
copied.push('docs/ y ejemplos HTML de demo-vault/');
console.log(`PhysicaLab Studio → ${target}\n  ${copied.join('\n  ')}`);
