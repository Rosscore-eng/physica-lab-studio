/**
 * Banco de pruebas visual: monta laboratorios fuera de Obsidian con el
 * mismo núcleo y KaTeX como motor matemático. Lo usa run-visual.mjs.
 *
 * URL: harness.html?labs=math.secant-tangent,physics.pendulum&theme=scientific-dark&width=720
 * Cada laboratorio puede llevar parámetros: labs=physics.pendulum{theta0:30,L:1.2}
 */
import katex from 'katex';
import { LabInstance, liveInstances } from '../../src/core/lab-host';
import { ResourceScope } from '../../src/core/lifecycle';
import { normalizeLabObject } from '../../src/core/schema';
import { CachedMathEngine, type MathEngine } from '../../src/render/math/math-renderer';
import { createBuiltinRegistry } from '../../src/presets/index';
import { isThemeId } from '../../src/theme/tokens';

class KatexEngine implements MathEngine {
	readonly kind = 'katex';
	render(tex: string, display: boolean): HTMLElement {
		const el = document.createElement(display ? 'div' : 'span');
		katex.render(tex, el, { throwOnError: false, displayMode: display, output: 'html' });
		return el;
	}
	finish(): void {}
}

const registry = createBuiltinRegistry();
const engine = new CachedMathEngine(new KatexEngine());
const qs = new URLSearchParams(location.search);
const theme = qs.get('theme');
const width = Number(qs.get('width') ?? '720');
const host = document.getElementById('note') as HTMLElement;
host.style.maxWidth = `${width}px`;
if (theme === 'scientific-light') document.body.classList.add('light');

function parseSpec(spec: string): { preset: string; params: Record<string, number | boolean | string> } {
	const m = /^([a-z0-9.-]+)(?:\{(.*)\})?$/.exec(spec.trim());
	if (!m) throw new Error(`spec inválido: ${spec}`);
	const params: Record<string, number | boolean | string> = {};
	if (m[2]) {
		for (const kv of m[2].split(';')) {
			const [k, v] = kv.split(':');
			if (!k || v === undefined) continue;
			params[k] = v === 'true' ? true : v === 'false' ? false : Number.isFinite(Number(v)) ? Number(v) : v;
		}
	}
	return { preset: m[1] as string, params };
}

const labs: LabInstance[] = [];
const specs = (qs.get('labs') || registry.ids().join(',')).split(',').filter(Boolean);
for (const [i, s] of specs.entries()) {
	const { preset, params } = parseSpec(s);
	const def = registry.get(preset);
	const wrap = document.createElement('div');
	wrap.className = 'lab-wrap';
	host.appendChild(wrap);
	if (!def) {
		wrap.textContent = `Preset desconocido: ${preset}`;
		continue;
	}
	const parsed = normalizeLabObject({ id: `test-${i}`, preset, parameters: params, theme: isThemeId(theme) ? theme : undefined });
	if (!parsed.config) {
		wrap.textContent = parsed.errors.join('\n');
		continue;
	}
	labs.push(
		new LabInstance(wrap, {
			preset: def,
			config: parsed.config,
			engine,
			services: {
				notify: (m) => console.log('[notify]', m),
				save: async (lab) => lab.markSaved(new Date().toISOString()),
				copy: async () => {},
				expand: () => {},
			},
			mathThrottleMs: 0,
		}),
	);
}

declare global {
	interface Window {
		physlab: {
			labs: LabInstance[];
			live: () => number;
			instances: () => number;
			destroyAll: () => void;
			flush: () => void;
			values: (i: number) => Record<string, unknown>;
			set: (i: number, id: string, v: number | boolean | string) => void;
			ready: boolean;
		};
	}
}

window.physlab = {
	labs,
	live: () => ResourceScope.live,
	instances: () => liveInstances.size,
	destroyAll: () => {
		for (const l of labs) l.destroy();
	},
	flush: () => {
		for (const l of labs) l.flush();
	},
	values: (i) => ({ ...(labs[i]?.store.all() ?? {}) }),
	set: (i, id, v) => {
		labs[i]?.store.set(id, v, 'api');
		labs[i]?.flush();
	},
	ready: true,
};
