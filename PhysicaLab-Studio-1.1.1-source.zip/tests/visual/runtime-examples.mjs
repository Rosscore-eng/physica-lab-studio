/** Browser acceptance for actual standalone HTML labs inside the actual runtime. */
import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { existsSync, mkdirSync, mkdtempSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { build } from 'esbuild';
import { chromium } from 'playwright-core';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '../..');
const out = join(root, 'tests/visual/output/runtime');
mkdirSync(out, { recursive: true });
const executablePath = ['C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe', 'C:/Program Files/Microsoft/Edge/Application/msedge.exe', 'C:/Program Files/Google/Chrome/Application/chrome.exe'].find(existsSync);
assert(executablePath, 'Installed Chromium browser required.');
const runtime = await build({ stdin: { contents: 'import {RuntimeFrame} from "./src/runtime/frame";import {THEMES} from "./src/theme/tokens";window.exampleHarness={RuntimeFrame,THEMES};', resolveDir: root, loader: 'ts' }, bundle: true, write: false, platform: 'browser', format: 'iife', target: 'es2021' });
const bundleText = Object.fromEntries(['katex.js', 'katex.css', 'three.js'].map(file => [file, readFileSync(join(root, 'vendor', file), 'utf8')]));
const server = createServer((req, res) => {
	if (req.url === '/runtime.js') { res.setHeader('Content-Type', 'application/javascript'); res.end(runtime.outputFiles[0].text); }
	else { res.setHeader('Content-Type', 'text/html'); res.end('<!doctype html><meta name="viewport" content="width=device-width,initial-scale=1"><style>body{margin:0}#host{width:100%}</style><div id="host"></div><script src="/runtime.js"></script>'); }
});
await new Promise(accept => server.listen(0, '127.0.0.1', accept));
const origin = `http://127.0.0.1:${server.address().port}`;
const report = { browser: executablePath, scope: 'Installed desktop browser, actual runtime iframe; mobile is 390px touch emulation, not physical Android or Obsidian Electron.', checks: [], errors: [], screenshots: [], acceptancePassed: false };
let browser;
const profile = mkdtempSync(join(out, 'browser-profile-'));
function check(label, condition, detail) { report.checks.push({ label, ok: Boolean(condition), ...(detail === undefined ? {} : { detail }) }); assert(condition, label + (detail === undefined ? '' : `: ${JSON.stringify(detail)}`)); }
const examples = [
	{ name: 'riemann-x2', marker: '#graph', initial: { n: 7, method: 'left', probeX: 1 }, range: '#n', key: 'n', value: 12, point: '#probe-dot', drag: [70, 0], dragKey: 'probeX' },
	{ name: 'thevenin-norton', marker: '#load-plot', initial: { vs: 12, r1: 1000, r2: 2000, rl: 1000 }, range: '#vs', key: 'vs', value: 18, point: '#load-point', drag: [60, 0], dragKey: 'rl' },
	{ name: 'bridge-rectifier', marker: '#waveform', initial: { peak: 10, frequency: 50, vf: .7, resistance: 1000, capacitance: 0, phase: .25 }, range: '#peak', key: 'peak', value: 14, point: '#time-point', drag: [65, 0], dragKey: 'phase' },
	{ name: 'sine-surface-3d', marker: '#surface', initial: { a: 1 }, range: '#amplitude', key: 'a', value: 1.5, point: '#handle-guide', drag: [0, -55], dragKey: 'a', three: true },
];
async function findLab(page, marker, previousFrame) {
	for (let tries = 0; tries < 80; tries++) {
		for (const frame of page.frames()) {
			try { if (frame !== previousFrame && await frame.locator(marker).count()) return frame; }
			catch (error) { if (!/detached/i.test(String(error))) throw error; }
		}
		await page.waitForTimeout(50);
	}
	throw new Error('No laboratory frame was initialized.');
}
async function range(frame, selector, value) { await frame.locator(selector).evaluate((element, v) => { element.value = String(v); element.dispatchEvent(new Event('input', { bubbles: true })); }, value); }
async function drag(page, from, to, touch) {
	if (!touch) { await page.mouse.move(from.x, from.y); await page.mouse.down(); await page.mouse.move(to.x, to.y, { steps: 12 }); await page.mouse.up(); return; }
	const cdp = await page.context().newCDPSession(page);
	const points = p => [{ x: p.x, y: p.y, id: 1, radiusX: 4, radiusY: 4, force: 1 }];
	await cdp.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: points(from) });
	for (let i = 1; i <= 12; i++) await cdp.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: points({ x: from.x + (to.x - from.x) * i / 12, y: from.y + (to.y - from.y) * i / 12 }) });
	await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
	await cdp.detach();
}
async function inspect(example, theme, mobile = false, noWebGL = false) {
	const label = `${example.name}/${theme}/${mobile ? '390px-touch' : 'desktop'}${noWebGL ? '/no-webgl' : ''}`;
	const context = await browser.newContext({ viewport: { width: mobile ? 390 : 1080, height: mobile ? 1000 : 950 }, deviceScaleFactor: 1, hasTouch: mobile, isMobile: mobile });
	if (noWebGL) await context.addInitScript(() => {
		const original = HTMLCanvasElement.prototype.getContext;
		HTMLCanvasElement.prototype.getContext = function(...args) { if (['webgl2', 'webgl', 'experimental-webgl'].includes(args[0])) return null; return original.apply(this, args); };
	});
	const page = await context.newPage();
	const errors = [];
	page.on('pageerror', error => errors.push(String(error)));
	page.on('console', message => { if (message.type() === 'error') errors.push(message.text()); });
	page.on('request', request => { if (/^https?:/.test(request.url()) && !request.url().startsWith(origin)) errors.push('External request: ' + request.url()); });
	await page.goto(origin);
	const html = readFileSync(join(root, 'demo-vault/PhysicaLab/labs', example.name + '.html'), 'utf8');
	await page.evaluate(({ html, name, initial, theme, three, bundleText }) => {
		window.saved = null; window.labErrors = [];
		const manifest = { version: 1, id: name, height: 1500, features: three ? ['2d', '3d', 'latex'] : ['2d', 'latex'], initialState: initial };
		window.lab = new window.exampleHarness.RuntimeFrame(document.querySelector('#host'), { html, manifest, initialState: initial, bundles: { katexJs: bundleText['katex.js'], katexCss: bundleText['katex.css'], ...(three ? { threeJs: bundleText['three.js'] } : {}) }, appearance: { tokens: window.exampleHarness.THEMES[theme], fontFamily: '"Latin Modern Roman", "KaTeX_Main", serif' }, onState: data => { window.saved = data; }, onError: message => window.labErrors.push(message) });
	}, { html, name: example.name, initial: example.initial, theme, three: example.three, bundleText });
	const frame = await findLab(page, example.marker);
	await page.waitForFunction(() => window.saved !== null);
	await frame.evaluate(async () => { await document.fonts.ready; });
	check(`${label}: state initialized from manifest`, JSON.stringify(await page.evaluate(() => window.lab.snapshot())) === JSON.stringify(example.initial));
	const layout = await frame.evaluate(() => ({ overflow: document.documentElement.scrollWidth - window.innerWidth, katex: document.querySelectorAll('.katex').length, mathError: Boolean(document.querySelector('.katex-error')), family: getComputedStyle(document.body).fontFamily, latin: [...document.fonts].some(font => font.family.includes('Latin Modern Roman') && font.status === 'loaded'), source: document.querySelector('#tex-source').textContent }));
	check(`${label}: no horizontal overflow`, layout.overflow <= 1, layout.overflow);
	check(`${label}: real offline KaTeX and Latin Modern`, layout.katex >= 2 && !layout.mathError && layout.latin && layout.family.includes('Latin Modern Roman'), layout);
	check(`${label}: literal LaTeX available`, layout.source.includes('\\'));
	await range(frame, example.range, example.value);
	await page.waitForFunction(({ key, value }) => Math.abs(window.lab.snapshot()[key] - value) < .001, { key: example.key, value: example.value });
	check(`${label}: control updates persisted scientific state`, true);
	if (example.three && noWebGL) {
		check(`${label}: WebGL fallback keeps table and 2D model`, await frame.locator('#z-plus').textContent() === '1.500' && (await frame.locator('#webgl-status').textContent()).includes('no ofrece WebGL2') && await frame.locator('#cut').isVisible());
	} else if (example.three) {
		await frame.waitForFunction(() => document.querySelector('#webgl-status').textContent.startsWith('WebGL2'));
		await frame.evaluate(() => { window.drawCalls = 0; const original = WebGL2RenderingContext.prototype.drawElements; WebGL2RenderingContext.prototype.drawElements = function(...args) { window.drawCalls++; return original.apply(this, args); }; });
		await page.waitForTimeout(100); const idle = await frame.evaluate(() => window.drawCalls);
		await page.waitForTimeout(100); check(`${label}: static scene renders on demand`, await frame.evaluate(() => window.drawCalls) === idle);
		await frame.locator('#surface').scrollIntoViewIfNeeded();
		const canvas = await frame.locator('#surface').boundingBox();
		const before = await page.evaluate(() => window.lab.snapshot().a);
		await drag(page, { x: canvas.x + 35, y: canvas.y + 35 }, { x: canvas.x + 100, y: canvas.y + 70 }, mobile);
		await page.waitForTimeout(100);
		check(`${label}: orbit changes no scientific parameter`, (await page.evaluate(() => window.lab.snapshot().a)) === before);
		check(`${label}: camera interaction draws scene`, (await frame.evaluate(() => window.drawCalls)) > idle);
		await page.evaluate(() => window.lab.setPaused(true)); await page.waitForTimeout(60);
		const paused = await frame.evaluate(() => window.drawCalls);
		await range(frame, '#amplitude', 1.25); await page.waitForTimeout(70);
		check(`${label}: host pause stops rendering`, await frame.evaluate(() => window.drawCalls) === paused);
		await page.evaluate(() => window.lab.setPaused(false)); await page.waitForTimeout(70);
		check(`${label}: host resume renders pending model`, await frame.evaluate(() => window.drawCalls) > paused);
	}
	const directPoint = noWebGL ? '#cut-point' : example.point;
	await frame.locator(directPoint).scrollIntoViewIfNeeded();
	await page.waitForTimeout(80);
	const box = await frame.locator(directPoint).boundingBox(); assert(box, 'Visible direct manipulation point');
	const beforeDrag = await page.evaluate(key => window.lab.snapshot()[key], example.dragKey);
	await drag(page, { x: box.x + box.width / 2, y: box.y + box.height / 2 }, { x: box.x + box.width / 2 + example.drag[0], y: box.y + box.height / 2 + example.drag[1] }, mobile);
	await page.waitForTimeout(100);
	const afterDrag = await page.evaluate(key => window.lab.snapshot()[key], example.dragKey);
	check(`${label}: direct ${mobile ? 'touch' : 'pointer'} drag changes model`, Math.abs(beforeDrag - afterDrag) > .01, { beforeDrag, afterDrag });
	await frame.locator('#reset').click(); await page.waitForTimeout(70);
	check(`${label}: example reset uses manifest initial state`, JSON.stringify(await page.evaluate(() => window.lab.snapshot())) === JSON.stringify(example.initial));
	await range(frame, example.range, example.value); await page.waitForTimeout(50);
	await page.evaluate(() => window.lab.reset());
	await page.waitForTimeout(150);
	const resetFrame = await findLab(page, example.marker, frame);
	await resetFrame.waitForFunction(() => document.querySelector('#tex-source')?.textContent.includes('\\'));
	await resetFrame.evaluate(async () => { await document.fonts.ready; });
	check(`${label}: host reset recreates initial state`, JSON.stringify(await page.evaluate(() => window.lab.snapshot())) === JSON.stringify(example.initial));
	const shot = !noWebGL && ((!mobile && example.name === 'riemann-x2' && theme === 'scientific-dark') || (example.name === 'bridge-rectifier' && theme === 'scientific-light') || (example.three && theme === 'scientific-dark'));
	if (shot) {
		const contentHeight = await resetFrame.evaluate(() => Math.ceil(document.querySelector('main').getBoundingClientRect().height + 40));
		await page.evaluate(height => { window.lab.iframe.style.height = `${height}px`; }, contentHeight);
		await page.waitForTimeout(100); await page.evaluate(() => window.scrollTo(0, 0));
		const file = `${example.name}-${theme}-${mobile ? '390' : 'desktop'}.png`;
		await page.screenshot({ path: join(out, file), fullPage: true }); report.screenshots.push(file);
	}
	check(`${label}: no runtime, page or external network errors`, !errors.length && !(await page.evaluate(() => window.labErrors.length)), { console: errors, bridge: await page.evaluate(() => window.labErrors) });
	await page.evaluate(() => window.lab.destroy());
	check(`${label}: iframe removed on destroy`, await page.locator('iframe').count() === 0);
	await context.close(); console.log(`PASS ${label}`);
}
try {
	const baseContext = await chromium.launchPersistentContext(profile, { executablePath, headless: true, args: ['--enable-webgl', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
	browser = baseContext.browser();
	for (const theme of ['scientific-dark', 'scientific-light']) for (const example of examples) await inspect(example, theme);
	for (const example of examples) await inspect(example, 'scientific-dark', true);
	await inspect(examples[3], 'scientific-light', true, true);
	report.acceptancePassed = true;
} catch (error) { report.errors.push(String(error.stack || error)); console.error(error); process.exitCode = 1; }
finally { await browser?.close(); await new Promise(accept => server.close(accept)); writeFileSync(join(out, 'report.json'), JSON.stringify(report, null, 2)); }
