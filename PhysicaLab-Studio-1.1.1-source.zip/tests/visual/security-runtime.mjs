/** Real-browser sandbox/bridge checks. No Obsidian installation or example labs required. */
import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { existsSync, mkdirSync, mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { build } from 'esbuild';
import { chromium } from 'playwright-core';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '../..');
const output = resolve(root, 'tests/visual/output/security-runtime.json');
mkdirSync(dirname(output), { recursive: true });
const profile = mkdtempSync(resolve(dirname(output), 'security-profile-'));
const browserPath = [
	'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',
	'C:/Program Files/Microsoft/Edge/Application/msedge.exe',
	'C:/Program Files/Google/Chrome/Application/chrome.exe',
].find(path => existsSync(path));
if (!browserPath) throw new Error('No installed Edge/Chrome executable was found.');

const bundled = await build({
	stdin: {
		contents: 'import { RuntimeFrame } from "./src/runtime/frame"; import { buildFrameDocument } from "./src/runtime/document"; window.runtimeTest={RuntimeFrame,buildFrameDocument};',
		resolveDir: root, loader: 'ts',
	}, bundle: true, write: false, format: 'iife', platform: 'browser', target: 'es2021',
});
const requests = [];
const server = createServer((request, response) => {
	const url = new URL(request.url ?? '/', 'http://localhost');
	if (url.pathname === '/') {
		response.setHeader('Content-Type', 'text/html');
		response.end('<!doctype html><html><head><title>Runtime security harness</title></head><body><h1>Runtime security harness</h1><div id="host"></div><script src="/harness.js"></script></body></html>');
	} else if (url.pathname === '/harness.js') {
		response.setHeader('Content-Type', 'application/javascript');
		response.end(bundled.outputFiles[0].text);
	} else {
		requests.push({ path: url.pathname, query: url.search, requiredCsp: request.headers['sec-required-csp'] ?? null });
		response.setHeader('Content-Type', 'text/html');
		response.end('<!doctype html><title>External endpoint</title><p id="remote">External request reached the server.</p>');
	}
});
await new Promise((accept, reject) => { server.once('error', reject); server.listen(0, '127.0.0.1', accept); });
const address = server.address();
assert(address && typeof address === 'object');
const origin = `http://127.0.0.1:${address.port}`;
const report = { browser: browserPath, scope: 'Headless installed desktop browser; not Electron/Obsidian or a physical Android device.', checks: [], limitations: [], requests, consoleErrors: [], acceptancePassed: false };
let browser;
function check(name, ok, details) {
	report.checks.push({ name, ok: Boolean(ok), ...(details === undefined ? {} : { details }) });
	console.log(`${ok ? 'PASS' : 'FAIL'} ${name}`);
}
async function findLabFrame(page) {
	for (const frame of page.frames()) {
		if (await frame.evaluate(() => typeof window.PhysLab !== 'undefined').catch(() => false)) return frame;
	}
	throw new Error('No inner sandbox with PhysLab was found.');
}

try {
	browser = await chromium.launchPersistentContext(profile, { executablePath: browserPath, headless: true, viewport: { width: 1100, height: 900 } });
	const page = await browser.newPage();
	page.on('console', message => { if (message.type() === 'error') report.consoleErrors.push(message.text()); });
	page.on('pageerror', error => report.consoleErrors.push(String(error)));
	await page.goto(origin);
	await page.waitForFunction(() => window.runtimeTest);
	const attackHtml = `</head><meta http-equiv="Content-Security-Policy" content="default-src * data: blob: 'unsafe-inline' 'unsafe-eval'"><head><base href="${origin}/blocked/"><link rel="stylesheet" href="${origin}/blocked/style"></head><body>
<img id="remote-image" src="${origin}/blocked/image"><script src="${origin}/blocked/script"></script>
<script>
window.initialN=PhysLab.initialState.n;
window.pauses=0;window.resumes=0;window.violations=[];
PhysLab.on('pause',()=>window.pauses++);PhysLab.on('resume',()=>window.resumes++);
addEventListener('securitypolicyviolation',e=>window.violations.push({directive:e.effectiveDirective,uri:e.blockedURI}));
let parentDenied=false,nodeAbsent=false,evalDenied=false;
try { void parent.document.body; } catch(e) { parentDenied=e.name==='SecurityError'; }
try { nodeAbsent=typeof require==='undefined'&&typeof process==='undefined'&&typeof module==='undefined'; } catch(e) { nodeAbsent=true; }
try { eval('window.unsafeEvaluated=true'); } catch(e) { evalDenied=true; }
window.probe={parentDenied,nodeAbsent,evalDenied};
fetch('${origin}/blocked/fetch').then(()=>window.fetchRejected=false).catch(()=>window.fetchRejected=true);
PhysLab.saveState({n:PhysLab.initialState.n});
</script></body>`;
	await page.evaluate(({ html }) => {
		window.states = []; window.errors = []; window.envelopes = [];
		window.addEventListener('message', event => { if (event.data?.ns === 'physlab') window.envelopes.push(event.data); });
		window.runtime = new window.runtimeTest.RuntimeFrame(document.getElementById('host'), {
			html, manifest: { version: 1, id: 'security-lab', height: 520, features: ['2d'], initialState: { n: 4 } },
			initialState: { n: 7 }, bundles: {}, onState: state => window.states.push(state), onError: error => window.errors.push(error),
		});
	}, { html: attackHtml });
	await page.waitForFunction(() => window.states.length > 0 && window.envelopes.some(message => message.type === 'READY'));
	let lab = await findLabFrame(page);
	await lab.waitForFunction(() => window.fetchRejected === true);
	const isolation = await lab.evaluate(() => ({ ...window.probe, initialN: window.initialN, origin: location.origin, fetchRejected: window.fetchRejected, violations: window.violations, firstHeadElement: document.head.firstElementChild.outerHTML }));
	check('Parent DOM access raises SecurityError', isolation.parentDenied);
	check('Node globals are absent inside sandbox', isolation.nodeAbsent);
	check('unsafe-eval is rejected', isolation.evalDenied);
	check('Sandbox has opaque null origin', isolation.origin === 'null');
	check('Initial restored parameters are available synchronously', isolation.initialN === 7);
	check('Host policy remains first after injected closing-head tags', isolation.firstHeadElement.includes('Content-Security-Policy') && isolation.firstHeadElement.includes("connect-src 'none'"));
	await page.waitForTimeout(250);
	check('Fetch, external image, stylesheet, base URI and script produce no HTTP hits', !requests.some(item => item.path.startsWith('/blocked/')), { violations: isolation.violations, blockedRequests: requests.filter(item => item.path.startsWith('/blocked/')) });
	check('State saved by the authentic child reaches host', await page.evaluate(() => window.runtime.snapshot().n === 7));
	for (const text of ['x'.repeat(32740), '界'.repeat(10910)]) {
		await lab.evaluate(text => PhysLab.saveState({ text }), text);
		await page.waitForFunction(text => window.runtime.snapshot().text === text, text);
	}
	check('Near-32KiB ASCII and Unicode state crosses both bridges without envelope truncation', true);
	await lab.evaluate(() => PhysLab.saveState({ n: 7 }));
	await page.waitForFunction(() => window.runtime.snapshot().n === 7);
	const directSpoofRejected = await lab.evaluate(message => {
		top.postMessage({ ...message, type: 'STATE_SAVE', payload: { n: 555 } }, '*');
		return true;
	}, await page.evaluate(() => window.envelopes.find(message => message.type === 'READY')));
	await page.waitForTimeout(50);
	check('Untrusted inner cannot bypass shell by posting directly to top', directSpoofRejected && await page.evaluate(() => window.runtime.snapshot().n === 7));

	const bridge = await page.evaluate(() => {
		const frame = window.runtime.iframe;
		const authentic = window.envelopes.find(message => message.type === 'READY');
		const before = window.states.length;
		const dispatch = (patch = {}, source = frame.contentWindow) => window.dispatchEvent(new MessageEvent('message', { source, data: { ...authentic, type: 'STATE_SAVE', payload: { n: 99 }, ...patch } }));
		dispatch({}, window);
		dispatch({ frameId: 'forged' }); dispatch({ nonce: 'forged' }); dispatch({ v: 2 }); dispatch({ ns: 'other' });
		for (const payload of [[], { n: Infinity }, { n: undefined }, { n: new Date() }, { text: 'x'.repeat(32768) }, { text: '界'.repeat(12000) }, JSON.parse('{"__proto__":{"x":1}}')]) dispatch({ payload });
		dispatch({ unexpected: 'x'.repeat(40000) });
		dispatch({ type: 'READ_FILE', payload: { file: 'private.md' } });
		const rejected = window.states.length === before && window.runtime.snapshot().n === 7;
		dispatch({ payload: { n: 8 } });
		const accepted = window.states.length === before + 1 && window.runtime.snapshot().n === 8;
		const copy = window.runtime.snapshot(); copy.n = 500;
		return { rejected, accepted, snapshotCopied: window.runtime.snapshot().n === 8 };
	});
	check('Forged source/id/nonce/version/type and malformed/oversized JSON are rejected', bridge.rejected);
	check('Authenticated valid state is accepted and snapshots are copies', bridge.accepted && bridge.snapshotCopied);
	await page.evaluate(() => window.runtime.setPaused(true));
	await lab.waitForFunction(() => window.pauses === 1);
	await page.evaluate(() => window.runtime.setPaused(false));
	await lab.waitForFunction(() => window.resumes === 1);
	check('Pause and resume reach the real sandbox lifecycle listeners', true);

	await page.evaluate(() => { window.oldEnvelope = window.envelopes.find(message => message.type === 'READY'); window.readyBeforeReset = window.envelopes.filter(message => message.type === 'READY').length; window.runtime.reset(); });
	await page.waitForFunction(() => window.runtime.snapshot().n === 4 && window.states.at(-1)?.n === 4 && window.envelopes.filter(message => message.type === 'READY').length > window.readyBeforeReset);
	lab = await findLabFrame(page);
	await lab.waitForFunction(() => window.initialN === 4);
	const reset = await page.evaluate(() => {
		const before = window.states.length;
		window.dispatchEvent(new MessageEvent('message', { source: window.runtime.iframe.contentWindow, data: { ...window.oldEnvelope, type: 'STATE_SAVE', payload: { n: 77 } } }));
		return { defaultsRestored: window.runtime.snapshot().n === 4, staleNonceRejected: window.states.length === before };
	});
	check('Reset reloads manifest defaults and rotates the nonce', reset.defaultsRestored && reset.staleNonceRejected);
	const teardown = await page.evaluate(() => {
		const frameWindow = window.runtime.iframe.contentWindow;
		const ready = window.envelopes.filter(message => message.type === 'READY').at(-1);
		window.runtime.destroy(); window.runtime.destroy();
		const before = window.states.length;
		window.dispatchEvent(new MessageEvent('message', { source: frameWindow, data: { ...ready, type: 'STATE_SAVE', payload: { n: 60 } } }));
		return { removed: document.querySelectorAll('#host iframe').length === 0, noStateCallback: window.states.length === before, state: window.runtime.snapshot() };
	});
	check('Destroy is idempotent, removes iframe and stops message handling', teardown.removed && teardown.noStateCallback && teardown.state.n === 4);

	// Measure actual HTTP hits for self-navigation through the production trusted shell.
	await page.evaluate(({ origin }) => {
		window.runtimeNavigation = new window.runtimeTest.RuntimeFrame(document.getElementById('host'), { html: `<script>PhysLab.saveState({started:true});setTimeout(()=>location.href=${JSON.stringify(origin + '/navigation?probe=untrusted-frame')},50);</script>`, manifest: { version: 1, id: 'navigation', height: 300, features: [], initialState: {} }, initialState: {}, bundles: {}, onState: state => window.navigationStarted=state.started });
	}, { origin });
	await page.waitForFunction(() => window.navigationStarted);
	await page.waitForTimeout(750);
	const navigationRequests = requests.filter(item => item.path === '/navigation');
	const arbitraryNetworkDenied = navigationRequests.length === 0;
	check('Self-navigation makes no external HTTP request', arbitraryNetworkDenied, navigationRequests);
	if (!arbitraryNetworkDenied) report.limitations.push('Self-navigation escaped the trusted shell embedding policy; strong no-network acceptance failed.');
	await page.evaluate(() => window.runtimeNavigation.destroy());
	report.limitations.push('The raw buildFrameDocument result is the innermost lab document. Only RuntimeFrame adds the trusted outer embedding policy required to block self-navigation. Tests exercise that production shell; they do not prove resistance to every browser defect, CPU/GPU denial of service, Electron or Android differences.');
	report.acceptancePassed = report.checks.every(item => item.ok);
} catch (error) {
	report.error = error instanceof Error ? error.stack : String(error);
	process.exitCode = 1;
} finally {
	await browser?.close();
	await new Promise(accept => server.close(accept));
	mkdirSync(dirname(output), { recursive: true });
	writeFileSync(output, JSON.stringify(report, null, 2));
	if (resolve(profile).startsWith(resolve(dirname(output)) + '\\')) rmSync(profile, { recursive: true, force: true });
	if (!report.acceptancePassed) process.exitCode = 1;
	console.log(`Security report: ${output}`);
}
