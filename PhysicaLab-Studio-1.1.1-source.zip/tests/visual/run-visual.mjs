/**
 * Pruebas de interfaz en un navegador real (Microsoft Edge sin interfaz,
 * mediante playwright-core; no descarga navegadores).
 *
 *   node tests/visual/run-visual.mjs [preset1,preset2,...]
 *
 * Para cada preset: captura en escritorio y en móvil (390 px, táctil),
 * arrastra cada asa con ratón y con el dedo, comprueba que el estado
 * cambia, que no hay desbordamiento horizontal ni errores de consola, y
 * que destruir los laboratorios no deja recursos vivos.
 */
import { chromium } from 'playwright-core';
import { existsSync, mkdirSync, writeFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));
const out = join(here, 'output');
mkdirSync(out, { recursive: true });

const EDGE = [
	'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',
	'C:/Program Files/Microsoft/Edge/Application/msedge.exe',
	'C:/Program Files/Google/Chrome/Application/chrome.exe',
].find((p) => existsSync(p));
if (!EDGE) throw new Error('No se encontró Edge ni Chrome');

const page0 = pathToFileURL(resolve(here, 'harness.html')).href;
const only = process.argv[2]?.split(',').filter(Boolean);
const bundle = (process.env.PHYSLAB_BUNDLE || 'harness').replace(/[^a-z0-9-]/gi, '');
const browser = await chromium.launch({ executablePath: EDGE, headless: true });
const report = { browser: EDGE, results: [] };
let failures = 0;

function check(r, cond, msg) {
	r.checks.push({ ok: !!cond, msg });
	if (!cond) {
		failures++;
		console.log(`  ✗ ${msg}`);
	} else console.log(`  ✓ ${msg}`);
}

async function open(ctxOpts, labs, theme = 'scientific-dark', width = 720) {
	const ctx = await browser.newContext(ctxOpts);
	const page = await ctx.newPage();
	const errors = [];
	page.on('console', (m) => {
		if (m.type() === 'error') errors.push(m.text());
	});
	page.on('pageerror', (e) => errors.push(String(e)));
	await page.goto(`${page0}?labs=${encodeURIComponent(labs)}&theme=${theme}&width=${width}&bundle=${bundle}`);
	await page.waitForFunction(() => window.physlab && window.physlab.ready);
	await page.waitForTimeout(250);
	return { ctx, page, errors };
}

/** Arrastre táctil real (Touch Events vía CDP → Pointer Events con pointerType 'touch'). */
async function touchDrag(page, from, to, steps = 8) {
	const cdp = await page.context().newCDPSession(page);
	const pt = (p) => [{ x: p.x, y: p.y, id: 1, radiusX: 4, radiusY: 4, force: 1 }];
	await cdp.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: pt(from) });
	for (let i = 1; i <= steps; i++) {
		const t = i / steps;
		await cdp.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: pt({ x: from.x + (to.x - from.x) * t, y: from.y + (to.y - from.y) * t }) });
	}
	await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
	await cdp.detach();
}

async function handles(page) {
	return page.$$eval('.physlab .pl-draggable', (els) =>
		els.map((e, i) => {
			const r = e.querySelector('.pl-handle-body')?.getBoundingClientRect() ?? e.getBoundingClientRect();
			const s = e.closest('.pl-stage')?.getBoundingClientRect() ?? r;
			const x = r.left + r.width / 2;
			const y = r.top + r.height / 2;
			// Dirección hacia el centro de su figura: así el arrastre no choca con un límite.
			const cx = s.left + s.width / 2 - x;
			const cy = s.top + s.height / 2 - y;
			const n = Math.hypot(cx, cy) || 1;
			return { i, x, y, dx: (cx / n) * 60, dy: (cy / n) * 60, label: e.getAttribute('aria-label') };
		}),
	);
}

const presetIds = await (async () => {
	const { page, ctx } = await open({ viewport: { width: 900, height: 700 } }, '');
	const ids = await page.evaluate(() => window.physlab.labs.map((l) => l.preset.id));
	await ctx.close();
	return ids;
})();
const targets = only ?? presetIds;

for (const id of targets) {
	console.log(`\n▶ ${id}`);
	const r = { preset: id, checks: [], shots: [] };
	report.results.push(r);

	// Escritorio
	{
		const { ctx, page, errors } = await open({ viewport: { width: 1100, height: 900 }, deviceScaleFactor: 1.5 }, id);
		const shot = join(out, `${id}-desktop.png`);
		await page.locator('.physlab').first().screenshot({ path: shot });
		r.shots.push(shot);
		const count = (await handles(page)).length;
		check(r, count > 0, `escritorio: ${count} asa(s) manipulable(s)`);
		for (let k = 0; k < count; k++) {
			// Releer posiciones: mover un asa puede desplazar otras (p. ej. B depende de A).
			const h = (await handles(page))[k];
			await page.evaluate((y) => window.scrollTo(0, Math.max(0, window.scrollY + y - 400)), h.y);
			await page.waitForTimeout(30);
			Object.assign(h, (await handles(page))[k]);
			const before = await page.evaluate(() => JSON.stringify(window.physlab.values(0)));
			await page.mouse.move(h.x, h.y);
			await page.mouse.down();
			await page.mouse.move(h.x + h.dx * 0.5, h.y + h.dy * 0.5, { steps: 6 });
			await page.mouse.move(h.x + h.dx, h.y + h.dy, { steps: 6 });
			await page.mouse.up();
			await page.waitForTimeout(80);
			const after = await page.evaluate(() => JSON.stringify(window.physlab.values(0)));
			check(r, before !== after, `escritorio: arrastrar «${h.label}» cambia el estado`);
		}
		const shot2 = join(out, `${id}-desktop-after-drag.png`);
		await page.locator('.physlab').first().screenshot({ path: shot2 });
		r.shots.push(shot2);
		const katexErr = await page.$$eval('.physlab .katex-error', (e) => e.map((x) => x.getAttribute('title') || x.textContent));
		check(r, katexErr.length === 0, `LaTeX sin errores de tipografía${katexErr.length ? ': ' + katexErr.join(' | ') : ''}`);
		const mathCount = await page.$$eval('.physlab .katex', (e) => e.length);
		check(r, mathCount > 3, `ecuaciones y etiquetas tipografiadas (${mathCount} expresiones)`);
		check(r, errors.length === 0, `sin errores de consola${errors.length ? ': ' + errors.join(' | ') : ''}`);
		await ctx.close();
	}

	// Móvil táctil estrecho
	{
		const { ctx, page, errors } = await open(
			{ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true },
			id,
			'scientific-dark',
			390,
		);
		const overflow = await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
		check(r, overflow <= 0, `móvil 390 px: sin desbordamiento horizontal (${overflow} px)`);
		const shot = join(out, `${id}-mobile.png`);
		await page.locator('.physlab').first().screenshot({ path: shot });
		r.shots.push(shot);
		const hs = await handles(page);
		if (hs[0]) {
			const h = hs[0];
			await page.evaluate((y) => window.scrollTo(0, Math.max(0, y - 300)), h.y);
			await page.waitForTimeout(50);
			const [h2] = (await handles(page)).filter((x) => x.i === h.i);
			const scrollBefore = await page.evaluate(() => window.scrollY);
			const before = await page.evaluate(() => JSON.stringify(window.physlab.values(0)));
			await touchDrag(page, h2, { x: h2.x + h2.dx * 0.8, y: h2.y + h2.dy * 0.8 });
			await page.waitForTimeout(80);
			const after = await page.evaluate(() => JSON.stringify(window.physlab.values(0)));
			const scrollAfter = await page.evaluate(() => window.scrollY);
			check(r, before !== after, `móvil: arrastre táctil de «${h.label}» cambia el estado`);
			check(r, scrollBefore === scrollAfter, `móvil: la página no se desplaza durante el arrastre (${scrollBefore}→${scrollAfter})`);
		}
		// Zona táctil efectiva: un interruptor cuenta con su etiqueta (fila completa).
		const small = await page.$$eval('.physlab button, .physlab input, .physlab select', (els) =>
			els
				.filter((e) => e.offsetParent !== null)
				.map((e) => (e.matches('input[type=checkbox]') ? (e.closest('.pl-ctl') ?? e) : e).getBoundingClientRect())
				.filter((b) => b.height < 30).length,
		);
		check(r, small === 0, `móvil: controles táctiles de al menos 30 px (${small} más pequeños)`);
		check(r, errors.length === 0, `móvil: sin errores de consola${errors.length ? ': ' + errors.join(' | ') : ''}`);
		await ctx.close();
	}

	// Nota ancha (panel a la derecha, como en un vault sin «ancho de línea legible»)
	{
		const { ctx, page, errors } = await open({ viewport: { width: 1320, height: 900 }, deviceScaleFactor: 1 }, id, 'scientific-dark', 1180);
		const shot = join(out, `${id}-wide.png`);
		await page.locator('.physlab').first().screenshot({ path: shot });
		r.shots.push(shot);
		const gap = await page.evaluate(() => {
			const fig = document.querySelector('.physlab .pl-figures')?.getBoundingClientRect();
			const body = document.querySelector('.physlab .pl-body')?.getBoundingClientRect();
			return fig && body ? Math.round(body.height - fig.height) : -1;
		});
		check(r, gap >= 0 && gap < 140, `nota ancha: sin hueco grande bajo la figura (${gap} px)`);
		check(r, errors.length === 0, `nota ancha: sin errores de consola${errors.length ? ': ' + errors.join(' | ') : ''}`);
		await ctx.close();
	}

	// Tema claro (solo captura)
	{
		const { ctx, page } = await open({ viewport: { width: 1000, height: 900 }, deviceScaleFactor: 1.25 }, id, 'scientific-light');
		const shot = join(out, `${id}-light.png`);
		await page.locator('.physlab').first().screenshot({ path: shot });
		r.shots.push(shot);
		await ctx.close();
	}
}

// Varios laboratorios en una nota + liberación de recursos
{
	console.log('\n▶ varios laboratorios en una nota');
	const r = { preset: 'multi', checks: [], shots: [] };
	report.results.push(r);
	const labs = [...presetIds, ...presetIds].join(',');
	const { ctx, page, errors } = await open({ viewport: { width: 1000, height: 900 } }, labs);
	const n = await page.evaluate(() => window.physlab.instances());
	check(r, n === presetIds.length * 2, `${n} laboratorios montados a la vez`);
	const live = await page.evaluate(() => window.physlab.live());
	await page.evaluate(() => window.physlab.destroyAll());
	await page.waitForTimeout(100);
	const after = await page.evaluate(() => ({ live: window.physlab.live(), n: window.physlab.instances(), dom: document.querySelectorAll('.physlab').length }));
	check(r, after.live === 0 && after.n === 0 && after.dom === 0, `al cerrar: recursos vivos ${live} → ${after.live}, instancias ${after.n}, nodos ${after.dom}`);
	check(r, errors.length === 0, `sin errores de consola${errors.length ? ': ' + errors.join(' | ') : ''}`);
	await ctx.close();
}

await browser.close();
writeFileSync(join(out, 'report.json'), JSON.stringify(report, null, 2));
console.log(`\n${failures === 0 ? 'OK' : `${failures} comprobación(es) fallida(s)`} — capturas en ${out}`);
process.exit(failures === 0 ? 0 : 1);
