/** Real Obsidian smoke test in an independent profile/vault; never uses the personal profile. */
import { chromium } from 'playwright-core';
import { spawn } from 'node:child_process';
import { mkdir, writeFile, copyFile, readFile } from 'node:fs/promises';
import { resolve, join, basename } from 'node:path';
import { setTimeout as delay } from 'node:timers/promises';

const root=resolve('.'),out=join(root,'tests/visual/output'),profile=join(out,'obsidian-profile');
const vault=join(root,'demo-vault'),port=9238;
const obsidianExe=process.env.PHYSLAB_OBSIDIAN_EXE;
if(!obsidianExe)throw new Error('Set PHYSLAB_OBSIDIAN_EXE to the Obsidian executable before running this optional smoke test.');
await mkdir(profile,{recursive:true});
await writeFile(join(profile,'obsidian.json'),JSON.stringify({vaults:{c0de202610240001:{path:vault,ts:Date.now(),open:true}},frame:'hidden'}));
await writeFile(join(profile,'c0de202610240001.json'),JSON.stringify({x:40,y:40,width:1280,height:900,isMaximized:false,devTools:false,zoom:0}));
if(process.env.PHYSLAB_OBSIDIAN_ASAR)await copyFile(process.env.PHYSLAB_OBSIDIAN_ASAR,join(profile,basename(process.env.PHYSLAB_OBSIDIAN_ASAR)));
await writeFile(join(profile,'id'),'c0de202610240001');
await writeFile(join(vault,'.obsidian','app.json'),JSON.stringify({livePreview:true,readableLineLength:false}));
const report={checks:[],errors:[],profile,vault};
const check=(ok,name)=>{report.checks.push({ok:!!ok,name});console.log((ok?'PASS ':'FAIL ')+name);};
let browser,child;
try{
 const busy=await fetch(`http://127.0.0.1:${port}/json/version`).then(()=>true).catch(()=>false);
 if(busy)throw new Error('Test debug port already occupied; refusing to attach an unrelated app.');
 child=spawn(obsidianExe,[`--user-data-dir=${profile}`,`--remote-debugging-port=${port}`,'--remote-allow-origins=http://localhost'],{windowsHide:true,stdio:'ignore'});
 for(let i=0;i<80;i++){const ready=await fetch(`http://127.0.0.1:${port}/json/version`).then(()=>true).catch(()=>false);if(ready)break;await delay(500);}
 browser=await chromium.connectOverCDP(`http://127.0.0.1:${port}`);
 let page;
 for(let i=0;i<40;i++){page=browser.contexts().flatMap(c=>c.pages()).find(p=>p.url().startsWith('app://obsidian.md'));if(page)break;await delay(500);}
 if(!page)throw new Error('No Obsidian renderer page.');
 page.on('pageerror',err=>report.errors.push(String(err)));
 page.on('console',msg=>{if(msg.type()==='error')report.errors.push(msg.text());});
 await page.waitForFunction(()=>window.app?.plugins&&window.app?.workspace?.layoutReady,null,{timeout:45000});
 const appInfo=await page.evaluate(async()=>{
  if(app.plugins.setEnable)await app.plugins.setEnable(true);
  if(app.plugins.loadManifests)await app.plugins.loadManifests();
  if(app.plugins.enablePluginAndSave)await app.plugins.enablePluginAndSave('physica-lab-studio');
  if(!app.plugins.plugins['physica-lab-studio'])await app.plugins.loadPlugin('physica-lab-studio');
  const plugin=app.plugins.plugins['physica-lab-studio'];
  if(!plugin)throw new Error('Plugin did not load; manifests='+JSON.stringify(app.plugins.manifests));
  plugin.settings.lazyLoad=false;
  const file=app.vault.getFileByPath('PhysicaLab Runtime V1.md');
  const leaf=app.workspace.getLeaf(false);await leaf.openFile(file);await leaf.setViewState({type:'markdown',state:{file:file.path,mode:'preview'}});
  return {vault:app.vault.adapter.getBasePath(),version:plugin.manifest.version,commands:Object.keys(app.commands.commands).filter(k=>k.startsWith('physica-lab-studio:'))};
 });
 report.appInfo=appInfo;check(appInfo.vault.replaceAll('\\','/').toLowerCase()===vault.replaceAll('\\','/').toLowerCase(),'independent test vault');
 check(!appInfo.commands.some(id=>id.includes('generate')),'no AI/CLI generator command');
 await page.waitForFunction(()=>document.querySelectorAll('.physlab-runtime iframe').length===4,{timeout:25000}).catch(async err=>{report.mountErrors=await page.locator('.physlab-error').allTextContents();throw err;});
 check(true,'Reading mode renders four original HTML labs in Obsidian');
 const frames=()=>page.frames().filter(f=>f!==page.mainFrame());
 let riemann;
 for(const frame of frames()){if(await frame.locator('#n').count().catch(()=>0)){riemann=frame;break;}}
 if(!riemann)throw new Error('Riemann frame not found');
 check((await riemann.locator('#sum').textContent()).includes('1.750'),'Riemann starts at exact left n=4 result');
 await riemann.locator('#method').selectOption('right');
 check((await riemann.locator('#sum').textContent()).includes('3.750'),'real Obsidian iframe controls recalculate');
 await delay(500);
 const state=await page.evaluate(()=>app.plugins.plugins['physica-lab-studio'].runtimeStates.get('PhysicaLab Runtime V1.md','runtime-riemann-x2'));
 check(state?.method==='right','iframe bridge persists updated state');
 await page.locator('.physlab-runtime').first().screenshot({path:join(out,'obsidian-runtime-reading.png')});
 await page.locator('.pl-runtime-expand').first().click();check(await page.locator('.pl-runtime-expanded').count()===1,'expanded view uses same block');
 await page.keyboard.press('Escape');check(await page.locator('.pl-runtime-expanded').count()===0,'Escape closes expanded view');
 await page.locator('.pl-runtime-source').first().click();
 check(await page.locator('.physlab-source-modal textarea').count()===1,'source opens as editable HTML text');
 await page.keyboard.press('Escape');
 await page.evaluate(async()=>{const leaf=app.workspace.getMostRecentLeaf();await leaf.setViewState({type:'markdown',state:{file:'PhysicaLab Runtime V1.md',mode:'source',source:false}});});
 await page.waitForFunction(()=>document.querySelector('.markdown-source-view.mod-cm6.is-live-preview'),{timeout:10000});
 await page.waitForFunction(()=>document.querySelectorAll('.physlab-runtime iframe').length>=1,{timeout:10000});
 check(true,'Live Preview mounts runtime blocks');
 await page.screenshot({path:join(out,'obsidian-runtime-live-preview.png')});
 await page.evaluate(async()=>{await app.plugins.unloadPlugin('physica-lab-studio');});
 check(await page.locator('.physlab-runtime iframe').count()===0,'plugin unload removes all runtime frames');
}catch(error){report.failure=String(error);console.error(error);}
finally{
 if(browser)await browser.close().catch(()=>{});
 if(child)child.kill();
 await writeFile(join(out,'obsidian-runtime.json'),JSON.stringify(report,null,2));
}
const passed=!report.failure&&report.checks.every(c=>c.ok);
console.log(passed?'Obsidian smoke PASS':'Obsidian smoke FAIL');process.exitCode=passed?0:1;
