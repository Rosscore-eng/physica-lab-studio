/**
 * Sustituto mínimo de la API de Obsidian para las pruebas unitarias.
 * Solo cubre lo que usa la capa de integración.
 */
import { parse, stringify } from 'yaml';

export function parseYaml(s: string): unknown {
	return parse(s);
}

export function stringifyYaml(o: unknown): string {
	return stringify(o);
}

export function normalizePath(p: string): string {
	return p
		.replace(/\\/g, '/')
		.replace(/\/+/g, '/')
		.replace(/^\/|\/$/g, '');
}

export const Platform = {
	isDesktop: true,
	isMobile: false,
	isDesktopApp: true,
	isMobileApp: false,
	isIosApp: false,
	isAndroidApp: false,
	isPhone: false,
	isTablet: false,
	isMacOS: false,
	isWin: true,
	isLinux: false,
	isSafari: false,
};

export class Component {
	private readonly cleanups: Array<() => void> = [];
	private children: Component[] = [];
	private loaded = false;
	load(): void {
		if (this.loaded) return;
		this.loaded = true;
		this.onload();
		for (const c of this.children) c.load();
	}
	unload(): void {
		if (!this.loaded) return;
		this.loaded = false;
		for (const c of this.children) c.unload();
		this.onunload();
		for (const f of this.cleanups.splice(0)) f();
	}
	onload(): void {}
	onunload(): void {}
	addChild<T extends Component>(c: T): T {
		this.children.push(c);
		if (this.loaded) c.load();
		return c;
	}
	register(cb: () => void): void {
		this.cleanups.push(cb);
	}
	registerDomEvent(el: EventTarget, type: string, cb: (ev: Event) => void): void {
		el.addEventListener(type, cb);
		this.register(() => el.removeEventListener(type, cb));
	}
	registerInterval(id: number): number {
		this.register(() => clearInterval(id));
		return id;
	}
}

export class MarkdownRenderChild extends Component {
	constructor(public containerEl: HTMLElement) {
		super();
	}
}

export class Notice {
	static messages: string[] = [];
	constructor(message: string) {
		Notice.messages.push(message);
	}
}

export function renderMath(source: string, display: boolean): HTMLElement {
	const el = document.createElement(display ? 'div' : 'span');
	el.className = 'mock-math';
	el.textContent = source;
	return el;
}

export async function finishRenderMath(): Promise<void> {}
export async function loadMathJax(): Promise<void> {}

/* ── Ayudantes de DOM que Obsidian añade a HTMLElement ─────────────── */

interface DomInfo {
	cls?: string | string[];
	text?: string;
	attr?: Record<string, string>;
	value?: string;
}

function applyInfo(el: HTMLElement, info?: DomInfo | string): void {
	if (!info) return;
	if (typeof info === 'string') {
		el.className = info;
		return;
	}
	if (info.cls) el.className = Array.isArray(info.cls) ? info.cls.join(' ') : info.cls;
	if (info.text !== undefined) el.textContent = info.text;
	if (info.attr) for (const [k, v] of Object.entries(info.attr)) el.setAttribute(k, v);
	if (info.value !== undefined) (el as HTMLInputElement).value = info.value;
}

type Creator = { createEl: (t: string, i?: DomInfo | string) => HTMLElement };
const P = HTMLElement.prototype as unknown as Record<string, unknown>;
if (!P.empty) {
	P.empty = function (this: HTMLElement) {
		this.replaceChildren();
	};
	P.createEl = function (this: HTMLElement, tag: string, info?: DomInfo | string) {
		const el = this.ownerDocument.createElement(tag);
		applyInfo(el, info);
		this.appendChild(el);
		return el;
	};
	P.createDiv = function (this: HTMLElement, info?: DomInfo | string) {
		return (this as unknown as Creator).createEl('div', info);
	};
	P.createSpan = function (this: HTMLElement, info?: DomInfo | string) {
		return (this as unknown as Creator).createEl('span', info);
	};
	P.addClass = function (this: HTMLElement, ...c: string[]) {
		this.classList.add(...c);
	};
	P.removeClass = function (this: HTMLElement, ...c: string[]) {
		this.classList.remove(...c);
	};
	P.setAttr = function (this: HTMLElement, k: string, v: string) {
		this.setAttribute(k, v);
	};
	P.setText = function (this: HTMLElement, t: string) {
		this.textContent = t;
	};
	P.appendText = function (this: HTMLElement, t: string) {
		this.appendChild(this.ownerDocument.createTextNode(t));
	};
}
