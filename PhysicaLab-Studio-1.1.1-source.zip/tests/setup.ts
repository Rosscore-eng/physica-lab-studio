/**
 * Entorno jsdom para las pruebas: PointerEvent, captura de puntero y
 * requestAnimationFrame deterministas.
 */
if (typeof (globalThis as { PointerEvent?: unknown }).PointerEvent === 'undefined') {
	class PointerEventPolyfill extends MouseEvent {
		pointerId: number;
		pointerType: string;
		isPrimary: boolean;
		constructor(type: string, init: PointerEventInit = {}) {
			super(type, init);
			this.pointerId = init.pointerId ?? 1;
			this.pointerType = init.pointerType ?? 'mouse';
			this.isPrimary = init.isPrimary ?? true;
		}
	}
	(globalThis as unknown as { PointerEvent: typeof PointerEventPolyfill }).PointerEvent = PointerEventPolyfill;
}

const proto = Element.prototype as Element & {
	setPointerCapture?: (id: number) => void;
	releasePointerCapture?: (id: number) => void;
	hasPointerCapture?: (id: number) => boolean;
};
if (!proto.setPointerCapture) {
	const captured = new WeakMap<Element, Set<number>>();
	proto.setPointerCapture = function (this: Element, id: number) {
		const s = captured.get(this) ?? new Set<number>();
		s.add(id);
		captured.set(this, s);
	};
	proto.releasePointerCapture = function (this: Element, id: number) {
		captured.get(this)?.delete(id);
	};
	proto.hasPointerCapture = function (this: Element, id: number) {
		return captured.get(this)?.has(id) ?? false;
	};
}

// rAF manual: las pruebas llaman a `flushFrames()` para avanzar.
type FrameCb = (t: number) => void;
let frameId = 0;
const frames = new Map<number, FrameCb>();
let now = 0;
(globalThis as unknown as { requestAnimationFrame: (cb: FrameCb) => number }).requestAnimationFrame = (cb: FrameCb) => {
	frames.set(++frameId, cb);
	return frameId;
};
(globalThis as unknown as { cancelAnimationFrame: (id: number) => void }).cancelAnimationFrame = (id: number) => {
	frames.delete(id);
};
window.requestAnimationFrame = globalThis.requestAnimationFrame;
window.cancelAnimationFrame = globalThis.cancelAnimationFrame;

export function flushFrames(count = 1, dtMs = 16): void {
	for (let i = 0; i < count; i++) {
		now += dtMs;
		const batch = [...frames.entries()];
		frames.clear();
		for (const [, cb] of batch) cb(now);
	}
}

export function pendingFrames(): number {
	return frames.size;
}

(globalThis as unknown as { __physlabTest: unknown }).__physlabTest = { flushFrames, pendingFrames };
