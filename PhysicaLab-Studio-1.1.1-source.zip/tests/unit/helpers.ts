import { LabInstance, type HostServices } from '../../src/core/lab-host';
import { normalizeLabObject } from '../../src/core/schema';
import type { Point } from '../../src/core/types';
import { PlainMathEngine } from '../../src/render/math/math-renderer';
import { createBuiltinRegistry } from '../../src/presets/index';
import { flushFrames } from '../setup';

export const registry = createBuiltinRegistry();

export interface Mounted {
	lab: LabInstance;
	container: HTMLElement;
	cleanup(): void;
}

/** Monta un laboratorio en jsdom con el motor matemático de texto. */
export function mountLab(
	presetId: string,
	parameters: Record<string, number | boolean | string> = {},
	block: Record<string, unknown> = {},
	services: Partial<HostServices> = {},
): Mounted {
	const def = registry.get(presetId);
	if (!def) throw new Error(`preset no registrado: ${presetId}`);
	const parsed = normalizeLabObject({ id: 'test-lab', preset: presetId, parameters, ...block });
	if (!parsed.config) throw new Error(parsed.errors.join('\n'));
	const container = document.createElement('div');
	document.body.appendChild(container);
	const lab = new LabInstance(container, {
		preset: def,
		config: parsed.config,
		engine: new PlainMathEngine(document),
		services: {
			notify: () => {},
			save: async (l) => l.markSaved('2026-10-20T00:00:00Z'),
			...services,
		},
		mathThrottleMs: 0,
	});
	lab.flush();
	return {
		lab,
		container,
		cleanup() {
			lab.destroy();
			container.remove();
		},
	};
}

/**
 * Simula un arrastre con Pointer Events. En jsdom el rectángulo del SVG
 * mide 0, así que las coordenadas de pantalla coinciden con las de escena.
 */
export function drag(el: Element, from: Point, to: Point, steps = 6, pointerType = 'mouse'): void {
	const opts = (p: Point): PointerEventInit => ({
		bubbles: true,
		cancelable: true,
		clientX: p.x,
		clientY: p.y,
		pointerId: 7,
		pointerType,
		button: 0,
		isPrimary: true,
	});
	el.dispatchEvent(new PointerEvent('pointerdown', opts(from)));
	for (let i = 1; i <= steps; i++) {
		const t = i / steps;
		el.dispatchEvent(new PointerEvent('pointermove', opts({ x: from.x + (to.x - from.x) * t, y: from.y + (to.y - from.y) * t })));
	}
	el.dispatchEvent(new PointerEvent('pointerup', opts(to)));
}

/** Centro de un asa a partir de su `transform="translate(x y)"`. */
export function handlePos(g: Element): Point {
	const m = /translate\(([-\d.]+)[ ,]([-\d.]+)\)/.exec(g.getAttribute('transform') ?? '');
	if (!m) throw new Error('asa sin transform');
	return { x: Number(m[1]), y: Number(m[2]) };
}

/** LaTeX actual de una ecuación o lectura. */
export function texOf(root: Element, id: string): string {
	const row = root.querySelector(`[data-eq="${id}"]`);
	const math = row?.querySelector('[data-tex]');
	return math?.getAttribute('data-tex') ?? '';
}

/** Escribe en un input y lanza el evento correspondiente. */
export function setInput(input: HTMLInputElement | HTMLSelectElement, value: string, event: 'input' | 'change' = 'input'): void {
	input.value = value;
	input.dispatchEvent(new Event(event, { bubbles: true }));
}

export function tick(n = 2): void {
	flushFrames(n);
}
