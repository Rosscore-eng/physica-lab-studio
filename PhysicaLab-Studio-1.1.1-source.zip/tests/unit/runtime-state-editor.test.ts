import { afterEach, describe, expect, it, vi } from 'vitest';
import { RuntimeStateStore, runtimeStateKey } from '../../src/runtime/state';
import { findRuntimeBlocks, runtimeCodeBlock, snapshotRuntimeBlock } from '../../src/runtime/editor';

afterEach(() => vi.useRealTimers());

describe('runtime local state', () => {
	it('isolates note/id pairs and clones state across reads and writes', async () => {
		const written: Record<string, Record<string, unknown>>[] = [];
		const store = new RuntimeStateStore({}, async (states) => { written.push(states); });
		const input = { nested: { n: 4 }, samples: [1, 2] };
		store.set('a:b', 'c', input);
		store.set('a', 'b:c', { n: 8 });
		input.nested.n = 99;
		const read = store.get('a:b', 'c')!;
		(read.nested as { n: number }).n = 77;
		expect(store.get('a:b', 'c')).toEqual({ nested: { n: 4 }, samples: [1, 2] });
		expect(store.get('a', 'b:c')).toEqual({ n: 8 });
		expect(runtimeStateKey('a:b', 'c')).toBe('["a:b","c"]');
		await store.flush();
		(written[0]['["a:b","c"]'].nested as { n: number }).n = 55;
		expect(store.get('a:b', 'c')?.nested).toEqual({ n: 4 });
	});

	it('loads only canonical keys containing finite small JSON records', () => {
		const store = new RuntimeStateStore({
			'["note.md","ok"]': { n: 4, list: [null, false, 'x'] },
			'["note.md", "spaces"]': { n: 1 },
			'not-a-key': { n: 1 },
			'["note.md","array"]': [1],
			'["note.md","infinite"]': { n: Infinity },
			'["note.md","large"]': { text: 'a'.repeat(33_000) },
		}, async () => {});
		expect(store.get('note.md', 'ok')).toEqual({ n: 4, list: [null, false, 'x'] });
		for (const id of ['spaces', 'array', 'infinite', 'large']) expect(store.get('note.md', id)).toBeUndefined();
	});

	it.each([
		['NaN', { n: NaN }], ['Infinity', { n: Infinity }], ['undefined', { n: undefined }], ['function', { fn: () => 1 }],
		['Date', { date: new Date() }], ['UTF-8 size', { text: '😀'.repeat(8_192) }],
	] as const)('rejects non-JSON or over-32KiB state without replacing valid state: %s', async (_name, invalid) => {
		const store = new RuntimeStateStore({}, async () => {});
		store.set('note.md', 'id', { n: 4 });
		expect(() => store.set('note.md', 'id', invalid)).toThrow();
		expect(store.get('note.md', 'id')).toEqual({ n: 4 });
		await store.flush();
	});

	it('rejects cyclic and prototype keys without mutating prototypes or saved state', () => {
		const store = new RuntimeStateStore({}, async () => {});
		const cyclic: Record<string, unknown> = {};
		cyclic.self = cyclic;
		expect(() => store.set('note.md', 'cycle', cyclic)).toThrow();
		for (const input of ['{"__proto__":{"polluted":true}}', '{"constructor":3}', '{"nested":{"prototype":1}}']) {
			expect(() => store.set('note.md', 'bad', JSON.parse(input))).toThrow();
			expect(store.get('note.md', 'bad')).toBeUndefined();
		}
		expect(({} as Record<string, unknown>).polluted).toBeUndefined();
	});

	it('rejects state deeper than the frame contract, including corrupt loaded entries', () => {
		let deep: Record<string, unknown> = { n: 1 };
		for (let i = 0; i < 33; i++) deep = { next: deep };
		const store = new RuntimeStateStore({
			'["note.md","deep"]': deep,
			'["note.md","proto"]': JSON.parse('{"__proto__":{"polluted":true}}'),
		}, async () => {});
		expect(store.get('note.md', 'deep')).toBeUndefined();
		expect(store.get('note.md', 'proto')).toBeUndefined();
		expect(() => store.set('note.md', 'deep', deep)).toThrow();
	});

	it('coalesces drag updates and never saves sooner than 300ms', async () => {
		vi.useFakeTimers();
		const written: Record<string, Record<string, unknown>>[] = [];
		const store = new RuntimeStateStore({}, async (states) => { written.push(states); }, 1);
		store.set('note.md', 'id', { n: 1 });
		await vi.advanceTimersByTimeAsync(200);
		store.set('note.md', 'id', { n: 2 });
		await vi.advanceTimersByTimeAsync(299);
		expect(written).toHaveLength(0);
		await vi.advanceTimersByTimeAsync(1);
		expect(written).toEqual([{ '["note.md","id"]': { n: 2 } }]);
	});

	it('serializes saves and drains updates arriving during a pending write', async () => {
		const written: Record<string, Record<string, unknown>>[] = [];
		let release!: () => void;
		let active = 0;
		let maxActive = 0;
		const store = new RuntimeStateStore({}, async (states) => {
			active++;
			maxActive = Math.max(maxActive, active);
			written.push(states);
			if (written.length === 1) await new Promise<void>((resolve) => { release = resolve; });
			active--;
		});
		store.set('note.md', 'id', { n: 1 });
		const pending = store.flush();
		store.set('note.md', 'id', { n: 2 });
		const alsoPending = store.flush();
		expect(written).toHaveLength(1);
		release();
		await Promise.all([pending, alsoPending]);
		expect(maxActive).toBe(1);
		expect(written).toEqual([
			{ '["note.md","id"]': { n: 1 } },
			{ '["note.md","id"]': { n: 2 } },
		]);
	});

	it('retains dirty updates after failure and surfaces explicit flush errors', async () => {
		const written: Record<string, Record<string, unknown>>[] = [];
		let fail = true;
		const store = new RuntimeStateStore({}, async (states) => {
			if (fail) throw new Error('disk unavailable');
			written.push(states);
		});
		store.set('note.md', 'id', { n: 1 });
		await expect(store.flush()).rejects.toThrow('disk unavailable');
		store.set('note.md', 'id', { n: 2 });
		fail = false;
		await store.flush();
		expect(written).toEqual([{ '["note.md","id"]': { n: 2 } }]);
	});

	it('handles background failures without an unhandled rejection and permits retry', async () => {
		vi.useFakeTimers();
		const warning = vi.spyOn(console, 'warn').mockImplementation(() => {});
		let fail = true;
		const written: Record<string, Record<string, unknown>>[] = [];
		const store = new RuntimeStateStore({}, async (states) => {
			if (fail) throw new Error('disk unavailable');
			written.push(states);
		});
		try {
			store.set('note.md', 'id', { n: 1 });
			await vi.advanceTimersByTimeAsync(350);
			fail = false;
			await store.flush();
			expect(written).toEqual([{ '["note.md","id"]': { n: 1 } }]);
		} finally { warning.mockRestore(); }
	});

	it('moves note states and persists reset without leaving old keys', async () => {
		const written: Record<string, Record<string, unknown>>[] = [];
		const store = new RuntimeStateStore({
			'["old.md","one"]': { n: 1 },
			'["old.md","two"]': { n: 2 },
			'["other.md","one"]': { n: 3 },
		}, async (states) => { written.push(states); });
		store.renameNote('old.md', 'folder/new.md');
		expect(store.get('old.md', 'one')).toBeUndefined();
		expect(store.get('folder/new.md', 'two')).toEqual({ n: 2 });
		store.reset('folder/new.md', 'one');
		await store.flush();
		expect(written).toEqual([{
			'["folder/new.md","two"]': { n: 2 },
			'["other.md","one"]': { n: 3 },
		}]);
	});
});

const external = '{"version":1,"id":"target","file":"labs/test.html","initialState":{"n":4}}';
const inline = '<!-- physlab:v1 {"id":"inline","initialState":{"n":2}} -->';

describe('runtime Markdown editing', () => {
	it('scans arbitrary matching fences and CRLF without parsing fences inside other code', () => {
		const md = 'Intro\r\n~~~~markdown\r\n```physlab\r\n' + external + '\r\n```\r\n~~~~\r\n'
			+ '  `````physlab\r\n' + external + '\r\n  ``````\r\nEnd';
		const blocks = findRuntimeBlocks(md);
		expect(blocks).toHaveLength(1);
		expect(blocks[0].id).toBe('target');
		expect(blocks[0].source).toBe(external);
		expect(md.slice(blocks[0].contentFrom, blocks[0].contentTo)).toBe(external);
		expect(md.slice(blocks[0].from, blocks[0].to)).toBe('  `````physlab\r\n' + external + '\r\n  ``````\r\n');
	});

	it('finds external and inline manifests while ignoring legacy YAML and malformed blocks', () => {
		const md = '```physlab\n' + external + '\n```\n~~~physlab\n' + inline + '\n<div>inline</div>\n~~~\n'
			+ '```physlab\nid: legacy\npreset: math.secant-tangent\n```\n'
			+ '```physlab\n{"id":"not-v1"}\n```\n```physlab\n{"version":1,broken}\n```';
		expect(findRuntimeBlocks(md).map((block) => block.id)).toEqual(['target', 'inline']);
	});

	it('ignores mismatched closing fence markers, short fences and unclosed blocks', () => {
		const source = inline + '\n~~~\n```\n<div>kept</div>';
		const md = '`````physlab\n' + source + '\n`````\n```physlab\n' + external;
		expect(findRuntimeBlocks(md).map(({ id, source: body }) => ({ id, body }))).toEqual([{ id: 'inline', body: source }]);
	});

	it('snapshots only the selected external source and preserves surrounding note bytes', () => {
		const before = 'Head\r\n~~~physlab\r\n';
		const after = '\r\n~~~\r\n\r\n```physlab\r\n' + inline + '\r\n<p>Other</p>\r\n```\r\nTail';
		const result = snapshotRuntimeBlock(before + external + after, 'target', external, { n: 7 });
		expect(result.startsWith(before)).toBe(true);
		expect(result.endsWith(after)).toBe(true);
		const blocks = findRuntimeBlocks(result);
		expect(JSON.parse(blocks[0].source)).toEqual({ version: 1, id: 'target', file: 'labs/test.html', initialState: { n: 7 } });
		expect(blocks[0].source.replace(/\r\n/g, '')).not.toContain('\n');
	});

	it('changes only the inline first header and preserves HTML and scripts exactly', () => {
		const body = '\r\n<div data-x="1">ñ</div>\r\n<script>const sample = "```";\r\n</script>\r\n';
		const md = 'Before\r\n~~~~physlab\r\n' + inline + body + '~~~~\r\nAfter';
		const source = findRuntimeBlocks(md)[0].source;
		const updated = snapshotRuntimeBlock(md, 'inline', source, { n: 8, mode: 'left' });
		expect(updated).toBe('Before\r\n~~~~physlab\r\n<!-- physlab:v1 {"id":"inline","initialState":{"n":8,"mode":"left"}} -->' + body + '~~~~\r\nAfter');
	});

	it('accepts exactly one optional expected terminal newline but keeps other conflicts strict', () => {
		const md = '```physlab\n' + external + '\n```';
		for (const terminal of ['', '\n', '\r\n']) {
			expect(snapshotRuntimeBlock(md, 'target', external + terminal, {})).toContain('"initialState": {}');
		}
		for (const changed of [' ' + external, external + ' ', external + '\n\n']) {
			expect(() => snapshotRuntimeBlock(md, 'target', changed, {})).toThrow(/cambi|source|modific/i);
		}
	});

	it('rejects missing and duplicate ids instead of overwriting an arbitrary block', () => {
		const block = '```physlab\n' + external + '\n```\n';
		expect(() => snapshotRuntimeBlock(block, 'missing', external, {})).toThrow(/encontr|missing/i);
		expect(() => snapshotRuntimeBlock(block + block, 'target', external, {})).toThrow(/duplic/i);
		expect(findRuntimeBlocks(block + block)).toHaveLength(2);
	});

	it('rejects an invalid snapshot before editing Markdown', () => {
		const md = '```physlab\n' + external + '\n```';
		expect(() => snapshotRuntimeBlock(md, 'target', external, { n: NaN })).toThrow();
	});

	it('inserts independent valid v1 references with JSON-escaped paths', () => {
		const file = 'PhysicaLab/quoted "name"\\file.html';
		const first = findRuntimeBlocks(runtimeCodeBlock(file))[0];
		const second = findRuntimeBlocks(runtimeCodeBlock(file))[0];
		const manifest = JSON.parse(first.source);
		expect(manifest).toEqual({ version: 1, id: first.id, file, height: 640, features: ['2d', 'latex'], initialState: {} });
		expect(first.id).toMatch(/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i);
		expect(second.id).not.toBe(first.id);
	});
});
