import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { runInNewContext } from 'node:vm';
import { describe, expect, it } from 'vitest';
import { loadVendorBundles } from '../../src/runtime/vendor';

const root = resolve(import.meta.dirname, '../..');

/** Execute the pure model actually used by an HTML lab, without a browser view. */
function model(name: string): Record<string, (...args: any[]) => any> {
	const html = readFileSync(resolve(root, 'demo-vault/PhysicaLab/labs', `${name}.html`), 'utf8');
	const source = html.match(/<script id="lab-model">([\s\S]*?)<\/script>/)?.[1];
	if (!source) throw new Error(`Missing pure model in ${name}`);
	const context = { globalThis: {} as { LabModel?: Record<string, (...args: any[]) => any> } };
	runInNewContext(source, context);
	return context.globalThis.LabModel!;
}

describe('offline vendor loading', () => {
	it('loads only requested features and does not read a missing 3D bundle for a 2D lab', async () => {
		const files: Record<string, string> = { '.obsidian/plugins/pl/vendor/katex.js': 'math-js', '.obsidian/plugins/pl/vendor/katex.css': 'math-css' };
		const adapter = { async read(path: string) { if (!(path in files)) throw new Error(`Missing ${path}`); return files[path]; } };
		expect(await loadVendorBundles(adapter, '.obsidian/plugins/pl', ['2d'])).toEqual({});
		expect(await loadVendorBundles(adapter, '.obsidian/plugins/pl', ['2d', 'latex'])).toEqual({ katexJs: 'math-js', katexCss: 'math-css' });
	});
	it('caches by adapter and full path while keeping another vault independent', async () => {
		let source = 'first';
		const adapter = { async read() { return source; } };
		expect((await loadVendorBundles(adapter, 'one', ['3d'])).threeJs).toBe('first');
		source = 'second';
		expect((await loadVendorBundles(adapter, 'one', ['3d'])).threeJs).toBe('first');
		expect((await loadVendorBundles(adapter, 'two', ['3d'])).threeJs).toBe('second');
		expect((await loadVendorBundles({ async read() { return 'other-vault'; } }, 'one', ['3d'])).threeJs).toBe('other-vault');
	});
	it('allows a missing bundle to be repaired and retried', async () => {
		let installed = false;
		const adapter = { async read() { if (!installed) throw new Error('not installed'); return 'repaired'; } };
		await expect(loadVendorBundles(adapter, 'pl', ['3d'])).rejects.toThrow(/three\.js/);
		installed = true;
		expect((await loadVendorBundles(adapter, 'pl', ['3d'])).threeJs).toBe('repaired');
	});
});

describe('original HTML lab scientific models', () => {
	it('Riemann left and right sums bracket 8/3, with exact n=4 fixtures and midpoint convergence', () => {
		const m = model('riemann-x2');
		expect(m.compute({ n: 4, method: 'left', probeX: 1 }).sum).toBeCloseTo(1.75, 12);
		expect(m.compute({ n: 4, method: 'right', probeX: 1 }).sum).toBeCloseTo(3.75, 12);
		expect(m.compute({ n: 4, method: 'mid', probeX: 1 }).sum).toBeCloseTo(2.625, 12);
		expect(m.compute({ n: 64, method: 'mid', probeX: 1 }).error).toBeLessThan(0.0002);
	});
	it('Thevenin/Norton equivalence matches the loaded divider and maximum power at RL=Rth', () => {
		const m = model('thevenin-norton');
		const r = m.compute({ vs: 12, r1: 1000, r2: 2000, rl: 1000 });
		expect(r.vth).toBeCloseTo(8, 12);
		expect(r.rth).toBeCloseTo(666.666666666667, 9);
		expect(r.inorton).toBeCloseTo(0.012, 12);
		expect(r.vload).toBeCloseTo(4.8, 12);
		expect(r.vloadNorton).toBeCloseTo(4.8, 12);
		expect(r.directVoltage).toBeCloseTo(4.8, 12);
		const optimum = m.compute({ vs: 12, r1: 1000, r2: 2000, rl: r.rth });
		expect(optimum.power).toBeCloseTo(0.024, 12);
		expect(r.power).toBeLessThan(optimum.power);
	});
	it('four diode bridge uses two forward drops, alternating diode pairs, and zero blocked current', () => {
		const m = model('bridge-rectifier');
		const p = { peak: 10, frequency: 50, vf: 0.7, resistance: 1000, capacitance: 0, phase: 0 };
		expect(m.sample(p, 0).output).toBe(0);
		expect(m.sample(p, 0.005).output).toBeCloseTo(8.6, 12);
		expect(m.sample(p, 0.005).diodes).toEqual([1, 4]);
		expect(m.sample(p, 0.015).output).toBeCloseTo(8.6, 12);
		expect(m.sample(p, 0.015).diodes).toEqual([2, 3]);
		expect(m.sample(p, 0.0001).current).toBe(0);
		expect(m.compute(p).mean).toBeCloseTo(5.0287, 3);
	});
	it('capacitor bridge decay follows its declared ideal-source peak hold RC model', () => {
		const m = model('bridge-rectifier');
		const p = { peak: 10, frequency: 50, vf: 0.7, resistance: 1000, capacitance: 0.0001, phase: 0 };
		const r = m.compute(p);
		expect(r.minimum).toBeGreaterThan(7.8);
		expect(r.maximum).toBeCloseTo(8.6, 4);
		expect(r.ripple).toBeLessThan(0.9);
		expect(m.step(p, 0.01, 8, 0.001).output).toBeCloseTo(7.920398669993344, 10);
	});
	it('sine surface preserves zero and extrema and inverse drag maps z back to amplitude', () => {
		const m = model('sine-surface-3d');
		expect(m.z(0, 1.1, 1.6)).toBe(0);
		expect(m.z(Math.PI / 2, 0, 1.6)).toBeCloseTo(1.6, 12);
		expect(m.z(Math.PI / 2, Math.PI, 1.6)).toBeCloseTo(-1.6, 12);
		expect(m.z(1, 2, 0)).toBeCloseTo(0, 12);
		expect(m.amplitudeFromHeight(1.35)).toBe(1.35);
		expect(m.amplitudeFromHeight(4)).toBe(2);
		for (let i = 0; i < 200; i++) expect(Math.abs(m.z(i * 0.127, i * 0.311, 1.6))).toBeLessThanOrEqual(1.6);
	});
});
