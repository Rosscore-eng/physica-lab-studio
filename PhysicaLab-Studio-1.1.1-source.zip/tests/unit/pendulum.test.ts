import { afterEach, describe, expect, it } from 'vitest';
import { ResourceScope } from '../../src/core/lifecycle';
import { liveInstances } from '../../src/core/lab-host';
import { PENDULUM_LAYOUT } from '../../src/presets/physics/pendulum';
import {
	advanceSim,
	agm,
	bobRadius,
	ellipticK,
	exactPeriod,
	forceLength,
	mechanicalEnergy,
	periodRatio,
	planetFor,
	planetGravity,
	rk4Step,
	smallAnglePeriod,
	smallAngleError,
	startSim,
	type PendulumState,
} from '../../src/presets/physics/pendulum-model';
import { drag, handlePos, mountLab, setInput, texOf, tick, type Mounted } from './helpers';

const deg = (d: number): number => (d * Math.PI) / 180;
const S = PENDULUM_LAYOUT.scale;
const PIV = PENDULUM_LAYOUT.pivot;

describe('modelo del péndulo', () => {
	it('AGM e integral elíptica K con valores de referencia', () => {
		expect(agm(1, 1)).toBe(1);
		expect(agm(24, 6)).toBeCloseTo(13.458171481725616, 12);
		expect(ellipticK(0)).toBeCloseTo(Math.PI / 2, 14);
		// K(1/√2) = Γ(1/4)² / (4√π)
		expect(ellipticK(Math.SQRT1_2)).toBeCloseTo(1.854074677301372, 12);
		expect(ellipticK(1)).toBe(Number.POSITIVE_INFINITY);
	});

	it('T0 = 2π√(L/g): L = 1 m, g = 9.81 m/s² → 2.006 s', () => {
		expect(smallAnglePeriod(1, 9.81)).toBeCloseTo(2.00607, 5);
		expect(Number(smallAnglePeriod(1, 9.81).toFixed(3))).toBe(2.006);
	});

	it('T/T0 para θ0 = 90° ≈ 1.18034 y tiende a 1 + θ0²/16', () => {
		expect(periodRatio(deg(90))).toBeCloseTo(1.18034, 5);
		expect(periodRatio(0)).toBe(1);
		expect(periodRatio(-deg(90))).toBe(periodRatio(deg(90)));
		const th = 0.1;
		expect(periodRatio(th)).toBeCloseTo(1 + (th * th) / 16, 6);
		// Error relativo de la aproximación: < 0.5 % hasta 15°, > 1 % a 30°.
		expect(smallAngleError(deg(15))).toBeLessThan(0.005);
		expect(smallAngleError(deg(30))).toBeGreaterThan(0.01);
	});

	it('unidades coherentes: T escala como √(L/g) y T(θ0→0) = T0', () => {
		const T = exactPeriod(1, 9.81, deg(40));
		expect(exactPeriod(4, 9.81, deg(40))).toBeCloseTo(2 * T, 12);
		expect(exactPeriod(1, 4 * 9.81, deg(40))).toBeCloseTo(T / 2, 12);
		expect(exactPeriod(1.3, 3.71, 0)).toBeCloseTo(smallAnglePeriod(1.3, 3.71), 12);
		expect(T / smallAnglePeriod(1, 9.81)).toBeCloseTo(periodRatio(deg(40)), 12);
	});

	it('RK4 conserva la energía y reproduce el período exacto (θ0 = 90°)', () => {
		const L = 1;
		const g = 9.81;
		const m = 2;
		const h = 1e-3;
		let s: PendulumState = { theta: deg(90), omega: 0 };
		const E0 = mechanicalEnergy(m, g, L, s);
		let maxDrift = 0;
		const crossings: number[] = [];
		for (let i = 1; i <= 20000; i++) {
			const next = rk4Step(s, h, g, L);
			if (s.theta > 0 && next.theta <= 0) crossings.push((i - 1) * h + (h * s.theta) / (s.theta - next.theta));
			s = next;
			maxDrift = Math.max(maxDrift, Math.abs(mechanicalEnergy(m, g, L, s) - E0) / E0);
		}
		expect(maxDrift).toBeLessThan(1e-8);
		const Tnum = (crossings[crossings.length - 1]! - crossings[0]!) / (crossings.length - 1);
		expect(Tnum / exactPeriod(L, g, deg(90)) - 1).toBeLessThan(1e-6);
		expect(Math.abs(Tnum - exactPeriod(L, g, deg(90)))).toBeLessThan(1e-6);
	});

	it('el paso fijo no depende de cómo se reparten los frames', () => {
		const a = advanceSim(startSim(deg(60)), 1.5, 9.81, 0.8);
		let b = startSim(deg(60));
		for (let i = 0; i < 90; i++) b = advanceSim(b, 1 / 60, 9.81, 0.8);
		expect(b.t).toBeCloseTo(a.t, 9);
		expect(b.theta).toBeCloseTo(a.theta, 9);
		expect(advanceSim(a, Number.NaN, 9.81, 0.8)).toBe(a);
	});

	it('cuerpos celestes y escalas de dibujo acotadas', () => {
		expect(planetGravity('moon')).toBe(1.62);
		expect(planetGravity('custom')).toBeNull();
		expect(planetFor(24.79)).toBe('jupiter');
		expect(planetFor(9.8)).toBe('custom');
		expect(bobRadius(0.05, 0.05, 5, 7, 15)).toBe(7);
		expect(bobRadius(5, 0.05, 5, 7, 15)).toBe(15);
		expect(bobRadius(1, 0.05, 5, 7, 15)).toBeGreaterThan(bobRadius(0.5, 0.05, 5, 7, 15));
		expect(forceLength(1e6, 0.05, 125, 24, 78)).toBe(78);
		expect(forceLength(0, 0.05, 125, 24, 78)).toBe(0);
	});
});

describe('laboratorio péndulo simple', () => {
	let m: Mounted;
	afterEach(() => m?.cleanup());

	const bob = (root: Element): Element => root.querySelector('.pl-pend-bob-handle') as Element;
	const dist = (p: { x: number; y: number }): number => Math.hypot(p.x - PIV.x, p.y - PIV.y);
	const slider = (root: Element, id: string): HTMLInputElement =>
		root.querySelector(`[data-param="${id}"] input.pl-slider`) as HTMLInputElement;
	const labelTex = (root: Element, id: string): string =>
		root.querySelector(`.pl-label[data-label="${id}"]`)?.getAttribute('data-tex') ?? '';

	it('arrastrar la masa respeta la restricción |OP| = L·escala y actualiza θ0', () => {
		m = mountLab('physics.pendulum', { theta0: 30, L: 1 });
		const b = bob(m.container);
		expect(dist(handlePos(b))).toBeCloseTo(1 * S, 1);
		// El puntero se aleja del círculo: la masa se proyecta sobre él.
		drag(b, handlePos(b), { x: PIV.x + 300, y: PIV.y + 50 });
		tick();
		expect(m.lab.store.num('theta0')).toBe(80.5); // atan2(300, 50) = 80.54° → paso 0.5
		expect(m.lab.store.num('L')).toBe(1);
		const p = handlePos(b);
		expect(dist(p)).toBeCloseTo(1 * S, 1);
		expect(Math.atan2(p.x - PIV.x, p.y - PIV.y)).toBeCloseTo(deg(80.5), 3);
		const rod = m.container.querySelector('line.pl-line.pl-s-text') as SVGLineElement;
		expect(Number(rod.getAttribute('x2'))).toBeCloseTo(p.x, 1);
		expect(Number(rod.getAttribute('y2'))).toBeCloseTo(p.y, 1);
		expect(texOf(m.container, 'theta')).toBe('\\theta_0=80.5^{\\circ}');
		// Por encima del pivote: el almacén limita θ0 a ±90°.
		drag(b, handlePos(b), { x: PIV.x - 40, y: PIV.y - 100 });
		tick();
		expect(m.lab.store.num('theta0')).toBe(-90);
		expect(dist(handlePos(b))).toBeCloseTo(S, 1);
	});

	it('con «arrastrar también la longitud» la distancia al pivote fija L (acotada)', () => {
		m = mountLab('physics.pendulum', { theta0: 0, L: 1, dragLength: true });
		const b = bob(m.container);
		drag(b, handlePos(b), { x: PIV.x, y: PIV.y + 1.6 * S });
		tick();
		expect(m.lab.store.num('L')).toBeCloseTo(1.6, 2);
		expect(dist(handlePos(b))).toBeCloseTo(1.6 * S, 0);
		drag(b, handlePos(b), { x: PIV.x, y: PIV.y + 5 * S });
		tick();
		expect(m.lab.store.num('L')).toBe(2);
	});

	it('el deslizador de θ0 mueve la masa y cambiar L cambia la geometría (escala fija)', () => {
		m = mountLab('physics.pendulum', { theta0: 30, L: 1 });
		const b = bob(m.container);
		setInput(slider(m.container, 'theta0'), '-45');
		tick();
		expect(m.lab.store.num('theta0')).toBe(-45);
		let p = handlePos(b);
		expect(p.x).toBeCloseTo(PIV.x - S * Math.sin(deg(45)), 1);
		expect(p.y).toBeCloseTo(PIV.y + S * Math.cos(deg(45)), 1);
		setInput(slider(m.container, 'L'), '2');
		tick();
		p = handlePos(b);
		expect(dist(p)).toBeCloseTo(2 * S, 1);
		setInput(slider(m.container, 'L'), '0.2');
		tick();
		expect(dist(handlePos(b))).toBeCloseTo(0.2 * S, 1);
		// El arco de θ y la etiqueta siguen al ángulo.
		expect(labelTex(m.container, 'theta')).toBe('\\theta_0');
	});

	it('el teclado cambia θ0 (y L si el arrastre de longitud está activo)', () => {
		m = mountLab('physics.pendulum', { theta0: 10, L: 1 });
		const b = bob(m.container);
		b.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowRight', bubbles: true }));
		expect(m.lab.store.num('theta0')).toBe(11);
		b.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowLeft', shiftKey: true, bubbles: true }));
		expect(m.lab.store.num('theta0')).toBe(6);
		b.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowUp', bubbles: true }));
		expect(m.lab.store.num('L')).toBe(1);
		m.lab.store.set('dragLength', true, 'panel');
		b.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowUp', bubbles: true }));
		expect(m.lab.store.num('L')).toBe(0.99);
	});

	it('el asa del inserto T/T0 cambia θ0 a lo largo de la curva', () => {
		m = mountLab('physics.pendulum', { theta0: 30 });
		const h = m.container.querySelector('.pl-stage-inset .pl-draggable') as Element;
		// x de escena de θ0 = −45° en el inserto: 52 + (−45 + 90)/180 · 222
		drag(h, handlePos(h), { x: 52 + (45 / 180) * 222, y: 10 });
		tick();
		expect(m.lab.store.num('theta0')).toBe(-45);
		expect(handlePos(h).y).toBeCloseTo(34 + ((1.2 - periodRatio(deg(45))) / 0.21) * 366, 1);
	});

	it('ecuaciones con valores y unidades: T0 = 2.006 s para L = 1 m, g = 9.81 m/s²', () => {
		m = mountLab('physics.pendulum', { theta0: 10, L: 1, g: 9.81 });
		expect(texOf(m.container, 'small')).toBe(
			'T_0=2\\pi\\sqrt{\\frac{L}{g}}=2\\pi\\sqrt{\\frac{1.00\\,\\mathrm{m}}{9.81\\,\\mathrm{m/s^2}}}=2.006\\,\\mathrm{s}',
		);
		expect(texOf(m.container, 'T0')).toBe('T_0=2.006\\,\\mathrm{s}');
		expect(texOf(m.container, 'exact')).toContain('\\mathrm{s}');
		expect(texOf(m.container, 'T')).toBe(`T=${exactPeriod(1, 9.81, deg(10)).toFixed(3)}\\,\\mathrm{s}`);
		expect(texOf(m.container, 'K')).toContain('\\operatorname{AGM}');
		expect(texOf(m.container, 'f')).toContain('\\mathrm{Hz}');
		// E_p = mgL(1 − cos 10°) = 0.149 J (prefijo SI).
		expect(texOf(m.container, 'E')).toBe('E=E_p=149\\,\\mathrm{mJ}');
		expect(texOf(m.container, 'Ep')).toContain('(1.00\\,\\mathrm{kg})(9.81\\,\\mathrm{m/s^2})(0.0152\\,\\mathrm{m})');
		// |θ0| ≤ 15°: sin aviso.
		expect(m.container.querySelector('.pl-status')?.classList.contains('pl-hidden')).toBe(true);
		expect(m.container.querySelector('[data-eq="err"]')?.classList.contains('pl-emph')).toBe(false);
	});

	it('θ0 = 90°: T/T0 = 1.18034 y aviso de que la aproximación deja de ser buena', () => {
		m = mountLab('physics.pendulum', { theta0: 90, L: 1, g: 9.81 });
		expect(texOf(m.container, 'err')).toContain('=1.18034');
		expect(texOf(m.container, 'exact')).toContain('=2.368\\,\\mathrm{s}');
		const status = m.container.querySelector('.pl-status') as HTMLElement;
		expect(status.classList.contains('pl-hidden')).toBe(false);
		expect(status.textContent).toMatch(/15°/);
		expect(m.container.querySelector('[data-eq="err"]')?.classList.contains('pl-emph')).toBe(true);
	});

	it('el selector de cuerpo celeste fija g y después refleja g (g es la fuente de verdad)', () => {
		m = mountLab('physics.pendulum', { theta0: 20, L: 1 });
		const sel = m.container.querySelector('[data-param="planet"] select') as HTMLSelectElement;
		expect(sel.value).toBe('earth');
		setInput(sel, 'moon', 'change');
		tick();
		expect(m.lab.store.num('g')).toBe(1.62);
		expect(texOf(m.container, 'small')).toContain(`=${smallAnglePeriod(1, 1.62).toFixed(3)}\\,\\mathrm{s}`);
		setInput(slider(m.container, 'g'), '5');
		tick();
		expect(m.lab.store.str('planet')).toBe('custom');
		expect(sel.value).toBe('custom');
		setInput(slider(m.container, 'g'), '3.71');
		tick();
		expect(sel.value).toBe('mars');
		// «planet» no se guarda: el estado persistente solo lleva g.
		expect(m.lab.store.snapshot().values).not.toHaveProperty('planet');
		m.lab.resetParameters();
		tick();
		expect(m.lab.store.num('g')).toBe(9.81);
		expect(sel.value).toBe('earth');
	});

	it('con g bloqueada el selector no cambia g y vuelve al cuerpo correcto', () => {
		m = mountLab('physics.pendulum', { g: 9.81 }, { lock: ['g'] });
		const sel = m.container.querySelector('[data-param="planet"] select') as HTMLSelectElement;
		setInput(sel, 'jupiter', 'change');
		tick();
		expect(m.lab.store.num('g')).toBe(9.81);
		expect(m.lab.store.str('planet')).toBe('earth');
	});

	it('la animación integra θ(t) sin arrancar sola, conserva E y se pausa al arrastrar', () => {
		m = mountLab('physics.pendulum', { theta0: 40, L: 1, m: 1, g: 9.81 });
		const b = bob(m.container);
		const p0 = handlePos(b);
		const E0 = texOf(m.container, 'E');
		expect(E0).toBe('E=E_p=2.30\\,\\mathrm{J}');
		tick(20);
		expect(texOf(m.container, 'theta')).toBe('\\theta_0=40.0^{\\circ}');
		expect(m.container.querySelector('[data-eq="t"]')?.classList.contains('pl-hidden')).toBe(true);

		const play = m.container.querySelector('.pl-btn-play') as HTMLButtonElement;
		play.click();
		tick(40);
		m.lab.flush();
		expect(texOf(m.container, 'theta')).toMatch(/^\\theta\(t\)=/);
		expect(m.container.querySelector('[data-eq="t"]')?.classList.contains('pl-hidden')).toBe(false);
		expect(labelTex(m.container, 'theta')).toBe('\\theta');
		const p1 = handlePos(b);
		expect(p1.x).toBeLessThan(p0.x); // la masa ha bajado hacia el equilibrio
		expect(dist(p1)).toBeCloseTo(S, 1); // sigue sobre la circunferencia
		expect(texOf(m.container, 'E')).toBe('E=E_c+E_p=2.30\\,\\mathrm{J}');
		expect(m.lab.store.num('theta0')).toBe(40); // θ(t) no es un parámetro

		// Arrastrar la masa pausa y fija θ0 en el valor arrastrado.
		drag(b, handlePos(b), { x: PIV.x - 200, y: PIV.y + 200 });
		tick();
		expect(play.getAttribute('aria-pressed')).toBe('false');
		expect(m.lab.store.num('theta0')).toBe(-45);
		expect(texOf(m.container, 'theta')).toBe('\\theta_0=-45.0^{\\circ}');
		expect(dist(handlePos(b))).toBeCloseTo(S, 1);

		// Reiniciar vuelve a t = 0 sin tocar los parámetros.
		play.click();
		tick(10);
		(m.container.querySelector('.pl-anim .pl-btn-quiet') as HTMLButtonElement).click();
		play.click();
		tick();
		m.lab.flush();
		expect(texOf(m.container, 'theta')).toBe('\\theta_0=-45.0^{\\circ}');
	});

	it('ningún NaN ni infinito en el DOM en casos extremos', () => {
		const cases: Array<Record<string, number | boolean | string>> = [
			{ theta0: 0, L: 0.2, m: 0.05, g: 1, showComponents: true },
			{ theta0: 90, L: 2, m: 5, g: 25, showComponents: true },
			{ theta0: -90, L: 2, m: 0.05, g: 1, showComponents: true, showWeight: false },
			{ theta0: 0.5, L: 0.2, showProjection: true },
			{ theta0: 'abc', L: -3, g: 1e9 },
		];
		for (const c of cases) {
			const mm = mountLab('physics.pendulum', c);
			tick();
			mm.lab.flush();
			const bad: string[] = [];
			for (const el of Array.from(mm.container.querySelectorAll('*'))) {
				for (const a of Array.from(el.attributes)) {
					if (/NaN|Infinity|\\infty/.test(a.value)) bad.push(`${el.tagName}[${a.name}]=${a.value}`);
				}
			}
			expect(bad, JSON.stringify(c)).toEqual([]);
			expect(mm.container.textContent ?? '').not.toMatch(/NaN|Infinity/);
			mm.cleanup();
		}
		m = mountLab('physics.pendulum');
	});

	it('no deja recursos vivos tras destruirse', () => {
		const base = ResourceScope.live;
		const labs = [mountLab('physics.pendulum'), mountLab('physics.pendulum', { theta0: -60 })];
		(labs[0]!.container.querySelector('.pl-btn-play') as HTMLButtonElement).click();
		tick(5);
		expect(liveInstances.size).toBe(2);
		expect(ResourceScope.live).toBeGreaterThan(base);
		for (const l of labs) l.cleanup();
		expect(ResourceScope.live).toBe(base);
		expect(liveInstances.size).toBe(0);
		expect(labs[0]!.lab.store.listenerCount).toBe(0);
		expect(labs[1]!.lab.store.listenerCount).toBe(0);
		m = mountLab('physics.pendulum');
	});
});
