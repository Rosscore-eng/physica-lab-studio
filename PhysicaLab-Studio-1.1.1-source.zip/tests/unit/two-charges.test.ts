import { afterEach, describe, expect, it } from 'vitest';
import { liveInstances } from '../../src/core/lab-host';
import { ResourceScope } from '../../src/core/lifecycle';
import { texSI } from '../../src/core/numeric';
import {
	avoidDiscs1D,
	coulombForce,
	fieldAt,
	K_COULOMB,
	lineCount,
	lineMarks,
	lineSources,
	logScale,
	MICRO,
	traceFieldLines,
	type PointCharge,
} from '../../src/presets/physics/charges-model';
import { drag, handlePos, mountLab, setInput, texOf, tick, type Mounted } from './helpers';

const K = K_COULOMB;
const R_CHARGE = 0.085;
const BOUNDS = { xMin: -2.1, xMax: 2.1, yMin: -1.35, yMax: 1.35 };

/* Plano [-2, 2] × [-1.25, 1.25] m dibujado en {x: 42, y: 26, 624 × 390}: 156 unidades por metro. */
const X = (x: number): number => 42 + (x + 2) * 156;
const Y = (y: number): number => 26 + (1.25 - y) * 156;

const role = (root: Element, r: string): SVGGElement => {
	const el = root.querySelector(`[data-role="${r}"]`);
	if (!el) throw new Error(`sin elemento ${r}`);
	return el as SVGGElement;
};

/** Campo de cargas puntuales calculado aquí, de forma independiente del modelo. */
function analyticField(cs: Array<[number, number, number]>, x: number, y: number): [number, number] {
	let ex = 0;
	let ey = 0;
	for (const [cx, cy, q] of cs) {
		const r = Math.sqrt((x - cx) ** 2 + (y - cy) ** 2);
		ex += (K * q * (x - cx)) / r ** 3;
		ey += (K * q * (y - cy)) / r ** 3;
	}
	return [ex, ey];
}

/** Dirección (escena) del vector dibujado por una flecha `Arrow`. */
function arrowDir(g: Element): { x: number; y: number; len: number } {
	const l = g.querySelector('.pl-arrow-shaft') as SVGLineElement;
	const x1 = Number(l.getAttribute('x1'));
	const y1 = Number(l.getAttribute('y1'));
	const x2 = Number(l.getAttribute('x2'));
	const y2 = Number(l.getAttribute('y2'));
	const len = Math.hypot(x2 - x1, y2 - y1);
	return { x: (x2 - x1) / len, y: (y2 - y1) / len, len };
}

/** Todos los atributos y estilos del laboratorio, más el LaTeX de etiquetas y ecuaciones. */
function domText(root: Element): string {
	const parts: string[] = [];
	for (const el of [root, ...Array.from(root.querySelectorAll('*'))]) {
		for (const a of Array.from(el.attributes)) parts.push(`${a.name}=${a.value}`);
	}
	return parts.join('\n');
}

const dist = (m: Mounted): number =>
	Math.hypot(m.lab.store.num('x2') - m.lab.store.num('x1'), m.lab.store.num('y2') - m.lab.store.num('y1'));

describe('modelo de dos cargas puntuales', () => {
	it('Coulomb: q1 = q2 = 1 μC a 1 m → F ≈ 8.99·10⁻³ N', () => {
		const F = coulombForce({ x: 0, y: 0, q: MICRO }, { x: 1, y: 0, q: MICRO });
		expect(F).not.toBeNull();
		expect(F!.magnitude).toBeCloseTo(8.9875517923e-3, 12);
		expect(Number(F!.magnitude.toPrecision(3))).toBe(8.99e-3);
		// Repulsión: F12 (sobre q2) apunta de q1 a q2.
		expect(F!.fx).toBeGreaterThan(0);
		expect(F!.attractive).toBe(false);
		const G = coulombForce({ x: 0, y: 0, q: 2 * MICRO }, { x: 0, y: -0.5, q: -3 * MICRO })!;
		expect(G.attractive).toBe(true);
		expect(G.fy).toBeGreaterThan(0); // q2 es atraída hacia q1
		expect(G.magnitude).toBeCloseTo((K * 6e-12) / 0.25, 12);
		expect(coulombForce({ x: 1, y: 1, q: MICRO }, { x: 1, y: 1, q: MICRO })).toBeNull();
	});

	it('el campo coincide con el cálculo analítico (tolerancia relativa 1e-9)', () => {
		// Dipolo +q en (−a, 0) y −q en (a, 0): en la mediatriz, Ex = 2kqa/(a² + y²)^{3/2}, Ey = 0.
		const q = 2 * MICRO;
		const a = 0.7;
		const dip: PointCharge[] = [
			{ x: -a, y: 0, q },
			{ x: a, y: 0, q: -q },
		];
		for (const y of [0, 0.3, -0.9, 1.2]) {
			const E = fieldAt(dip, 0, y)!;
			const ex = (2 * K * q * a) / Math.pow(a * a + y * y, 1.5);
			expect(Math.abs(E.x - ex) / ex).toBeLessThan(1e-9);
			expect(Math.abs(E.y)).toBeLessThan(1e-9 * ex);
		}
		// Punto genérico con cargas distintas.
		const cs: Array<[number, number, number]> = [
			[-0.8, 0.1, 3 * MICRO],
			[0.65, -0.4, -2.5 * MICRO],
		];
		for (const [x, y] of [
			[0.2, 0.65],
			[-1.7, -1.1],
			[1.9, 1.2],
			[0.66, -0.25],
		] as const) {
			const E = fieldAt(
				cs.map(([cx, cy, cq]) => ({ x: cx, y: cy, q: cq })),
				x,
				y,
			)!;
			const [ex, ey] = analyticField(cs, x, y);
			const mag = Math.hypot(ex, ey);
			expect(Math.hypot(E.x - ex, E.y - ey) / mag).toBeLessThan(1e-9);
		}
	});

	it('cambiar el signo de q1 invierte su contribución al campo', () => {
		const P = { x: 0.3, y: 0.5 };
		const solo = fieldAt([{ x: -0.5, y: 0, q: 2 * MICRO }], P.x, P.y)!;
		const inv = fieldAt([{ x: -0.5, y: 0, q: -2 * MICRO }], P.x, P.y)!;
		expect(inv.x).toBeCloseTo(-solo.x, 9);
		expect(inv.y).toBeCloseTo(-solo.y, 9);
		const two = fieldAt(
			[
				{ x: -0.5, y: 0, q: 2 * MICRO },
				{ x: 0.7, y: 0.1, q: -MICRO },
			],
			P.x,
			P.y,
		)!;
		const twoInv = fieldAt(
			[
				{ x: -0.5, y: 0, q: -2 * MICRO },
				{ x: 0.7, y: 0.1, q: -MICRO },
			],
			P.x,
			P.y,
		)!;
		// E(−q1) = E − 2·E1
		expect(twoInv.x).toBeCloseTo(two.x - 2 * solo.x, 6);
		expect(twoInv.y).toBeCloseTo(two.y - 2 * solo.y, 6);
	});

	it('no evalúa el campo dentro de una carga; las cargas nulas no contribuyen', () => {
		const cs: PointCharge[] = [
			{ x: 0, y: 0, q: MICRO },
			{ x: 1, y: 0, q: 0 },
		];
		expect(fieldAt(cs, 0, 0)).toBeNull();
		expect(fieldAt(cs, 0.05, 0, R_CHARGE)).toBeNull();
		expect(fieldAt(cs, 0.2, 0, R_CHARGE)).not.toBeNull();
		// Sobre la carga nula el campo sí está definido (solo lo crea q1).
		const E = fieldAt(cs, 1, 0, R_CHARGE)!;
		expect(E.x).toBeCloseTo(K * MICRO, 6);
		expect(fieldAt([{ x: 0, y: 0, q: 0 }], 0, 0)).toEqual({ x: 0, y: 0 });
		expect(logScale(0, 1e3, 1e7)).toBe(0);
		expect(logScale(1e5, 1e3, 1e7)).toBeCloseTo(0.5, 12);
	});

	it('número de líneas ∝ |q| y criterio de flujo', () => {
		expect(lineCount(0)).toBe(0);
		expect(lineCount(2 * MICRO)).toBe(2 * lineCount(MICRO));
		expect(lineCount(-3 * MICRO)).toBe(3 * lineCount(MICRO));
		const c = (q: number): PointCharge => ({ x: 0, y: 0, q: q * MICRO });
		expect(lineSources([c(3), c(-2)])).toEqual([{ index: 0, sense: 1 }]);
		expect(lineSources([c(2), c(-2)])).toEqual([{ index: 0, sense: 1 }]);
		expect(lineSources([c(2), c(-4)])).toEqual([{ index: 1, sense: -1 }]);
		expect(lineSources([c(1), c(2)])).toEqual([
			{ index: 0, sense: 1 },
			{ index: 1, sense: 1 },
		]);
		expect(lineSources([c(-1), c(-2)])).toEqual([
			{ index: 0, sense: -1 },
			{ index: 1, sense: -1 },
		]);
		expect(lineSources([c(0), c(-2)])).toEqual([{ index: 1, sense: -1 }]);
		expect(lineSources([c(0), c(0)])).toEqual([]);
	});

	it('trazado RK4: líneas finitas que empiezan y acaban en el borde de las cargas', () => {
		const cs: PointCharge[] = [
			{ x: -0.8, y: 0, q: 3 * MICRO },
			{ x: 0.8, y: 0, q: -2 * MICRO },
		];
		const { lines } = traceFieldLines(cs, { bounds: BOUNDS, rCharge: R_CHARGE });
		expect(lines).toHaveLength(lineCount(3 * MICRO));
		for (const l of lines) {
			expect(l.pts.every(Number.isFinite)).toBe(true);
			expect(l.sense).toBe(1);
			expect(Math.hypot((l.pts[0] as number) + 0.8, l.pts[1] as number)).toBeCloseTo(R_CHARGE, 9);
			const ex = l.pts[l.pts.length - 2] as number;
			const ey = l.pts[l.pts.length - 1] as number;
			if (l.to === 1) expect(Math.hypot(ex - 0.8, ey)).toBeCloseTo(R_CHARGE, 9);
			else expect(ex < BOUNDS.xMin || ex > BOUNDS.xMax || ey < BOUNDS.yMin || ey > BOUNDS.yMax).toBe(true);
		}
		// La línea del eje va recta de q1 a q2; parte del flujo llega a q2 y el resto escapa.
		const ending = lines.filter((l) => l.to === 1).length;
		expect(ending).toBeGreaterThanOrEqual(5);
		expect(ending).toBeLessThan(lines.length);
		const axis = lines.find((l) => Math.abs((l.pts[1] as number) - 0) < 1e-12 && (l.pts[0] as number) > -0.8)!;
		expect(axis.to).toBe(1);
		expect(Math.max(...axis.pts.filter((_, i) => i % 2 === 1).map(Math.abs))).toBeLessThan(1e-9);
		// Las puntas de flecha siguen el sentido de E.
		for (const mk of lineMarks(axis, { first: 0.4, spacing: 0.8, minLength: 0.18, endGap: 0.2 })) expect(mk.ux).toBeCloseTo(1, 9);
	});

	it('trazado hacia atrás desde la negativa dominante y presupuesto de pasos acotado', () => {
		const neg = traceFieldLines(
			[
				{ x: 0, y: 0, q: MICRO },
				{ x: 0.5, y: 0.2, q: -4 * MICRO },
			],
			{ bounds: BOUNDS, rCharge: R_CHARGE },
		);
		expect(neg.lines.every((l) => l.from === 1 && l.sense === -1)).toBe(true);
		const t0 = performance.now();
		const big = traceFieldLines(
			[
				{ x: -0.2, y: 0, q: 10 * MICRO },
				{ x: 0.2, y: 0, q: 10 * MICRO },
			],
			{ bounds: BOUNDS, rCharge: R_CHARGE, budget: 24000 },
		);
		const ms = performance.now() - t0;
		expect(big.lines).toHaveLength(2 * lineCount(10 * MICRO));
		// Cada intento de paso cuenta; como mucho se pasa en los reintentos del último paso.
		expect(big.steps).toBeLessThanOrEqual(24000 + 6);
		expect(ms).toBeLessThan(250);
	});

	it('restricción 1D: saca la coordenada del disco de exclusión hacia el borde más cercano', () => {
		const disc = [{ along: 0.8, across: 0, r: 0.25 }];
		expect(avoidDiscs1D(0.7, 0, disc, -1.85, 1.85, 0.01)).toBe(0.55);
		expect(avoidDiscs1D(0.9, 0, disc, -1.85, 1.85, 0.01)).toBe(1.05);
		expect(avoidDiscs1D(0.7, 0.3, disc, -1.85, 1.85, 0.01)).toBe(0.7); // fuera del disco
		// Si el borde cercano queda fuera de rango, elige el otro.
		expect(avoidDiscs1D(1.8, 0, [{ along: 1.75, across: 0, r: 0.25 }], -1.85, 1.85, 0.01)).toBe(1.5);
		const v = avoidDiscs1D(0.8, 0.2, disc, -1.85, 1.85, 0.01);
		expect(Math.hypot(v - 0.8, 0.2)).toBeGreaterThanOrEqual(0.25 - 1e-9);
		// A igual distancia, el borde del lado del valor anterior.
		expect(avoidDiscs1D(0.8, 0, disc, -1.85, 1.85, 0.01, 1.4)).toBe(1.05);
		expect(avoidDiscs1D(0.8, 0, disc, -1.85, 1.85, 0.01, -1)).toBe(0.55);
	});
});

describe('laboratorio de dos cargas', () => {
	let m: Mounted;
	afterEach(() => m?.cleanup());

	it('arrastrar cada carga cambia su posición en el almacén y en la figura', () => {
		m = mountLab('physics.two-charges', { q1: 3, q2: -2, x1: -0.8, y1: 0, x2: 0.8, y2: 0 });
		const h1 = role(m.container, 'q1');
		const h2 = role(m.container, 'q2');
		expect(handlePos(h1).x).toBeCloseTo(X(-0.8), 1);
		expect(handlePos(h1).y).toBeCloseTo(Y(0), 1);

		drag(h1, handlePos(h1), { x: X(-1.2), y: Y(0.5) });
		tick();
		expect(m.lab.store.num('x1')).toBeCloseTo(-1.2, 2);
		expect(m.lab.store.num('y1')).toBeCloseTo(0.5, 2);
		expect(handlePos(h1).x).toBeCloseTo(X(-1.2), 0);
		expect(handlePos(h1).y).toBeCloseTo(Y(0.5), 0);
		// El panel refleja el arrastre (sincronía bidireccional).
		const num = m.container.querySelector('[data-param="y1"] input.pl-num') as HTMLInputElement;
		expect(num.value).toBe('0.50');

		drag(h2, handlePos(h2), { x: X(1.0), y: Y(-0.6) }, 8, 'touch');
		tick();
		expect(m.lab.store.num('x2')).toBeCloseTo(1.0, 2);
		expect(m.lab.store.num('y2')).toBeCloseTo(-0.6, 2);
		expect(handlePos(h2).x).toBeCloseTo(X(1.0), 0);
		expect(texOf(m.container, 'r')).toBe(`r=${(Math.hypot(2.2, 1.1)).toFixed(2)}\\,\\mathrm{m}`);
	});

	it('el panel mueve las cargas (sincronía bidireccional)', () => {
		m = mountLab('physics.two-charges', { x1: -0.8, y1: 0 });
		const slider = m.container.querySelector('[data-param="x1"] input.pl-slider') as HTMLInputElement;
		setInput(slider, '-1.5');
		tick();
		expect(m.lab.store.num('x1')).toBe(-1.5);
		expect(handlePos(role(m.container, 'q1')).x).toBeCloseTo(X(-1.5), 1);
	});

	it('la distancia mínima entre cargas se respeta al arrastrar, con el teclado y desde el panel', () => {
		m = mountLab('physics.two-charges', { x1: -0.8, y1: 0, x2: 0.8, y2: 0 });
		const h1 = role(m.container, 'q1');
		// Encima de q2 y rodeándola.
		drag(h1, handlePos(h1), { x: X(0.8), y: Y(0) }, 12);
		tick();
		expect(dist(m)).toBeGreaterThanOrEqual(0.25 - 1e-9);
		for (const [x, y] of [
			[0.85, 0.1],
			[0.8, 0.2],
			[0.7, -0.05],
			[0.9, -0.1],
		] as const) {
			drag(h1, handlePos(h1), { x: X(x), y: Y(y) }, 4);
			tick();
			expect(dist(m)).toBeGreaterThanOrEqual(0.25 - 1e-9);
		}
		// Teclado: flecha a la derecha hasta chocar con q2.
		m.lab.store.update({ x1: 0, y1: 0 }, 'api');
		for (let i = 0; i < 30; i++) h1.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowRight', bubbles: true }));
		tick();
		expect(dist(m)).toBeGreaterThanOrEqual(0.25 - 1e-9);
		// Panel: x1 = x2 con y1 = y2.
		m.lab.store.update({ x1: -1, y1: 0 }, 'api');
		const num = m.container.querySelector('[data-param="x1"] input.pl-num') as HTMLInputElement;
		setInput(num, '0.8', 'change');
		tick();
		expect(dist(m)).toBeGreaterThanOrEqual(0.25 - 1e-9);
		expect(m.lab.store.num('x1')).toBe(0.55);
		expect(m.container.querySelector('.pl-status')?.textContent).toMatch(/Distancia mínima/);
	});

	it('cambiar el signo de q1 invierte el campo en P (con q2 = 0)', () => {
		m = mountLab('physics.two-charges', { q1: 2, q2: 0, x1: -0.5, y1: 0, xP: 0.4, yP: 0.5 });
		const before = arrowDir(role(m.container, 'E'));
		const slider = m.container.querySelector('[data-param="q1"] input.pl-slider') as HTMLInputElement;
		setInput(slider, '-2');
		tick();
		expect(m.lab.store.num('q1')).toBe(-2);
		const after = arrowDir(role(m.container, 'E'));
		expect(before.x * after.x + before.y * after.y).toBeCloseTo(-1, 3);
		expect(after.len).toBeCloseTo(before.len, 1);
		// q1 negativa: E en P apunta hacia q1 (hacia la izquierda y abajo en el plano).
		expect(after.x).toBeLessThan(0);
	});

	it('el campo en P coincide con el cálculo analítico', () => {
		const q1 = 3;
		const q2 = -2.5;
		m = mountLab('physics.two-charges', { q1, q2, x1: -0.8, y1: 0.1, x2: 0.65, y2: -0.4, xP: 0.2, yP: 0.65 });
		const [ex, ey] = analyticField(
			[
				[-0.8, 0.1, q1 * MICRO],
				[0.65, -0.4, q2 * MICRO],
			],
			0.2,
			0.65,
		);
		const mag = Math.hypot(ex, ey);
		expect(texOf(m.container, 'E')).toBe(`|\\vec E(P)|=${texSI(mag, 'N/C')}`);
		const d = arrowDir(role(m.container, 'E'));
		// En la escena el eje y apunta hacia abajo.
		expect(d.x).toBeCloseTo(ex / mag, 2);
		expect(d.y).toBeCloseTo(-ey / mag, 2);
		const eq = texOf(m.container, 'fieldP');
		const sci = (v: number): string => {
			const e = Math.floor(Math.log10(Math.abs(v)));
			return `${(v / 10 ** e).toFixed(2)}\\times 10^{${e}}`;
		};
		expect(eq).toContain(sci(ex));
		expect(eq).toContain(sci(ey));
		expect(eq).toContain(sci(mag));
		// Arrastrar P cambia el valor.
		const hP = role(m.container, 'P');
		drag(hP, handlePos(hP), { x: X(-1.5), y: Y(-0.9) });
		tick();
		expect(m.lab.store.num('xP')).toBeCloseTo(-1.5, 2);
		expect(texOf(m.container, 'fieldP')).not.toBe(eq);
	});

	it('Coulomb en el laboratorio: q1 = q2 = 1 μC a 1 m → 8.99·10⁻³ N', () => {
		m = mountLab('physics.two-charges', { q1: 1, q2: 1, x1: -0.5, y1: 0, x2: 0.5, y2: 0 });
		expect(texOf(m.container, 'coulomb')).toContain('=8.99\\times 10^{-3}\\,\\mathrm{N}');
		expect(texOf(m.container, 'F')).toBe('F=8.99\\,\\mathrm{mN}\\ (\\text{repulsiva})');
		expect(texOf(m.container, 'coulomb')).toContain('k\\,\\frac{|q_1\\,q_2|}{r^2}');
		expect(texOf(m.container, 'k')).toContain('8.99\\times 10^{9}\\,\\mathrm{N\\,m^2/C^2}');
		// Fuerzas iguales y opuestas, repulsivas.
		const f12 = arrowDir(role(m.container, 'F12'));
		const f21 = arrowDir(role(m.container, 'F21'));
		expect(f12.x).toBeCloseTo(1, 6);
		expect(f21.x).toBeCloseTo(-1, 6);
		expect(f12.len).toBeCloseTo(f21.len, 6);
	});

	it('ningún NaN ni Infinity en el DOM: P dentro de una carga, P muy cerca, cargas nulas', () => {
		// P (0.2, 0.65) por defecto; la carga 1 se coloca encima.
		m = mountLab('physics.two-charges', { x1: 0.2, y1: 0.65 });
		expect(m.lab.store.num('xP')).toBe(0.2);
		expect(texOf(m.container, 'fieldP')).toContain('no definido en la carga } q_1');
		expect(texOf(m.container, 'E')).toContain('no definido');
		expect(m.container.querySelector('[data-label="Emod"]')?.getAttribute('data-tex')).toContain('no definido');
		expect(role(m.container, 'E').getAttribute('display')).toBe('none');
		expect(m.container.querySelector('.pl-status')?.textContent).toMatch(/campo no está definido/);
		expect(domText(m.container)).not.toMatch(/NaN|Infinity/);

		// P alrededor de una carga, tan cerca como permite el almacén.
		const store = m.lab.store;
		store.update({ x1: -0.8, y1: 0, xP: 0, yP: 0 }, 'api');
		for (let a = 0; a < 2 * Math.PI; a += Math.PI / 7) {
			store.update({ xP: -0.8 + 0.1 * Math.cos(a), yP: 0.1 * Math.sin(a) }, 'api');
			tick();
			expect(Math.hypot(store.num('xP') + 0.8, store.num('yP'))).toBeGreaterThanOrEqual(0.1 - 1e-9);
			expect(domText(m.container)).not.toMatch(/NaN|Infinity/);
		}

		// Cargas nulas.
		store.update({ q1: 0, q2: 0 }, 'api');
		tick();
		expect(texOf(m.container, 'F')).toBe('F=0\\,\\mathrm{N}');
		expect(role(m.container, 'F12').getAttribute('display')).toBe('none');
		expect(m.container.querySelector('[data-role="lines"]')?.getAttribute('data-count')).toBe('0');
		expect(m.container.querySelector('.pl-status')?.textContent).toMatch(/nulas/);
		for (const view of ['vectors', 'both', 'lines']) {
			store.set('fieldView', view, 'api');
			tick();
			expect(domText(m.container)).not.toMatch(/NaN|Infinity/);
		}
	});

	it('número de líneas ∝ |q| y selector de representación', () => {
		m = mountLab('physics.two-charges', { q1: 2, q2: 0 });
		const lines = role(m.container, 'lines');
		expect(lines.dataset.count).toBe(String(lineCount(2 * MICRO)));
		m.lab.store.set('q1', 4, 'panel');
		tick();
		expect(lines.dataset.count).toBe(String(2 * lineCount(2 * MICRO)));
		const visibleLines = Array.from(lines.querySelectorAll('.pl-field-line')).filter((p) => p.getAttribute('display') !== 'none');
		expect(visibleLines).toHaveLength(2 * lineCount(2 * MICRO));

		const sel = m.container.querySelector('[data-param="fieldView"] select') as HTMLSelectElement;
		setInput(sel, 'vectors', 'change');
		tick();
		const vectors = role(m.container, 'vectors');
		expect(lines.getAttribute('display')).toBe('none');
		expect(vectors.getAttribute('display')).toBeNull();
		const shown = Array.from(vectors.querySelectorAll('.pl-tc-evec')).filter((p) => p.getAttribute('display') !== 'none');
		expect(shown.length).toBeGreaterThan(120);
		for (const p of shown) {
			const o = Number(p.getAttribute('opacity'));
			expect(o).toBeGreaterThan(0.3);
			expect(o).toBeLessThanOrEqual(1);
		}
		setInput(sel, 'both', 'change');
		tick();
		expect(lines.getAttribute('display')).toBeNull();
		expect(vectors.getAttribute('display')).toBeNull();
	});

	it('los interruptores ocultan fuerzas, P, cota y rejilla', () => {
		m = mountLab('physics.two-charges', { showForces: false, showP: false, showDistance: false, showGrid: false });
		expect(role(m.container, 'F12').getAttribute('display')).toBe('none');
		expect(role(m.container, 'P').getAttribute('display')).toBe('none');
		expect(role(m.container, 'E').getAttribute('display')).toBe('none');
		expect(m.container.querySelector('.pl-tc-dim')?.getAttribute('display')).toBe('none');
		expect(m.container.querySelector('.pl-tc-grid')?.getAttribute('display')).toBe('none');
		expect(m.container.querySelector('[data-eq="fieldP"]')?.classList.contains('pl-hidden')).toBe(true);
		const toggle = m.container.querySelector('[data-param="showP"] input') as HTMLInputElement;
		toggle.checked = true;
		toggle.dispatchEvent(new Event('change', { bubbles: true }));
		tick();
		expect(role(m.container, 'P').getAttribute('display')).toBeNull();
		expect(m.container.querySelector('[data-eq="fieldP"]')?.classList.contains('pl-hidden')).toBe(false);
	});

	it('las ecuaciones usan LaTeX real con unidades', () => {
		m = mountLab('physics.two-charges');
		expect(texOf(m.container, 'superposition')).toContain('\\sum_{i} k\\,\\frac{q_i}{|\\vec r-\\vec r_i|^2}\\,\\hat u_i');
		expect(texOf(m.container, 'distance')).toContain('=1.600\\,\\mathrm{m}');
		expect(m.container.querySelector('[data-label="q1"]')?.getAttribute('data-tex')).toBe('q_1=+3.0\\,\\mu\\mathrm{C}');
		expect(m.container.querySelector('[data-label="q2"]')?.getAttribute('data-tex')).toBe('q_2=-2.0\\,\\mu\\mathrm{C}');
		expect(texOf(m.container, 'F')).toContain('atractiva');
	});

	it('restablecer vuelve a los valores del bloque', () => {
		m = mountLab('physics.two-charges', { x1: -1, q2: 1.5 });
		m.lab.store.update({ x1: 0.3, y1: 0.9, q2: -4 }, 'panel');
		(m.container.querySelector('.pl-tool-reset') as HTMLButtonElement).click();
		tick();
		expect(m.lab.store.num('x1')).toBe(-1);
		expect(m.lab.store.num('y1')).toBe(0);
		expect(m.lab.store.num('q2')).toBe(1.5);
	});

	it('no deja recursos vivos tras destruirse', () => {
		const base = ResourceScope.live;
		const labs = [mountLab('physics.two-charges'), mountLab('physics.two-charges', { fieldView: 'both', q1: -5 })];
		expect(liveInstances.size).toBe(2);
		expect(ResourceScope.live).toBeGreaterThan(base);
		for (const l of labs) l.cleanup();
		expect(ResourceScope.live).toBe(base);
		expect(liveInstances.size).toBe(0);
		expect(labs[0]!.lab.store.listenerCount).toBe(0);
		m = mountLab('physics.two-charges');
	});
});
