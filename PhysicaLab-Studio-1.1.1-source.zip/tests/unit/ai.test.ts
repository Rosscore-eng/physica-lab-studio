import { spawnSync } from 'node:child_process';
import * as childProcess from 'node:child_process';
import * as fs from 'node:fs';
import * as os from 'node:os';
import * as path from 'node:path';
import { fileURLToPath } from 'node:url';
import { describe, expect, it } from 'vitest';
import { parse } from 'yaml';
import {
	buildCatalog,
	createProviders,
	DEFAULT_AI_SETTINGS,
	DesktopBridge,
	generateOffline,
	validateGenerated,
	type GenerationResult,
	type NodeApi,
} from '../../src/ai';
import { extractQuantities } from '../../src/ai/units';
import type { PresetDefinition } from '../../src/core/preset';
import { PresetRegistry } from '../../src/core/registry';
import { ID_PATTERN, parseLabSource } from '../../src/core/schema';
import type { ParamSpec } from '../../src/core/types';
import { createBuiltinRegistry } from '../../src/presets';
import { secantTangentPreset } from '../../src/presets/math/secant-tangent';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
const HELPER = path.join(ROOT, 'helper', 'physlab-helper.mjs');

/* ── Presets de prueba (independientes de las fases en curso) ── */

function fixture(id: string, title: string, params: ParamSpec[], keywords: string[] = []): PresetDefinition {
	const [mode] = id.split('.') as [PresetDefinition['mode']];
	return {
		id,
		version: 1,
		mode,
		title,
		summary: `${title} (prueba).`,
		keywords,
		params,
		fidelity: 'Prueba.',
		create: () => ({ render() {} }),
	};
}

const pendulum = fixture(
	'physics.pendulum',
	'Péndulo simple',
	[
		{ id: 'L', type: 'number', name: 'Longitud del hilo', label: 'L', initial: 1, min: 0.1, max: 3, step: 0.01, unit: '\\mathrm{m}', unitText: 'm' },
		{ id: 'theta0', type: 'number', name: 'Ángulo inicial', label: '\\theta_0', initial: 20, min: -80, max: 80, step: 1, unit: '^\\circ', unitText: '°' },
		{ id: 'g', type: 'number', name: 'Gravedad', label: 'g', initial: 9.81, min: 1, max: 25, step: 0.01, unitText: 'm/s²' },
		{ id: 'showVectors', type: 'boolean', name: 'Mostrar vectores de fuerza', initial: false },
	],
	['péndulo', 'oscilación', 'periodo'],
);

const charges = fixture(
	'physics.two-charges',
	'Dos cargas eléctricas',
	[
		{ id: 'q1', type: 'number', name: 'Carga 1', label: 'q_1', initial: 2, min: -10, max: 10, step: 0.1, unit: '\\mu\\mathrm{C}', unitText: 'μC' },
		{ id: 'q2', type: 'number', name: 'Carga 2', label: 'q_2', initial: -2, min: -10, max: 10, step: 0.1, unit: '\\mu\\mathrm{C}', unitText: 'μC' },
		{ id: 'd', type: 'number', name: 'Separación entre las cargas', label: 'd', initial: 1, min: 0.1, max: 2, step: 0.01, unitText: 'm' },
		{ id: 'showField', type: 'boolean', name: 'Líneas de campo', initial: true },
	],
	['campo eléctrico', 'coulomb'],
);

const rc = fixture(
	'circuits.rc-charging',
	'Circuito RC (carga)',
	[
		{ id: 'R', type: 'number', name: 'Resistencia', label: 'R', initial: 10, min: 0.1, max: 100, step: 0.1, unitText: 'kΩ' },
		{ id: 'C', type: 'number', name: 'Capacidad', label: 'C', initial: 100, min: 1, max: 1000, step: 1, unitText: 'μF' },
		{ id: 'V0', type: 'number', name: 'Tensión de la fuente', label: 'V_0', initial: 5, min: 1, max: 24, step: 0.5, unitText: 'V' },
		{
			id: 'process',
			type: 'enum',
			name: 'Proceso',
			initial: 'charge',
			options: [
				{ value: 'charge', label: 'Carga' },
				{ value: 'discharge', label: 'Descarga' },
			],
		},
	],
	['condensador', 'RC'],
);

function fixtureRegistry(): PresetRegistry {
	const r = new PresetRegistry();
	for (const p of [secantTangentPreset, pendulum, charges, rc]) r.register(p);
	return r;
}

const gen = (prompt: string, registry = fixtureRegistry()): GenerationResult => generateOffline({ prompt }, registry);

/* ── Catálogo ─────────────────────────────────────────────── */

function hasFunction(v: unknown): boolean {
	if (typeof v === 'function') return true;
	if (Array.isArray(v)) return v.some(hasFunction);
	if (v && typeof v === 'object') return Object.values(v).some(hasFunction);
	return false;
}

describe('buildCatalog', () => {
	it('describe los presets solo con datos (sin funciones)', () => {
		const cat = buildCatalog(fixtureRegistry());
		expect(hasFunction(cat)).toBe(false);
		expect(JSON.parse(JSON.stringify(cat))).toEqual(cat);
		expect(cat.map((e) => e.id)).toEqual(['math.secant-tangent', 'physics.pendulum', 'physics.two-charges', 'circuits.rc-charging']);
		const sec = cat[0];
		expect(sec?.mode).toBe('math');
		expect(sec?.keywords).toContain('derivada');
		expect(sec?.params.find((p) => p.id === 'h')).toMatchObject({ type: 'number', min: -2, max: 2 });
		expect(cat[2]?.params.find((p) => p.id === 'q1')?.unit).toBe('μC');
		expect(cat[3]?.params.find((p) => p.id === 'process')?.options).toEqual(['charge', 'discharge']);
	});
	it('filtra por modo y funciona con los presets incluidos', () => {
		expect(buildCatalog(fixtureRegistry(), 'circuits').map((e) => e.id)).toEqual(['circuits.rc-charging']);
		expect(hasFunction(buildCatalog(createBuiltinRegistry()))).toBe(false);
	});
});

/* ── Magnitudes con unidades ─────────────────────────────── */

describe('extractQuantities', () => {
	it('reconoce unidades, prefijos, coma decimal y símbolos', () => {
		const q = extractQuantities('q1 = 3 μC, carga de -2 uC, L = 1,5 m, longitud 80 cm, ángulo de 30°, R = 10 kΩ, C = 220 uF, g = 1.62');
		const byRaw = Object.fromEntries(q.map((x) => [x.raw, x]));
		expect(byRaw['3 uC']).toMatchObject({ dim: 'charge', symbol: 'q1' });
		expect(byRaw['3 uC']?.value).toBeCloseTo(3e-6);
		expect(byRaw['-2 uC']?.value).toBeCloseTo(-2e-6);
		expect(byRaw['-2 uC']?.hints).toContain('carga');
		expect(byRaw['1,5 m']).toMatchObject({ value: 1.5, dim: 'length', symbol: 'L' });
		expect(byRaw['80 cm']?.value).toBeCloseTo(0.8);
		expect(byRaw['80 cm']?.hints).toContain('longitud');
		expect(byRaw['30°']).toMatchObject({ value: 30, dim: 'angle' });
		expect(byRaw['10 kohm']).toMatchObject({ value: 10000, dim: 'resistance', symbol: 'R' });
		expect(byRaw['220 uF']?.value).toBeCloseTo(220e-6);
		expect(byRaw['1.62']).toMatchObject({ value: 1.62, dim: null, symbol: 'g' });
	});
	it('entiende «10k», «4k7», notación científica y radianes', () => {
		const q = extractQuantities('10k, 4k7, 3×10⁻⁶ C, 0,5 rad, 2 segundos');
		expect(q.map((x) => x.value)).toEqual([10000, 4700, expect.closeTo(3e-6, 12), expect.closeTo(28.6479, 3), 2]);
		expect(q[0]?.guessed).toBe(true);
		expect(q[4]?.dim).toBe('time');
	});
	it('ignora números que forman parte de identificadores, exponentes o palabras', () => {
		expect(extractQuantities('f(x) = x^2 en 3D con q1 y x0')).toEqual([]);
		expect(extractQuantities('cuando h tiende a 0')).toEqual([]);
	});
});

/* ── Generador sin IA: elección del preset ───────────────── */

const PHRASES: Array<[string, string]> = [
	['Crea un diagrama interactivo del campo eléctrico de dos cargas; quiero arrastrarlas y controlar sus magnitudes', 'physics.two-charges'],
	['Péndulo simple de L = 1,5 m y ángulo de 30°', 'physics.pendulum'],
	['simple pendulum with length 80 cm on the Moon', 'physics.pendulum'],
	['Carga de un condensador de 220 uF a través de R = 10 kΩ', 'circuits.rc-charging'],
	['circuito RC con 10k y 100 nF', 'circuits.rc-charging'],
	['derivada de x^2 como límite de la secante en x0=1', 'math.secant-tangent'],
	['Quiero ver la recta tangente a una parábola', 'math.secant-tangent'],
	['dipolo eléctrico con q1 = 3 μC y q2 = -2 µC', 'physics.two-charges'],
	['Ley de Coulomb entre dos cargas puntuales', 'physics.two-charges'],
	['periodo de oscilación de un péndulo con la gravedad de la Luna', 'physics.pendulum'],
	['constante de tiempo tau de la descarga de un capacitor', 'circuits.rc-charging'],
	['pendiente de la secante cuando h tiende a 0', 'math.secant-tangent'],
	['electric field lines of two point charges', 'physics.two-charges'],
	['capacitor charging curve and time constant', 'circuits.rc-charging'],
	['Cociente incremental y derivada como límite', 'math.secant-tangent'],
];

describe('generateOffline: elección del preset', () => {
	it.each(PHRASES)('«%s» → %s', (prompt, expected) => {
		const r = gen(prompt);
		expect(r.ok).toBe(true);
		expect(r.supported).toBe(true);
		expect(r.provider).toBe('offline');
		expect(r.config?.preset).toBe(expected);
		expect(r.block).toContain(`preset: ${expected}`);
	});
	it.each(PHRASES)('con los presets incluidos: «%s» → %s', (prompt, expected) => {
		const r = gen(prompt, createBuiltinRegistry());
		expect(r.config?.preset).toBe(expected);
	});
	it('respeta el modo preferido', () => {
		const r = generateOffline({ prompt: 'curva de carga', mode: 'circuits' }, fixtureRegistry());
		expect(r.config?.preset).toBe('circuits.rc-charging');
	});
	it('es determinista (mismo texto, mismo bloque e id)', () => {
		const a = gen('Péndulo de 2 m en Marte');
		const b = gen('Péndulo de 2 m en Marte');
		expect(a.block).toBe(b.block);
		expect(a.config?.id).toMatch(ID_PATTERN);
	});
	it('rechaza descripciones vacías o demasiado largas', () => {
		expect(gen('   ').ok).toBe(false);
		expect(gen('péndulo '.repeat(600)).ok).toBe(false);
	});
});

/* ── Generador sin IA: parámetros ────────────────────────── */

describe('generateOffline: parámetros con unidades', () => {
	it('péndulo: L con coma decimal y ángulo en grados', () => {
		const r = gen('Péndulo simple de L = 1,5 m y ángulo de 30°');
		expect(r.config?.parameters).toEqual({ L: 1.5, theta0: 30 });
		expect(r.explanation).toContain('L = 1.5 m');
	});
	it('péndulo: centímetros y gravedad de la Luna', () => {
		const r = gen('simple pendulum with length 80 cm on the Moon');
		expect(r.config?.parameters).toEqual({ L: 0.8, g: 1.62 });
	});
	it('péndulo: g sin unidad, longitud y radianes convertidos a grados', () => {
		expect(gen('péndulo con g = 1.62 y longitud 2 m').config?.parameters).toEqual({ g: 1.62, L: 2 });
		expect(gen('péndulo con amplitud de 0,5 rad').config?.parameters).toEqual({ theta0: 29 });
	});
	it('cargas: símbolos, μ/u, signo y separación en cm', () => {
		const r = gen('dipolo: q1 = 3 μC, q2 = -2 uC separadas 50 cm');
		expect(r.config?.parameters).toEqual({ q1: 3, q2: -2, d: 0.5 });
	});
	it('cargas: orden («una … y otra …») sin símbolos', () => {
		const r = gen('dos cargas: una carga de 3 uC y otra de -2 uC');
		expect(r.config?.parameters).toEqual({ q1: 3, q2: -2 });
	});
	it('RC: kΩ, uF y voltios en las unidades del preset', () => {
		const r = gen('Carga de un condensador C = 220 uF con R = 10 kΩ y una batería de 9 V');
		expect(r.config?.parameters).toEqual({ C: 220, R: 10, V0: 9 });
	});
	it('RC: «10k» y valores fuera de rango (se ajustan con aviso)', () => {
		const r = gen('circuito RC con 10k y 100 nF');
		expect(r.config?.parameters).toEqual({ R: 10, C: 1 });
		expect(r.warnings.join(' ')).toMatch(/fuera de \[1, 1000\]/);
	});
	it('secante: x0 y h con coma decimal', () => {
		const r = gen('derivada con la secante en x0=1 y h = 0,5');
		expect(r.config?.parameters).toEqual({ x0: 1, h: 0.5 });
	});
	it('avisa de magnitudes que no encajan en el preset', () => {
		const r = gen('péndulo de 2 m con una masa de 3 kg');
		expect(r.config?.parameters).toEqual({ L: 2 });
		expect(r.warnings.join(' ')).toContain('3 kg');
	});
	it('interruptores y parámetros booleanos desde el texto', () => {
		const r = gen('Péndulo sin ecuaciones, con panel plegado y mostrar vectores');
		expect(r.config?.explicitFeatures).toEqual({ equations: false, controlsCollapsed: true });
		expect(r.config?.parameters.showVectors).toBe(true);
		expect(r.block).toContain('equations: false');
		expect(gen('dos cargas sin líneas de campo').config?.parameters.showField).toBe(false);
	});
	it('el bloque generado se vuelve a leer igual', () => {
		const r = gen('Péndulo simple de L = 1,5 m y ángulo de 30°');
		const src = (r.block ?? '').replace(/^```physlab\n|```\n?$/g, '');
		const back = parseLabSource(src, parse);
		expect(back.errors).toEqual([]);
		expect(back.config?.preset).toBe('physics.pendulum');
		expect(back.config?.parameters).toEqual({ L: 1.5, theta0: 30 });
		expect(back.config?.id).toBe(r.config?.id);
	});
});

/* ── Generador sin IA: fuera de alcance ──────────────────── */

describe('generateOffline: peticiones fuera de alcance', () => {
	it('circuito RLC: no se finge; propone el RC', () => {
		const r = gen('Quiero un circuito RLC en serie con una bobina de 10 mH');
		expect(r.ok).toBe(true);
		expect(r.supported).toBe(false);
		expect(r.block).toBeNull();
		expect(r.limitations.join(' ')).toMatch(/inductancias/);
		expect(r.alternatives).toContain('circuits.rc-charging');
	});
	it('péndulo doble: propone el péndulo simple', () => {
		const r = gen('péndulo doble caótico');
		expect(r.supported).toBe(false);
		expect(r.alternatives).toEqual(['physics.pendulum']);
	});
	it('fluidos y simulación molecular: sin preset', () => {
		for (const p of ['flujo de un fluido en una tubería (Bernoulli)', 'simulación molecular de un gas ideal']) {
			const r = gen(p);
			expect(r.supported).toBe(false);
			expect(r.limitations.length).toBeGreaterThan(0);
			expect(r.config).toBeNull();
		}
	});
	it('3D: genera el más cercano y lo declara como limitación', () => {
		const r = gen('simulación 3D de un péndulo de 2 m');
		expect(r.supported).toBe(true);
		expect(r.config?.preset).toBe('physics.pendulum');
		expect(r.config?.parameters).toEqual({ L: 2 });
		expect(r.limitations.join(' ')).toMatch(/3D/);
	});
	it('texto sin relación: no inventa un preset', () => {
		const r = gen('receta de tortilla de patatas');
		expect(r.supported).toBe(false);
		expect(r.limitations[0]).toMatch(/no coincide/);
		expect(r.alternatives.length).toBeGreaterThan(0);
	});
	it('no marca como limitación algo que un preset del registro ya ofrece', () => {
		const reg = fixtureRegistry();
		reg.register(fixture('physics.double-pendulum', 'Péndulo doble', [], ['péndulo doble']));
		const r = gen('péndulo doble caótico', reg);
		expect(r.supported).toBe(true);
		expect(r.config?.preset).toBe('physics.double-pendulum');
	});
});

/* ── Validación de salidas ───────────────────────────────── */

describe('validateGenerated', () => {
	const reg = fixtureRegistry();
	const ok = (raw: unknown): GenerationResult => validateGenerated(raw, reg, 'claude-cli', { random: () => 0.5 });

	it('acepta una salida correcta y genera bloque e id', () => {
		const r = ok({ supported: true, preset: 'physics.pendulum', title: 'Péndulo lunar', parameters: { L: 1.2, g: 1.62 }, explanation: 'Péndulo.' });
		expect(r.ok).toBe(true);
		expect(r.provider).toBe('claude-cli');
		expect(r.config?.parameters).toEqual({ L: 1.2, g: 1.62 });
		expect(r.config?.id).toMatch(/^pendulo-lunar-[a-z0-9]{4}$/);
		expect(r.block).toMatch(/^```physlab\nid: pendulo-lunar-/);
		expect(r.warnings).toEqual([]);
	});
	it('rechaza presets inexistentes', () => {
		const r = ok({ supported: true, preset: 'physics.rocket', parameters: {} });
		expect(r.ok).toBe(false);
		expect(r.error).toMatch(/no existe/);
		expect(r.block).toBeNull();
	});
	it.each(['script', 'html', 'js', 'Inner_HTML', 'onload', 'code'])('rechaza la clave de código «%s»', (key) => {
		const r = ok({ supported: true, preset: 'physics.pendulum', parameters: { L: 1 }, [key]: 'alert(1)' });
		expect(r.ok).toBe(false);
		expect(r.error).toMatch(/código/);
	});
	it('rechaza código anidado, marcado ejecutable y __proto__', () => {
		expect(ok({ supported: true, preset: 'physics.pendulum', parameters: { js: 'x' } }).ok).toBe(false);
		expect(ok({ supported: true, preset: 'physics.pendulum', features: { html: true } }).ok).toBe(false);
		expect(ok({ supported: true, preset: 'physics.pendulum', title: '<script>alert(1)</script>' }).ok).toBe(false);
		expect(ok({ supported: true, preset: 'physics.pendulum', explanation: 'ver javascript:alert(1)' }).ok).toBe(false);
		expect(ok(JSON.parse('{"supported":true,"preset":"physics.pendulum","__proto__":{"x":1}}')).ok).toBe(false);
		expect(ok({ supported: true, preset: 'physics.pendulum', parameters: { L: () => 1 } }).ok).toBe(false);
	});
	it('ajusta valores fuera de rango y avisa', () => {
		const r = ok({ supported: true, preset: 'physics.pendulum', parameters: { L: 50, theta0: -200 } });
		expect(r.ok).toBe(true);
		expect(r.config?.parameters).toEqual({ L: 3, theta0: -80 });
		expect(r.warnings.filter((w) => w.includes('fuera de'))).toHaveLength(2);
	});
	it('descarta tipos incorrectos con aviso', () => {
		const r = ok({
			supported: true,
			preset: 'physics.pendulum',
			parameters: { L: 'largo', theta0: '12,5', showVectors: 'yes', g: { v: 1 }, inventado: 3 },
			features: { controls: 'no', latex: false, magic: true },
		});
		expect(r.ok).toBe(true);
		expect(r.config?.parameters).toEqual({ theta0: 13 });
		expect(r.config?.explicitFeatures).toEqual({ latex: false });
		const w = r.warnings.join(' | ');
		expect(w).toMatch(/«L» debe ser numérico/);
		expect(w).toMatch(/«showVectors» debe ser true o false/);
		expect(w).toMatch(/«g» debe ser numérico/);
		expect(w).toMatch(/no tiene el parámetro «inventado»/);
		expect(w).toMatch(/features\.controls/);
		expect(w).toMatch(/magic/);
	});
	it('enum: acepta valor o etiqueta y rechaza el resto', () => {
		expect(ok({ supported: true, preset: 'circuits.rc-charging', parameters: { process: 'Descarga' } }).config?.parameters).toEqual({ process: 'discharge' });
		const r = ok({ supported: true, preset: 'circuits.rc-charging', parameters: { process: 'boom' } });
		expect(r.config?.parameters).toEqual({});
		expect(r.warnings.join(' ')).toMatch(/admite: charge, discharge/);
	});
	it('acepta parámetros como lista de pares (esquema estricto de Codex) y texto JSON', () => {
		const r = validateGenerated(
			'```json\n{"supported":true,"preset":"physics.two-charges","parameters":[{"name":"q1","value":4}],"features":{"latex":null}}\n```',
			reg,
			'codex-cli',
		);
		expect(r.ok).toBe(true);
		expect(r.config?.parameters).toEqual({ q1: 4 });
	});
	it('supported:false se devuelve sin bloque, con alternativas válidas', () => {
		const r = ok({ supported: false, preset: '', limitations: ['No hay fluidos.'], alternatives: ['physics.pendulum', 'physics.rocket'] });
		expect(r.ok).toBe(true);
		expect(r.supported).toBe(false);
		expect(r.block).toBeNull();
		expect(r.alternatives).toEqual(['physics.pendulum']);
		expect(r.warnings.join(' ')).toMatch(/physics\.rocket/);
	});
	it('rechaza lo que no es un objeto y avisa de claves desconocidas', () => {
		expect(ok('no es json').ok).toBe(false);
		expect(ok([1, 2]).ok).toBe(false);
		expect(ok({ supported: true, preset: 'physics.pendulum', mood: 'feliz' }).warnings.join(' ')).toMatch(/mood/);
	});
});

/* ── Proveedores y programa auxiliar ─────────────────────── */

function runHelper(args: string[], input?: string): { status: number | null; out: Record<string, unknown>; lines: number } {
	const r = spawnSync(process.execPath, [HELPER, ...args], { input: input ?? '', encoding: 'utf8', timeout: 20_000 });
	const lines = r.stdout.split(/\r?\n/).filter((l) => l.trim() !== '');
	return { status: r.status, out: JSON.parse(lines[lines.length - 1] ?? '{}') as Record<string, unknown>, lines: lines.length };
}

const nodeApi: NodeApi = { child_process: childProcess, fs, path, os, process };

describe('proveedores', () => {
	it('createProviders: siempre offline; en escritorio añade las CLI', async () => {
		const reg = fixtureRegistry();
		const mobile = createProviders({ registry: reg, settings: DEFAULT_AI_SETTINGS, desktop: null });
		expect(mobile.map((p) => p.id)).toEqual(['offline']);
		expect((await mobile[0]?.detect())?.available).toBe(true);
		const desktop = createProviders({ registry: reg, settings: DEFAULT_AI_SETTINGS, desktop: { pluginDir: ROOT, vaultDir: ROOT } });
		expect(desktop.map((p) => p.id)).toEqual(['offline', 'claude-cli', 'codex-cli']);
		const r = await mobile[0]?.generate({ prompt: 'péndulo de 1 m' });
		expect(r?.config?.parameters).toEqual({ L: 1 });
	});
	it('el puente lleva la petición al auxiliar y devuelve su error sin llamar a ninguna CLI', async () => {
		const bridge = new DesktopBridge({ pluginDir: ROOT, vaultDir: ROOT }, nodeApi);
		const missing = path.join(os.tmpdir(), 'physlab-no-existe', process.platform === 'win32' ? 'claude.exe' : 'claude');
		const res = await bridge.run({
			version: 1,
			provider: 'claude',
			prompt: 'péndulo',
			catalog: buildCatalog(fixtureRegistry()),
			cliPath: missing,
			timeoutSec: 10,
		});
		expect(res.ok).toBe(false);
		expect(res.error).toMatch(/No existe/);
		const ctrl = new AbortController();
		ctrl.abort();
		const cancelled = await bridge.run({ version: 1, provider: 'codex', prompt: 'x', catalog: [], timeoutSec: 10 }, ctrl.signal);
		expect(cancelled.error).toMatch(/cancelada/);
	});
});

describe('helper/physlab-helper.mjs', () => {
	it('--self-test pasa sin llamar a ninguna CLI', () => {
		const r = runHelper(['--self-test']);
		expect(r.status).toBe(0);
		expect(r.out.ok).toBe(true);
		expect(r.out.failed).toBe(0);
	});
	const valid = {
		version: 1,
		provider: 'claude',
		prompt: 'péndulo',
		catalog: [{ id: 'physics.pendulum', mode: 'physics', title: 'Péndulo', summary: '', keywords: [], params: [] }],
		timeoutSec: 10,
	};
	it.each([
		['JSON roto', '{"version":1,'],
		['no es un objeto', '[1,2,3]'],
		['clave desconocida', JSON.stringify({ ...valid, shell: 'calc.exe' })],
		['proveedor desconocido', JSON.stringify({ ...valid, provider: 'bash' })],
		['prompt vacío', JSON.stringify({ ...valid, prompt: '  ' })],
		['catálogo vacío', JSON.stringify({ ...valid, catalog: [] })],
		['ruta relativa', JSON.stringify({ ...valid, cliPath: 'claude' })],
		['modelo con metacaracteres', JSON.stringify({ ...valid, model: 'opus && calc' })],
		['tiempo límite absurdo', JSON.stringify({ ...valid, timeoutSec: 0 })],
	])('rechaza una petición mal formada: %s', (_name, input) => {
		const r = runHelper([], input);
		expect(r.status).toBe(1);
		expect(r.lines).toBe(1);
		expect(r.out.ok).toBe(false);
		expect(typeof r.out.error).toBe('string');
		expect(typeof r.out.durationMs).toBe('number');
	});
	it('rechaza una petición demasiado grande', () => {
		const r = runHelper([], JSON.stringify({ ...valid, prompt: 'x'.repeat(600 * 1024) }));
		expect(r.out.ok).toBe(false);
	});
});
