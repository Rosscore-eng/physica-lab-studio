import { afterEach, describe, expect, it, vi } from 'vitest';
import { runInNewContext } from 'node:vm';
import { isRuntimeSource, parseRuntimeSource, type RuntimeManifest } from '../../src/runtime/manifest';
import { buildFrameDocument } from '../../src/runtime/document';
import { RuntimeFrame } from '../../src/runtime/frame';

const manifest: RuntimeManifest = {
	version: 1, id: 'open-lab', file: 'PhysicaLab/labs/open.html', height: 520,
	features: ['2d', 'latex'], initialState: { n: 4 },
};

/** Execute the generated document's actual scripts, without pretending jsdom enforces CSP. */
function runDocument(html: string): { context: Record<string, unknown>; sent: Array<Record<string, unknown>>; listeners: Map<string, Array<(event: unknown) => void>>; parsed: Document } {
	const parsed = new DOMParser().parseFromString(html, 'text/html');
	const sent: Array<Record<string, unknown>> = [];
	const listeners = new Map<string, Array<(event: unknown) => void>>();
	const context: Record<string, unknown> = {
		document: parsed,
		parent: { postMessage: (message: Record<string, unknown>) => sent.push(message) },
		console, TextEncoder,
		addEventListener: (type: string, callback: (event: unknown) => void) => {
			listeners.set(type, [...(listeners.get(type) ?? []), callback]);
		},
	};
	context.window = context;
	for (const script of parsed.querySelectorAll('script')) runInNewContext(script.textContent ?? '', context);
	const inner = parsed.querySelector('iframe');
	if (inner?.srcdoc) return runDocument(inner.srcdoc);
	return { context, sent, listeners, parsed };
}

describe('physlab/v1 manifest', () => {
	it('accepts an external HTML lab without registering its subject', () => {
		expect(parseRuntimeSource(JSON.stringify(manifest))).toEqual({ manifest });
		expect(isRuntimeSource(JSON.stringify(manifest))).toBe(true);
		expect(isRuntimeSource('preset: physics.pendulum')).toBe(false);
		expect(isRuntimeSource('{"version":2,"id":"future"}')).toBe(true);
	});
	it('parses the mandatory inline header and preserves original HTML', () => {
		const source = '<!-- physlab:v1 {"id":"novel","features":["3d","latex"]} -->\n<div>Original</div><script>window.model=1;</script>';
		const result = parseRuntimeSource(source);
		expect(result.manifest).toMatchObject({ version: 1, id: 'novel', height: 520, features: ['3d', 'latex'], initialState: {} });
		expect(result.html).toBe('<div>Original</div><script>window.model=1;</script>');
	});
	it.each(['../out.html', 'labs/../out.html', 'labs/./x.html', '/x.html', 'C:/x.html', 'labs\\x.html', 'https://host/x.html', '//host/x.html', 'labs/%2e%2e/x.html', 'labs//x.html', 'labs/x.svg', 'labs/x.html?x=1', 'labs/.. /x.html', 'labs /x.html', 'labs./x.html'])('rejects unsafe or non-HTML path %s', file => {
		expect(() => parseRuntimeSource(JSON.stringify({ ...manifest, file }))).toThrow();
	});
	it.each([
		{ version: 2 }, { id: '' }, { id: 'x\nspoof' }, { height: 199 }, { height: 1601 },
		{ features: ['preset-name'] }, { initialState: [] }, { theme: 'unknown' },
	])('rejects malformed contract field %j', patch => {
		expect(() => parseRuntimeSource(JSON.stringify({ ...manifest, ...patch }))).toThrow();
	});
	it('rejects state too large to persist and prototype keys', () => {
		expect(() => parseRuntimeSource(JSON.stringify({ ...manifest, initialState: { text: 'x'.repeat(32768) } }))).toThrow();
		expect(() => parseRuntimeSource('{"version":1,"id":"bad","file":"x.html","initialState":{"__proto__":{"pwn":1}}}')).toThrow();
	});
	it('measures state limits in UTF-8 bytes and accepts mixed-case HTML extensions', () => {
		expect(parseRuntimeSource(JSON.stringify({ ...manifest, file: 'labs/Mesh.HtMl' })).manifest.file).toBe('labs/Mesh.HtMl');
		expect(() => parseRuntimeSource(JSON.stringify({ ...manifest, initialState: { text: '界'.repeat(12000) } }))).toThrow();
	});
});

describe('sandbox document', () => {
	it('loads the bridge, requested local libraries and initial state before original lab code', () => {
		const html = buildFrameDocument({
			html: '<!doctype html><html><head><title>Original</title></head><body><script>window.observed={n:PhysLab.initialState.n,version:PhysLab.apiVersion,katex:!!PhysLab.libs.katex,three:!!PhysLab.libs.THREE};PhysLab.saveState({n:8});</script></body></html>',
			manifest, initialState: { n: 7 }, frameId: 'f1', nonce: 'secret',
			bundles: { katexJs: 'window.katex={render:function(){}};', katexCss: '.katex{font-family:KaTeX_Main}', threeJs: 'window.THREE={};' },
		});
		const { context, sent, parsed } = runDocument(html);
		expect(context.observed).toEqual({ n: 7, version: 1, katex: true, three: false });
		expect(sent).toContainEqual({ ns: 'physlab', v: 1, frameId: 'f1', nonce: 'secret', type: 'STATE_SAVE', payload: { n: 8 } });
		const policy = parsed.head.firstElementChild!;
		expect(policy.getAttribute('http-equiv')).toBe('Content-Security-Policy');
		expect(policy.getAttribute('content')).toContain("connect-src 'none'");
		expect(policy.getAttribute('content')).not.toContain('unsafe-eval');
	});
	it('escapes serialized closing tags and preserves executable vendor strings', () => {
		const html = buildFrameDocument({
			html: '<script>window.safe=PhysLab.initialState.text;window.vendorText=PhysLab.libs.katex.text;</script>', manifest,
			initialState: { text: '</script><script>window.injected=true;</script>' }, frameId: 'f', nonce: 'n',
			bundles: { katexJs: 'window.katex={text:"</script>"};' },
		});
		const { context } = runDocument(html);
		expect(context.safe).toBe('</script><script>window.injected=true;</script>');
		expect(context.vendorText).toBe('</script>');
		expect(context.injected).toBeUndefined();
	});
	it('exposes resolved appearance and local LaTeX body font', () => {
		const html = buildFrameDocument({ html: '<script>window.theme=PhysLab.theme;</script>', manifest, initialState: {}, frameId: 'f', nonce: 'n', bundles: {}, appearance: { tokens: { bg: '#fff', text: '#111' }, fontFamily: 'KaTeX_Main, serif' } });
		const { context, parsed } = runDocument(html);
		expect(context.theme).toMatchObject({ tokens: { bg: '#fff', text: '#111' }, fontFamily: 'KaTeX_Main, serif' });
		expect(parsed.querySelector('style')?.textContent).toContain('--pl-bg:#fff');
		expect(parsed.querySelector('style')?.textContent).toContain('font-family:KaTeX_Main, serif');
	});
	it('dispatches host lifecycle events only for authenticated parent messages', () => {
		const html = buildFrameDocument({ html: '<script>window.pauses=0;PhysLab.on("pause",()=>window.pauses++);</script>', manifest, initialState: {}, frameId: 'f', nonce: 'n', bundles: {} });
		const { context, listeners } = runDocument(html);
		const message = { ns: 'physlab', v: 1, frameId: 'f', nonce: 'n', type: 'PAUSE' };
		for (const callback of listeners.get('message') ?? []) {
			callback({ source: {}, data: message });
			callback({ source: context.parent, data: { ...message, nonce: 'wrong' } });
			callback({ source: context.parent, data: message });
		}
		expect(context.pauses).toBe(1);
	});
	it('makes both compatible local 3D globals available to an original lab', () => {
		const html = buildFrameDocument({ html: '<script>window.sceneVersion=PhysLab.libs.THREE.REVISION;window.orbitWorks=typeof PhysLab.libs.OrbitControls;</script>', manifest: { ...manifest, features: ['3d'] }, initialState: {}, frameId: 'f', nonce: 'n', bundles: { threeJs: 'window.THREE={REVISION:"pinned"};window.OrbitControls=function(){};' } });
		const { context } = runDocument(html);
		expect(context.sceneVersion).toBe('pinned');
		expect(context.orbitWorks).toBe('function');
	});
});

describe('runtime frame host', () => {
	const frames: RuntimeFrame[] = [];
	afterEach(() => { for (const frame of frames.splice(0)) frame.destroy(); document.body.replaceChildren(); vi.restoreAllMocks(); });
	function mount() {
		const container = document.createElement('div'); document.body.appendChild(container);
		const onState = vi.fn(); const onError = vi.fn();
		const frame = new RuntimeFrame(container, { html: '<p>lab</p>', manifest, initialState: { n: 6 }, bundles: {}, onState, onError });
		frames.push(frame);
		const ready = runDocument(frame.iframe.srcdoc).sent.find(message => message.type === 'READY')!;
		const send = (type: string, payload: unknown, patch: Record<string, unknown> = {}, source: MessageEventSource | null = frame.iframe.contentWindow) => {
			window.dispatchEvent(new MessageEvent('message', { source, data: { ...ready, type, payload, ...patch } }));
		};
		return { frame, onState, onError, send };
	}
	it('isolates the document and accepts state only from its authenticated frame', () => {
		const { frame, onState, send } = mount();
		expect(frame.iframe.getAttribute('sandbox')).toBe('allow-scripts');
		expect(frame.snapshot()).toEqual({ n: 6 });
		send('STATE_SAVE', { n: 9 }, {}, window);
		send('STATE_SAVE', { n: 9 }, { nonce: 'spoof' });
		send('STATE_SAVE', { n: 9 }, { v: 2 });
		expect(onState).not.toHaveBeenCalled();
		send('STATE_SAVE', { n: 9 });
		expect(frame.snapshot()).toEqual({ n: 9 });
		expect(onState).toHaveBeenCalledWith({ n: 9 });
		const snapshot = frame.snapshot(); snapshot.n = 100;
		expect(frame.snapshot()).toEqual({ n: 9 });
	});
	it('rejects non-JSON, nested invalid values and oversized state', () => {
		const { frame, send, onState } = mount();
		for (const value of [[], { n: Infinity }, { nested: undefined }, { n: new Date() }, { text: 'x'.repeat(32768) }, JSON.parse('{"__proto__":{"x":1}}')]) send('STATE_SAVE', value);
		expect(onState).not.toHaveBeenCalled();
		expect(frame.snapshot()).toEqual({ n: 6 });
	});
	it('rejects envelopes with additional unvalidated properties', () => {
		const { frame, send, onState } = mount();
		send('STATE_SAVE', { n: 9 }, { unexpected: 'x'.repeat(40000) });
		expect(onState).not.toHaveBeenCalled();
		expect(frame.snapshot()).toEqual({ n: 6 });
	});
	it.each(['x'.repeat(32740), '界'.repeat(10910)])('accepts JSON payload near 32 KiB independently of envelope overhead', text => {
		const { frame, send, onState } = mount();
		send('STATE_SAVE', { text });
		expect(onState).toHaveBeenCalledWith({ text });
		expect(frame.snapshot()).toEqual({ text });
	});
	it('bounds resize requests and reports lab errors', () => {
		const { frame, send, onError } = mount();
		send('RESIZE_REQUEST', { height: 99999 });
		expect(frame.iframe.style.height).toBe('1600px');
		send('RESIZE_REQUEST', { height: 20 });
		expect(frame.iframe.style.height).toBe('200px');
		send('ERROR', { message: 'model failed' });
		expect(onError).toHaveBeenCalledWith('model failed');
	});
	it('reset reloads original defaults and destroy removes the frame and message handler', () => {
		const { frame, send, onState } = mount();
		send('STATE_SAVE', { n: 12 });
		frame.reset();
		expect(frame.snapshot()).toEqual({ n: 4 });
		expect(onState).toHaveBeenLastCalledWith({ n: 4 });
		const result = runDocument(frame.iframe.srcdoc);
		expect((result.context.PhysLab as { initialState: unknown }).initialState).toEqual({ n: 4 });
		frame.destroy();
		expect(document.querySelector('iframe')).toBeNull();
		send('STATE_SAVE', { n: 25 });
		expect(frame.snapshot()).toEqual({ n: 4 });
	});
	it('sends explicit pause, resume and destroy lifecycle requests', () => {
		const { frame } = mount();
		const post = vi.spyOn(frame.iframe.contentWindow!, 'postMessage');
		frame.setPaused(true);
		frame.setPaused(false);
		frame.destroy();
		expect(post.mock.calls.map(call => (call[0] as { type: string }).type)).toEqual(['PAUSE', 'RESUME', 'DESTROY']);
	});
	it('pauses when hidden and disconnects visibility/resize observers on teardown', () => {
		let intersectionCallback: IntersectionObserverCallback | undefined;
		let resizeCallback: ResizeObserverCallback | undefined;
		const disconnectIntersection = vi.fn();
		const disconnectResize = vi.fn();
		vi.stubGlobal('IntersectionObserver', class {
			constructor(callback: IntersectionObserverCallback) { intersectionCallback = callback; }
			observe() { }
			disconnect() { disconnectIntersection(); }
		});
		vi.stubGlobal('ResizeObserver', class {
			constructor(callback: ResizeObserverCallback) { resizeCallback = callback; }
			observe() { }
			disconnect() { disconnectResize(); }
		});
		try {
			const { frame } = mount();
			const post = vi.spyOn(frame.iframe.contentWindow!, 'postMessage');
			const bounds = frame.iframe.getBoundingClientRect();
			const entry = { target: frame.iframe, boundingClientRect: bounds, intersectionRect: bounds, rootBounds: bounds, time: 0, intersectionRatio: 0 };
			intersectionCallback?.([{ ...entry, isIntersecting: false }], {} as IntersectionObserver);
			intersectionCallback?.([{ ...entry, isIntersecting: true, intersectionRatio: 1 }], {} as IntersectionObserver);
			resizeCallback?.([], {} as ResizeObserver);
			expect(post.mock.calls.map(call => (call[0] as { type: string }).type)).toEqual(['PAUSE', 'RESUME', 'RESIZE']);
			frame.destroy();
			expect(disconnectIntersection).toHaveBeenCalledOnce();
			expect(disconnectResize).toHaveBeenCalledOnce();
		} finally { vi.unstubAllGlobals(); }
	});
});
