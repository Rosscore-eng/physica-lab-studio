import { afterEach, describe, expect, it, vi } from 'vitest';

vi.mock('obsidian', async (orig) => {
	const real = (await orig()) as Record<string, unknown>;
	class ItemView {
		contentEl: HTMLElement;
		app: unknown;
		constructor(public leaf: { app?: unknown }) {
			this.contentEl = document.createElement('div');
			document.body.appendChild(this.contentEl);
			this.app = leaf.app;
		}
	}
	class Modal {
		contentEl = document.createElement('div');
		modalEl = document.createElement('div');
		titleEl = document.createElement('div');
		constructor(public app: unknown) {}
		open(): void {
			(this as unknown as { onOpen(): void }).onOpen();
		}
		close(): void {
			(this as unknown as { onClose(): void }).onClose();
		}
	}
	return { ...real, ItemView, Modal };
});

import { liveInstances } from '../../src/core/lab-host';
import { ResourceScope } from '../../src/core/lifecycle';
import type { PhysLabHost } from '../../src/obsidian/host';
import { LabRenderChild } from '../../src/obsidian/lab-child';
import { DEFAULT_SETTINGS } from '../../src/obsidian/settings';
import { StudioView } from '../../src/obsidian/studio-view';
import { LabFiles, MemoryFileAdapter } from '../../src/persistence/lab-files';
import { PlainMathEngine } from '../../src/render/math/math-renderer';
import { createBuiltinRegistry } from '../../src/presets/index';
import { flushFrames } from '../setup';

function makeHost(lazy: boolean, mem = new MemoryFileAdapter()) {
	const settings = structuredClone(DEFAULT_SETTINGS);
	settings.lazyLoad = lazy;
	const files = new LabFiles(mem, () => settings.paths);
	const host: PhysLabHost & { mem: MemoryFileAdapter } = {
		mem,
		app: {} as PhysLabHost['app'],
		settings,
		registry: createBuiltinRegistry(),
		engine: new PlainMathEngine(document),
		files,
		ensureMath: async () => {},
		saveSettings: async () => {},
		saveLabState: async (lab) => {
			const f = await files.saveState(lab.config.id as string, lab.preset.id, lab.preset.version, lab.store.snapshot().values);
			lab.markSaved(f.savedAt);
		},
		openExpanded: () => {},
		insertIntoActiveNote: () => false,
		refreshLabs: () => {},
	};
	return host;
}

async function settle(): Promise<void> {
	for (let i = 0; i < 6; i++) {
		await new Promise((r) => setTimeout(r, 0));
		flushFrames(1);
	}
}

const SEC = 'id: sec-1\npreset: math.secant-tangent\nparameters:\n  x0: 1\n  h: 0.5';

// IntersectionObserver controlable (jsdom no lo trae).
type IOcb = (entries: Array<{ isIntersecting: boolean; target: Element }>) => void;
const observers: Array<{ cb: IOcb; targets: Element[]; disconnected: boolean }> = [];
class FakeIO {
	rec: { cb: IOcb; targets: Element[]; disconnected: boolean };
	constructor(cb: IOcb) {
		this.rec = { cb, targets: [], disconnected: false };
		observers.push(this.rec);
	}
	observe(el: Element): void {
		this.rec.targets.push(el);
	}
	disconnect(): void {
		this.rec.disconnected = true;
	}
	unobserve(): void {}
	takeRecords(): [] {
		return [];
	}
}

afterEach(() => {
	document.body.replaceChildren();
	for (const l of [...liveInstances]) l.destroy();
	delete (globalThis as { IntersectionObserver?: unknown }).IntersectionObserver;
	delete (window as unknown as { IntersectionObserver?: unknown }).IntersectionObserver;
	observers.length = 0;
});

describe('REVIEW obsidian lifecycle', () => {
	it('carga diferida + remount (refreshLabs) => un solo montaje sin instancia huérfana', async () => {
		(globalThis as { IntersectionObserver?: unknown }).IntersectionObserver = FakeIO;
		(window as unknown as { IntersectionObserver?: unknown }).IntersectionObserver = FakeIO;
		const host = makeHost(true);
		const reg = new Set<LabRenderChild>();
		const el = document.createElement('div');
		document.body.appendChild(el);
		const child = new LabRenderChild(el, host, SEC, reg);
		child.load();
		await settle();
		console.log('[REVIEW] antes de refresh: liveInstances =', liveInstances.size, 'placeholder =', !!el.querySelector('.physlab-placeholder'));
		// Ajustes -> refreshLabs() -> remount() de un bloque aún fuera de pantalla
		await child.remount();
		await settle();
		const first = child.instance;
		console.log('[REVIEW] tras remount: liveInstances =', liveInstances.size);
		// El usuario hace scroll: el IntersectionObserver de la carga diferida sigue vivo
		const lazyIO = observers[0]!;
		console.log('[REVIEW] IO diferido desconectado tras remount?', lazyIO.disconnected);
		lazyIO.cb([{ isIntersecting: true, target: el }]);
		await settle();
		const second = child.instance;
		console.log('[REVIEW] tras scroll: liveInstances =', liveInstances.size, 'misma instancia?', first === second, 'first destruida?', first?.isDestroyed, 'first.root conectado?', first?.root.isConnected);
		const live = ResourceScope.live;
		child.unload();
		console.log('[REVIEW] tras cerrar la nota: liveInstances =', liveInstances.size, 'ResourceScope.live', live, '->', ResourceScope.live);
		expect(liveInstances.size).toBe(0);
	});

	it('refreshLabs/remount conserva cambios sin guardar', async () => {
		const host = makeHost(false);
		const reg = new Set<LabRenderChild>();
		const el = document.createElement('div');
		document.body.appendChild(el);
		const child = new LabRenderChild(el, host, SEC, reg);
		child.load();
		await settle();
		child.instance!.store.set('h', 1.25, 'drag');
		console.log('[REVIEW] antes: h =', child.instance!.store.num('h'), 'dirty =', child.instance!.store.isDirty());
		await child.remount();
		await settle();
		console.log('[REVIEW] tras remount (cambio de tema/decimales): h =', child.instance!.store.num('h'), 'dirty =', child.instance!.store.isDirty());
		expect(child.instance!.store.num('h')).toBe(1.25);
	});

	it('copiar bloque asigna otro id y conserva estados independientes', async () => {
		const host = makeHost(false);
		const reg = new Set<LabRenderChild>();
		const elA = document.createElement('div');
		document.body.appendChild(elA);
		const a = new LabRenderChild(elA, host, SEC, reg);
		a.load();
		await settle();
		a.instance!.store.set('h', 1.25, 'drag');
		const copied = a.instance!.toBlockYaml();
		console.log('[REVIEW] YAML copiado:\n' + copied);
		const elB = document.createElement('div');
		document.body.appendChild(elB);
		const b = new LabRenderChild(elB, host, copied, reg);
		b.load();
		await settle();
		// A guarda h=1.25; B cambia y guarda h=0.1
		(elA.querySelector('.pl-tool-save') as HTMLButtonElement).click();
		await settle();
		b.instance!.store.set('h', 0.1, 'drag');
		(elB.querySelector('.pl-tool-save') as HTMLButtonElement).click();
		await settle();
		a.unload();
		const elA2 = document.createElement('div');
		document.body.appendChild(elA2);
		const a2 = new LabRenderChild(elA2, host, SEC, reg);
		a2.load();
		await settle();
		console.log('[REVIEW] A reabierto: h =', a2.instance!.store.num('h'), '(A había guardado 1.25)', 'avisos:', elA2.querySelector('.pl-warnings')?.textContent ?? 'ninguno');
		expect(a2.instance!.store.num('h')).toBe(1.25);
	});

	it('StudioView: cerrar la vista mientras onOpen espera => ninguna vista previa huérfana', async () => {
		const mem = new MemoryFileAdapter();
		mem.dirs.add('PhysicaLab/templates');
		const host = makeHost(false, mem);
		const view = new StudioView({ app: {} } as never, host);
		const opening = view.onOpen();
		await view.onClose(); // el usuario cierra la pestaña enseguida
		await opening;
		await settle();
		const orphan = [...liveInstances][0];
		console.log('[REVIEW] tras cerrar Studio: liveInstances =', liveInstances.size, 'root conectado?', orphan?.root.isConnected, 'recursos vivos', orphan?.resourceCount);
		expect(liveInstances.size).toBe(0);
	});
});

import { ExpandedLabModal } from '../../src/obsidian/modals';
describe('REVIEW modal ampliado', () => {
	it('guardar desde la vista ampliada limpia el indicador de cambios sin guardar en el bloque', async () => {
		const host = makeHost(false);
		const reg = new Set<LabRenderChild>();
		const el = document.createElement('div');
		document.body.appendChild(el);
		const child = new LabRenderChild(el, host, SEC, reg);
		child.load();
		await settle();
		const inline = child.instance!;
		const modal = new ExpandedLabModal({} as never, host, inline);
		modal.open();
		document.body.appendChild((modal as unknown as { contentEl: HTMLElement }).contentEl);
		inline.store.set('h', 1.25, 'drag');
		await settle();
		const mEl = (modal as unknown as { contentEl: HTMLElement }).contentEl;
		console.log('[REVIEW] antes de guardar: punto inline =', el.querySelector('.pl-dirty')?.textContent, ' punto modal =', mEl.querySelector('.pl-dirty')?.textContent);
		(mEl.querySelector('.pl-tool-save') as HTMLButtonElement).click();
		await settle();
		modal.close();
		console.log('[REVIEW] tras guardar en el modal y cerrarlo: store.isDirty =', inline.store.isDirty(), ' punto inline =', JSON.stringify(el.querySelector('.pl-dirty')?.textContent), ' inline.lastSaved =', inline.lastSaved, ' archivo =', host.mem.files.has('PhysicaLab/states/sec-1.json'));
		expect(el.querySelector('.pl-dirty')?.textContent).toBe('');
	});
});

describe('REVIEW studio variante MathJax lento', () => {
	it('cerrar Studio mientras la vista previa espera a MathJax', async () => {
		const host = makeHost(false);
		host.ensureMath = () => new Promise((r) => setTimeout(r, 50));
		const view = new StudioView({ app: {} } as never, host);
		await view.onOpen(); // onOpen ya terminó; showPreview sigue esperando a MathJax
		console.log('[REVIEW] tras onOpen: liveInstances =', liveInstances.size);
		await view.onClose();
		await new Promise((r) => setTimeout(r, 120));
		await settle();
		const orphan = [...liveInstances][0];
		console.log('[REVIEW] 120 ms después de cerrar: liveInstances =', liveInstances.size, 'root conectado?', orphan?.root.isConnected, 'recursos', orphan?.resourceCount, 'ResourceScope.live', ResourceScope.live);
		expect(liveInstances.size).toBe(0);
	});
});

describe('REVIEW modal ampliado + animación', () => {
	it('la animación del bloque sigue en el modal y sus botones no la controlan (doble reloj)', async () => {
		const host = makeHost(false);
		const reg = new Set<LabRenderChild>();
		const el = document.createElement('div');
		document.body.appendChild(el);
		const child = new LabRenderChild(el, host, 'id: rc-1\npreset: circuits.rc-charging\nparameters:\n  t: 0', reg);
		child.load();
		await settle();
		const inline = child.instance!;
		(el.querySelector('.pl-btn-play') as HTMLButtonElement).click();
		flushFrames(3);
		const modal = new ExpandedLabModal({} as never, host, inline);
		modal.open();
		const mEl = (modal as unknown as { contentEl: HTMLElement }).contentEl;
		document.body.appendChild(mEl);
		const mPlay = mEl.querySelector('.pl-btn-play') as HTMLButtonElement;
		const step = (n: number): number => {
			const t0 = inline.store.num('t');
			flushFrames(n);
			return (inline.store.num('t') - t0) / n;
		};
		console.log('[REVIEW] modal abierto, botón del modal aria-pressed =', mPlay.getAttribute('aria-pressed'), '| avance de t por frame =', step(5).toExponential(3));
		mPlay.click();
		flushFrames(1);
		console.log('[REVIEW] tras pulsar Reproducir en el modal: avance por frame =', step(5).toExponential(3));
		mPlay.click();
		console.log('[REVIEW] tras pulsar Pausar en el modal: aria-pressed =', mPlay.getAttribute('aria-pressed'), '| avance por frame =', step(5).toExponential(3));
		modal.close();
	});
});
