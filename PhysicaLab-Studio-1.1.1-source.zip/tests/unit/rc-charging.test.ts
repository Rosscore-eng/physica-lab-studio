import { afterEach, describe, expect, it } from 'vitest';
import { liveInstances } from '../../src/core/lab-host';
import { ResourceScope } from '../../src/core/lifecycle';
import type { ParamValues, Point } from '../../src/core/types';
import { dragBounds, partTerminals, RC_PART_IDS, RC_PARTS, RC_WIRES, windowOf } from '../../src/presets/circuits/rc-charging';
import {
	autoWindow,
	capacitorEnergy,
	capacitorVoltage,
	charge,
	CHARGE_AT_TAU,
	current,
	fromPanel,
	niceAbove,
	resistorVoltage,
	stateAt,
	timeConstant,
} from '../../src/presets/circuits/rc-model';
import { routeOrthogonal, terminalsOf, type Terminal } from '../../src/presets/circuits/schematic';
import { drag, handlePos, mountLab, setInput, texOf, tick, type Mounted } from './helpers';

const ID = 'circuits.rc-charging';
/** Rectángulo de la gráfica en la escena (debe coincidir con PLOT del preset). */
const PLOT = { x: 58, y: 40, width: 368, height: 212 };

/** Puntos de un atributo `d` formado por M/L. */
function pathPoints(d: string | null): Point[] {
	const out: Point[] = [];
	const re = /[ML]\s*([-\d.]+)[ ,]([-\d.]+)/g;
	let m: RegExpExecArray | null;
	while ((m = re.exec(d ?? ''))) out.push({ x: Number(m[1]), y: Number(m[2]) });
	return out;
}

function near(a: Point, b: Point, tol = 0.01): boolean {
	return Math.abs(a.x - b.x) <= tol && Math.abs(a.y - b.y) <= tol;
}

/** Comprueba que cada cable une exactamente los terminales de su conexión y es ortogonal. */
function expectWiresAnchored(root: Element, v: Readonly<ParamValues>): void {
	const wires = root.querySelectorAll('[data-wire]');
	expect(wires.length).toBe(RC_WIRES.length);
	for (const w of RC_WIRES) {
		const el = root.querySelector(`[data-wire="${w.id}"]`);
		expect(el?.getAttribute('data-from')).toBe(`${w.from[0]}.${w.from[1]}`);
		expect(el?.getAttribute('data-to')).toBe(`${w.to[0]}.${w.to[1]}`);
		const pts = pathPoints(el?.getAttribute('d') ?? null);
		expect(pts.length).toBeGreaterThanOrEqual(2);
		const a = partTerminals(v, w.from[0])[w.from[1]];
		const b = partTerminals(v, w.to[0])[w.to[1]];
		expect(near(pts[0]!, a)).toBe(true);
		expect(near(pts[pts.length - 1]!, b)).toBe(true);
		for (let i = 1; i < pts.length; i++) {
			const p = pts[i - 1]!;
			const q = pts[i]!;
			expect(Math.abs(p.x - q.x) < 0.01 || Math.abs(p.y - q.y) < 0.01).toBe(true);
		}
	}
}

/** Ningún atributo ni expresión LaTeX contiene NaN o Infinity. */
function expectFinite(root: Element): void {
	for (const el of Array.from(root.querySelectorAll('*'))) {
		for (const attr of Array.from(el.attributes)) {
			if (attr.name === 'style' && /NaN|Infinity/.test(attr.value)) throw new Error(`${el.tagName} style=${attr.value}`);
			if (/NaN|Infinity/.test(attr.value)) throw new Error(`${el.tagName} ${attr.name}=${attr.value}`);
		}
	}
	expect(root.textContent ?? '').not.toMatch(/NaN|Infinity/);
}

describe('modelo RC serie', () => {
	it('τ = R·C en segundos (10 kΩ · 100 μF = 1 s; 1 kΩ · 1 μF = 1 ms)', () => {
		const c = fromPanel(12, 10, 100);
		expect(c.R).toBe(1e4);
		expect(c.C).toBeCloseTo(1e-4, 15);
		expect(timeConstant(c.R, c.C)).toBeCloseTo(1, 12);
		const d = fromPanel(5, 1, 1);
		expect(timeConstant(d.R, d.C)).toBeCloseTo(1e-3, 15);
	});

	it('V_C(τ) = 0.632·V_s y la carga es completa a los 5τ', () => {
		const tau = 2.2;
		expect(CHARGE_AT_TAU).toBeCloseTo(1 - Math.exp(-1), 12);
		expect(capacitorVoltage(tau, 12, tau) / 12).toBeCloseTo(0.6321, 4);
		expect(capacitorVoltage(5 * tau, 12, tau) / 12).toBeGreaterThan(0.993);
		expect(capacitorVoltage(0, 12, tau)).toBe(0);
		expect(capacitorVoltage(-1, 12, tau)).toBe(0);
	});

	it('I(0⁺) = V_s/R, V_R + V_C = V_s, q = C·V_C y U_C = ½·C·V_C²', () => {
		const c = fromPanel(9, 4.7, 220);
		const tau = timeConstant(c.R, c.C);
		expect(current(0, c.Vs, c.R, tau)).toBeCloseTo(9 / 4700, 12);
		for (const t of [0, 0.3 * tau, tau, 4 * tau]) {
			const s = stateAt(t, c);
			expect(s.vR + s.vC).toBeCloseTo(c.Vs, 10);
			expect(s.i * c.R).toBeCloseTo(s.vR, 10);
			expect(s.q).toBeCloseTo(charge(c.C, s.vC), 15);
			expect(s.uC).toBeCloseTo(capacitorEnergy(c.C, s.vC), 15);
			expect(s.uC).toBeCloseTo(0.5 * c.C * s.vC ** 2, 15);
		}
		expect(resistorVoltage(tau, 9, tau)).toBeCloseTo(9 * Math.exp(-1), 12);
	});

	it('la ventana automática es un valor redondo ≥ 5τ (no siempre 5τ exacto)', () => {
		expect(autoWindow(1)).toBe(5);
		expect(autoWindow(1.1)).toBe(10);
		expect(autoWindow(0.3)).toBe(2);
		expect(autoWindow(1e-4)).toBeCloseTo(5e-4, 12);
		for (const tau of [1e-4, 3.3e-3, 0.47, 2.2, 100]) expect(autoWindow(tau)).toBeGreaterThanOrEqual(5 * tau * (1 - 1e-9));
		expect(niceAbove(12 * 1.08)).toBe(15);
		expect(niceAbove(5 * 1.08)).toBe(6);
		expect(niceAbove(24 * 1.08)).toBe(30);
	});

	it('valores extremos siempre finitos', () => {
		for (const [Vs, R, C] of [
			[1, 0.1, 1],
			[24, 100, 1000],
		] as const) {
			const c = fromPanel(Vs, R, C);
			const tau = timeConstant(c.R, c.C);
			for (const t of [0, tau, 1000]) {
				const s = stateAt(t, c);
				for (const v of Object.values(s)) expect(Number.isFinite(v)).toBe(true);
			}
		}
	});
});

describe('enrutado ortogonal de cables', () => {
	const T = (x: number, y: number, dx: number, dy: number): Terminal => ({ x, y, dx, dy });

	it('une los terminales, sale y entra en la dirección de cada patilla', () => {
		const cases: Array<[Terminal, Terminal]> = [
			[T(80, 120, 0, -1), T(120, 60, -1, 0)],
			[T(200, 60, 1, 0), T(240, 60, -1, 0)],
			[T(200, 60, 1, 0), T(240, 100, -1, 0)],
			[T(320, 60, 1, 0), T(360, 120, 0, -1)],
			[T(360, 200, 0, 1), T(80, 200, 0, 1)],
			[T(100, 120, 0, -1), T(140, 60, -1, 0)],
		];
		for (const [a, b] of cases) {
			const p = routeOrthogonal(a, b, [], { lanes: { y: [260] } });
			expect(near(p[0]!, a)).toBe(true);
			expect(near(p[p.length - 1]!, b)).toBe(true);
			for (let i = 1; i < p.length; i++) expect(p[i - 1]!.x === p[i]!.x || p[i - 1]!.y === p[i]!.y).toBe(true);
			const d0 = { x: Math.sign(p[1]!.x - p[0]!.x), y: Math.sign(p[1]!.y - p[0]!.y) };
			expect(d0.x === a.dx && d0.y === a.dy).toBe(true);
			const n = p.length;
			const d1 = { x: Math.sign(p[n - 1]!.x - p[n - 2]!.x), y: Math.sign(p[n - 1]!.y - p[n - 2]!.y) };
			expect(d1.x === -b.dx && d1.y === -b.dy).toBe(true);
		}
	});

	it('el retorno usa el carril inferior y esquiva los cuerpos de los componentes', () => {
		const p = routeOrthogonal(T(360, 200, 0, 1), T(80, 200, 0, 1), [], { lanes: { y: [260] } });
		expect(p.map((q) => q.y)).toContain(260);
		// Un obstáculo en medio del camino recto fuerza un rodeo.
		const blocked = routeOrthogonal(T(200, 60, 1, 0), T(300, 60, -1, 0), [{ x: 240, y: 50, width: 20, height: 20 }]);
		expect(blocked.length).toBeGreaterThan(2);
	});

	it('los terminales de un símbolo vertical quedan arriba (a) y abajo (b)', () => {
		const [a, b] = terminalsOf({ x: 100, y: 160 }, 'v');
		expect(a).toEqual({ x: 100, y: 120, dx: 0, dy: -1 });
		expect(b).toEqual({ x: 100, y: 200, dx: 0, dy: 1 });
	});
});

describe('laboratorio de carga RC', () => {
	let m: Mounted;
	afterEach(() => m?.cleanup());

	const part = (id: string): SVGGElement => m.container.querySelector(`[data-part="${id}"]`) as SVGGElement;
	const curveD = (): string => m.container.querySelector('.rc-curve-vc')?.getAttribute('d') ?? '';
	const X = (t: number, w = 5): number => PLOT.x + (t / w) * PLOT.width;

	it('dibuja el circuito con cada cable anclado a sus terminales', () => {
		m = mountLab(ID);
		expectWiresAnchored(m.container, m.lab.store.all());
		for (const id of RC_PART_IDS) {
			const p = handlePos(part(id));
			expect(p.x).toBe(RC_PARTS[id].x0 * 20);
			expect(p.y).toBe(RC_PARTS[id].y0 * 20);
		}
	});

	it('arrastrar la resistencia la recoloca en la rejilla sin cambiar la topología', () => {
		m = mountLab(ID);
		const before = m.lab.store.all();
		expectWiresAnchored(m.container, before);
		const r = part('r');
		const p = handlePos(r);
		drag(r, p, { x: p.x - 40, y: p.y + 40 });
		tick();
		const after = m.lab.store.all();
		expect(after.rX).toBe(13); // límite: 5 celdas a la derecha del interruptor
		expect(after.rY).toBe(5); // límite: 3 celdas por encima del condensador
		expect(handlePos(r)).toEqual({ x: 260, y: 100 });
		expectWiresAnchored(m.container, after);
		// Los demás componentes no se mueven.
		for (const k of ['vsX', 'vsY', 'swX', 'swY', 'cX', 'cY']) expect(after[k]).toBe(before[k]);
	});

	it('cualquier arrastre mantiene los componentes en su región y los cables anclados', () => {
		m = mountLab(ID);
		const moves: Point[] = [
			{ x: 200, y: 200 },
			{ x: -300, y: -300 },
			{ x: 37, y: -63 },
		];
		for (const id of RC_PART_IDS) {
			for (const d of moves) {
				const el = part(id);
				const p = handlePos(el);
				drag(el, p, { x: p.x + d.x, y: p.y + d.y });
				tick();
				const v = m.lab.store.all();
				const def = RC_PARTS[id];
				const x = v[def.xId] as number;
				const y = v[def.yId] as number;
				expect(Number.isInteger(x) && Number.isInteger(y)).toBe(true);
				expect(x).toBeGreaterThanOrEqual(def.region.x[0]);
				expect(x).toBeLessThanOrEqual(def.region.x[1]);
				expect(y).toBeGreaterThanOrEqual(def.region.y[0]);
				expect(y).toBeLessThanOrEqual(def.region.y[1]);
				const b = dragBounds(id, v);
				expect(x >= b.x[0] && x <= b.x[1] && y >= b.y[0] && y <= b.y[1]).toBe(true);
				expectWiresAnchored(m.container, v);
			}
		}
		expectFinite(m.container);
	});

	it('el teclado mueve un componente una celda', () => {
		m = mountLab(ID);
		const c = part('c');
		c.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowLeft', bubbles: true }));
		tick();
		expect(m.lab.store.num('cX')).toBe(17);
		c.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowUp', bubbles: true }));
		tick();
		expect(m.lab.store.num('cY')).toBe(7);
		expectWiresAnchored(m.container, m.lab.store.all());
	});

	it('«Recolocar esquema» devuelve las posiciones iniciales', () => {
		m = mountLab(ID, { rX: 15, cY: 9 });
		const c = part('c');
		c.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowDown', bubbles: true }));
		tick();
		expect(m.lab.store.num('cY')).toBe(10);
		const btn = Array.from(m.container.querySelectorAll('button')).find((b) => b.textContent === 'Recolocar esquema');
		btn?.click();
		tick();
		expect(m.lab.store.num('cY')).toBe(9);
		expect(m.lab.store.num('rX')).toBe(15);
	});

	it('τ = RC con unidades: 10 kΩ · 100 μF = 1.00 s', () => {
		m = mountLab(ID, { R: 10, C: 100 });
		expect(texOf(m.container, 'tau')).toBe('\\tau=RC=(10.0\\,\\mathrm{k\\Omega})(100\\,\\mu\\mathrm{F})=1.00\\,\\mathrm{s}');
		m.lab.store.update({ R: 4.7, C: 1 }, 'api');
		tick();
		expect(texOf(m.container, 'tau')).toContain('=4.70\\,\\mathrm{ms}');
		expect(m.container.querySelector('[data-label="ax-t"][data-tex]')?.getAttribute('data-tex')).toBe('t\\;(\\mathrm{ms})');
	});

	it('R y C cambian la curva; la ventana automática es redonda ≥ 5τ', () => {
		m = mountLab(ID, { R: 10, C: 100, t: 1 });
		expect(windowOf(m.lab.store.all())).toBe(5);
		const d0 = curveD();
		m.lab.store.set('R', 8.2, 'panel'); // τ = 0.82 s: misma ventana de 5 s, curva más rápida
		tick();
		expect(windowOf(m.lab.store.all())).toBe(5);
		const d1 = curveD();
		expect(d1).not.toBe(d0);
		m.lab.store.set('C', 150, 'panel'); // τ = 1.23 s → 5τ = 6.15 s → ventana 10 s
		tick();
		expect(windowOf(m.lab.store.all())).toBe(10);
		expect(m.lab.store.num('tWindow')).toBe(10);
		expect(m.lab.store.range('t').max).toBe(10);
		expect(curveD()).not.toBe(d1);
	});

	it('con la ventana fijada, aumentar R hace la curva más lenta en la misma ventana', () => {
		m = mountLab(ID, { R: 10, C: 100, t: 1 });
		const toggle = m.container.querySelector('[data-param="fixWindow"] input') as HTMLInputElement;
		toggle.checked = true;
		toggle.dispatchEvent(new Event('change', { bubbles: true }));
		tick();
		expect(m.lab.store.bool('fixWindow')).toBe(true);
		const before = pathPoints(curveD());
		m.lab.store.set('R', 47, 'panel'); // τ = 4.7 s dentro de una ventana fija de 5 s
		tick();
		expect(windowOf(m.lab.store.all())).toBe(5);
		const after = pathPoints(curveD());
		// Misma abscisa final (ventana), pero menor tensión alcanzada (y de escena mayor).
		expect(after[after.length - 1]!.x).toBeCloseTo(before[before.length - 1]!.x, 1);
		expect(after[after.length - 1]!.y).toBeGreaterThan(before[before.length - 1]!.y + 40);
		expect(m.container.querySelector('.pl-status')?.textContent ?? '').toBe('');
		m.lab.store.set('R', 100, 'panel'); // τ = 10 s > ventana
		tick();
		expect(m.container.querySelector('.pl-status')?.textContent).toMatch(/fuera de la ventana/);
		expectFinite(m.container);
	});

	it('el deslizador de t actualiza V_C, el cursor y las ecuaciones', () => {
		m = mountLab(ID, { Vs: 12, R: 10, C: 100, t: 1.5 });
		const slider = m.container.querySelector('[data-param="t"] input.pl-slider') as HTMLInputElement;
		setInput(slider, '2');
		tick();
		expect(m.lab.store.num('t')).toBe(2);
		expect(texOf(m.container, 'vc')).toBe('V_C=10.4\\,\\mathrm{V}');
		expect(texOf(m.container, 'vc-t')).toContain('e^{-2.00}');
		const hV = m.container.querySelector('.pl-pt-blue') as SVGGElement;
		expect(handlePos(hV).x).toBeCloseTo(X(2), 1);
		expect(m.container.querySelector('[data-label="vc"][data-tex]')?.getAttribute('data-tex')).toBe('V_C=10.4\\,\\mathrm{V}');
	});

	it('arrastrar el punto de la curva cambia t (imán en t = τ)', () => {
		m = mountLab(ID, { Vs: 12, R: 10, C: 100, t: 1.5 });
		const hV = m.container.querySelector('.pl-pt-blue') as SVGGElement;
		drag(hV, handlePos(hV), { x: X(3), y: 40 });
		tick();
		expect(m.lab.store.num('t')).toBeCloseTo(3, 2);
		expect(texOf(m.container, 'vc')).toBe('V_C=11.4\\,\\mathrm{V}');
		drag(hV, handlePos(hV), { x: X(1) + 3, y: 200 });
		tick();
		expect(m.lab.store.num('t')).toBe(1);
		// V_C(τ) = 0.632·V_s = 7.59 V
		expect(texOf(m.container, 'vc')).toBe('V_C=7.59\\,\\mathrm{V}');
		expect(texOf(m.container, 'ratio')).toBe('t/\\tau=1.00');
	});

	it('el botón «t = τ» lleva a V_C = 63.2 % de V_s', () => {
		m = mountLab(ID, { Vs: 10, R: 22, C: 47, t: 0 });
		const btn = Array.from(m.container.querySelectorAll('button')).find((b) => b.textContent === 't = τ');
		btn?.click();
		tick();
		const tau = 22e3 * 47e-6;
		expect(m.lab.store.num('t')).toBeCloseTo(tau, 5);
		expect(texOf(m.container, 'vc')).toBe('V_C=6.32\\,\\mathrm{V}');
	});

	it('en t = 0 el interruptor está abierto y el condensador descargado', () => {
		m = mountLab(ID, { t: 0 });
		const sw = m.container.querySelector('.sch-switch');
		expect(sw?.classList.contains('sch-closed')).toBe(false);
		expect(m.container.querySelector('.pl-arrow')?.getAttribute('display')).toBe('none');
		expect(m.container.querySelectorAll('.sch-signs:not([display="none"])').length).toBe(0);
		expect(texOf(m.container, 'i')).toBe('I(0^{+})=1.20\\,\\mathrm{mA}');
		expect(m.container.querySelector('.pl-status')?.textContent).toMatch(/t = 0/);
		m.lab.store.set('t', 4.5, 'panel');
		tick();
		expect(sw?.classList.contains('sch-closed')).toBe(true);
		expect(m.container.querySelectorAll('.sch-signs:not([display="none"])').length).toBe(2);
		expect(m.container.querySelector('.pl-arrow')?.getAttribute('display')).toBeNull();
	});

	it('la flecha de corriente crece con I(t)', () => {
		m = mountLab(ID, { t: 0.1 });
		const len = (): number => {
			const l = m.container.querySelector('.pl-arrow .pl-arrow-shaft') as SVGLineElement;
			return Math.hypot(Number(l.getAttribute('x2')) - Number(l.getAttribute('x1')), Number(l.getAttribute('y2')) - Number(l.getAttribute('y1')));
		};
		const early = len();
		m.lab.store.set('t', 3, 'panel');
		tick();
		expect(len()).toBeLessThan(early - 10);
	});

	it('la animación avanza t, se detiene al final y vuelve a empezar desde 0', () => {
		m = mountLab(ID, { R: 10, C: 100, t: 0 });
		const play = m.container.querySelector('.pl-btn-play') as HTMLButtonElement;
		play.click();
		tick(30);
		const mid = m.lab.store.num('t');
		expect(mid).toBeGreaterThan(0);
		expect(mid).toBeLessThan(5);
		tick(600);
		expect(m.lab.store.num('t')).toBe(5);
		expect(play.getAttribute('aria-pressed')).toBe('false');
		play.click();
		tick(3);
		expect(m.lab.store.num('t')).toBeLessThan(0.5);
		// Mover t a mano pausa la animación.
		m.lab.store.set('t', 2, 'panel');
		tick();
		expect(play.getAttribute('aria-pressed')).toBe('false');
	});

	it('ningún NaN ni Infinity en casos extremos', () => {
		const cases: Array<Record<string, number | boolean>> = [
			{ R: 0.1, C: 1, t: 0 },
			{ R: 0.1, C: 1, t: 1000 },
			{ R: 100, C: 1000, t: 500 },
			{ R: 0.1, C: 1, fixWindow: true, tWindow: 1000, t: 1000 },
			{ R: 100, C: 1000, fixWindow: true, tWindow: 1e-4, t: 1e-4 },
			{ Vs: 1, R: 100, C: 1, t: 0.0003 },
		];
		for (const p of cases) {
			m = mountLab(ID, p);
			tick();
			expectFinite(m.container);
			expectWiresAnchored(m.container, m.lab.store.all());
			m.cleanup();
		}
		m = mountLab(ID, { R: 0.1, C: 1 });
		expect(m.container.querySelector('[data-label="ax-t"][data-tex]')?.getAttribute('data-tex')).toBe('t\\;(\\mu\\mathrm{s})');
		// 12 V / 100 Ω = 0,12 A → el eje se rotula en mA.
		expect(m.container.querySelector('[data-label="ax-i"][data-tex]')?.getAttribute('data-tex')).toBe('I\\;(\\mathrm{mA})');
	});

	it('no deja recursos vivos tras destruirse', () => {
		const base = ResourceScope.live;
		const labs = [mountLab(ID), mountLab(ID, { t: 0 })];
		(labs[0]!.container.querySelector('.pl-btn-play') as HTMLButtonElement).click();
		tick(2);
		expect(liveInstances.size).toBe(2);
		expect(ResourceScope.live).toBeGreaterThan(base);
		for (const l of labs) l.cleanup();
		expect(ResourceScope.live).toBe(base);
		expect(liveInstances.size).toBe(0);
		expect(labs[0]!.lab.store.listenerCount).toBe(0);
		m = mountLab(ID);
	});
});
