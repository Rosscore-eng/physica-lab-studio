import { afterEach, describe, expect, it } from 'vitest';
import { parse } from 'yaml';
import { liveInstances } from '../../src/core/lab-host';
import { ResourceScope } from '../../src/core/lifecycle';
import type { PhysLabHost } from '../../src/obsidian/host';
import { LabRenderChild } from '../../src/obsidian/lab-child';
import { DEFAULT_SETTINGS, sanitizeSettings } from '../../src/obsidian/settings';
import { LabFiles, MemoryFileAdapter, cleanVaultPath } from '../../src/persistence/lab-files';
import { PlainMathEngine } from '../../src/render/math/math-renderer';
import { createBuiltinRegistry } from '../../src/presets/index';
import { flushFrames } from '../setup';

type TestHost = PhysLabHost & { mem: MemoryFileAdapter; saved: string[] };

function makeHost(mem = new MemoryFileAdapter()): TestHost {
	const settings = structuredClone(DEFAULT_SETTINGS);
	settings.lazyLoad = false;
	const files = new LabFiles(mem, () => settings.paths);
	const saved: string[] = [];
	return {
		mem,
		saved,
		app: {} as PhysLabHost['app'],
		settings,
		registry: createBuiltinRegistry(),
		engine: new PlainMathEngine(document),
		files,
		ensureMath: async () => {},
		saveSettings: async () => {},
		saveLabState: async (lab) => {
			const f = await files.saveState(lab.config.id as string, lab.preset.id, lab.preset.version, lab.store.snapshot().values);
			lab.markSaved(f.savedAt);
			saved.push(lab.config.id as string);
		},
		openExpanded: () => {},
		insertIntoActiveNote: () => false,
		refreshLabs: () => {},
	};
}

async function settle(): Promise<void> {
	for (let i = 0; i < 5; i++) {
		await new Promise((r) => setTimeout(r, 0));
		flushFrames(1);
	}
}

const SEC = 'id: sec-1\npreset: math.secant-tangent\nparameters:\n  x0: 1\n  h: 0.5';

describe('persistencia en archivos', () => {
	it('guarda y lee estados en PhysicaLab/states/<id>.json', async () => {
		const mem = new MemoryFileAdapter();
		const files = new LabFiles(mem, () => DEFAULT_SETTINGS.paths);
		const f = await files.saveState('pendulo-1', 'physics.pendulum', 1, { theta0: 30, L: 1.2 }, new Date('2026-10-20T12:00:00Z'));
		expect(mem.files.has('PhysicaLab/states/pendulo-1.json')).toBe(true);
		expect(f.savedAt).toBe('2026-10-20T12:00:00.000Z');
		const back = await files.loadState('pendulo-1');
		expect(back?.values).toEqual({ L: 1.2, theta0: 30 });
		expect(await files.loadState('no-existe')).toBeNull();
	});

	it('informa estados corruptos (p. ej. conflicto de sincronización)', async () => {
		const mem = new MemoryFileAdapter();
		mem.files.set('PhysicaLab/states/x.json', '{ roto');
		const files = new LabFiles(mem, () => DEFAULT_SETTINGS.paths);
		await expect(files.loadState('x')).rejects.toThrow(/JSON/);
	});

	it('plantillas: lista YAML/JSON, no sobrescribe e ignora copias en conflicto', async () => {
		const mem = new MemoryFileAdapter();
		const files = new LabFiles(mem, () => DEFAULT_SETTINGS.paths);
		const p = await files.saveTemplate('Péndulo lunar', 'preset: physics.pendulum\nparameters:\n  g: 1.62\n');
		expect(p).toBe('PhysicaLab/templates/Pendulo-lunar.yaml');
		const p2 = await files.saveTemplate('Péndulo lunar', 'preset: physics.pendulum\n');
		expect(p2).toBe('PhysicaLab/templates/Pendulo-lunar-2.yaml');
		mem.files.set('PhysicaLab/templates/Pendulo-lunar.sync-conflict-20261020.yaml', 'preset: x.y');
		const list = await files.listTemplates(parse);
		expect(list.map((t) => t.name)).toEqual(['Pendulo-lunar', 'Pendulo-lunar-2']);
	});

	it('rechaza rutas peligrosas', () => {
		expect(cleanVaultPath('../secretos.json')).toBeNull();
		expect(cleanVaultPath('a/./b.yaml')).toBeNull();
		expect(cleanVaultPath('C:\\x.yaml')).toBeNull();
		expect(cleanVaultPath('\\PhysicaLab\\labs\\a.yaml')).toBe('PhysicaLab/labs/a.yaml');
	});
});

describe('ajustes', () => {
	it('valida los datos guardados', () => {
		const s = sanitizeSettings({
			theme: 'neón',
			decimals: 99,
			tokenOverrides: { blue: '#ABCDEF', rose: 'url(x)' },
			ai: { preferred: 'gpt', timeoutSec: 5 },
		});
		expect(s.theme).toBe('scientific-dark');
		expect(s.decimals).toBe(2);
		expect(s.tokenOverrides).toEqual({ blue: '#ABCDEF' });
		expect(s).not.toHaveProperty('ai');
		
	});
});

describe('bloque physlab en una nota (ciclo de vida)', () => {
	afterEach(() => {
		document.body.replaceChildren();
	});

	it('monta, guarda solo al pulsar Guardar, restaura y libera al cerrar la nota', async () => {
		const host = makeHost();
		const registry = new Set<LabRenderChild>();
		const base = ResourceScope.live;
		const el = document.createElement('div');
		document.body.appendChild(el);
		const child = new LabRenderChild(el, host, SEC, registry);
		child.load();
		await settle();
		const lab = child.instance;
		expect(lab).not.toBeNull();
		expect(el.querySelector('.physlab')).not.toBeNull();
		lab!.store.set('h', 1.25, 'drag');
		// Mover un parámetro NO escribe nada en disco.
		expect(host.mem.files.size).toBe(0);
		(el.querySelector('.pl-tool-save') as HTMLButtonElement).click();
		await settle();
		expect(host.saved).toEqual(['sec-1']);
		expect(JSON.parse(host.mem.files.get('PhysicaLab/states/sec-1.json')!).values.h).toBe(1.25);
		child.unload();
		expect(liveInstances.size).toBe(0);
		expect(ResourceScope.live).toBe(base);
		expect(registry.size).toBe(0);

		// Reabrir la nota: se restaura el estado guardado, sin cambios pendientes.
		const el2 = document.createElement('div');
		document.body.appendChild(el2);
		const child2 = new LabRenderChild(el2, host, SEC, registry);
		child2.load();
		await settle();
		expect(child2.instance?.store.num('h')).toBe(1.25);
		expect(child2.instance?.store.isDirty()).toBe(false);
		// Restablecer vuelve a los valores del bloque, no a los guardados.
		child2.instance?.resetParameters();
		expect(child2.instance?.store.num('h')).toBe(0.5);
		child2.unload();
		expect(ResourceScope.live).toBe(base);
	});

	it('cerrar la nota mientras el laboratorio se está montando no deja nada vivo', async () => {
		const host = makeHost();
		const el = document.createElement('div');
		const child = new LabRenderChild(el, host, SEC, new Set());
		child.load();
		child.unload();
		await settle();
		expect(liveInstances.size).toBe(0);
		expect(el.querySelector('.physlab')).toBeNull();
	});

	it('muestra un error legible con los presets disponibles', async () => {
		const host = makeHost();
		const el = document.createElement('div');
		const child = new LabRenderChild(el, host, 'preset: physics.cohete', new Set());
		child.load();
		await settle();
		expect(el.querySelector('.physlab-error')?.textContent).toMatch(/No existe el preset/);
		expect(el.textContent).toMatch(/math\.secant-tangent/);
		child.unload();
	});

	it('carga una definición externa con file: (el bloque manda)', async () => {
		const host = makeHost();
		host.mem.files.set('PhysicaLab/labs/sec.yaml', 'preset: math.secant-tangent\ntitle: Desde archivo\nparameters:\n  x0: -2\n  h: 1\n');
		const el = document.createElement('div');
		document.body.appendChild(el);
		const child = new LabRenderChild(el, host, 'file: sec.yaml\nparameters:\n  h: 0.25', new Set());
		child.load();
		await settle();
		expect(child.instance?.store.num('x0')).toBe(-2);
		expect(child.instance?.store.num('h')).toBe(0.25);
		expect(el.querySelector('.pl-title')?.textContent).toBe('Desde archivo');
		child.unload();
	});

	it('varios laboratorios en la misma nota no se interfieren', async () => {
		const host = makeHost();
		const reg = new Set<LabRenderChild>();
		const kids = [0, 1, 2].map((i) => {
			const el = document.createElement('div');
			document.body.appendChild(el);
			const c = new LabRenderChild(el, host, `id: s${i}\npreset: math.secant-tangent\nparameters:\n  x0: ${i - 1}`, reg);
			c.load();
			return c;
		});
		await settle();
		kids[0]!.instance!.store.set('x0', 2, 'drag');
		expect(kids[1]!.instance!.store.num('x0')).toBe(0);
		expect(kids[2]!.instance!.store.num('x0')).toBe(1);
		const ids = new Set([...document.querySelectorAll('clipPath')].map((c) => c.id));
		expect(ids.size).toBe(3);
		for (const k of kids) k.unload();
		expect(liveInstances.size).toBe(0);
	});
});
