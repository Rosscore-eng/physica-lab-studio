import { afterEach, describe, expect, it, vi } from 'vitest';
import { RuntimeRenderChild, type RuntimeHost } from '../../src/obsidian/runtime-child';
import { RuntimeStateStore } from '../../src/runtime/state';

const source = JSON.stringify({version: 1, id: 'new-topic', file: 'labs/original.html', features: ['2d'], initialState: {x: 2}});
function makeHost(note = '```physlab\n' + source + '\n```'): RuntimeHost {
 return {
  settings: {lazyLoad: false, theme: 'scientific-dark', tokenOverrides: {}},
  runtimeStates: new RuntimeStateStore({}, async () => {}),
  readRuntimeNote: async () => note,
  readRuntimeHTML: async () => '<div id="original">New phenomenon</div>',
  runtimeVendors: async () => ({}),
  openRuntimeSource: async () => {},
  saveRuntimeSnapshot: async () => {},
 };
}
async function settle() { for (let i=0;i<8;i++) await new Promise(r=>setTimeout(r,0)); }
let restoreFullscreen=()=>{};
function mockFullscreen(){
 const elementDescriptor=Object.getOwnPropertyDescriptor(document,'fullscreenElement');
 const requestDescriptor=Object.getOwnPropertyDescriptor(HTMLElement.prototype,'requestFullscreen');
 const exitDescriptor=Object.getOwnPropertyDescriptor(document,'exitFullscreen');
 let active:Element|null=null;
 const request=vi.fn(function(this:HTMLElement){active=this;document.dispatchEvent(new Event('fullscreenchange'));return Promise.resolve();});
 const exit=vi.fn(async()=>{active=null;document.dispatchEvent(new Event('fullscreenchange'));});
 Object.defineProperty(document,'fullscreenElement',{configurable:true,get:()=>active});
 Object.defineProperty(HTMLElement.prototype,'requestFullscreen',{configurable:true,value:request});
 Object.defineProperty(document,'exitFullscreen',{configurable:true,value:exit});
 restoreFullscreen=()=>{
  if(elementDescriptor)Object.defineProperty(document,'fullscreenElement',elementDescriptor);else delete (document as unknown as Record<string,unknown>).fullscreenElement;
  if(requestDescriptor)Object.defineProperty(HTMLElement.prototype,'requestFullscreen',requestDescriptor);else delete (HTMLElement.prototype as unknown as Record<string,unknown>).requestFullscreen;
  if(exitDescriptor)Object.defineProperty(document,'exitFullscreen',exitDescriptor);else delete (document as unknown as Record<string,unknown>).exitFullscreen;
 };
 return {request,exit};
}
afterEach(()=>{document.body.replaceChildren();restoreFullscreen();restoreFullscreen=()=>{};});
describe('runtime Obsidian lifecycle',()=>{
 it('mounts original HTML without registering a phenomenon and releases its iframe',async()=>{
  const host=makeHost(), registry=new Set<RuntimeRenderChild>();
  const el=document.body.appendChild(document.createElement('div'));
  const child=new RuntimeRenderChild(el,host,source,'Science.md',registry);
  child.load(); await settle();
  expect(el.querySelector('iframe')?.srcdoc).toContain('New phenomenon');
  expect(el.querySelector('iframe')?.getAttribute('sandbox')).toBe('allow-scripts');
  expect(registry.size).toBe(1);
  child.unload(); expect(el.querySelector('iframe')).toBeNull(); expect(registry.size).toBe(0);
 });
 it('refuses duplicate ids in one note before creating either state-sharing frame',async()=>{
  const host=makeHost(('```physlab\n'+source+'\n```\n').repeat(2));
  const el=document.body.appendChild(document.createElement('div'));
  const child=new RuntimeRenderChild(el,host,source,'Science.md',new Set());
  child.load(); await settle();
  expect(el.querySelector('iframe')).toBeNull(); expect(el.textContent).toMatch(/duplicado/i); child.unload();
 });
 it('closing while HTML is loading never attaches a late iframe',async()=>{
  const host=makeHost(); let resolve!: (html:string)=>void;
  host.readRuntimeHTML=()=>new Promise(r=>{resolve=r;});
  const el=document.body.appendChild(document.createElement('div'));
  const child=new RuntimeRenderChild(el,host,source,'Science.md',new Set());
  child.load(); await settle(); child.unload(); resolve('<div>late</div>'); await settle();
  expect(el.querySelector('iframe')).toBeNull();
 });
 it('restores state and changes appearance without writing the note',async()=>{
  const host=makeHost(); host.runtimeStates.set('Science.md','new-topic',{x:9});
  host.saveRuntimeSnapshot=vi.fn();
  const el=document.body.appendChild(document.createElement('div'));
  const child=new RuntimeRenderChild(el,host,source,'Science.md',new Set());
  child.load(); await settle();
  expect(child.frame?.snapshot()).toEqual({x:9});
  host.settings.theme='scientific-light'; await child.remount();
  expect(child.frame?.snapshot()).toEqual({x:9}); expect(host.saveRuntimeSnapshot).not.toHaveBeenCalled();
  (el.querySelector('.pl-runtime-reset') as HTMLButtonElement).click();
  expect(child.frame?.snapshot()).toEqual({x:2}); child.unload();
 });
 it('remounting an expanded lab clears the old expansion and Escape handler',async()=>{
  mockFullscreen();
  const el=document.body.appendChild(document.createElement('div'));
  const child=new RuntimeRenderChild(el,makeHost(),source,'Science.md',new Set());
  child.load();await settle();
  (el.querySelector('.pl-runtime-expand') as HTMLButtonElement).click();
  expect(el.classList.contains('pl-runtime-expanded')).toBe(true);
  await child.remount();
  expect(el.classList.contains('pl-runtime-expanded')).toBe(false);
  (el.querySelector('.pl-runtime-expand') as HTMLButtonElement).click();
  expect(el.classList.contains('pl-runtime-expanded')).toBe(true);
  child.unload();
 });
 it('uses native fullscreen outside Live Preview clipping and preserves the same frame on exit',async()=>{
  const native=mockFullscreen();
  const el=document.body.appendChild(document.createElement('div'));
  const child=new RuntimeRenderChild(el,makeHost(),source,'Science.md',new Set());
  child.load();await settle();
  const frame=child.frame;
  const expand=el.querySelector('.pl-runtime-expand') as HTMLButtonElement;
  expand.click();await settle();
  expect(native.request).toHaveBeenCalledOnce();
  expect(document.fullscreenElement).toBe(el);
  expect(expand.textContent).toBe('Cerrar ampliación');
  expect(child.frame).toBe(frame);
  expect(child.frame?.snapshot()).toEqual({x:2});
  await native.exit();
  expect(el.classList.contains('pl-runtime-expanded')).toBe(false);
  expect(expand.textContent).toBe('Ampliar');
  expect(child.frame).toBe(frame);
  child.unload();
 });
 it('rejects nested callout blocks even when a top-level lab shares the same id',async()=>{
  const note='```physlab\n'+source+'\n```\n\n> ```physlab\n> '+source+'\n> ```';
  const el=document.body.appendChild(document.createElement('div'));
  const child=new RuntimeRenderChild(el,makeHost(note),source,'Science.md',new Set(),()=>4);
  child.load();await settle();
  expect(el.querySelector('iframe')).toBeNull();expect(el.textContent).toMatch(/nivel principal/i);child.unload();
 });
});
