import { afterEach, describe, expect, it } from 'vitest';
import { ResourceScope } from '../../src/core/lifecycle';
import { liveInstances } from '../../src/core/lab-host';
import { secantSlope, tangentSlope, slopeError } from '../../src/presets/math/secant-math';
import { drag, handlePos, mountLab, setInput, texOf, tick, type Mounted } from './helpers';

describe('modelo secante–tangente', () => {
	it('la pendiente de la secante es 2x0 + h', () => {
		for (const [x0, h] of [
			[1, 0.75],
			[-1.5, 0.05],
			[2.2, -0.4],
			[0, 1e-3],
		] as const) {
			expect(secantSlope(x0, h)).toBeCloseTo(2 * x0 + h, 9);
			expect(slopeError(x0, h)).toBeCloseTo(Math.abs(h), 9);
		}
		expect(tangentSlope(1.25)).toBe(2.5);
	});

	it('h = 0 es indefinido (0/0), no el límite', () => {
		expect(Number.isNaN(secantSlope(1, 0))).toBe(true);
	});
});

describe('laboratorio secante–tangente', () => {
	let m: Mounted;
	afterEach(() => m?.cleanup());

	const handles = (root: Element) => root.querySelectorAll('.pl-handle');

	it('arrastrar B actualiza h, el gráfico y las ecuaciones', () => {
		m = mountLab('math.secant-tangent', { x0: 1, h: 0.75 });
		const [, hB] = handles(m.container);
		const before = handlePos(hB!);
		// Mundo x ∈ [-3,3] en 592 unidades desde x=34 → 98.67 u/unidad. Llevar B a x = 2.
		const target = { x: 34 + (2 + 3) * (592 / 6), y: before.y };
		drag(hB!, before, target);
		tick();
		expect(m.lab.store.num('h')).toBeCloseTo(1, 2);
		const after = handlePos(hB!);
		expect(after.x).toBeCloseTo(target.x, 0);
		expect(after.y).toBeLessThan(before.y); // f(2) > f(1.75): B sube
		expect(texOf(m.container, 'num')).toContain('=3.0000');
		expect(texOf(m.container, 'msec')).toBe('m_{\\text{sec}}=3.0000');
	});

	it('el deslizador de h mueve B (sincronía bidireccional)', () => {
		m = mountLab('math.secant-tangent', { x0: 1, h: 0.75 });
		const [, hB] = handles(m.container);
		const slider = m.container.querySelector('[data-param="h"] input.pl-slider') as HTMLInputElement;
		const num = m.container.querySelector('[data-param="h"] input.pl-num') as HTMLInputElement;
		setInput(slider, '-0.5');
		tick();
		expect(m.lab.store.num('h')).toBe(-0.5);
		expect(num.value).toBe('-0.500');
		expect(handlePos(hB!).x).toBeCloseTo(34 + (0.5 + 3) * (592 / 6), 1);
		setInput(num, '0,25', 'change');
		tick();
		expect(m.lab.store.num('h')).toBe(0.25);
		expect(slider.value).toBe('0.25');
	});

	it('arrastrar A lo mantiene sobre la parábola', () => {
		m = mountLab('math.secant-tangent', { x0: 1, h: 0.5 });
		const [hA] = handles(m.container);
		const p = handlePos(hA!);
		drag(hA!, p, { x: 34 + (-1 + 3) * (592 / 6), y: 10 }); // el usuario tira hacia arriba
		tick();
		expect(m.lab.store.num('x0')).toBeCloseTo(-1, 2);
		const q = handlePos(hA!);
		// y de escena de f(-1) = 1 en el viewport [-1.2, 9.4] sobre 386 unidades desde y=14
		expect(q.y).toBeCloseTo(14 + (9.4 - 1) * (386 / 10.6), 1);
	});

	it('el caso h = 0 distingue el cociente indefinido de su límite', () => {
		m = mountLab('math.secant-tangent', { x0: 1.5, h: 0 });
		tick();
		expect(texOf(m.container, 'num')).toContain('\\frac{0}{0}');
		expect(texOf(m.container, 'num')).toContain('no definido');
		expect(texOf(m.container, 'msec')).toContain('indefinida');
		expect(texOf(m.container, 'lim')).toContain('=3.00');
		const secant = m.container.querySelector('.pl-line.pl-s-amber');
		expect(secant?.getAttribute('display')).toBe('none');
		expect(m.container.querySelector('.pl-status')?.textContent).toMatch(/0\/0/);
	});

	it('B soltado sobre A activa el imán de h = 0', () => {
		m = mountLab('math.secant-tangent', { x0: 1, h: 0.3 });
		const [hA, hB] = handles(m.container);
		drag(hB!, handlePos(hB!), handlePos(hA!));
		tick();
		expect(m.lab.store.num('h')).toBe(0);
	});

	it('las ecuaciones usan LaTeX real', () => {
		m = mountLab('math.secant-tangent');
		expect(texOf(m.container, 'def')).toContain('\\frac{f(x_0+h)-f(x_0)}{h}');
		expect(texOf(m.container, 'lim')).toContain('\\lim_{h\\to 0}');
	});

	it('restablecer vuelve a los valores del bloque', () => {
		m = mountLab('math.secant-tangent', { x0: 0.5, h: 1 });
		m.lab.store.set('x0', 2, 'panel');
		(m.container.querySelector('.pl-tool-reset') as HTMLButtonElement).click();
		tick();
		expect(m.lab.store.num('x0')).toBe(0.5);
	});

	it('la animación h → 0 converge y se detiene sola', () => {
		m = mountLab('math.secant-tangent', { x0: 1, h: 0.8 });
		const play = m.container.querySelector('.pl-btn-play') as HTMLButtonElement;
		play.click();
		tick(600);
		expect(Math.abs(m.lab.store.num('h'))).toBeLessThanOrEqual(0.001);
		expect(play.getAttribute('aria-pressed')).toBe('false');
	});

	it('no deja recursos vivos tras destruirse', () => {
		const base = ResourceScope.live;
		const labs = [mountLab('math.secant-tangent'), mountLab('math.secant-tangent', { h: -1 })];
		expect(liveInstances.size).toBe(2);
		expect(ResourceScope.live).toBeGreaterThan(base);
		for (const l of labs) l.cleanup();
		expect(ResourceScope.live).toBe(base);
		expect(liveInstances.size).toBe(0);
		expect(labs[0]!.lab.store.listenerCount).toBe(0);
		m = mountLab('math.secant-tangent');
	});
});
