import { describe, expect, it, vi } from 'vitest';
import { parse } from 'yaml';
import { ResourceScope, AnimationClock } from '../../src/core/lifecycle';
import { niceCeil, snapToStep, texNum, texSI, ticks, fractionDigits } from '../../src/core/numeric';
import { mergeRawLabObjects, normalizeLabObject, parseLabSource, serializeLab, makeLabId, checkParameters } from '../../src/core/schema';
import { ParamStore } from '../../src/core/store';
import type { ParamSpec } from '../../src/core/types';
import { resolveTokens } from '../../src/theme/tokens';
import { flushFrames } from '../setup';

describe('numeric', () => {
	it('ajusta al paso sin ruido de coma flotante', () => {
		expect(snapToStep(0.30000000004, 0.01, -2.5)).toBe(0.3);
		expect(snapToStep(1.2346, 0.001, -2)).toBe(1.235);
		expect(snapToStep(-0.0001, 0.01, -1)).toBe(0);
		expect(fractionDigits(1e-7)).toBe(7);
	});
	it('formatea números para LaTeX', () => {
		expect(texNum(2.5, 2)).toBe('2.50');
		expect(texNum(-0.0001, 2)).toBe('-1.00\\times 10^{-4}');
		expect(texNum(123456, 1)).toBe('1.2\\times 10^{5}');
		expect(texNum(Number.NaN)).toBe('\\text{—}');
		expect(texNum(-0.004, 2)).toBe('0.00'); // sin «-0.00»
	});
	it('usa prefijos SI', () => {
		expect(texSI(0.0025, 's')).toBe('2.50\\,\\mathrm{ms}');
		expect(texSI(4.7e-6, 'F')).toBe('4.70\\,\\mu\\mathrm{F}');
		expect(texSI(10000, '\\Omega')).toBe('10.0\\,\\mathrm{k\\Omega}');
	});
	it('genera ejes redondos', () => {
		expect(niceCeil(3.2)).toBe(5);
		expect(niceCeil(0.012)).toBe(0.02);
		expect(ticks(-3, 3, 6)).toEqual([-3, -2, -1, 0, 1, 2, 3]);
	});
});

const specs: ParamSpec[] = [
	{ id: 'a', type: 'number', name: 'a', initial: 1, min: 0, max: 10, step: 0.5 },
	{ id: 'b', type: 'number', name: 'b', initial: 2, min: -5, max: 5, step: 0.1, range: (v) => ({ min: -5, max: 10 - (v.a as number) }) },
	{ id: 'r', type: 'number', name: 'r', initial: 10, min: 0.1, max: 1000, step: 0.1, scale: 'log' },
	{ id: 'on', type: 'boolean', name: 'on', initial: true },
	{ id: 'mode', type: 'enum', name: 'mode', initial: 'x', options: [{ value: 'x', label: 'X' }, { value: 'y', label: 'Y' }] },
];

describe('ParamStore', () => {
	it('valida tipo, límites y paso', () => {
		const s = new ParamStore(specs);
		expect(s.set('a', 3.3)).toBe(true);
		expect(s.num('a')).toBe(3.5);
		s.set('a', 99);
		expect(s.num('a')).toBe(10);
		s.set('a', Number.NaN);
		expect(s.num('a')).toBe(10);
		s.set('a', '2,5' as unknown as number);
		expect(s.num('a')).toBe(2.5);
		s.set('mode', 'zzz');
		expect(s.str('mode')).toBe('x');
		s.set('on', 'false' as unknown as boolean);
		expect(s.bool('on')).toBe(false);
	});

	it('aplica rangos dinámicos a los parámetros dependientes', () => {
		const s = new ParamStore(specs, { b: 5 });
		expect(s.num('b')).toBe(5);
		const changed = s.update({ a: 8 });
		expect(changed.has('b')).toBe(true);
		expect(s.num('b')).toBe(2);
		expect(s.range('b')).toEqual({ min: -5, max: 2 });
	});

	it('redondea a 3 cifras en escala logarítmica', () => {
		const s = new ParamStore(specs);
		s.set('r', 12.3456);
		expect(s.num('r')).toBe(12.3);
	});

	it('notifica una vez por actualización con su origen', () => {
		const s = new ParamStore(specs);
		const fn = vi.fn();
		const off = s.subscribe(fn);
		s.update({ a: 2, on: false }, 'panel');
		expect(fn).toHaveBeenCalledTimes(1);
		expect([...fn.mock.calls[0]![0]].sort()).toEqual(['a', 'on']);
		expect(fn.mock.calls[0]![1]).toBe('panel');
		s.set('a', 2);
		expect(fn).toHaveBeenCalledTimes(1);
		off();
		expect(s.listenerCount).toBe(0);
	});

	it('respeta parámetros bloqueados frente a panel y arrastre', () => {
		const s = new ParamStore(specs, {}, { lock: ['a'], hide: ['on'] });
		expect(s.set('a', 4, 'drag')).toBe(false);
		expect(s.set('a', 4, 'api')).toBe(true);
		expect(s.getPresentation('on')).toEqual({ visible: false, locked: false });
	});

	it('guarda, carga y detecta cambios sin guardar', () => {
		const s = new ParamStore(specs, { a: 4 });
		expect(s.isDirty()).toBe(false);
		s.set('a', 6);
		expect(s.isDirty()).toBe(true);
		const snap = s.snapshot();
		s.markSaved();
		expect(s.isDirty()).toBe(false);
		s.reset();
		expect(s.num('a')).toBe(4);
		const ignored = s.load({ ...snap.values, ghost: 1 });
		expect(ignored).toEqual(['ghost']);
		expect(s.num('a')).toBe(6);
	});
});

describe('schema', () => {
	const yaml = (s: string) => parse(s) as unknown;

	it('lee un bloque válido', () => {
		const r = parseLabSource(
			'id: calculo-secantes-01\npreset: math.secant-tangent\ntheme: scientific-dark\nparameters:\n  x0: 1\n  h: 0.75\nfeatures:\n  draggable: true\n  controls: false',
			yaml,
		);
		expect(r.errors).toEqual([]);
		expect(r.config?.parameters).toEqual({ x0: 1, h: 0.75 });
		expect(r.config?.features.controls).toBe(false);
		expect(r.config?.explicitFeatures).toEqual({ draggable: true, controls: false });
	});

	it('acepta JSON y el atajo de solo preset', () => {
		expect(parseLabSource('{"preset":"physics.pendulum"}', yaml).config?.preset).toBe('physics.pendulum');
		expect(normalizeLabObject('physics.pendulum').config?.preset).toBe('physics.pendulum');
	});

	it('informa errores y avisos claros', () => {
		expect(parseLabSource('', yaml).errors[0]).toMatch(/vacío/);
		expect(parseLabSource('preset: [', yaml).errors[0]).toMatch(/YAML/);
		expect(parseLabSource('title: x', yaml).errors[0]).toMatch(/preset/);
		expect(parseLabSource('preset: Física', yaml).errors[0]).toMatch(/formato/);
		expect(parseLabSource('preset: a.b\nid: "../x"', yaml).errors[0]).toMatch(/id/);
		expect(parseLabSource('preset: a.b\nphyslab: 9', yaml).errors[0]).toMatch(/v9/);
		const w = parseLabSource('preset: a.b\ncolor: red\nfeatures:\n  turbo: true', yaml).warnings;
		expect(w.join(' ')).toMatch(/color/);
		expect(w.join(' ')).toMatch(/turbo/);
	});

	it('no admite rutas peligrosas en file', () => {
		expect(parseLabSource('file: ../../secret.json', yaml).errors.length).toBeGreaterThan(0);
		expect(parseLabSource('file: labs/x.exe', yaml).errors.length).toBeGreaterThan(0);
		expect(parseLabSource('file: PhysicaLab/labs/pendulo.yaml', yaml).config?.file).toBe('PhysicaLab/labs/pendulo.yaml');
	});

	it('serializa y vuelve a leer igual', () => {
		const cfg = parseLabSource('id: lab-1\npreset: math.secant-tangent\ntitle: "Secante: prueba"\nparameters:\n  x0: -1.5\n  h: 0.05\nfeatures:\n  controls: false\nlock: [x0]', yaml).config!;
		const text = serializeLab(cfg);
		const again = parseLabSource(text, yaml).config!;
		expect(again).toEqual(cfg);
	});

	it('fusiona un archivo de laboratorio con el bloque', () => {
		const m = mergeRawLabObjects(
			{ preset: 'physics.pendulum', parameters: { L: 2, m: 1 }, features: { controls: false }, file: 'x.yaml' },
			{ id: 'p1', parameters: { L: 1 } },
		);
		expect(m).toEqual({ preset: 'physics.pendulum', id: 'p1', parameters: { L: 1, m: 1 }, features: { controls: false } });
	});

	it('genera ids válidos y legibles', () => {
		expect(makeLabId('Péndulo simple', () => 0.5)).toMatch(/^pendulo-simple-[0-9a-z]{4}$/);
	});

	it('contrasta parámetros con el preset', () => {
		const cfg = normalizeLabObject({ preset: 'x.y', parameters: { a: 50, zz: 1, mode: 'q' } }).config!;
		const w = checkParameters(cfg, specs).join(' | ');
		expect(w).toMatch(/fuera/);
		expect(w).toMatch(/zz/);
		expect(w).toMatch(/admite/);
	});
});

describe('ResourceScope y AnimationClock', () => {
	it('libera listeners, temporizadores y frames', () => {
		const base = ResourceScope.live;
		const scope = new ResourceScope(window);
		const el = document.createElement('div');
		const fn = vi.fn();
		scope.listen(el, 'click', fn);
		scope.timeout(fn, 1000);
		scope.frame(fn);
		const child = scope.child();
		child.listen(el, 'keydown', fn);
		expect(ResourceScope.live).toBeGreaterThan(base);
		scope.dispose();
		expect(ResourceScope.live).toBe(base);
		el.dispatchEvent(new Event('click'));
		flushFrames(2);
		expect(fn).not.toHaveBeenCalled();
	});

	it('el reloj solo consume frames mientras está en marcha', () => {
		const scope = new ResourceScope(window);
		const ticks: number[] = [];
		const clock = new AnimationClock(scope, (dt) => {
			ticks.push(dt);
			return ticks.length < 5;
		});
		flushFrames(3);
		expect(ticks.length).toBe(0);
		clock.play();
		flushFrames(10);
		expect(ticks.length).toBe(5);
		expect(clock.playing).toBe(false);
		clock.play();
		clock.setVisible(false);
		const before = ticks.length;
		flushFrames(5);
		expect(ticks.length).toBe(before);
		scope.dispose();
	});
});

describe('tokens', () => {
	it('solo acepta reemplazos hexadecimales', () => {
		const t = resolveTokens('scientific-dark', { blue: '#123456', green: 'red; background:url(x)' });
		expect(t.blue).toBe('#123456');
		expect(t.green).toBe('#7EE2A8');
	});
});
