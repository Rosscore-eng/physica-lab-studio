# Mejoras previstas para la V1.1

Ordenadas por valor para el estudio frente a esfuerzo y riesgo.

## Prioridad alta

1. **Verificación en un Android real.** La V1.0 se probó con emulación táctil (Edge, 390 px, eventos táctiles por CDP), no en un teléfono. Hay que confirmar la lista de [INSTALACION-ANDROID.md](INSTALACION-ANDROID.md) y ajustar los tamaños táctiles reales.
2. **Ecuaciones largas en pantallas estrechas.** Ahora se desplazan dentro de su caja. Lo ideal es que cada preset ofrezca una versión partida en varias líneas (el péndulo ya lo hace) y el anfitrión la elija según el ancho.
3. **Convención de tarjetas Anki desde los laboratorios.** Se podría exportar el estado guardado como pregunta con valores concretos (por ejemplo, «calcula τ para R = 22 kΩ y C = 100 µF»). Requiere definir antes la convención de Anki del vault.
4. **Más presets MathLab**, reutilizando el núcleo sin cambios: integral de Riemann (sumas izquierda/derecha/punto medio), recta tangente de cualquier función de una lista cerrada (sin evaluar código), vectores en el plano (suma y producto escalar) y curvas paramétricas.
5. **Más presets PhysicsLab:** plano inclinado con rozamiento, tiro parabólico (con y sin arrastre lineal) y muelle-masa con energía.

## Prioridad media

6. **CircuitLab RL y RC de descarga** con el mismo esquema y la misma gráfica. El RLC serie, subamortiguado, como preset aparte con solución analítica.
7. **API de selectores de acción** (`panel.addSelect`) para controles que no son parámetros (por ejemplo, el cuerpo celeste del péndulo), propuesta por la revisión de la Fase C.
8. **`MathLabel.bbox()`** para colocar las etiquetas sin umbrales aproximados, y **`Handle.setRadius()`**.
9. **Exportar la figura** como SVG o PNG (para informes en Word o LaTeX), con las etiquetas tipografiadas incrustadas.
10. **Ollama** como proveedor local (escritorio) usando la misma arquitectura de proveedores y el mismo esquema de salida.
11. **Codex CLI:** verificarlo con una instalación real y ajustar el adaptador si cambió la sintaxis.

## Exploración

12. **Motor Canvas o WebGL** para campos densos (mapas de potencial y equipotenciales) sobre la interfaz `RenderSurface`, sin tocar los presets SVG.
13. **Contenido personalizado aislado y revisado.** Presets de terceros cargados en un `iframe` con `sandbox` y comunicados solo por mensajes con el esquema de parámetros. En la V1 no se permite la ejecución libre.
14. **Modo ejercicio:** parámetros ocultos con una pregunta y comprobación de la respuesta dentro de una tolerancia, para usarlo con TaskNotes o los planes semanales.
