# Cómo crear un preset nuevo

Un **preset** es un tipo de laboratorio: `math.secant-tangent`, `physics.pendulum`, etc. Añadir uno **no exige tocar el núcleo**. Solo hay que escribir dos módulos y añadir una línea a `src/presets/index.ts`.

## 1. Estructura

```
src/presets/<modo>/
  mi-modelo.ts      ← física/matemática pura: funciones sin DOM, fáciles de probar
  mi-preset.ts      ← figura, parámetros y ecuaciones
  mi-preset.css     ← opcional: estilos propios (se unen a styles.css al compilar)
tests/unit/mi-preset.test.ts
```

`<modo>` es `math`, `physics` o `circuits`. El identificador del preset debe empezar por ese modo, por ejemplo `physics.plano-inclinado`.

## 2. Parámetros: la única fuente de verdad

```ts
const params: ParamSpec[] = [
  { id: 'theta', type: 'number', name: 'Inclinación', label: '\\theta',
    unit: '^\\circ', initial: 30, min: 0, max: 60, step: 0.5, group: 'Geometría' },
  { id: 'mu', type: 'number', name: 'Rozamiento', label: '\\mu', initial: 0.2, min: 0, max: 1, step: 0.01 },
  { id: 'showForces', type: 'boolean', name: 'Diagrama de fuerzas', initial: true, group: 'Mostrar' },
  { id: 'view', type: 'enum', name: 'Vista', initial: 'fuerzas',
    options: [{ value: 'fuerzas', label: 'Fuerzas' }, { value: 'energia', label: 'Energía' }] },
];
```

- El panel de controles (deslizador + campo numérico, interruptor o selector) **se genera solo** a partir de esta lista.
- El almacén (`ParamStore`) valida cada escritura: tipo, `min`/`max`, `step`, `scale: 'log'`, rango dinámico (`range`) y regla propia (`validate`).
- `control: 'none'` crea un parámetro que solo se manipula arrastrando, por ejemplo la posición de un componente.
- `persist: false` impide que el parámetro se guarde en el archivo de estado.

## 3. La clase del preset

```ts
export const planoPreset: PresetDefinition = {
  id: 'physics.plano-inclinado', version: 1, mode: 'physics',
  title: 'Plano inclinado', summary: 'Bloque sobre un plano con rozamiento.',
  keywords: ['plano', 'inclinado', 'rozamiento', 'friction'],
  params,
  fidelity: 'Exacto: estática y dinámica del bloque puntual con rozamiento de Coulomb.',
  examples: [{ title: 'Sin rozamiento', parameters: { mu: 0 } }],
  create: (ctx) => new PlanoLab(ctx),
};

class PlanoLab implements PresetInstance {
  constructor(private readonly ctx: PresetContext) {
    const scene = ctx.createScene({ width: 640, height: 400, label: 'Plano inclinado' });
    // 1) Crear los elementos UNA vez (svgEl, Arrow, Handle, Dimension, Axes...).
    // 2) Hacer manipulables las asas:
    ctx.draggable(scene, handle.g, {
      onMove: (p) => ctx.store.set('theta', anguloDesde(p), 'drag'), // restricción + escritura en el store
      onKey: (dx) => ctx.store.set('theta', ctx.store.num('theta') + dx, 'keyboard'),
    }, 'Extremo del plano');
  }
  render() {
    // 3) Leer SIEMPRE del store y actualizar atributos (determinista).
    const th = this.ctx.store.num('theta');
    // ... setAttrs(...), scene.labels.label('th', '\\theta').at(p, 'ne') ...
    this.ctx.equations.set('newton', `ma = mg\\sin\\theta - \\mu mg\\cos\\theta`, 'Segunda ley');
  }
}
```

Reglas:

- **Un solo estado.** El arrastre escribe en el store (`'drag'`); el panel también (`'panel'`). Ambos se redibujan desde el store. Nunca guardes copias de un parámetro.
- **LaTeX real.** Las etiquetas van en `scene.labels` y las ecuaciones en `ctx.equations`. En Obsidian se tipografían con su MathJax nativo, sin conexión.
- **Sin colores literales.** Usa las clases `pl-s-<color>` (trazo), `pl-f-<color>` (relleno) y `pl-c-<color>` (etiquetas), con los colores `text`, `muted`, `blue`, `green`, `amber`, `violet` y `rose`.
- **Recursos.** Todo listener, observador o temporizador se registra en `ctx.scope`. Las animaciones se crean con `ctx.clock(...)`: nunca arrancan solas y se pausan fuera de la vista.
- **Seguridad.** Nada de `eval`, `new Function`, red ni APIs de Node en el preset.

## 4. Registrar

```ts
// src/presets/index.ts
import { planoPreset } from './physics/plano-inclinado';
export const BUILTIN_PRESETS = [..., planoPreset];
```

Otro plugin también puede registrarlo en tiempo de ejecución:

```ts
app.plugins.plugins['physica-lab-studio'].api.registerPreset(planoPreset);
```

## 5. Probar

- `npx vitest run tests/unit/mi-preset.test.ts`: prueba el modelo (valores de referencia) y el arrastre simulado con `mountLab` y `drag` de `tests/unit/helpers.ts`.
- `npm run visual -- physics.plano-inclinado`: abre Edge sin interfaz, toma capturas (escritorio, móvil táctil y tema claro) y arrastra cada asa. También comprueba que no haya desbordamiento horizontal ni recursos vivos al cerrar.

El generador sin IA y el catálogo que se envía a Claude Code o Codex se construyen a partir de `keywords`, `summary` y `params`. Un preset nuevo queda disponible para ellos sin más cambios.

## 6. Laboratorios sin escribir TypeScript (motor declarativo)

Para familias de funciones `y = f(x; parámetros)` no hace falta un módulo: se
describen en JSON y el script genera el preset con el motor genérico.

```bash
node scripts/nuevo-lab.mjs labs/familia-primitivas.json --build --install "C:\ruta\del\vault"
# o, con npm:
npm run lab -- labs/familia-primitivas.json --build --install "C:\ruta\del\vault"
```

Esquema mínimo del JSON:

- `id` (`math.<nombre>`), `title`, `summary`, `keywords`, `fidelity`.
- `xMin`, `xMax`.
- `params`: `{ id, name, label, initial, min, max, step, group }`.
- `curves`: `{ expr, color }`, con la sintaxis del evaluador: `+ - * / ^`,
  `sin, cos, tan, sqrt, abs, exp, ln, log, min, max, pow` y las variables
  `x` más los `id` de los parámetros. Constantes: `pi`, `e`.
- `cursor`: id del parámetro que mueve el punto arrastrable.
- `equation`: LaTeX que se muestra bajo la figura.

El script escribe `src/presets/math/generated/<nombre>.ts`, lo registra en
`BUILTIN_PRESETS`, compila e instala. El evaluador (`src/core/expr.ts`) no usa
`eval` ni `new Function`: tokeniza y construye un árbol con una lista blanca de
funciones.

Los laboratorios con esquema eléctrico, simulación o geometría propia (como
`circuits.rc-charging` o `math.thevenin`) siguen necesitando un módulo, porque
su dibujo no es una función de `x`.
