# PhysicaLab runtime continuation

Continue the specified `physlab/v1` design in an isolated development copy. Preserve the dedicated runtime branch and compatibility with legacy notes, then package verified deliverables.

Goal: AI writes original standalone HTML/JS; Obsidian plays it in an isolated iframe, with offline math/3D libraries, real controls/drag, state and editable source.

## Tasks

- [ ] Runtime parser, restrictive srcdoc/CSP, authenticated minimal bridge and lifecycle; contractual unit tests.
- [ ] Debounced state keyed by note path/id, exact-block snapshot conflict checks and insertion; unit tests.
- [ ] Feature-selective local KaTeX/Three/OrbitControls bundles, embedded font licensing and four original demonstration labs; mathematical and real-browser checks.
- [ ] Obsidian lifecycle and toolbars, external-file insertion/source command, settings/themes; remove AI/CLI from the shipped plugin. Retain old preset rendering for compatibility.
- [ ] Correct the six old review tests that intentionally assert already fixed bugs; keep meaningful regression assertions.
- [ ] Build, full tests, desktop/mobile-sized browser interactions, sandbox attacks, real Obsidian Reading/Live Preview if executable available; independent code review.
- [ ] Back up source/installed files, update the existing repository and install into vault with documentation and a demonstration note. Do not claim physical Android validation.

## Review focus

Same ID in one note must error; same ID across notes must remain independent. Closing/remounting during asynchronous reads must leave no frames. Persisting state must not change Markdown; explicit snapshots must detect edited source. HTML paths must be vault relative with no traversal, remote URLs or links outside the vault. Bridge spoofing, large/invalid state, network and parent-DOM access must fail. Dark/light/inherited theme tokens and actual local LaTeX font must reach the isolated document.

## Baseline and decisions

2026-10-24: baseline reproduced 189/195 passing, six failures are old review assertions expecting fixed bugs. TypeScript check passes. No runtime code or saved design document found from interrupted Claude workflow. Existing UI themes: scientific-dark, scientific-light, obsidian. Implement these in the new runtime. Mathematical font is provided locally; no additional AI service integration is needed.
