import esbuild from 'esbuild';
import process from 'process';
import { builtinModules } from 'node:module';

const banner = `/*
PhysicaLab Studio — archivo generado por esbuild.
Código fuente: carpeta src/ del repositorio physica-lab-studio.
*/
`;

const mode = process.argv[2] ?? 'dev';

if (mode === 'harness') {
	// Banco de pruebas visual fuera de Obsidian (núcleo + presets + KaTeX).
	// PHYSLAB_BUNDLE permite compilar copias independientes (agentes en paralelo).
	const bundle = (process.env.PHYSLAB_BUNDLE || 'harness').replace(/[^a-z0-9-]/gi, '');
	await esbuild.build({
		entryPoints: ['tests/visual/harness.ts'],
		bundle: true,
		format: 'iife',
		target: 'es2021',
		platform: 'browser',
		sourcemap: 'inline',
		logLevel: 'info',
		outfile: `tests/visual/dist/${bundle}.js`,
	});
	process.exit(0);
}

const prod = mode === 'production';

const context = await esbuild.context({
	banner: { js: banner },
	entryPoints: ['src/main.ts'],
	bundle: true,
	external: [
		'obsidian',
		'electron',
		'@codemirror/autocomplete',
		'@codemirror/collab',
		'@codemirror/commands',
		'@codemirror/language',
		'@codemirror/lint',
		'@codemirror/search',
		'@codemirror/state',
		'@codemirror/view',
		'@lezer/common',
		'@lezer/highlight',
		'@lezer/lr',
		...builtinModules,
		...builtinModules.map(name => `node:${name}`),
	],
	format: 'cjs',
	target: 'es2021',
	logLevel: 'info',
	sourcemap: prod ? false : 'inline',
	treeShaking: true,
	outfile: 'main.js',
	minify: prod,
});

if (prod) {
	await context.rebuild();
	process.exit(0);
} else {
	await context.watch();
}
