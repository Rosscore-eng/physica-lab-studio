/**
 * Modelo del circuito RC serie ideal en carga (funciones puras, sin DOM).
 *
 * Todas las funciones trabajan en SI (V, Ω, F, s, A, C, J). El preset
 * convierte desde las unidades del panel (V, kΩ, μF) con `fromPanel`.
 * Hipótesis: fuente ideal (sin resistencia interna), condensador
 * inicialmente descargado e interruptor ideal que se cierra en t = 0.
 * Es la solución analítica de este circuito, no un solucionador de redes.
 */
import { niceCeil } from '../../core/numeric';

/** Parámetros eléctricos en SI. */
export interface RcCircuit {
	/** Tensión de la fuente (V). */
	Vs: number;
	/** Resistencia (Ω). */
	R: number;
	/** Capacidad (F). */
	C: number;
}

/** Estado del circuito en un instante t (SI). */
export interface RcState {
	t: number;
	tau: number;
	/** Tensión en el condensador (V). */
	vC: number;
	/** Tensión en la resistencia (V). */
	vR: number;
	/** Corriente (A); en t = 0 vale I(0⁺) = V_s/R. */
	i: number;
	/** Carga del condensador q = C·V_C (C). */
	q: number;
	/** Energía almacenada U_C = ½·C·V_C² (J). */
	uC: number;
	/** Fracción de carga V_C/V_s ∈ [0, 1]. */
	fraction: number;
}

/** Fracción de carga en t = τ: 1 − e⁻¹ ≈ 0.632. */
export const CHARGE_AT_TAU = -Math.expm1(-1);

/** Unidades del panel (V, kΩ, μF) → SI. */
export function fromPanel(VsVolt: number, RkOhm: number, CmicroF: number): RcCircuit {
	return { Vs: VsVolt, R: RkOhm * 1e3, C: CmicroF * 1e-6 };
}

/** Constante de tiempo τ = RC (s). Con R en kΩ y C en μF el producto sale en ms. */
export function timeConstant(R: number, C: number): number {
	return R * C;
}

/** V_C(t) = V_s (1 − e^{−t/τ}) para t ≥ 0; 0 antes de cerrar el interruptor. */
export function capacitorVoltage(t: number, Vs: number, tau: number): number {
	if (!(t > 0) || !(tau > 0)) return 0;
	// −expm1(−x) = 1 − e^{−x} sin pérdida de precisión para x pequeño.
	return Vs * -Math.expm1(-t / tau);
}

/** V_R(t) = V_s e^{−t/τ} = V_s − V_C (malla de Kirchhoff). */
export function resistorVoltage(t: number, Vs: number, tau: number): number {
	if (t < 0 || !(tau > 0)) return 0;
	return Vs * Math.exp(-t / tau);
}

/** I(t) = (V_s/R) e^{−t/τ}; en t = 0 devuelve el límite por la derecha I(0⁺) = V_s/R. */
export function current(t: number, Vs: number, R: number, tau: number): number {
	if (!(R > 0)) return 0;
	return resistorVoltage(t, Vs, tau) / R;
}

/** q = C·V_C. */
export function charge(C: number, vC: number): number {
	return C * vC;
}

/** U_C = ½·C·V_C². */
export function capacitorEnergy(C: number, vC: number): number {
	return 0.5 * C * vC * vC;
}

/** Estado completo en t (SI). */
export function stateAt(t: number, c: RcCircuit): RcState {
	const tau = timeConstant(c.R, c.C);
	const vC = capacitorVoltage(t, c.Vs, tau);
	const vR = resistorVoltage(t, c.Vs, tau);
	return {
		t,
		tau,
		vC,
		vR,
		i: current(t, c.Vs, c.R, tau),
		q: charge(c.C, vC),
		uC: capacitorEnergy(c.C, vC),
		fraction: c.Vs > 0 ? vC / c.Vs : 0,
	};
}

/**
 * Ventana temporal automática: valor redondo {1, 2, 5}·10ⁿ ≥ 5τ. Al no
 * escalar siempre a 5τ exacto, cambiar R o C cambia la forma de la curva.
 */
export function autoWindow(tau: number): number {
	return niceCeil(5 * tau);
}

/** Valor redondo ≥ v con más escalones que `niceCeil` (escala vertical de la gráfica). */
export function niceAbove(v: number): number {
	if (!(v > 0) || !Number.isFinite(v)) return 1;
	const e = Math.floor(Math.log10(v));
	const base = Math.pow(10, e);
	for (const m of [1, 1.2, 1.5, 2, 2.5, 3, 4, 5, 6, 8, 10]) {
		if (m * base >= v * (1 - 1e-9)) return Number((m * base).toPrecision(12));
	}
	return 10 * base;
}
