import type { AnimationClock } from '../../core/lifecycle';
import { clamp, fmt, texSI, texSig, ticks } from '../../core/numeric';
import type { PresetContext, PresetDefinition, PresetInstance } from '../../core/preset';
import type { NumberParamSpec, ParamSpec, ParamValues, Point, Rect } from '../../core/types';
import { Arrow, Axes, Handle } from '../../render/svg/primitives';
import type { Place } from '../../render/svg/math-layer';
import type { SvgScene } from '../../render/svg/scene';
import { polyPath, setAttrs, show, svgEl, Viewport } from '../../render/svg/svg';
import {
	autoWindow,
	CHARGE_AT_TAU,
	capacitorVoltage,
	fromPanel,
	niceAbove,
	resistorVoltage,
	stateAt,
	timeConstant,
	type RcCircuit,
	type RcState,
} from './rc-model';
import {
	BatterySymbol,
	CapacitorSymbol,
	longestSegment,
	PartHandle,
	ResistorSymbol,
	routeOrthogonal,
	SwitchSymbol,
	terminalsOf,
	Wire,
	type Orient,
	type Terminal,
	type TwoTerminalSymbol,
} from './schematic';

/* ── Disposición del esquema ─────────────────────────────── */

/** Lado de la celda de la rejilla del esquema (unidades de escena). Las posiciones se guardan en celdas. */
export const RC_GRID = 20;
const SCH = { width: 460, height: 300 };
const GRAPH = { width: 480, height: 300 };
/** Carril del cable de retorno (celda y). */
const LANE_Y = 13;
/** Un barrido completo de la ventana dura 6 s reales a velocidad ×1 (tiempo escalado). */
const SWEEP_SECONDS = 6;
const WINDOW_MIN = 1e-4;
const WINDOW_MAX = 1000;
const T_STEP = 1e-6;

export type RcPartId = 'vs' | 'sw' | 'r' | 'c';
export const RC_PART_IDS: readonly RcPartId[] = ['vs', 'sw', 'r', 'c'];

interface PartLayout {
	name: string;
	orient: Orient;
	xId: string;
	yId: string;
	/** Posición inicial (celdas). */
	x0: number;
	y0: number;
	/** Región permitida para el centro (celdas). */
	region: { x: [number, number]; y: [number, number] };
}

export const RC_PARTS: Record<RcPartId, PartLayout> = {
	vs: { name: 'Fuente de tensión V_s', orient: 'v', xId: 'vsX', yId: 'vsY', x0: 4, y0: 8, region: { x: [4, 7], y: [6, 10] } },
	sw: { name: 'Interruptor', orient: 'h', xId: 'swX', yId: 'swY', x0: 8, y0: 3, region: { x: [7, 11], y: [3, 6] } },
	r: { name: 'Resistencia R', orient: 'h', xId: 'rX', yId: 'rY', x0: 14, y0: 3, region: { x: [12, 16], y: [3, 6] } },
	c: { name: 'Condensador C', orient: 'v', xId: 'cX', yId: 'cY', x0: 18, y0: 8, region: { x: [15, 18], y: [6, 10] } },
};

export interface RcWire {
	id: string;
	from: [RcPartId, 0 | 1];
	to: [RcPartId, 0 | 1];
	/** El retorno va por el carril inferior. */
	lane?: boolean;
}

/**
 * Topología fija (malla serie). Terminal 0 = extremo a del símbolo (arriba
 * en vertical, izquierda en horizontal): + de la fuente y placa positiva.
 */
export const RC_WIRES: readonly RcWire[] = [
	{ id: 'w1', from: ['vs', 0], to: ['sw', 0] },
	{ id: 'w2', from: ['sw', 1], to: ['r', 0] },
	{ id: 'w3', from: ['r', 1], to: ['c', 0] },
	{ id: 'w4', from: ['c', 1], to: ['vs', 1], lane: true },
];

/** Centro de un componente en la escena a partir del estado. */
export function partCenter(v: Readonly<ParamValues>, id: RcPartId): Point {
	const p = RC_PARTS[id];
	return { x: (v[p.xId] as number) * RC_GRID, y: (v[p.yId] as number) * RC_GRID };
}

/** Terminales [a, b] de un componente a partir del estado. */
export function partTerminals(v: Readonly<ParamValues>, id: RcPartId): [Terminal, Terminal] {
	return terminalsOf(partCenter(v, id), RC_PARTS[id].orient);
}

/**
 * Límites de arrastre (celdas) que impiden cruzar a los vecinos de la
 * malla: así el enrutado ortogonal siempre es limpio. Los límites absolutos
 * (región) los aplica el almacén.
 */
export function dragBounds(id: RcPartId, v: Readonly<ParamValues>): { x: [number, number]; y: [number, number] } {
	const n = (k: string): number => v[k] as number;
	const r = RC_PARTS[id].region;
	let x: [number, number] = [r.x[0], r.x[1]];
	let y: [number, number] = [r.y[0], r.y[1]];
	switch (id) {
		case 'vs':
			x[1] = Math.min(x[1], n('swX') - 3);
			y[0] = Math.max(y[0], n('swY') + 3);
			break;
		case 'sw':
			x[0] = Math.max(x[0], n('vsX') + 3);
			x[1] = Math.min(x[1], n('rX') - 5);
			y[1] = Math.min(y[1], n('vsY') - 3);
			break;
		case 'r':
			x[0] = Math.max(x[0], n('swX') + 5);
			x[1] = Math.min(x[1], n('cX') - 3);
			y[1] = Math.min(y[1], n('cY') - 3);
			break;
		case 'c':
			x[0] = Math.max(x[0], n('rX') + 3);
			y[0] = Math.max(y[0], n('rY') + 3);
			break;
	}
	// Una disposición escrita a mano puede incumplir las reglas: no se bloquea el arrastre.
	if (x[0] > x[1]) x = [r.x[0], r.x[1]];
	if (y[0] > y[1]) y = [r.y[0], r.y[1]];
	return { x, y };
}

/* ── Tiempo y unidades ───────────────────────────────────── */

function circuitOf(v: Readonly<ParamValues>): RcCircuit {
	return fromPanel(v.Vs as number, v.R as number, v.C as number);
}

function autoWindowOf(v: Readonly<ParamValues>): number {
	const c = circuitOf(v);
	return autoWindow(timeConstant(c.R, c.C));
}

/** Ventana del eje de tiempo (s): automática (redonda ≥ 5τ) o fija. */
export function windowOf(v: Readonly<ParamValues>): number {
	if (v.fixWindow === true) return clamp(v.tWindow as number, WINDOW_MIN, WINDOW_MAX);
	return clamp(autoWindowOf(v), WINDOW_MIN, WINDOW_MAX);
}

interface UnitScale {
	k: number;
	tex: string;
}

/** Unidad del eje de tiempo según la ventana. */
function timeUnit(w: number): UnitScale {
	if (w >= 1) return { k: 1, tex: '\\mathrm{s}' };
	if (w >= 1e-3) return { k: 1e-3, tex: '\\mathrm{ms}' };
	return { k: 1e-6, tex: '\\mu\\mathrm{s}' };
}

/** Unidad del eje de corriente según su máximo (A). */
function currentUnit(iMax: number): UnitScale {
	if (iMax >= 1) return { k: 1, tex: '\\mathrm{A}' };
	if (iMax >= 1e-3) return { k: 1e-3, tex: '\\mathrm{mA}' };
	return { k: 1e-6, tex: '\\mu\\mathrm{A}' };
}

function tickDecimals(values: readonly number[]): number {
	if (values.length < 2) return 0;
	const step = Math.abs((values[1] as number) - (values[0] as number));
	if (!(step > 0) || step >= 1) return 0;
	return Math.min(4, Math.ceil(-Math.log10(step) - 1e-9));
}

/* ── Parámetros ─────────────────────────────────────────── */

function positionParams(): ParamSpec[] {
	const out: ParamSpec[] = [];
	for (const id of RC_PART_IDS) {
		const p = RC_PARTS[id];
		for (const axis of ['x', 'y'] as const) {
			out.push({
				id: axis === 'x' ? p.xId : p.yId,
				type: 'number',
				name: `${p.name}: posición ${axis} en el esquema (celdas)`,
				initial: axis === 'x' ? p.x0 : p.y0,
				min: p.region[axis][0],
				max: p.region[axis][1],
				step: 1,
				control: 'none',
				group: 'Esquema',
			});
		}
	}
	return out;
}

const params: ParamSpec[] = [
	{
		id: 'Vs',
		type: 'number',
		name: 'Tensión de la fuente',
		label: 'V_s',
		initial: 12,
		min: 1,
		max: 24,
		step: 0.1,
		unit: '\\mathrm{V}',
		unitText: 'V',
		group: 'Circuito',
	},
	{
		id: 'R',
		type: 'number',
		name: 'Resistencia',
		label: 'R',
		initial: 10,
		min: 0.1,
		max: 100,
		step: 0.01,
		scale: 'log',
		unit: '\\mathrm{k\\Omega}',
		unitText: 'kΩ',
		group: 'Circuito',
	},
	{
		id: 'C',
		type: 'number',
		name: 'Capacidad',
		label: 'C',
		initial: 100,
		min: 1,
		max: 1000,
		step: 0.1,
		scale: 'log',
		unit: '\\mu\\mathrm{F}',
		unitText: 'μF',
		group: 'Circuito',
	},
	{
		id: 't',
		type: 'number',
		name: 'Tiempo desde el cierre',
		description: 'El interruptor se cierra en t = 0',
		label: 't',
		initial: 1.5,
		min: 0,
		max: WINDOW_MAX,
		step: T_STEP,
		precision: 4,
		unit: '\\mathrm{s}',
		unitText: 's',
		group: 'Tiempo',
		range: (v) => ({ min: 0, max: windowOf(v) }),
	} satisfies NumberParamSpec,
	{
		id: 'fixWindow',
		type: 'boolean',
		name: 'Fijar la ventana de tiempo',
		description: 'Desactivada: valor redondo ≥ 5τ. Activada: la ventana actual queda fija al cambiar R o C.',
		initial: false,
		group: 'Gráfica',
	},
	{
		id: 'tWindow',
		type: 'number',
		name: 'Ventana de tiempo',
		label: 't_{\\max}',
		initial: 5,
		min: WINDOW_MIN,
		max: WINDOW_MAX,
		step: WINDOW_MIN,
		scale: 'log',
		unit: '\\mathrm{s}',
		unitText: 's',
		control: 'none',
		group: 'Gráfica',
		// Sin fijar, el almacén la mantiene igual a la ventana automática; al fijarla conserva su valor.
		range: (v) => {
			if (v.fixWindow === true) return { min: WINDOW_MIN, max: WINDOW_MAX };
			const w = autoWindowOf(v);
			return { min: w, max: w };
		},
	} satisfies NumberParamSpec,
	{ id: 'showCurrent', type: 'boolean', name: 'Corriente I(t) (eje derecho)', initial: true, group: 'Gráfica' },
	{ id: 'showTau', type: 'boolean', name: 'Marca de τ (63.2 % de la carga final)', initial: true, group: 'Gráfica' },
	...positionParams(),
];

const FIDELITY =
	'Exacto: solución analítica del circuito RC serie ideal (fuente ideal sin resistencia interna, condensador inicialmente descargado, ' +
	'interruptor ideal que se cierra en t = 0): Vc(t) = Vs·(1 − e^(−t/τ)), I(t) = (Vs/R)·e^(−t/τ), τ = RC. ' +
	'No es un simulador de redes (sin SPICE): mover los componentes solo cambia el dibujo; la topología y los valores no cambian. ' +
	'Aproximación educativa: la animación usa tiempo escalado (recorre la ventana en 6 s a ×1) y los signos ± de las placas ' +
	'indican la carga de forma cualitativa.';

export const rcChargingPreset: PresetDefinition = {
	id: 'circuits.rc-charging',
	version: 1,
	mode: 'circuits',
	title: 'Circuito RC (carga)',
	summary: 'Carga de un condensador en un circuito RC serie: V_C(t), I(t) y la constante de tiempo τ = RC.',
	keywords: [
		'rc',
		'circuito rc',
		'condensador',
		'capacitor',
		'carga',
		'carga del condensador',
		'constante de tiempo',
		'tau',
		'resistencia',
		'exponencial',
		'transitorio',
		'kirchhoff',
		'circuito',
	],
	params,
	fidelity: FIDELITY,
	examples: [
		{ title: 'τ = 1 s (10 kΩ · 100 μF)', parameters: { Vs: 12, R: 10, C: 100, t: 1 } },
		{ title: 'Carga rápida (τ = 4.7 ms)', parameters: { Vs: 5, R: 4.7, C: 1, t: 0.005 } },
		{ title: 'Ventana fija para comparar R', parameters: { R: 22, C: 100, fixWindow: true, tWindow: 5, t: 2 } },
	],
	create: (ctx) => new RcChargingLab(ctx),
};

/* ── Laboratorio ────────────────────────────────────────── */

const PLOT: Rect = { x: 58, y: 40, width: 368, height: 212 };

class RcChargingLab implements PresetInstance {
	private readonly sch: SvgScene;
	private readonly graph: SvgScene;
	private readonly parts: Record<RcPartId, PartHandle<TwoTerminalSymbol>>;
	private readonly switchSym: SwitchSymbol;
	private readonly capacitor: CapacitorSymbol;
	private readonly wires = new Map<string, Wire>();
	private readonly arrow: Arrow;
	private vp: Viewport;
	private readonly axes: Axes;
	private readonly rightAxis: SVGGElement;
	private readonly vcCurve: SVGPathElement;
	private readonly iCurve: SVGPathElement;
	private readonly asymptote: SVGLineElement;
	private readonly tauV: SVGLineElement;
	private readonly tauH: SVGLineElement;
	private readonly tauDot: SVGCircleElement;
	private readonly cursor: SVGLineElement;
	private readonly hV: Handle;
	private readonly hI: Handle;
	private readonly clock: AnimationClock;
	private graphSig = '';
	/** Desplazamiento puntero → centro del componente al empezar a arrastrar. */
	private grab: Point = { x: 0, y: 0 };

	constructor(private readonly ctx: PresetContext) {
		const store = ctx.store;
		const sch = (this.sch = ctx.createScene({
			...SCH,
			label: 'Esquema del circuito RC serie: fuente, interruptor, resistencia y condensador',
		}));
		const graph = (this.graph = ctx.createScene({
			...GRAPH,
			label: 'Tensión en el condensador y corriente en función del tiempo',
		}));

		/* Esquema: cables detrás, componentes delante, anotaciones encima. */
		for (const w of RC_WIRES) {
			const wire = new Wire(sch.layers.back, w.id);
			wire.el.dataset.from = `${w.from[0]}.${w.from[1]}`;
			wire.el.dataset.to = `${w.to[0]}.${w.to[1]}`;
			this.wires.set(w.id, wire);
		}
		const main = sch.layers.main;
		const vsPart = new PartHandle(main, 'rc-part-vs', (b) => new BatterySymbol(b, RC_PARTS.vs.orient));
		const swPart = new PartHandle(main, 'rc-part-sw', (b) => new SwitchSymbol(b, RC_PARTS.sw.orient));
		const rPart = new PartHandle(main, 'rc-part-r', (b) => new ResistorSymbol(b, RC_PARTS.r.orient, 'ansi'));
		const cPart = new PartHandle(main, 'rc-part-c', (b) => new CapacitorSymbol(b, RC_PARTS.c.orient));
		this.parts = { vs: vsPart, sw: swPart, r: rPart, c: cPart };
		this.switchSym = swPart.symbol;
		this.capacitor = cPart.symbol;
		this.arrow = new Arrow(sch.layers.front, 'pl-s-amber', 10, 8);

		for (const id of RC_PART_IDS) {
			const part = this.parts[id];
			part.handle.g.dataset.part = id;
			const def = RC_PARTS[id];
			ctx.draggable(
				sch,
				part.handle.g,
				{
					onStart: (p) => {
						const c = partCenter(store.all(), id);
						this.grab = { x: p.x - c.x, y: p.y - c.y };
					},
					onMove: (p) => this.movePart(id, Math.round((p.x - this.grab.x) / RC_GRID), Math.round((p.y - this.grab.y) / RC_GRID), 'drag'),
					onKey: (dx, dy, m) => {
						const k = m.coarse ? 2 : 1;
						this.movePart(id, store.num(def.xId) + dx * k, store.num(def.yId) - dy * k, 'keyboard');
					},
				},
				`${def.name} en el esquema: arrástralo para recolocarlo; las conexiones se mantienen`,
			);
		}

		/* Gráfica */
		this.vp = new Viewport({ xMin: 0, xMax: 5, yMin: 0, yMax: 15 }, PLOT);
		this.axes = new Axes(graph.layers.grid, graph.layers.back);
		this.rightAxis = svgEl(graph.layers.back, 'g', { class: 'pl-axes rc-axis-i' });
		const clipId = graph.id('plot');
		const cp = svgEl(graph.defs, 'clipPath', { id: clipId });
		svgEl(cp, 'rect', { x: PLOT.x - 2, y: PLOT.y - 4, width: PLOT.width + 4, height: PLOT.height + 6 });
		const plot = svgEl(graph.layers.main, 'g', { 'clip-path': `url(#${clipId})` });
		this.asymptote = svgEl(plot, 'line', { class: 'pl-line pl-thin pl-dashed pl-s-muted' });
		this.tauV = svgEl(plot, 'line', { class: 'pl-line pl-thin pl-dotted pl-s-green' });
		this.tauH = svgEl(plot, 'line', { class: 'pl-line pl-thin pl-dotted pl-s-green' });
		this.iCurve = svgEl(plot, 'path', { class: 'pl-curve pl-s-amber pl-dashed rc-curve-i' });
		this.vcCurve = svgEl(plot, 'path', { class: 'pl-curve pl-s-blue rc-curve-vc' });
		this.cursor = svgEl(graph.layers.front, 'line', { class: 'pl-line pl-thin pl-s-muted rc-cursor' });
		this.tauDot = svgEl(graph.layers.front, 'circle', { class: 'pl-f-green', r: 3 });
		this.hI = new Handle(graph.layers.handles, 'pl-pt pl-pt-amber', 4.5);
		svgEl(this.hI.body, 'circle', { r: 4.5, class: 'pl-pt-dot' });
		this.hV = new Handle(graph.layers.handles, 'pl-pt pl-pt-blue', 5.5);
		svgEl(this.hV.body, 'circle', { r: 5.5, class: 'pl-pt-dot' });

		const timeHandlers = (label: string, el: SVGGElement): void => {
			ctx.draggable(
				graph,
				el,
				{
					onMove: (p) => store.set('t', this.timeFromPointer(p), 'drag'),
					onKey: (dx, _dy, m) => {
						const w = windowOf(store.all());
						store.set('t', store.num('t') + dx * w * (m.coarse ? 0.05 : m.fine ? 0.001 : 0.01), 'keyboard');
					},
				},
				label,
			);
		};
		timeHandlers('Instante t sobre la curva V_C(t): arrastra en horizontal para cambiar el tiempo', this.hV.g);
		timeHandlers('Instante t sobre la curva I(t): arrastra en horizontal para cambiar el tiempo', this.hI.g);

		const fitHits = (): void => {
			for (const id of RC_PART_IDS) this.parts[id].handle.setHitRadius(sch.touchRadius(22));
			this.hV.setHitRadius(graph.touchRadius(22));
			this.hI.setHitRadius(graph.touchRadius(20));
		};
		fitHits();
		ctx.scope.add(sch.onResize(fitHits));
		ctx.scope.add(graph.onResize(fitHits));

		/* Animación: t avanza de 0 al final de la ventana en tiempo escalado. */
		this.clock = ctx.clock((dt) => {
			const w = windowOf(store.all());
			const t = store.num('t');
			if (t >= w) return false;
			const next = Math.min(w, Math.max(t + T_STEP, t + (dt * w) / SWEEP_SECONDS));
			store.set('t', next, 'animation');
			return next < w;
		});
		ctx.scope.add(
			this.clock.onChange((playing) => {
				// Reproducir desde el final vuelve a empezar desde t = 0.
				if (playing && store.num('t') >= windowOf(store.all())) store.set('t', 0, 'animation');
				ctx.requestRender();
			}),
		);
		// Mover t a mano (deslizador, cursor o teclado) pausa la animación.
		ctx.scope.add(
			store.subscribe((changed, source) => {
				if (changed.has('t') && (source === 'panel' || source === 'drag' || source === 'keyboard')) this.clock.pause();
			}),
		);
		if (ctx.features.animation) {
			ctx.panel.addAnimationControls(this.clock, {
				label: 'carga del condensador',
				onRestart: () => store.set('t', 0, 'api'),
			});
		}
		ctx.panel.addButton(
			't = τ',
			() => {
				this.clock.pause();
				const c = circuitOf(store.all());
				store.set('t', timeConstant(c.R, c.C), 'api');
			},
			{ title: 'Coloca el cursor en t = τ, donde V_C = 63.2 % de V_s', quiet: true },
		);
		ctx.panel.addButton(
			'Recolocar esquema',
			() => {
				const init = store.initialValues();
				const patch: ParamValues = {};
				for (const id of RC_PART_IDS) {
					const p = RC_PARTS[id];
					patch[p.xId] = init[p.xId] as number;
					patch[p.yId] = init[p.yId] as number;
				}
				store.update(patch, 'api');
			},
			{ title: 'Devuelve los componentes a su posición inicial (la topología no cambia)', quiet: true },
		);
		ctx.panel.addNote('Arrastra los componentes del esquema o el punto de la curva. La animación recorre la ventana en 6 s (tiempo escalado).');
		ctx.setNote(FIDELITY);
	}

	/** Mueve un componente a la celda pedida respetando a sus vecinos (el almacén aplica la región). */
	private movePart(id: RcPartId, cx: number, cy: number, source: 'drag' | 'keyboard'): void {
		const store = this.ctx.store;
		const def = RC_PARTS[id];
		const b = dragBounds(id, store.all());
		store.update({ [def.xId]: clamp(cx, b.x[0], b.x[1]), [def.yId]: clamp(cy, b.y[0], b.y[1]) }, source);
	}

	/** Tiempo bajo el puntero, con imán en t = τ (6 px). */
	private timeFromPointer(p: Point): number {
		const store = this.ctx.store;
		let t = this.vp.toWorld(p).x;
		const c = circuitOf(store.all());
		const tau = timeConstant(c.R, c.C);
		if (store.bool('showTau') && Math.abs(this.vp.X(t) - this.vp.X(tau)) * this.graph.pxPerUnit < 6) t = tau;
		return t;
	}

	render(): void {
		const store = this.ctx.store;
		const v = store.all();
		const c = circuitOf(v);
		const w = windowOf(v);
		const t = store.num('t');
		const s = stateAt(t, c);
		const closed = t > 0 || this.clock.playing;
		this.renderSchematic(v, c, s, closed);
		this.renderGraph(v, c, s, w);
		this.renderEquations(c, s, t);
		this.ctx.status(
			t === 0
				? 't = 0: el interruptor se cierra; se muestran los valores en t = 0⁺'
				: s.tau > w
					? 'τ queda fuera de la ventana fija: V_C no llega al 63.2 % de V_s'
					: t >= 5 * s.tau
						? 't ≥ 5τ: V_C supera el 99.3 % de V_s (régimen casi estacionario)'
						: null,
		);
	}

	setVisible(v: boolean): void {
		if (!v) this.clock.pause();
	}

	destroy(): void {
		this.clock.pause();
	}

	/* ── Esquema ─────────────────────────────────────────── */

	private renderSchematic(v: Readonly<ParamValues>, c: RcCircuit, s: RcState, closed: boolean): void {
		const centers = {} as Record<RcPartId, Point>;
		for (const id of RC_PART_IDS) {
			centers[id] = partCenter(v, id);
			this.parts[id].moveTo(centers[id]);
		}
		const boxes = RC_PART_IDS.map((id) => this.parts[id].symbol.box(centers[id]));
		for (const w of RC_WIRES) {
			const a = partTerminals(v, w.from[0])[w.from[1]];
			const b = partTerminals(v, w.to[0])[w.to[1]];
			const pts = routeOrthogonal(a, b, boxes, w.lane ? { lanes: { y: [LANE_Y * RC_GRID] } } : {});
			this.wires.get(w.id)?.set(pts);
		}

		this.switchSym.setClosed(closed);
		this.capacitor.setCharge(s.fraction);

		// Flecha de corriente sobre el tramo más largo del retorno, hacia el interior de la malla.
		const ret = this.wires.get('w4')?.points ?? [];
		const seg = longestSegment(ret);
		const ux = seg.length > 0 ? (seg.b.x - seg.a.x) / seg.length : -1;
		const uy = seg.length > 0 ? (seg.b.y - seg.a.y) / seg.length : 0;
		let cx = 0;
		let cy = 0;
		for (const id of RC_PART_IDS) {
			cx += centers[id].x / RC_PART_IDS.length;
			cy += centers[id].y / RC_PART_IDS.length;
		}
		const mid = { x: (seg.a.x + seg.b.x) / 2, y: (seg.a.y + seg.b.y) / 2 };
		let nx = -uy;
		let ny = ux;
		if (nx * (cx - mid.x) + ny * (cy - mid.y) < 0) {
			nx = -nx;
			ny = -ny;
		}
		const i0 = c.Vs / c.R;
		const frac = closed && i0 > 0 ? clamp(s.i / i0, 0, 1) : 0;
		const len = 18 + 30 * frac;
		const ax = mid.x + nx * 12;
		const ay = mid.y + ny * 12;
		this.arrow.set(ax - (ux * len) / 2, ay - (uy * len) / 2, ax + (ux * len) / 2, ay + (uy * len) / 2);
		this.arrow.visible(frac > 0.01);
		setAttrs(this.arrow.g, { opacity: (0.45 + 0.55 * frac).toFixed(3) });

		const L = this.sch.labels;
		const vs = centers.vs;
		const sw = centers.sw;
		const r = centers.r;
		const cc = centers.c;
		L.label('vs', `\\begin{matrix}V_s\\\\${texSI(c.Vs, 'V')}\\end{matrix}`).at({ x: vs.x - 21, y: vs.y }, 'w', 5);
		L.label('sw', 't=0').at({ x: sw.x, y: sw.y - 18 }, 'n', 2).fontSize('sm').color('muted');
		L.label('r', `R=${texSI(c.R, '\\Omega')}`).at({ x: r.x, y: r.y - 12 }, 'n', 3);
		L.label('vr', `V_R=${texSI(s.vR, 'V')}`).at({ x: r.x, y: r.y + 12 }, 's', 3).fontSize('sm').color('violet');
		L.label('c', `\\begin{matrix}C\\\\${texSI(c.C, 'F')}\\end{matrix}`).at({ x: cc.x + 26, y: cc.y }, 'e', 5);
		L.label('vc', `V_C=${texSI(s.vC, 'V')}`).at({ x: cc.x - 28, y: cc.y }, 'w', 4).fontSize('sm').color('blue');
		const place: Place = Math.abs(ny) >= Math.abs(nx) ? (ny < 0 ? 'n' : 's') : nx < 0 ? 'w' : 'e';
		L.label('i', closed ? `I=${texSI(s.i, 'A')}` : `I(0^{+})=${texSI(i0, 'A')}`)
			.at({ x: ax + nx * 4, y: ay + ny * 4 }, place, 3)
			.fontSize('sm')
			.color('amber');
	}

	/* ── Gráfica ─────────────────────────────────────────── */

	private renderGraph(v: Readonly<ParamValues>, c: RcCircuit, s: RcState, w: number): void {
		const showI = v.showCurrent === true;
		const showTau = v.showTau === true;
		const tau = s.tau;
		const sig = [c.Vs, c.R, c.C, w, showI, showTau].join('|');
		const G = this.graph.labels;
		if (sig !== this.graphSig) {
			this.graphSig = sig;
			const yMax = niceAbove(c.Vs * 1.08);
			const vp = (this.vp = new Viewport({ xMin: 0, xMax: w, yMin: 0, yMax }, PLOT));
			const tu = timeUnit(w);
			const xt = ticks(0, w / tu.k, 5);
			const yt = ticks(0, yMax, 5);
			const xd = tickDecimals(xt);
			const yd = tickDecimals(yt);
			this.axes.draw(vp, {
				xTicks: xt.map((x) => x * tu.k),
				yTicks: yt,
				cross: false,
				xFormat: (x) => fmt(x / tu.k, xd),
				yFormat: (y) => fmt(y, yd),
			});
			this.drawCurrentAxis(vp, c, yMax, showI);

			this.vcCurve.setAttribute('d', curvePath(vp, (x) => capacitorVoltage(x, c.Vs, tau), w, tau));
			// I(t)·R comparte la escala de tensiones: el eje derecho la traduce a corriente.
			this.iCurve.setAttribute('d', curvePath(vp, (x) => resistorVoltage(x, c.Vs, tau), w, tau));
			show(this.iCurve, showI);
			setAttrs(this.asymptote, { x1: vp.X(0), y1: vp.Y(c.Vs), x2: vp.X(w), y2: vp.Y(c.Vs) });

			const tauIn = showTau && tau <= w;
			const v63 = c.Vs * CHARGE_AT_TAU;
			setAttrs(this.tauV, { x1: vp.X(tau), y1: vp.Y(0), x2: vp.X(tau), y2: vp.Y(v63) });
			setAttrs(this.tauH, { x1: vp.X(0), y1: vp.Y(v63), x2: vp.X(tau), y2: vp.Y(v63) });
			setAttrs(this.tauDot, { cx: vp.X(tau), cy: vp.Y(v63) });
			for (const el of [this.tauV, this.tauH, this.tauDot]) show(el, tauIn);
			const nearRight = vp.X(tau) > PLOT.x + PLOT.width - 70;
			G.label('tau', '\\tau')
				.at({ x: vp.X(tau), y: vp.Y(0) }, nearRight ? 'nw' : 'ne', 3)
				.color('green')
				.visible(tauIn);
			G.label('tau-pt', '0.632\\,V_s')
				.at({ x: vp.X(tau), y: vp.Y(v63) }, nearRight ? 'nw' : 'se', 5)
				.fontSize('sm')
				.color('green')
				.visible(tauIn);

			G.label('ax-v', 'V_C\\;(\\mathrm{V})').at({ x: PLOT.x, y: PLOT.y - 5 }, 'n', 2).fontSize('sm').color('blue');
			G.label('ax-t', `t\\;(${tu.tex})`)
				.at({ x: PLOT.x + PLOT.width / 2, y: PLOT.y + PLOT.height + 19 }, 's', 1)
				.fontSize('sm')
				.color('muted');
			G.label('vs', 'V_s').at({ x: PLOT.x + PLOT.width - 4, y: vp.Y(c.Vs) }, 'nw', 3).fontSize('sm').color('muted');

			// Etiquetas de las curvas en t = 0.72·ventana, sin solaparse entre sí.
			const tl = 0.72 * w;
			const yv = capacitorVoltage(tl, c.Vs, tau);
			const yi = resistorVoltage(tl, c.Vs, tau);
			const inner = yv >= yi && vp.Y(yi) - vp.Y(yv) > 46;
			const vcPlace: Place = yv >= yi && !inner ? 'n' : 's';
			const iPlace: Place = yv >= yi && !inner ? 's' : 'n';
			G.label('vc-curve', 'V_C(t)').at({ x: vp.X(tl), y: vp.Y(yv) }, vcPlace, 6).color('blue');
			G.label('i-curve', 'I(t)').at({ x: vp.X(tl), y: vp.Y(yi) }, iPlace, 6).color('amber').visible(showI);
		}

		// Cursor del instante t (siempre se actualiza).
		const vp = this.vp;
		const X = vp.X(s.t);
		setAttrs(this.cursor, { x1: X, y1: vp.Y(0), x2: X, y2: PLOT.y });
		this.hV.moveTo({ x: X, y: vp.Y(s.vC) });
		this.hI.moveTo({ x: X, y: vp.Y(s.vR) });
		this.hI.visible(showI);
	}

	/** Eje derecho de corriente: la curva I·R se lee en A, mA o μA. */
	private drawCurrentAxis(vp: Viewport, c: RcCircuit, yMax: number, visible: boolean): void {
		const g = this.rightAxis;
		g.replaceChildren();
		show(g, visible);
		const iMax = yMax / c.R;
		const u = currentUnit(iMax);
		const it = ticks(0, iMax / u.k, 5);
		const d = tickDecimals(it);
		const x = vp.X(vp.world.xMax);
		svgEl(g, 'line', { class: 'pl-axis', x1: x, y1: vp.Y(0), x2: x, y2: vp.Y(yMax) });
		for (const val of it) {
			const y = vp.Y(val * u.k * c.R);
			if (y < vp.Y(yMax) - 0.5) continue;
			svgEl(g, 'line', { class: 'pl-tick', x1: x, y1: y, x2: x + 4, y2: y });
			const label = svgEl(g, 'text', { class: 'pl-tick-label rc-tick-i', x: x + 7, y: y + 3.5, 'text-anchor': 'start' });
			label.textContent = fmt(val, d);
		}
		this.graph.labels
			.label('ax-i', `I\\;(${u.tex})`)
			.at({ x, y: PLOT.y - 5 }, 'n', 2)
			.fontSize('sm')
			.color('amber')
			.visible(visible);
	}

	/* ── Ecuaciones y lecturas ───────────────────────────── */

	private renderEquations(c: RcCircuit, s: RcState, t: number): void {
		const eq = this.ctx.equations;
		const ratio = s.tau > 0 ? t / s.tau : 0;
		// Cifras significativas (no decimales fijos): con t ≪ τ el exponente sustituido debe reproducir V_C e I.
		const r = texSig(ratio, 3);
		const V = (x: number): string => texSI(x, 'V');
		eq.readout('t', `t=${texSI(t, 's')}`);
		eq.readout('ratio', `t/\\tau=${r}`);
		eq.readout('vc', `V_C=${V(s.vC)}`);
		eq.readout('vr', `V_R=${V(s.vR)}`);
		eq.readout('i', t > 0 ? `I=${texSI(s.i, 'A')}` : `I(0^{+})=${texSI(s.i, 'A')}`);
		eq.readout('q', `q=CV_C=${texSI(s.q, 'C')}`);
		eq.readout('uc', `U_C=\\tfrac{1}{2}CV_C^2=${texSI(s.uC, 'J')}`);

		eq.set(
			'tau',
			`\\tau=RC=(${texSI(c.R, '\\Omega')})(${texSI(c.C, 'F')})=${texSI(s.tau, 's')}`,
			'Constante de tiempo (1 kΩ · 1 μF = 1 ms)',
		);
		eq.set(
			'vc-t',
			`V_C(t)=V_s\\left(1-e^{-t/\\tau}\\right)=${V(c.Vs)}\\left(1-e^{-${r}}\\right)=${V(s.vC)}`,
			'Tensión en el condensador (carga desde 0)',
		);
		eq.set(
			'i-t',
			`I(t)=\\frac{V_s}{R}\\,e^{-t/\\tau}=\\frac{${V(c.Vs)}}{${texSI(c.R, '\\Omega')}}\\,e^{-${r}}=${texSI(s.i, 'A')}`,
			t > 0 ? 'Corriente en la malla' : 'Corriente en la malla (t = 0⁺, justo tras cerrar)',
		);
		eq.set(
			'vr-t',
			`V_R(t)=R\\,I(t)=V_s\\,e^{-t/\\tau}=${V(s.vR)},\\qquad V_R+V_C=V_s`,
			'Tensión en la resistencia (ley de mallas de Kirchhoff)',
		);
	}
}

/**
 * Trazo de f en [0, w]: muestreo uniforme más puntos finos en los primeros
 * 8τ, para que la subida no se pierda cuando τ es mucho menor que la ventana.
 */
function curvePath(vp: Viewport, f: (t: number) => number, w: number, tau: number): string {
	const ts: number[] = [];
	const N = 200;
	for (let i = 0; i <= N; i++) ts.push((w * i) / N);
	const fine = Math.min(w, 8 * tau);
	if (fine < w / 4) for (let i = 1; i < 80; i++) ts.push((fine * i) / 80);
	ts.sort((a, b) => a - b);
	const pts: Point[] = [];
	let last = Number.NaN;
	for (const t of ts) {
		if (t === last) continue;
		last = t;
		const y = f(t);
		if (Number.isFinite(y)) pts.push({ x: vp.X(t), y: vp.Y(y) });
	}
	return polyPath(pts);
}
