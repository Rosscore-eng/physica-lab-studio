import type { Point, Rect } from '../../core/types';
import { Handle } from '../../render/svg/primitives';
import { polyPath, setAttrs, show, svgEl } from '../../render/svg/svg';

/**
 * Símbolos de esquema eléctrico reutilizables (CircuitLab) y enrutado
 * ortogonal de cables.
 *
 * Norma: ANSI/IEEE Std 315 (resistencia en zigzag). El rectángulo de
 * IEC 60617 está disponible con `style: 'iec'`. La batería sigue el
 * convenio común a ambas normas: placa larga y fina = polo positivo.
 *
 * Todos los símbolos de dos terminales miden 2·PART_HALF entre terminales y
 * se dibujan en coordenadas locales (eje del componente = x local). La
 * orientación ('h' o 'v') se aplica a las coordenadas, no con `rotate`, para
 * que los signos + y − se vean siempre derechos.
 *
 * Estilos: clases `sch-*` en src/presets/circuits/rc-charging.css.
 */

export type Orient = 'h' | 'v';

/** Distancia centro → terminal de los símbolos de dos terminales. */
export const PART_HALF = 40;

/** Terminal: posición en la escena y dirección unitaria hacia fuera del componente. */
export interface Terminal extends Point {
	dx: number;
	dy: number;
}

/* ── Geometría pura ─────────────────────────────────────── */

/** Coordenadas locales → desplazamiento en la escena. En 'v' el extremo a (x < 0) queda arriba. */
export function orientOffset(p: Point, orient: Orient): Point {
	return orient === 'h' ? { x: p.x, y: p.y } : { x: -p.y || 0, y: p.x };
}

/** Terminales [a, b] de un símbolo centrado en `c` (a en x local negativa). */
export function terminalsOf(c: Point, orient: Orient, half = PART_HALF): [Terminal, Terminal] {
	const a = orientOffset({ x: -half, y: 0 }, orient);
	const b = orientOffset({ x: half, y: 0 }, orient);
	return [
		{ x: c.x + a.x, y: c.y + a.y, dx: Math.sign(a.x) || 0, dy: Math.sign(a.y) || 0 },
		{ x: c.x + b.x, y: c.y + b.y, dx: Math.sign(b.x) || 0, dy: Math.sign(b.y) || 0 },
	];
}

/** Rectángulo de escena que ocupa el cuerpo (sin patillas) de un símbolo centrado en `c`. */
export function bodyBox(c: Point, orient: Orient, halfLen: number, halfWidth: number): Rect {
	return orient === 'h'
		? { x: c.x - halfLen, y: c.y - halfWidth, width: 2 * halfLen, height: 2 * halfWidth }
		: { x: c.x - halfWidth, y: c.y - halfLen, width: 2 * halfWidth, height: 2 * halfLen };
}

/** Quita puntos repetidos y puntos intermedios alineados (incluidos los retrocesos). */
export function simplifyPath(points: readonly Point[]): Point[] {
	const out: Point[] = [];
	for (const p of points) {
		const last = out[out.length - 1];
		if (last && Math.abs(last.x - p.x) < 1e-6 && Math.abs(last.y - p.y) < 1e-6) continue;
		out.push({ x: p.x, y: p.y });
		while (out.length >= 3) {
			const a = out[out.length - 3] as Point;
			const b = out[out.length - 2] as Point;
			const c = out[out.length - 1] as Point;
			const cross = (b.x - a.x) * (c.y - b.y) - (b.y - a.y) * (c.x - b.x);
			if (Math.abs(cross) > 1e-6) break;
			out.splice(out.length - 2, 1);
		}
	}
	return out;
}

export interface RouteOptions {
	/** Tramo recto con el que el cable sale de cada terminal antes de girar. */
	stub?: number;
	/** Carriles preferidos: si una ruta en U por ellos es válida y libre, se usa. */
	lanes?: { x?: number[]; y?: number[] };
}

const BEND_COST = 12;
const BLOCKED_COST = 1e5;

/**
 * Cable ortogonal entre dos terminales. El cable sale de `a` en su
 * dirección y entra en `b` por la suya; se elige, entre rutas en L, Z y U,
 * la más corta con menos codos que no atraviesa el cuerpo de ningún
 * componente (`obstacles`). El primer punto es siempre `a` y el último `b`.
 */
export function routeOrthogonal(a: Terminal, b: Terminal, obstacles: readonly Rect[] = [], opts: RouteOptions = {}): Point[] {
	const A: Point = { x: a.x, y: a.y };
	const B: Point = { x: b.x, y: b.y };
	if (Math.hypot(A.x - B.x, A.y - B.y) < 1e-6) return [A, B];
	const stub = opts.stub ?? 20;
	const general: Point[][] = [];
	const laned: Point[][] = [];
	for (const s of [0, stub]) {
		const P: Point = { x: a.x + a.dx * s, y: a.y + a.dy * s };
		const Q: Point = { x: b.x + b.dx * s, y: b.y + b.dy * s };
		const mx = (P.x + Q.x) / 2;
		const my = (P.y + Q.y) / 2;
		const ext = 2 * stub;
		const mids: Point[][] = [
			[{ x: Q.x, y: P.y }],
			[{ x: P.x, y: Q.y }],
			[
				{ x: mx, y: P.y },
				{ x: mx, y: Q.y },
			],
			[
				{ x: P.x, y: my },
				{ x: Q.x, y: my },
			],
		];
		// Rodeos en U a ambos lados, por si el camino directo está bloqueado.
		for (const y of [Math.min(P.y, Q.y) - ext, Math.max(P.y, Q.y) + ext]) {
			mids.push([
				{ x: P.x, y },
				{ x: Q.x, y },
			]);
		}
		for (const x of [Math.min(P.x, Q.x) - ext, Math.max(P.x, Q.x) + ext]) {
			mids.push([
				{ x, y: P.y },
				{ x, y: Q.y },
			]);
		}
		for (const m of mids) general.push([A, P, ...m, Q, B]);
		for (const y of opts.lanes?.y ?? []) laned.push([A, P, { x: P.x, y }, { x: Q.x, y }, Q, B]);
		for (const x of opts.lanes?.x ?? []) laned.push([A, P, { x, y: P.y }, { x, y: Q.y }, Q, B]);
	}
	const lane = bestRoute(laned, a, b, obstacles);
	if (lane.path && lane.cost < BLOCKED_COST) return lane.path;
	const any = bestRoute(general, a, b, obstacles);
	return any.path ?? [A, { x: B.x, y: A.y }, B];
}

function bestRoute(
	candidates: readonly Point[][],
	a: Terminal,
	b: Terminal,
	obstacles: readonly Rect[],
): { path: Point[] | null; cost: number } {
	let path: Point[] | null = null;
	let cost = Number.POSITIVE_INFINITY;
	for (const raw of candidates) {
		const p = simplifyPath(raw);
		if (!leavesAndEnters(p, a, b)) continue;
		const c = routeCost(p, obstacles);
		if (c < cost - 1e-9) {
			cost = c;
			path = p;
		}
	}
	return { path, cost };
}

/** El cable sale de `a` en su dirección y llega a `b` en sentido contrario al de `b`. */
function leavesAndEnters(p: readonly Point[], a: Terminal, b: Terminal): boolean {
	if (p.length < 2) return false;
	const p0 = p[0] as Point;
	const p1 = p[1] as Point;
	const q0 = p[p.length - 2] as Point;
	const q1 = p[p.length - 1] as Point;
	const d0 = unit(p0, p1);
	const d1 = unit(q0, q1);
	return d0.x === a.dx && d0.y === a.dy && d1.x === -b.dx && d1.y === -b.dy;
}

function unit(p: Point, q: Point): Point {
	return { x: Math.sign(q.x - p.x) || 0, y: Math.sign(q.y - p.y) || 0 };
}

function routeCost(p: readonly Point[], obstacles: readonly Rect[]): number {
	let cost = BEND_COST * Math.max(0, p.length - 2);
	for (let i = 1; i < p.length; i++) {
		const s = p[i - 1] as Point;
		const e = p[i] as Point;
		cost += Math.abs(e.x - s.x) + Math.abs(e.y - s.y);
		for (const r of obstacles) if (segmentHitsBox(s, e, r)) cost += BLOCKED_COST;
	}
	return cost;
}

/** ¿El segmento ortogonal p–q entra en el interior del rectángulo (con margen)? */
export function segmentHitsBox(p: Point, q: Point, r: Rect, margin = 3): boolean {
	const x0 = Math.min(p.x, q.x);
	const x1 = Math.max(p.x, q.x);
	const y0 = Math.min(p.y, q.y);
	const y1 = Math.max(p.y, q.y);
	return x1 > r.x - margin && x0 < r.x + r.width + margin && y1 > r.y - margin && y0 < r.y + r.height + margin;
}

/** Tramo más largo de una polilínea (para colocar flechas y etiquetas). */
export function longestSegment(p: readonly Point[]): { a: Point; b: Point; length: number } {
	let best = { a: p[0] ?? { x: 0, y: 0 }, b: p[1] ?? p[0] ?? { x: 0, y: 0 }, length: 0 };
	for (let i = 1; i < p.length; i++) {
		const a = p[i - 1] as Point;
		const b = p[i] as Point;
		const length = Math.hypot(b.x - a.x, b.y - a.y);
		if (length > best.length) best = { a, b, length };
	}
	return best;
}

/* ── Símbolos ───────────────────────────────────────────── */

/** Base de los símbolos de dos terminales: dibuja en coordenadas locales ya orientadas. */
export abstract class TwoTerminalSymbol {
	readonly g: SVGGElement;
	/** Semilongitud y semianchura del cuerpo (sin patillas), en coordenadas locales. */
	abstract readonly halfLen: number;
	abstract readonly halfWidth: number;

	constructor(
		parent: Element,
		readonly orient: Orient,
		cls: string,
	) {
		this.g = svgEl(parent, 'g', { class: `sch-sym ${cls}` });
	}

	/** Cuerpo en la escena para un centro dado. */
	box(c: Point): Rect {
		return bodyBox(c, this.orient, this.halfLen, this.halfWidth);
	}

	/** Cuerpo relativo al centro (selección y zona táctil). */
	localBox(pad = 0): Rect {
		const r = this.box({ x: 0, y: 0 });
		return { x: r.x - pad, y: r.y - pad, width: r.width + 2 * pad, height: r.height + 2 * pad };
	}

	protected at(x: number, y: number): Point {
		return orientOffset({ x, y }, this.orient);
	}

	protected line(x1: number, y1: number, x2: number, y2: number, cls?: string): SVGLineElement {
		const p = this.at(x1, y1);
		const q = this.at(x2, y2);
		return svgEl(this.g, 'line', { x1: p.x, y1: p.y, x2: q.x, y2: q.y, class: cls });
	}

	protected setLine(el: SVGLineElement, x1: number, y1: number, x2: number, y2: number): void {
		const p = this.at(x1, y1);
		const q = this.at(x2, y2);
		setAttrs(el, { x1: p.x, y1: p.y, x2: q.x, y2: q.y });
	}

	protected path(points: Array<[number, number]>, cls?: string): SVGPathElement {
		return svgEl(this.g, 'path', { d: polyPath(points.map(([x, y]) => this.at(x, y))), class: cls });
	}

	/** Patillas desde los terminales (±PART_HALF) hasta ±`inner`. */
	protected leads(inner: number): void {
		this.line(-PART_HALF, 0, -inner, 0);
		this.line(inner, 0, PART_HALF, 0);
	}
}

/** Resistencia: zigzag ANSI/IEEE 315 (por defecto) o rectángulo IEC 60617. */
export class ResistorSymbol extends TwoTerminalSymbol {
	readonly halfLen = 25;
	readonly halfWidth: number;

	constructor(parent: Element, orient: Orient, style: 'ansi' | 'iec' = 'ansi') {
		super(parent, orient, `sch-resistor sch-${style}`);
		const w = 24;
		this.leads(w);
		if (style === 'iec') {
			this.halfWidth = 9;
			this.path(
				[
					[-w, -8],
					[w, -8],
					[w, 8],
					[-w, 8],
					[-w, -8],
				],
				'sch-body',
			);
		} else {
			// Seis tramos de igual anchura con amplitud ±8: tres crestas arriba y tres abajo.
			this.halfWidth = 10;
			const d = (2 * w) / 6;
			const pts: Array<[number, number]> = [[-w, 0]];
			for (let k = 0; k < 6; k++) pts.push([-w + d / 2 + k * d, k % 2 === 0 ? -8 : 8]);
			pts.push([w, 0]);
			this.path(pts, 'sch-body');
		}
	}
}

/**
 * Condensador de placas paralelas. La placa del terminal a es la positiva.
 * `setCharge(f)` muestra la carga con dos pares de signos + y − por placa,
 * cuya opacidad crece de forma continua con f (cualitativo).
 */
export class CapacitorSymbol extends TwoTerminalSymbol {
	readonly halfLen = 7;
	readonly halfWidth = 24;
	private readonly pairs: SVGGElement[] = [];
	private static readonly SLOTS = [8.5, 17.5];

	constructor(parent: Element, orient: Orient) {
		super(parent, orient, 'sch-capacitor');
		const gap = 6;
		const half = 24;
		this.leads(gap);
		this.line(-gap, -half, -gap, half, 'sch-plate');
		this.line(gap, -half, gap, half, 'sch-plate');
		const s = 3.4;
		const off = gap + 8;
		for (const along of CapacitorSymbol.SLOTS) {
			const pair = svgEl(this.g, 'g', { class: 'sch-signs' });
			for (const sg of [-1, 1]) {
				const p = this.at(-off, sg * along);
				const m = this.at(off, sg * along);
				svgEl(pair, 'path', { class: 'sch-sign sch-sign-plus', d: `M${p.x - s} ${p.y}H${p.x + s}M${p.x} ${p.y - s}V${p.y + s}` });
				svgEl(pair, 'path', { class: 'sch-sign sch-sign-minus', d: `M${m.x - s} ${m.y}H${m.x + s}` });
			}
			this.pairs.push(pair);
		}
		this.setCharge(0);
	}

	/** Fracción de carga ∈ [0, 1]: el par k aparece entre f = k/2 y f = (k+1)/2. */
	setCharge(fraction: number): void {
		const f = Number.isFinite(fraction) ? Math.min(1, Math.max(0, fraction)) : 0;
		const n = this.pairs.length;
		this.pairs.forEach((g, k) => {
			const o = Math.min(1, Math.max(0, n * f - k));
			show(g, o > 0.02);
			g.setAttribute('opacity', o.toFixed(3));
		});
	}

	/** Número de pares de signos visibles (pruebas). */
	get signCount(): number {
		return this.pairs.filter((g) => g.getAttribute('display') !== 'none').length;
	}
}

/** Batería (fuente de tensión continua): placa larga = +, placa corta y gruesa = −. */
export class BatterySymbol extends TwoTerminalSymbol {
	readonly halfLen = 7;
	readonly halfWidth = 19;

	constructor(parent: Element, orient: Orient) {
		super(parent, orient, 'sch-battery');
		this.leads(5);
		this.line(-5, -18, -5, 18, 'sch-plate');
		this.line(5, -9, 5, 9, 'sch-plate sch-plate-thick');
		// «+» junto a la placa positiva (encima si es horizontal, a la derecha si es vertical).
		const p = this.at(-14, -15);
		const s = 3.4;
		svgEl(this.g, 'path', { class: 'sch-polarity', d: `M${p.x - s} ${p.y}H${p.x + s}M${p.x} ${p.y - s}V${p.y + s}` });
	}
}

/** Interruptor unipolar (contacto de palanca). */
export class SwitchSymbol extends TwoTerminalSymbol {
	readonly halfLen = 20;
	readonly halfWidth = 17;
	private readonly lever: SVGLineElement;
	private closedState = false;

	constructor(parent: Element, orient: Orient) {
		super(parent, orient, 'sch-switch');
		const c = 17;
		const r = 2.6;
		this.leads(c + r);
		this.lever = this.line(-c, 0, c, 0, 'sch-lever');
		for (const x of [-c, c]) {
			const p = this.at(x, 0);
			svgEl(this.g, 'circle', { class: 'sch-contact', cx: p.x, cy: p.y, r });
		}
		this.setClosed(false);
	}

	setClosed(closed: boolean): void {
		this.closedState = closed;
		const c = 17;
		if (closed) this.setLine(this.lever, -c, 0, c, 0);
		else {
			const len = 2 * c;
			const a = (28 * Math.PI) / 180;
			this.setLine(this.lever, -c, 0, -c + len * Math.cos(a), -len * Math.sin(a));
		}
		this.g.classList.toggle('sch-closed', closed);
	}

	get closed(): boolean {
		return this.closedState;
	}
}

/** Nodo (unión de tres o más cables). */
export class NodeDot {
	readonly el: SVGCircleElement;

	constructor(parent: Element, r = 2.8) {
		this.el = svgEl(parent, 'circle', { class: 'sch-node', r });
	}

	moveTo(p: Point): this {
		setAttrs(this.el, { cx: p.x, cy: p.y });
		return this;
	}
}

/** Cable: polilínea ortogonal. */
export class Wire {
	readonly el: SVGPathElement;
	private pts: Point[] = [];

	constructor(parent: Element, id: string) {
		this.el = svgEl(parent, 'path', { class: 'sch-wire', 'data-wire': id });
	}

	set(points: readonly Point[]): this {
		this.pts = points.map((p) => ({ x: p.x, y: p.y }));
		this.el.setAttribute('d', polyPath(this.pts));
		return this;
	}

	get points(): readonly Point[] {
		return this.pts;
	}
}

/**
 * Componente manipulable: asa (zona táctil amplia) que contiene el símbolo,
 * un rectángulo de selección discontinuo y una zona de toque rectangular
 * que cubre todo el cuerpo.
 */
export class PartHandle<S extends TwoTerminalSymbol> {
	readonly handle: Handle;
	readonly symbol: S;

	constructor(parent: Element, cls: string, make: (body: SVGGElement) => S) {
		this.handle = new Handle(parent, `sch-part ${cls}`, 14);
		const sel = svgEl(this.handle.body, 'rect', { class: 'sch-sel', rx: 3 });
		const hit = svgEl(this.handle.body, 'rect', { class: 'sch-hit' });
		this.symbol = make(this.handle.body);
		const r = this.symbol.localBox(7);
		setAttrs(sel, { x: r.x, y: r.y, width: r.width, height: r.height });
		const h = this.symbol.localBox(12);
		setAttrs(hit, { x: h.x, y: h.y, width: h.width, height: h.height });
	}

	moveTo(c: Point): this {
		this.handle.moveTo(c);
		return this;
	}
}
