/**
 * Modelo del péndulo simple ideal (funciones puras, sin DOM).
 *
 * Convenios: pivote en el origen, eje y hacia arriba, ángulos en radianes
 * medidos desde la vertical descendente (positivos hacia +x). Unidades SI:
 * L en m, g en m/s², m en kg, t en s, energías en J.
 */

export interface PendulumState {
	/** Ángulo θ (rad). */
	theta: number;
	/** Velocidad angular θ̇ (rad/s). */
	omega: number;
}

/** Estado de la simulación con paso fijo: el resto de tiempo aún no integrado va en `acc`. */
export interface PendulumSim extends PendulumState {
	t: number;
	acc: number;
}

/** Paso fijo de la integración RK4 (s). */
export const RK4_STEP = 1e-3;

/** Amplitud a partir de la cual se avisa de que T₀ deja de ser buena aproximación. */
export const SMALL_ANGLE_LIMIT_DEG = 15;

/* ── Período ─────────────────────────────────────────────── */

/** Media aritmético-geométrica AGM(a, b) (convergencia cuadrática). */
export function agm(a: number, b: number): number {
	if (!(a >= 0) || !(b >= 0)) return Number.NaN;
	if (a === 0 || b === 0) return 0;
	for (let i = 0; i < 64; i++) {
		const an = (a + b) / 2;
		const bn = Math.sqrt(a * b);
		if (Math.abs(an - bn) <= 1e-15 * an) return an;
		a = an;
		b = bn;
	}
	return (a + b) / 2;
}

/**
 * Integral elíptica completa de primera especie
 * K(k) = ∫₀^{π/2} dφ / √(1 − k² sin² φ) = π / (2·AGM(1, √(1 − k²))).
 * Diverge cuando |k| → 1 (se devuelve `Infinity`).
 */
export function ellipticK(k: number): number {
	const k2 = k * k;
	if (!(k2 < 1)) return Number.POSITIVE_INFINITY;
	return Math.PI / (2 * agm(1, Math.sqrt(1 - k2)));
}

/** Módulo k = sin(θ₀/2) de la integral elíptica para la amplitud θ₀. */
export function ellipticModulus(theta0: number): number {
	return Math.sin(Math.abs(theta0) / 2);
}

/** Período de pequeñas oscilaciones T₀ = 2π√(L/g) (aproximación sin θ ≈ θ). */
export function smallAnglePeriod(L: number, g: number): number {
	return 2 * Math.PI * Math.sqrt(L / g);
}

/** Período exacto T = 4√(L/g)·K(sin(θ₀/2)) para la amplitud θ₀ (partiendo del reposo). */
export function exactPeriod(L: number, g: number, theta0: number): number {
	return 4 * Math.sqrt(L / g) * ellipticK(ellipticModulus(theta0));
}

/** Cociente T/T₀ = (2/π)·K(sin(θ₀/2)); no depende de L ni de g. */
export function periodRatio(theta0: number): number {
	return (2 / Math.PI) * ellipticK(ellipticModulus(theta0));
}

/** Error relativo de la aproximación de ángulos pequeños: ε = (T − T₀)/T. */
export function smallAngleError(theta0: number): number {
	return 1 - 1 / periodRatio(theta0);
}

/* ── Geometría, fuerzas y energía ────────────────────────── */

/** Posición de la masa respecto del pivote (y hacia arriba). */
export function bobPosition(L: number, theta: number): { x: number; y: number } {
	return { x: L * Math.sin(theta), y: -L * Math.cos(theta) };
}

/** Ángulo de un punto (x, y) respecto del pivote: restricción a la circunferencia. */
export function angleOf(x: number, y: number): number {
	return Math.atan2(x, -y);
}

/** Altura sobre el punto más bajo: h = L(1 − cos θ). */
export function heightAbove(L: number, theta: number): number {
	return L * (1 - Math.cos(theta));
}

/** Componentes del peso: tangencial mg·sin θ (hacia el equilibrio) y radial mg·cos θ. */
export function weightComponents(m: number, g: number, theta: number): { tangential: number; radial: number } {
	return { tangential: m * g * Math.sin(theta), radial: m * g * Math.cos(theta) };
}

/** Energía potencial respecto del punto más bajo: E_p = mgL(1 − cos θ). */
export function potentialEnergy(m: number, g: number, L: number, theta: number): number {
	return m * g * heightAbove(L, theta);
}

/** Energía cinética E_c = ½ m L² θ̇². */
export function kineticEnergy(m: number, L: number, omega: number): number {
	return 0.5 * m * L * L * omega * omega;
}

export function mechanicalEnergy(m: number, g: number, L: number, s: PendulumState): number {
	return kineticEnergy(m, L, s.omega) + potentialEnergy(m, g, L, s.theta);
}

/* ── Integración numérica (ecuación no lineal exacta) ────── */

/** Un paso RK4 de θ̈ = −(g/L)·sin θ. */
export function rk4Step(s: PendulumState, h: number, g: number, L: number): PendulumState {
	const w2 = g / L;
	const a = (th: number): number => -w2 * Math.sin(th);
	const k1t = s.omega;
	const k1w = a(s.theta);
	const k2t = s.omega + 0.5 * h * k1w;
	const k2w = a(s.theta + 0.5 * h * k1t);
	const k3t = s.omega + 0.5 * h * k2w;
	const k3w = a(s.theta + 0.5 * h * k2t);
	const k4t = s.omega + h * k3w;
	const k4w = a(s.theta + h * k3t);
	return {
		theta: s.theta + (h / 6) * (k1t + 2 * k2t + 2 * k3t + k4t),
		omega: s.omega + (h / 6) * (k1w + 2 * k2w + 2 * k3w + k4w),
	};
}

/** Simulación en reposo en θ₀ (t = 0). */
export function startSim(theta0: number): PendulumSim {
	return { theta: theta0, omega: 0, t: 0, acc: 0 };
}

/**
 * Avanza `dt` segundos con pasos RK4 de tamaño fijo `h`. El resto (< h) se
 * acumula para el siguiente avance: el resultado no depende de los frames.
 */
export function advanceSim(sim: PendulumSim, dt: number, g: number, L: number, h = RK4_STEP): PendulumSim {
	if (!(dt > 0) || !Number.isFinite(dt)) return sim;
	let acc = sim.acc + dt;
	let s: PendulumState = { theta: sim.theta, omega: sim.omega };
	let t = sim.t;
	// Tolerancia relativa para no perder un paso por redondeo.
	while (acc >= h * (1 - 1e-9)) {
		s = rk4Step(s, h, g, L);
		acc -= h;
		t += h;
	}
	return { theta: s.theta, omega: s.omega, t, acc: Math.max(0, acc) };
}

/* ── Gravedad de referencia ──────────────────────────────── */

export type PlanetId = 'earth' | 'moon' | 'mars' | 'jupiter' | 'custom';

/** g en la superficie (m/s²), valores redondeados de uso escolar. */
export const PLANET_G: Readonly<Record<Exclude<PlanetId, 'custom'>, number>> = {
	earth: 9.81,
	moon: 1.62,
	mars: 3.71,
	jupiter: 24.79,
};

/** g de un cuerpo de la tabla, o `null` si es «personalizado» o desconocido. */
export function planetGravity(id: string): number | null {
	return Object.prototype.hasOwnProperty.call(PLANET_G, id) ? PLANET_G[id as Exclude<PlanetId, 'custom'>] : null;
}

/** Cuerpo cuya g coincide con `g` (a 0.005 m/s²) o `custom`. */
export function planetFor(g: number): PlanetId {
	for (const [id, v] of Object.entries(PLANET_G)) {
		if (Math.abs(v - g) < 0.005) return id as PlanetId;
	}
	return 'custom';
}

/* ── Escalas de dibujo (ilustrativas) ────────────────────── */

/** Radio de la lenteja: crece como ∛m (densidad constante), acotado a [rMin, rMax]. */
export function bobRadius(m: number, mMin: number, mMax: number, rMin: number, rMax: number): number {
	const c = (v: number): number => Math.cbrt(Math.max(v, 0));
	const t = (c(m) - c(mMin)) / (c(mMax) - c(mMin));
	const u = Number.isFinite(t) ? Math.min(1, Math.max(0, t)) : 0;
	return rMin + (rMax - rMin) * u;
}

/** Longitud de un vector de fuerza en escala logarítmica acotada (esquemática). */
export function forceLength(F: number, fMin: number, fMax: number, lMin: number, lMax: number): number {
	if (!(F > 0)) return 0;
	const t = Math.log(F / fMin) / Math.log(fMax / fMin);
	const u = Number.isFinite(t) ? Math.min(1, Math.max(0, t)) : 0;
	return lMin + (lMax - lMin) * u;
}
