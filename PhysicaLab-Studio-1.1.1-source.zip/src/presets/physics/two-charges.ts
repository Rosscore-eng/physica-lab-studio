import { fmt, texNum, texSI, texSig } from '../../core/numeric';
import type { PresetContext, PresetDefinition, PresetInstance } from '../../core/preset';
import type { NumberParamSpec, ParamSpec, ParamValues, Point } from '../../core/types';
import type { Place } from '../../render/svg/math-layer';
import { Arrow, Axes, Dimension, Handle } from '../../render/svg/primitives';
import type { SvgScene } from '../../render/svg/scene';
import { r2, show, svgEl, Viewport } from '../../render/svg/svg';
import {
	avoidDiscs1D,
	coulombForce,
	fieldAt,
	K_COULOMB,
	lineMarks,
	logScale,
	MICRO,
	projectOutside,
	traceFieldLines,
	type PointCharge,
} from './charges-model';

/* ── Geometría de la figura ─────────────────────────────────── */

const WORLD = { xMin: -2, xMax: 2, yMin: -1.25, yMax: 1.25 };
/** Área del plano en la escena (156 unidades por metro en ambos ejes). */
const PLOT = { x: 42, y: 26, width: 624, height: 390 };
const SCENE = { width: 680, height: 458 };

/** Radio dibujado de cada carga (m): las líneas arrancan y terminan en él. */
const R_CHARGE = 0.085;
/** Distancia mínima entre las cargas (m). */
const D_MIN = 0.25;
/** P no puede acercarse a menos de esto del centro de una carga (m). */
const R_P = 0.1;
/** Sin vectores de rejilla a menos de esta distancia de una carga (m). */
const R_GRID = 0.15;
/** Lado de la celda de la rejilla de vectores (m). */
const CELL = 0.25;
/** Margen para que el redondeo al paso (0.01 m) no meta un punto en un disco. */
const SNAP_MARGIN = 0.008;
const POS_STEP = 0.01;
/** Separación (px) entre una etiqueta y su ancla. */
const LABEL_GAP = 2;

/** Escalas logarítmicas acotadas de las flechas (solo visuales). */
const E_LO = 1e3;
const E_HI = 1e7;
const F_LO = 1e-4;
const F_HI = 10;

const QX = { min: -1.85, max: 1.85 };
const QY = { min: -1.1, max: 1.1 };
const PX = { min: -1.95, max: 1.95 };
const PY = { min: -1.2, max: 1.2 };

type Which = 1 | 2;

const num = (v: Readonly<ParamValues>, id: string): number => v[id] as number;

/** Validación de una coordenada de carga: fuera del disco de exclusión de la otra. */
function chargeAxis(which: Which, axis: 'x' | 'y'): NumberParamSpec['validate'] {
	const other = which === 1 ? 2 : 1;
	const box = axis === 'x' ? QX : QY;
	return (v, vals) => {
		const perpAxis = axis === 'x' ? 'y' : 'x';
		const disc = { along: num(vals, `${axis}${other}`), across: num(vals, `${perpAxis}${other}`), r: D_MIN };
		return avoidDiscs1D(v, num(vals, `${perpAxis}${which}`), [disc], box.min, box.max, POS_STEP, num(vals, `${axis}${which}`));
	};
}

/** Validación de una coordenada de P: fuera de los discos de ambas cargas. */
function probeAxis(axis: 'x' | 'y'): NumberParamSpec['validate'] {
	const box = axis === 'x' ? PX : PY;
	return (v, vals) => {
		const perpAxis = axis === 'x' ? 'y' : 'x';
		const discs = [1, 2].map((i) => ({ along: num(vals, `${axis}${i}`), across: num(vals, `${perpAxis}${i}`), r: R_P }));
		return avoidDiscs1D(v, num(vals, `${perpAxis}P`), discs, box.min, box.max, POS_STEP, num(vals, `${axis}P`));
	};
}

const charge = (i: Which, q: number): NumberParamSpec => ({
	id: `q${i}`,
	type: 'number',
	name: `Carga ${i}`,
	label: `q_${i}`,
	initial: q,
	min: -10,
	max: 10,
	step: 0.5,
	precision: 1,
	unit: '\\mu\\mathrm{C}',
	unitText: 'μC',
	group: 'Cargas',
});

const coord = (id: string, name: string, label: string, initial: number, box: { min: number; max: number }, validate: NumberParamSpec['validate']): NumberParamSpec => ({
	id,
	type: 'number',
	name,
	label,
	initial,
	min: box.min,
	max: box.max,
	step: POS_STEP,
	unit: '\\mathrm{m}',
	unitText: 'm',
	group: 'Posiciones',
	validate,
});

const params: ParamSpec[] = [
	charge(1, 3),
	charge(2, -2),
	{
		id: 'fieldView',
		type: 'enum',
		name: 'Representación del campo',
		initial: 'lines',
		options: [
			{ value: 'vectors', label: 'Vectores' },
			{ value: 'lines', label: 'Líneas de campo' },
			{ value: 'both', label: 'Ambos' },
		],
		group: 'Campo',
	},
	{ id: 'showForces', type: 'boolean', name: 'Fuerzas de Coulomb', initial: true, group: 'Mostrar' },
	{ id: 'showP', type: 'boolean', name: 'Punto de prueba P', initial: true, group: 'Mostrar' },
	{ id: 'showDistance', type: 'boolean', name: 'Cota de la distancia r', initial: true, group: 'Mostrar' },
	{ id: 'showGrid', type: 'boolean', name: 'Rejilla de coordenadas', initial: true, group: 'Mostrar' },
	coord('x1', 'Posición x de la carga 1', 'x_1', -0.8, QX, chargeAxis(1, 'x')),
	coord('y1', 'Posición y de la carga 1', 'y_1', 0, QY, chargeAxis(1, 'y')),
	coord('x2', 'Posición x de la carga 2', 'x_2', 0.8, QX, chargeAxis(2, 'x')),
	coord('y2', 'Posición y de la carga 2', 'y_2', 0, QY, chargeAxis(2, 'y')),
	coord('xP', 'Posición x del punto P', 'x_P', 0.2, PX, probeAxis('x')),
	coord('yP', 'Posición y del punto P', 'y_P', 0.65, PY, probeAxis('y')),
];

const FIDELITY =
	'Exacto: campo eléctrico y fuerza de Coulomb de cargas puntuales en el vacío (k = 8.9876·10⁹ N·m²/C²), ' +
	'dirección de todas las flechas y valores numéricos. Aproximación educativa: la longitud y la opacidad de los ' +
	'vectores siguen una escala logarítmica acotada (no son proporcionales a |E| ni a |F|); las líneas de campo se ' +
	'integran numéricamente (RK4 con paso adaptativo y número de pasos acotado), su número es proporcional a |q| ' +
	'(5 líneas por μC) y terminan al llegar a otra carga o al salir del plano dibujado. El campo no se evalúa dentro ' +
	'del radio dibujado de cada carga.';

export const twoChargesPreset: PresetDefinition = {
	id: 'physics.two-charges',
	version: 1,
	mode: 'physics',
	title: 'Campo eléctrico de dos cargas',
	summary: 'Dos cargas puntuales desplazables: ley de Coulomb, líneas de campo y campo en un punto de prueba.',
	keywords: [
		'carga',
		'cargas',
		'coulomb',
		'campo eléctrico',
		'campo electrico',
		'líneas de campo',
		'lineas de campo',
		'dipolo',
		'superposición',
		'superposicion',
		'electrostática',
		'electrostatica',
		'fuerza eléctrica',
	],
	params,
	fidelity: FIDELITY,
	examples: [
		{ title: 'Dipolo eléctrico', parameters: { q1: 2, q2: -2, x1: -0.7, y1: 0, x2: 0.7, y2: 0 } },
		{ title: 'Dos cargas positivas', parameters: { q1: 3, q2: 3, x1: -0.7, y1: 0, x2: 0.7, y2: 0 } },
		{ title: 'Cargas distintas (vectores)', parameters: { q1: 4, q2: -1, fieldView: 'both' } },
	],
	create: (ctx) => new TwoChargesLab(ctx),
};

/** Lugar de una etiqueta que se aleja del ancla en la dirección (dx, dy) de escena. */
function placeToward(dx: number, dy: number): Place {
	const a = Math.atan2(-dy, dx);
	const places: Place[] = ['e', 'ne', 'n', 'nw', 'w', 'sw', 's', 'se'];
	const k = ((Math.round(a / (Math.PI / 4)) % 8) + 8) % 8;
	return places[k] as Place;
}

/** Rectángulo en unidades de escena. */
interface Box {
	x0: number;
	y0: number;
	x1: number;
	y1: number;
}

/** Desplazamiento de la caja de una etiqueta según su lugar: [fx, fy] × tamaño y [gx, gy] × separación. */
const PLACE_BOX: Record<Place, [number, number, number, number]> = {
	c: [-0.5, -0.5, 0, 0],
	n: [-0.5, -1, 0, -1],
	s: [-0.5, 0, 0, 1],
	e: [0, -0.5, 1, 0],
	w: [-1, -0.5, -1, 0],
	ne: [0, -1, 0.7, -0.7],
	nw: [-1, -1, -0.7, -0.7],
	se: [0, 0, 0.7, 0.7],
	sw: [-1, 0, -0.7, 0.7],
};

/** Las ocho direcciones de colocación (escena, y hacia abajo). */
const COMPASS: Point[] = Array.from({ length: 8 }, (_, k) => ({ x: Math.cos((k * Math.PI) / 4), y: -Math.sin((k * Math.PI) / 4) }));

const overlaps = (a: Box, b: Box): boolean => a.x0 < b.x1 && b.x0 < a.x1 && a.y0 < b.y1 && b.y0 < a.y1;

/** Punta de flecha (triángulo) centrada en (x, y) y orientada según (ux, uy), en coordenadas de escena. */
function headPath(x: number, y: number, ux: number, uy: number, len: number, width: number): string {
	const tx = x + (ux * len) / 2;
	const ty = y + (uy * len) / 2;
	const bx = x - (ux * len) / 2;
	const by = y - (uy * len) / 2;
	const px = (-uy * width) / 2;
	const py = (ux * width) / 2;
	return `M${r2(tx)} ${r2(ty)}L${r2(bx + px)} ${r2(by + py)}L${r2(bx - px)} ${r2(by - py)}Z`;
}

/** Conjunto reutilizable de `path`: crea solo los que faltan y oculta los sobrantes. */
class PathPool {
	private readonly items: SVGPathElement[] = [];
	private used = 0;

	constructor(
		private readonly parent: SVGGElement,
		private readonly cls: string,
	) {}

	begin(): void {
		this.used = 0;
	}

	next(): SVGPathElement {
		let p = this.items[this.used];
		if (!p) {
			p = svgEl(this.parent, 'path', { class: this.cls });
			this.items.push(p);
		} else show(p, true);
		this.used++;
		return p;
	}

	end(): void {
		for (let i = this.used; i < this.items.length; i++) show(this.items[i] as SVGPathElement, false);
	}

	get count(): number {
		return this.used;
	}
}

interface ChargeView {
	which: Which;
	handle: Handle;
	disk: SVGCircleElement;
	sign: SVGPathElement;
}

class TwoChargesLab implements PresetInstance {
	private readonly scene: SvgScene;
	private readonly vp: Viewport;
	private readonly gridG: SVGGElement;
	private readonly linesG: SVGGElement;
	private readonly lines: PathPool;
	private readonly heads: SVGPathElement;
	private readonly vecG: SVGGElement;
	private readonly vectors: SVGPathElement[] = [];
	private readonly vectorCells: Point[] = [];
	private readonly dim: Dimension;
	private readonly f12: Arrow;
	private readonly f21: Arrow;
	private readonly eArrow: Arrow;
	private readonly hP: Handle;
	private readonly charges: [ChargeView, ChargeView];
	private linesKey = '';
	private vectorsKey = '';
	/** Desplazamiento entre el puntero y el centro del objeto arrastrado (m). */
	private grab: Point = { x: 0, y: 0 };

	constructor(private readonly ctx: PresetContext) {
		const store = ctx.store;
		const scene = (this.scene = ctx.createScene({
			width: SCENE.width,
			height: SCENE.height,
			label: 'Plano con dos cargas puntuales, sus líneas de campo eléctrico y un punto de prueba P',
		}));
		const vp = (this.vp = new Viewport(WORLD, PLOT, { equalAspect: true }));

		// Rejilla y ejes de coordenadas (en metros)
		this.gridG = svgEl(scene.layers.grid, 'g', { class: 'pl-tc-grid' });
		new Axes(this.gridG, scene.layers.back).draw(vp, {
			xTicks: [-2, -1.5, -1, -0.5, 0, 0.5, 1, 1.5, 2],
			yTicks: [-1, -0.5, 0, 0.5, 1],
			cross: false,
			xDecimals: 1,
			yDecimals: 1,
		});
		const rect = vp.sceneRect;
		svgEl(scene.layers.back, 'rect', { class: 'pl-tc-frame', x: rect.x, y: rect.y, width: rect.width, height: rect.height });
		// Títulos de los ejes fuera del plano: x bajo las marcas, y sobre el eje vertical.
		scene.labels
			.label('ax-x', 'x\\,(\\mathrm{m})')
			.at({ x: vp.X(0), y: rect.y + rect.height + 22 }, 's', 0)
			.color('muted')
			.fontSize('sm');
		scene.labels
			.label('ax-y', 'y\\,(\\mathrm{m})')
			.at({ x: rect.x, y: rect.y - 3 }, 'n', 0)
			.color('muted')
			.fontSize('sm');

		// Campo: líneas (pool de paths + un único path con todas las puntas) y rejilla de vectores
		const clipId = scene.id('clip');
		const cp = svgEl(scene.defs, 'clipPath', { id: clipId });
		svgEl(cp, 'rect', { x: rect.x, y: rect.y, width: rect.width, height: rect.height });
		const clipped = svgEl(scene.layers.back, 'g', { 'clip-path': `url(#${clipId})` });
		this.vecG = svgEl(clipped, 'g', { class: 'pl-tc-vectors pl-s-violet', 'data-role': 'vectors' });
		this.linesG = svgEl(clipped, 'g', { class: 'pl-tc-lines pl-s-muted', 'data-role': 'lines' });
		this.lines = new PathPool(svgEl(this.linesG, 'g'), 'pl-field-line');
		this.heads = svgEl(this.linesG, 'path', { class: 'pl-tc-heads' });
		const cols = Math.round((WORLD.xMax - WORLD.xMin) / CELL);
		const rows = Math.round((WORLD.yMax - WORLD.yMin) / CELL);
		for (let j = 0; j < rows; j++) {
			for (let i = 0; i < cols; i++) {
				this.vectorCells.push({ x: WORLD.xMin + (i + 0.5) * CELL, y: WORLD.yMin + (j + 0.5) * CELL });
				this.vectors.push(svgEl(this.vecG, 'path', { class: 'pl-tc-evec' }));
			}
		}

		// Cota de la distancia, fuerzas y campo en P
		this.dim = new Dimension(scene.layers.back, 'pl-tc-dim');
		this.f21 = new Arrow(scene.layers.main, 'pl-s-amber', 9, 6.5);
		this.f12 = new Arrow(scene.layers.main, 'pl-s-amber', 9, 6.5);
		this.f12.g.dataset.role = 'F12';
		this.f21.g.dataset.role = 'F21';
		this.eArrow = new Arrow(scene.layers.main, 'pl-s-green', 9, 6.5);
		this.eArrow.g.dataset.role = 'E';

		// Asas: P debajo de las cargas (las cargas tienen prioridad al solaparse)
		this.hP = new Handle(scene.layers.handles, 'pl-pt pl-tc-probe', 4.5);
		svgEl(this.hP.body, 'circle', { r: 4.5, class: 'pl-pt-dot' });
		this.hP.g.dataset.role = 'P';
		const rq = vp.len(R_CHARGE);
		const makeCharge = (which: Which): ChargeView => {
			const handle = new Handle(scene.layers.handles, 'pl-tc-charge', rq);
			handle.g.dataset.role = `q${which}`;
			const disk = svgEl(handle.body, 'circle', { r: rq, class: 'pl-tc-disk' });
			const sign = svgEl(handle.body, 'path', { class: 'pl-tc-sign' });
			return { which, handle, disk, sign };
		};
		this.charges = [makeCharge(1), makeCharge(2)];

		const fitHits = (): void => {
			for (const c of this.charges) c.handle.setHitRadius(scene.touchRadius(22));
			this.hP.setHitRadius(scene.touchRadius(20));
		};
		fitHits();
		ctx.scope.add(scene.onResize(fitHits));

		// Arrastre 2D de las cargas y de P (con el desplazamiento del agarre)
		for (const c of this.charges) {
			const i = c.which;
			ctx.draggable(
				scene,
				c.handle.g,
				{
					onStart: (p) => {
						const w = vp.toWorld(p);
						this.grab = { x: store.num(`x${i}`) - w.x, y: store.num(`y${i}`) - w.y };
					},
					onMove: (p) => {
						const w = vp.toWorld(p);
						this.moveCharge(i, w.x + this.grab.x, w.y + this.grab.y, 'drag');
					},
					onKey: (dx, dy, m) => {
						const s = m.coarse ? 0.25 : m.fine ? 0.01 : 0.05;
						this.moveCharge(i, store.num(`x${i}`) + dx * s, store.num(`y${i}`) + dy * s, 'keyboard');
					},
				},
				`Carga q${i} (arrastrar para moverla por el plano)`,
			);
		}
		ctx.draggable(
			scene,
			this.hP.g,
			{
				onStart: (p) => {
					const w = vp.toWorld(p);
					this.grab = { x: store.num('xP') - w.x, y: store.num('yP') - w.y };
				},
				onMove: (p) => {
					const w = vp.toWorld(p);
					this.moveProbe(w.x + this.grab.x, w.y + this.grab.y, 'drag');
				},
				onKey: (dx, dy, m) => {
					const s = m.coarse ? 0.25 : m.fine ? 0.01 : 0.05;
					this.moveProbe(store.num('xP') + dx * s, store.num('yP') + dy * s, 'keyboard');
				},
			},
			'Punto de prueba P (arrastrar para medir el campo)',
		);

		ctx.panel.addNote('Arrastra las cargas y el punto P sobre la figura (o usa las flechas del teclado).');
		ctx.setNote(FIDELITY);
	}

	/* ── Manipulación directa: proyecta sobre las restricciones y escribe en el almacén ── */

	private moveCharge(i: Which, x: number, y: number, source: 'drag' | 'keyboard'): void {
		const store = this.ctx.store;
		const o = i === 1 ? 2 : 1;
		const other = { x: store.num(`x${o}`), y: store.num(`y${o}`) };
		const cur = { x: store.num(`x${i}`), y: store.num(`y${i}`) };
		let p = { x: clampTo(x, QX), y: clampTo(y, QY) };
		p = projectOutside(p, other, D_MIN + SNAP_MARGIN, cur);
		p = { x: clampTo(p.x, QX), y: clampTo(p.y, QY) };
		this.write(`x${i}`, `y${i}`, p, cur, [{ ...other, r: D_MIN }], source);
	}

	private moveProbe(x: number, y: number, source: 'drag' | 'keyboard'): void {
		const store = this.ctx.store;
		const cur = { x: store.num('xP'), y: store.num('yP') };
		let p = { x: clampTo(x, PX), y: clampTo(y, PY) };
		const discs = ([1, 2] as const).map((i) => ({ x: store.num(`x${i}`), y: store.num(`y${i}`), r: R_P }));
		for (let pass = 0; pass < 2; pass++) {
			for (const d of discs) p = projectOutside(p, d, d.r + SNAP_MARGIN, cur);
		}
		p = { x: clampTo(p.x, PX), y: clampTo(p.y, PY) };
		this.write('xP', 'yP', p, cur, discs, source);
	}

	/**
	 * Escribe las dos coordenadas de una vez. El almacén valida en orden, así
	 * que primero va la coordenada cuyo estado intermedio ya es válido (evita
	 * que la validación 1D empuje el punto al rodear un disco).
	 */
	private write(
		ix: string,
		iy: string,
		p: Point,
		cur: Point,
		discs: ReadonlyArray<{ x: number; y: number; r: number }>,
		source: 'drag' | 'keyboard',
	): void {
		const snap = (v: number): number => Math.round(v / POS_STEP) * POS_STEP;
		const free = (q: Point): boolean => discs.every((d) => Math.hypot(q.x - d.x, q.y - d.y) >= d.r);
		const xFirst = free({ x: snap(p.x), y: cur.y }) || !free({ x: cur.x, y: snap(p.y) });
		const patch: Record<string, number> = {};
		if (xFirst) {
			patch[ix] = p.x;
			patch[iy] = p.y;
		} else {
			patch[iy] = p.y;
			patch[ix] = p.x;
		}
		this.ctx.store.update(patch, source);
	}

	/**
	 * Elige la dirección de colocación de una etiqueta: la primera de `prefs`
	 * (y, si `compass`, de las ocho direcciones ordenadas por cercanía a la
	 * preferida) cuya caja estimada queda dentro del plano y no tapa ninguna
	 * de `avoid`. Añade la caja elegida a `avoid` y devuelve la dirección.
	 */
	private fit(prefs: Point[], anchor: (u: Point) => Point, widthEm: number, size: 'sm' | 'md', avoid: Box[], compass = true): Point {
		const s = Math.max(this.scene.pxPerUnit, 0.05);
		const fontPx = size === 'sm' ? clampTo(12.5 * s, { min: 10, max: 14 }) : clampTo(14.5 * s, { min: 11, max: 16 });
		const w = (widthEm * fontPx) / s;
		const h = (1.3 * fontPx) / s;
		const gap = LABEL_GAP / s;
		const norm = (u: Point): Point => {
			const l = Math.hypot(u.x, u.y) || 1;
			return { x: u.x / l, y: u.y / l };
		};
		const first = norm(prefs[0] ?? { x: 0, y: -1 });
		const cands = prefs.map(norm);
		if (compass) cands.push(...[...COMPASS].sort((a, b) => b.x * first.x + b.y * first.y - (a.x * first.x + a.y * first.y)));
		const boxOf = (u: Point): Box => {
			const at = anchor(u);
			const [fx, fy, gx, gy] = PLACE_BOX[placeToward(u.x, u.y)];
			const x0 = at.x + fx * w + gx * gap;
			const y0 = at.y + fy * h + gy * gap;
			return { x0, y0, x1: x0 + w, y1: y0 + h };
		};
		const free = (b: Box): boolean =>
			b.x0 >= PLOT.x + 1 && b.y0 >= PLOT.y + 1 && b.x1 <= PLOT.x + PLOT.width - 1 && b.y1 <= PLOT.y + PLOT.height - 1 && !avoid.some((a) => overlaps(a, b));
		for (const u of cands) {
			const b = boxOf(u);
			if (free(b)) {
				avoid.push(b);
				return u;
			}
		}
		avoid.push(boxOf(first));
		return first;
	}

	/* ── Dibujo ─────────────────────────────────────────────── */

	render(_changed: ReadonlySet<string>, full: boolean): void {
		const { store } = this.ctx;
		const vp = this.vp;
		const q1 = store.num('q1');
		const q2 = store.num('q2');
		const c1: PointCharge = { x: store.num('x1'), y: store.num('y1'), q: q1 * MICRO };
		const c2: PointCharge = { x: store.num('x2'), y: store.num('y2'), q: q2 * MICRO };
		const list = [c1, c2];
		const view = store.str('fieldView');
		const showLines = view !== 'vectors';
		const showVectors = view !== 'lines';
		const geomKey = `${q1},${q2},${c1.x},${c1.y},${c2.x},${c2.y}`;

		if (showLines && (full || geomKey !== this.linesKey)) {
			this.linesKey = geomKey;
			this.drawLines(list);
		}
		show(this.linesG, showLines);
		if (showVectors && (full || geomKey !== this.vectorsKey)) {
			this.vectorsKey = geomKey;
			this.drawVectors(list);
		}
		show(this.vecG, showVectors);
		this.vecG.classList.toggle('pl-tc-faded', view === 'both');
		show(this.gridG, store.bool('showGrid'));

		// Cargas
		const S1 = vp.toScene(c1);
		const S2 = vp.toScene(c2);
		const ax = S2.x - S1.x;
		const ay = S2.y - S1.y;
		const aLen = Math.hypot(ax, ay) || 1;
		const ux = ax / aLen;
		const uy = ay / aLen;
		// Normal «hacia arriba» de la escena: etiquetas de carga a un lado; cota y fuerzas al otro.
		let nx = uy;
		let ny = -ux;
		if (ny > 1e-9 || (Math.abs(ny) <= 1e-9 && nx > 0)) {
			nx = -nx;
			ny = -ny;
		}
		const rq = vp.len(R_CHARGE);
		const inside = (p: Point, m: number): boolean =>
			p.x > PLOT.x + m && p.x < PLOT.x + PLOT.width - m && p.y > PLOT.y + m && p.y < PLOT.y + PLOT.height - m;
		let side = 1;
		const labelOut = [S1, S2].some((S) => !inside({ x: S.x + nx * (rq + 22), y: S.y + ny * (rq + 22) }, 0));
		const dimOut = !inside({ x: (S1.x + S2.x) / 2 - nx * 52, y: (S1.y + S2.y) / 2 - ny * 52 }, 0);
		if (labelOut || dimOut) side = -1;
		const sx = nx * side;
		const sy = ny * side;

		const L = this.scene.labels;
		// Zonas que las etiquetas no deben tapar: las dos cargas (las demás se añaden al colocarlas).
		const avoid: Box[] = [S1, S2].map((S) => ({ x0: S.x - rq, y0: S.y - rq, x1: S.x + rq, y1: S.y + rq }));
		for (const [k, c] of [c1, c2].entries()) {
			const v = this.charges[k] as ChargeView;
			const S = k === 0 ? S1 : S2;
			const q = k === 0 ? q1 : q2;
			v.handle.moveTo(S);
			const color = q > 0 ? 'rose' : q < 0 ? 'blue' : 'muted';
			v.handle.body.setAttribute('class', `pl-handle-body pl-s-${color}${q === 0 ? ' pl-tc-neutral' : ''}`);
			const a = rq * 0.42;
			v.sign.setAttribute('d', q > 0 ? `M${r2(-a)} 0H${r2(a)}M0 ${r2(-a)}V${r2(a)}` : q < 0 ? `M${r2(-a)} 0H${r2(a)}` : '');
			// Etiqueta en diagonal (del lado de las etiquetas y alejándose de la otra carga),
			// o en la primera dirección libre si se sale de la escena o tapa algo.
			const away = k === 0 ? -1 : 1;
			const d = this.fit(
				[{ x: sx + away * ux * 0.9, y: sy + away * uy * 0.9 }],
				(u) => ({ x: S.x + u.x * (rq + 2), y: S.y + u.y * (rq + 2) }),
				7.2,
				'md',
				avoid,
			);
			L.label(`q${k + 1}`, `q_${k + 1}=${qTex(q)}`)
				.at({ x: S.x + d.x * (rq + 2), y: S.y + d.y * (rq + 2) }, placeToward(d.x, d.y), LABEL_GAP)
				.color(color);
			v.handle.g.setAttribute('aria-valuetext', `q${k + 1} = ${fmt(q, 1)} μC en (${fmt(c.x)}, ${fmt(c.y)}) m`);
		}

		// Fuerzas de Coulomb (F12: la que ejerce q1 sobre q2; F21 = −F12)
		const F = coulombForce(c1, c2);
		const r = F ? F.r : Math.hypot(c2.x - c1.x, c2.y - c1.y);
		const showF = store.bool('showForces') && !!F && F.magnitude > 0;
		if (F && showF) {
			let len = 0.12 + 0.38 * logScale(F.magnitude, F_LO, F_HI);
			if (F.attractive) len = Math.min(len, r - R_CHARGE - 0.02);
			const fx = (F.fx / F.magnitude) * vp.len(len);
			const fy = (-F.fy / F.magnitude) * vp.len(len);
			this.f12.set(S2.x, S2.y, S2.x + fx, S2.y + fy);
			this.f21.set(S1.x, S1.y, S1.x - fx, S1.y - fy);
			// Etiquetas junto al punto medio de cada flecha, del lado de la cota.
			const m12 = { x: S2.x + fx / 2, y: S2.y + fy / 2 };
			const m21 = { x: S1.x - fx / 2, y: S1.y - fy / 2 };
			const apart = Math.hypot(m12.x - m21.x, m12.y - m21.y) > 44;
			const lab = (id: string, tex: string, at: Point): void => {
				const d = this.fit(
					[
						{ x: -sx, y: -sy },
						{ x: sx, y: sy },
					],
					(u) => ({ x: at.x + u.x * 6, y: at.y + u.y * 6 }),
					1.9,
					'sm',
					avoid,
					false,
				);
				L.label(id, tex)
					.at({ x: at.x + d.x * 6, y: at.y + d.y * 6 }, placeToward(d.x, d.y), LABEL_GAP)
					.color('amber')
					.fontSize('sm')
					.visible(apart);
			};
			lab('F12', '\\vec F_{12}', m12);
			lab('F21', '\\vec F_{21}', m21);
		} else {
			L.label('F12').visible(false);
			L.label('F21').visible(false);
		}
		this.f12.visible(showF);
		this.f21.visible(showF);

		// Cota de la distancia r (del lado opuesto a las etiquetas de las cargas)
		const showDim = store.bool('showDistance');
		if (showDim) {
			const off = 36;
			// Dimension desplaza hacia la normal (−uy, ux) del segmento: se elige el signo que apunta a −(sx, sy).
			const sign = -uy * -sx + ux * -sy >= 0 ? 1 : -1;
			this.dim.set(S1, S2, sign * off);
			L.label('r', `r=${texNum(r, 2)}\\,\\mathrm{m}`)
				.at({ x: this.dim.mid.x + this.dim.normal.x * 3, y: this.dim.mid.y + this.dim.normal.y * 3 }, placeToward(this.dim.normal.x, this.dim.normal.y), 2)
				.color('muted')
				.fontSize('sm')
				.visible(true);
		} else L.label('r').visible(false);
		this.dim.visible(showDim);

		this.renderProbe(list, avoid);
		this.renderEquations(c1, c2, F, r);
	}

	private drawLines(list: PointCharge[]): void {
		const vp = this.vp;
		const res = traceFieldLines(list, {
			bounds: { xMin: WORLD.xMin - 0.1, xMax: WORLD.xMax + 0.1, yMin: WORLD.yMin - 0.1, yMax: WORLD.yMax + 0.1 },
			rCharge: R_CHARGE,
		});
		this.lines.begin();
		let heads = '';
		// Puntas: como mucho en ~16 líneas por carga y a distancias escalonadas (sin «anillos» de puntas).
		const perSource = new Map<number, number>();
		for (const line of res.lines) perSource.set(line.from, (perSource.get(line.from) ?? 0) + 1);
		const seen = new Map<number, number>();
		for (const line of res.lines) {
			const p = line.pts;
			const k = seen.get(line.from) ?? 0;
			seen.set(line.from, k + 1);
			if (p.length < 4) continue;
			let d = `M${r2(vp.X(p[0] as number))} ${r2(vp.Y(p[1] as number))}`;
			for (let i = 2; i < p.length; i += 2) d += `L${r2(vp.X(p[i] as number))} ${r2(vp.Y(p[i + 1] as number))}`;
			const path = this.lines.next();
			path.setAttribute('d', d);
			path.dataset.from = String(line.from + 1);
			const stride = Math.max(1, Math.ceil((perSource.get(line.from) ?? 1) / 16));
			if (k % stride !== 0) continue;
			const first = 0.36 + 0.24 * ((k * 0.618034) % 1);
			for (const m of lineMarks(line, { first, spacing: 0.85, minLength: 0.18, endGap: 0.2 })) {
				// El eje y de la escena apunta hacia abajo.
				heads += headPath(vp.X(m.x), vp.Y(m.y), m.ux, -m.uy, 6.5, 5);
			}
		}
		this.lines.end();
		this.heads.setAttribute('d', heads);
		this.linesG.dataset.count = String(this.lines.count);
	}

	private drawVectors(list: PointCharge[]): void {
		const vp = this.vp;
		const half = vp.len(CELL) / 2;
		for (let i = 0; i < this.vectorCells.length; i++) {
			const c = this.vectorCells[i] as Point;
			const el = this.vectors[i] as SVGPathElement;
			const near = list.some((q) => Math.hypot(c.x - q.x, c.y - q.y) < R_GRID);
			const E = near ? null : fieldAt(list, c.x, c.y, R_CHARGE);
			const m = E ? Math.hypot(E.x, E.y) : 0;
			if (!E || !(m > 0)) {
				show(el, false);
				continue;
			}
			const g = logScale(m, E_LO, E_HI);
			const len = half * 2 * (0.22 + 0.68 * g);
			const ux = E.x / m;
			const uy = -E.y / m;
			const X = vp.X(c.x);
			const Y = vp.Y(c.y);
			const x1 = X - (ux * len) / 2;
			const y1 = Y - (uy * len) / 2;
			const x2 = X + (ux * len) / 2;
			const y2 = Y + (uy * len) / 2;
			const hl = Math.min(6, len * 0.4);
			el.setAttribute('d', `M${r2(x1)} ${r2(y1)}L${r2(x2 - ux * hl * 0.6)} ${r2(y2 - uy * hl * 0.6)}` + headPath(x2 - (ux * hl) / 2, y2 - (uy * hl) / 2, ux, uy, hl, hl * 0.75));
			el.setAttribute('opacity', (0.35 + 0.65 * g).toFixed(2));
			show(el, true);
		}
	}

	private renderProbe(list: PointCharge[], avoid: Box[]): void {
		const { store } = this.ctx;
		const vp = this.vp;
		const visible = store.bool('showP');
		const P = { x: store.num('xP'), y: store.num('yP') };
		const S = vp.toScene(P);
		const E = fieldAt(list, P.x, P.y, R_CHARGE);
		const undefinedHere = E === null;
		const m = E ? Math.hypot(E.x, E.y) : 0;
		const L = this.scene.labels;
		this.hP.moveTo(S).visible(visible);
		this.hP.g.setAttribute('aria-valuetext', `P en (${fmt(P.x)}, ${fmt(P.y)}) m`);

		let ux = 1;
		let uy = 0;
		// Con P dentro de una carga, las etiquetas se anclan fuera de su disco.
		const reach = undefinedHere ? vp.len(R_CHARGE) + 4 : 7;
		if (E && m > 0) {
			ux = E.x / m;
			uy = -E.y / m;
			const len = vp.len(0.12 + 0.43 * logScale(m, E_LO, E_HI));
			this.eArrow.set(S.x, S.y, S.x + ux * len, S.y + uy * len);
			const tip = (u: Point): Point => ({ x: S.x + ux * len + u.x * 3, y: S.y + uy * len + u.y * 3 });
			const d = this.fit([{ x: ux, y: uy }], tip, 1.3, 'md', avoid, false);
			L.label('E', '\\vec E').at(tip(d), placeToward(d.x, d.y), 3).color('green').visible(visible);
		} else L.label('E').visible(false);
		this.eArrow.visible(visible && !!E && m > 0);

		// «P» en el lado contrario a E; el módulo, en perpendicular (o donde quepa).
		const at = (u: Point): Point => ({ x: S.x + u.x * reach, y: S.y + u.y * reach });
		const dP = this.fit([{ x: -ux, y: -uy }], at, 1, 'md', avoid);
		L.label('P', 'P').at(at(dP), placeToward(dP.x, dP.y), 3).visible(visible);
		let px = -uy;
		let py = ux;
		if (py > 0) {
			px = -px;
			py = -py;
		}
		const d = this.fit(
			[
				{ x: px, y: py },
				{ x: -px, y: -py },
			],
			at,
			undefinedHere ? 14 : 8.6,
			'sm',
			avoid,
		);
		L.label('Emod', undefinedHere ? '\\text{campo no definido en la carga}' : `|\\vec E|=${texSI(m, 'N/C')}`)
			.at(at(d), placeToward(d.x, d.y), 3)
			.color(undefinedHere ? 'rose' : 'green')
			.fontSize('sm')
			.visible(visible);
	}

	private renderEquations(c1: PointCharge, c2: PointCharge, F: ReturnType<typeof coulombForce>, r: number): void {
		const { store, equations } = this.ctx;
		const q1 = store.num('q1');
		const q2 = store.num('q2');
		const fMag = F ? F.magnitude : 0;
		const kTex = texSci(K_COULOMB);
		equations.readout('r', `r=${texSig(r, 3)}\\,\\mathrm{m}`);
		equations.readout(
			'F',
			fMag === 0 ? 'F=0\\,\\mathrm{N}' : `F=${texSI(fMag, 'N')}\\ (\\text{${F?.attractive ? 'atractiva' : 'repulsiva'}})`,
		);
		equations.set(
			'coulomb',
			'\\begin{aligned}F=|\\vec F_{12}|=|\\vec F_{21}|&=k\\,\\frac{|q_1\\,q_2|}{r^2}\\\\' +
				`&=${kTex}\\,\\frac{(${texSci(Math.abs(q1) * MICRO, 1)})(${texSci(Math.abs(q2) * MICRO, 1)})}{(${texSig(r, 4)})^2}\\ \\mathrm{N}=${texSci(fMag)}\\,\\mathrm{N}\\end{aligned}`,
			'Ley de Coulomb. F12 es la fuerza que q1 ejerce sobre q2; F21 = −F12 (tercera ley de Newton)',
		);
		equations.set(
			'distance',
			`r=|\\vec r_2-\\vec r_1|=\\sqrt{(${texNum(c2.x - c1.x, 2)})^2+(${texNum(c2.y - c1.y, 2)})^2}\\ \\mathrm{m}=${texSig(r, 4)}\\,\\mathrm{m}`,
			'Distancia entre las cargas',
		);
		equations.set('k', `k=\\frac{1}{4\\pi\\varepsilon_0}=${kTex}\\,\\mathrm{N\\,m^2/C^2}`, 'Constante de Coulomb (vacío)');
		equations.set(
			'superposition',
			'\\vec E(\\vec r)=\\sum_{i} k\\,\\frac{q_i}{|\\vec r-\\vec r_i|^2}\\,\\hat u_i,\\quad \\hat u_i=\\frac{\\vec r-\\vec r_i}{|\\vec r-\\vec r_i|}',
			'Campo eléctrico: principio de superposición',
		);

		const showP = store.bool('showP');
		const xP = store.num('xP');
		const yP = store.num('yP');
		const E = fieldAt([c1, c2], xP, yP, R_CHARGE);
		if (E) {
			const m = Math.hypot(E.x, E.y);
			equations.set(
				'fieldP',
				`\\begin{aligned}\\vec E(P)&=\\bigl(${texSci(E.x)},\\ ${texSci(E.y)}\\bigr)\\ \\mathrm{N/C}\\\\|\\vec E(P)|&=${texSci(m)}\\,\\mathrm{N/C}\\end{aligned}`,
				`Campo en P = (${fmt(xP)}, ${fmt(yP)}) m`,
			);
			const row = (i: 1 | 2, q: number, c: PointCharge): string => {
				const d = Math.hypot(xP - c.x, yP - c.y);
				const e = q === 0 ? 0 : (K_COULOMB * Math.abs(q) * MICRO) / (d * d);
				return `|\\vec E_${i}|&=k\\,\\frac{|q_${i}|}{r_{${i}P}^2}=${kTex}\\,\\frac{${texSci(Math.abs(q) * MICRO, 1)}}{(${texSig(d, 4)})^2}=${texSci(e)}\\,\\mathrm{N/C}`;
			};
			equations.set(
				'contrib',
				`\\begin{aligned}${row(1, q1, c1)}\\\\${row(2, q2, c2)}\\end{aligned}`,
				'Contribución de cada carga en P (r1P y r2P en metros)',
			);
			equations.readout('E', `|\\vec E(P)|=${texSI(m, 'N/C')}`);
		} else {
			const which = Math.hypot(xP - c1.x, yP - c1.y) <= R_CHARGE ? 1 : 2;
			equations.set('fieldP', `\\vec E(P)\\ \\text{no definido en la carga } q_${which}`, 'P está dentro de una carga puntual');
			equations.set(
				'contrib',
				`|\\vec r_P-\\vec r_${which}|<${texNum(R_CHARGE, 3)}\\,\\mathrm{m}`,
				'El campo no se evalúa dentro del radio dibujado de la carga',
			);
			equations.readout('E', '|\\vec E(P)|\\ \\text{no definido}');
		}
		equations.highlight('fieldP', !E);
		equations.visible('fieldP', showP);
		equations.visible('contrib', showP);
		equations.visible('E', showP);

		this.ctx.status(
			q1 === 0 && q2 === 0
				? 'Ambas cargas son nulas: no hay campo'
				: showP && !E
					? 'P está sobre una carga: el campo no está definido ahí'
					: r <= D_MIN + 0.005
						? `Distancia mínima entre cargas: ${fmt(D_MIN)} m`
						: null,
		);
	}
}

function clampTo(v: number, box: { min: number; max: number }): number {
	return v < box.min ? box.min : v > box.max ? box.max : v;
}

/** q en μC como LaTeX con signo explícito: +3.0\,\mu\mathrm{C}. */
function qTex(q: number): string {
	if (q === 0) return '0';
	return `${q > 0 ? '+' : ''}${fmt(q, 1)}\\,\\mu\\mathrm{C}`;
}

/**
 * Número en LaTeX con `decimals` decimales en la mantisa: notación científica
 * fuera de [0.1, 1000) (p. ej. 2.11\times 10^{-2}); 0 se escribe «0».
 */
function texSci(v: number, decimals = 2): string {
	if (v === 0 || !Number.isFinite(v)) return '0';
	const a = Math.abs(v);
	if (a >= 0.1 && a < 1000) return fmt(v, a >= 100 ? 0 : a >= 10 ? 1 : decimals);
	let e = Math.floor(Math.log10(a));
	let mant = Number((v / Math.pow(10, e)).toFixed(decimals));
	if (Math.abs(mant) >= 10) {
		mant /= 10;
		e += 1;
	}
	return `${mant.toFixed(decimals)}\\times 10^{${e}}`;
}
