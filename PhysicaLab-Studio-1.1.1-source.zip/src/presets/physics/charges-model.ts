/**
 * Modelo físico del laboratorio de dos cargas puntuales en el vacío.
 * Funciones puras (sin DOM), en unidades SI: metros, coulombs, newtons y N/C.
 */
import type { Point, WorldBounds } from '../../core/types';

/** Constante de Coulomb k = 1/(4π ε0) en N·m²/C² (CODATA 2018). */
export const K_COULOMB = 8.9875517923e9;

/** 1 μC en coulombs. */
export const MICRO = 1e-6;

/** Líneas de campo por cada μC de carga de origen (número ∝ |q|). */
export const LINES_PER_MICROCOULOMB = 5;

export interface PointCharge {
	x: number;
	y: number;
	/** Carga en coulombs (con signo). */
	q: number;
}

/* ── Campo y fuerza (exactos) ───────────────────────────────── */

/**
 * Campo eléctrico por superposición: E = Σ k qᵢ (r − rᵢ)/|r − rᵢ|³.
 * Devuelve `null` si el punto está a menos de `rCore` de una carga no nula
 * (o justo sobre ella): ahí el campo de la carga puntual no se evalúa.
 * Las cargas nulas no contribuyen.
 */
export function fieldAt(charges: readonly PointCharge[], x: number, y: number, rCore = 0): Point | null {
	let ex = 0;
	let ey = 0;
	const rc2 = rCore * rCore;
	for (const c of charges) {
		if (c.q === 0) continue;
		const dx = x - c.x;
		const dy = y - c.y;
		const d2 = dx * dx + dy * dy;
		if (!(d2 > rc2)) return null;
		const s = (K_COULOMB * c.q) / (d2 * Math.sqrt(d2));
		ex += s * dx;
		ey += s * dy;
	}
	return Number.isFinite(ex) && Number.isFinite(ey) ? { x: ex, y: ey } : null;
}

/** Módulo del campo de una sola carga a distancia r: k|q|/r². */
export function fieldMagnitude(q: number, r: number): number {
	return r > 0 ? (K_COULOMB * Math.abs(q)) / (r * r) : Number.NaN;
}

export interface CoulombForce {
	/** Componentes de F₁₂: fuerza que ejerce la carga a sobre la carga b (N). */
	fx: number;
	fy: number;
	/** |F| = k|qa qb|/r² (N). */
	magnitude: number;
	/** Distancia entre las cargas (m). */
	r: number;
	attractive: boolean;
}

/**
 * Ley de Coulomb: fuerza que ejerce `a` sobre `b`,
 * F = k qa qb (rb − ra)/|rb − ra|³. La fuerza sobre `a` es −F (tercera ley).
 * `null` si las cargas coinciden.
 */
export function coulombForce(a: PointCharge, b: PointCharge): CoulombForce | null {
	const dx = b.x - a.x;
	const dy = b.y - a.y;
	const r = Math.hypot(dx, dy);
	if (!(r > 0)) return null;
	const s = (K_COULOMB * a.q * b.q) / (r * r * r);
	return {
		fx: s * dx,
		fy: s * dy,
		magnitude: (K_COULOMB * Math.abs(a.q * b.q)) / (r * r),
		r,
		attractive: a.q * b.q < 0,
	};
}

/* ── Escalas visuales (aproximación educativa) ──────────────── */

/** Escala logarítmica acotada: log10(v) llevado de [lo, hi] a [0, 1]. */
export function logScale(v: number, lo: number, hi: number): number {
	if (!(v > 0) || !Number.isFinite(v)) return 0;
	const t = (Math.log10(v) - Math.log10(lo)) / (Math.log10(hi) - Math.log10(lo));
	return t < 0 ? 0 : t > 1 ? 1 : t;
}

/* ── Restricciones geométricas ──────────────────────────────── */

/**
 * Lleva `p` al borde del disco (c, r) si está dentro, en dirección radial.
 * Si `p` coincide con el centro, usa la dirección de `from` (o +x).
 */
export function projectOutside(p: Point, c: Point, r: number, from?: Point): Point {
	let dx = p.x - c.x;
	let dy = p.y - c.y;
	let d = Math.hypot(dx, dy);
	if (d >= r) return p;
	if (!(d > 1e-12)) {
		dx = from ? from.x - c.x : 1;
		dy = from ? from.y - c.y : 0;
		d = Math.hypot(dx, dy);
		if (!(d > 1e-12)) {
			dx = 1;
			dy = 0;
			d = 1;
		}
	}
	return { x: c.x + (dx / d) * r, y: c.y + (dy / d) * r };
}

/** Disco de exclusión expresado en el eje que se corrige (`along`) y el otro (`across`). */
export interface Disc1D {
	along: number;
	across: number;
	r: number;
}

/**
 * Corrige una sola coordenada `v` (con la otra fija en `perp`) para que el
 * punto quede fuera de todos los discos: si cae dentro, lo desplaza a lo
 * largo del eje hasta el borde más cercano que sea válido y esté en
 * [min, max], redondeado hacia fuera al paso `step`. A igual distancia
 * gana el borde más próximo a `prefer` (p. ej. el valor anterior). Si no
 * hay ninguna posición válida, devuelve `v` sin cambios.
 */
export function avoidDiscs1D(
	v: number,
	perp: number,
	discs: readonly Disc1D[],
	min: number,
	max: number,
	step: number,
	prefer = v,
): number {
	const valid = (c: number): boolean => {
		if (c < min - 1e-9 || c > max + 1e-9) return false;
		for (const d of discs) {
			const a = c - d.along;
			const b = perp - d.across;
			if (a * a + b * b < d.r * d.r - 1e-9) return false;
		}
		return true;
	};
	if (valid(v)) return v;
	const digits = Math.max(0, Math.min(10, Math.ceil(-Math.log10(step) - 1e-9)));
	let best = v;
	let bestDist = Number.POSITIVE_INFINITY;
	for (const d of discs) {
		const b = perp - d.across;
		if (Math.abs(b) >= d.r) continue;
		const half = Math.ceil(Math.sqrt(d.r * d.r - b * b) / step - 1e-9) * step;
		for (const s of [1, -1]) {
			const c = Number((d.along + s * half).toFixed(digits));
			if (!valid(c)) continue;
			const dist = Math.abs(c - v);
			const tie = Math.abs(dist - bestDist) <= 1e-9;
			if ((dist < bestDist && !tie) || (tie && Math.abs(c - prefer) < Math.abs(best - prefer))) {
				best = c;
				bestDist = Math.abs(c - v);
			}
		}
	}
	return best;
}

/* ── Líneas de campo (trazado numérico) ─────────────────────── */

/** Número de líneas de una carga: proporcional a |q| (q en coulombs). */
export function lineCount(q: number): number {
	return Math.round(Math.abs(q / MICRO) * LINES_PER_MICROCOULOMB);
}

export interface LineSource {
	/** Índice de la carga de la que salen las líneas. */
	index: number;
	/** +1: se traza en el sentido de E (desde cargas positivas); −1: en contra (desde negativas). */
	sense: 1 | -1;
}

/**
 * Criterio de flujo: si la carga positiva total ≥ |carga negativa total|,
 * las líneas salen de las positivas hacia delante; si no, de las negativas
 * hacia atrás. Con cargas de un solo signo, salen de todas ellas.
 */
export function lineSources(charges: readonly PointCharge[]): LineSource[] {
	let pos = 0;
	let neg = 0;
	for (const c of charges) {
		if (c.q > 0) pos += c.q;
		else if (c.q < 0) neg -= c.q;
	}
	const out: LineSource[] = [];
	const fromPositive = pos > 0 && pos >= neg;
	charges.forEach((c, index) => {
		if (fromPositive ? c.q > 0 : c.q < 0) out.push({ index, sense: fromPositive ? 1 : -1 });
	});
	return out;
}

export interface FieldLine {
	/** Puntos x0, y0, x1, y1… en metros (ya diezmados para dibujar). */
	pts: number[];
	sense: 1 | -1;
	/** Carga de origen. */
	from: number;
	/** Carga en la que termina, o −1 si sale del dominio o se detiene. */
	to: number;
	/** Longitud recorrida (m). */
	length: number;
}

export interface TraceOptions {
	/** Dominio de trazado (las líneas terminan al salir). */
	bounds: WorldBounds;
	/** Radio de las cargas: las líneas arrancan en él y terminan al entrar en otra. */
	rCharge: number;
	/** Paso mínimo y máximo de integración (m). */
	stepMin?: number;
	stepMax?: number;
	/** Presupuesto total de pasos RK4 para todas las líneas. */
	budget?: number;
	/** Separación mínima entre puntos emitidos (m). */
	emitMin?: number;
}

export interface TraceResult {
	lines: FieldLine[];
	/** Pasos RK4 consumidos (incluidos los rechazados por el control de paso). */
	steps: number;
}

/** Desviación angular máxima entre el inicio y el final de un paso (rad). */
const MAX_TURN = 0.2;
const COS_TURN = Math.cos(MAX_TURN);

/**
 * Traza las líneas de campo con RK4 sobre la dirección unitaria de E
 * (parámetro = longitud de arco), con paso adaptativo acotado: proporcional
 * a la distancia a la carga más próxima y reducido a la mitad si la
 * dirección gira más de MAX_TURN en un paso. El número total de pasos está
 * acotado por `budget`, repartido entre las líneas.
 */
export function traceFieldLines(charges: readonly PointCharge[], opts: TraceOptions): TraceResult {
	const stepMin = opts.stepMin ?? 0.004;
	const stepMax = opts.stepMax ?? 0.04;
	const emitMin = opts.emitMin ?? 0.012;
	const budget = opts.budget ?? 24000;
	const R = opts.rCharge;
	const B = opts.bounds;
	const active = charges.filter((c) => c.q !== 0);
	const sources = lineSources(charges);

	// Semillas: ángulos uniformes alrededor de cada carga de origen, alineados con la otra carga.
	const seeds: Array<{ from: number; sense: 1 | -1; x: number; y: number }> = [];
	for (const s of sources) {
		const c = charges[s.index] as PointCharge;
		const n = lineCount(c.q);
		if (n === 0) continue;
		let base = 0;
		let offset = 0.5;
		let best = Number.POSITIVE_INFINITY;
		charges.forEach((o, j) => {
			if (j === s.index || o.q === 0) return;
			const d = Math.hypot(o.x - c.x, o.y - c.y);
			if (d < best) {
				best = d;
				base = Math.atan2(o.y - c.y, o.x - c.x);
				// Con signos opuestos, una línea va recta hacia la otra carga; con el mismo signo se evita el punto neutro.
				offset = o.q * c.q < 0 ? 0 : 0.5;
			}
		});
		for (let k = 0; k < n; k++) {
			const a = base + (2 * Math.PI * (k + offset)) / n;
			seeds.push({ from: s.index, sense: s.sense, x: c.x + R * Math.cos(a), y: c.y + R * Math.sin(a) });
		}
	}

	// Dirección unitaria de E (por `sense`); `false` si el campo es nulo o no finito.
	const u = { x: 0, y: 0 };
	const dir = (x: number, y: number, sense: number): boolean => {
		let ex = 0;
		let ey = 0;
		for (const c of active) {
			const dx = x - c.x;
			const dy = y - c.y;
			const d2 = dx * dx + dy * dy;
			if (!(d2 > 1e-18)) return false;
			const s = c.q / (d2 * Math.sqrt(d2));
			ex += s * dx;
			ey += s * dy;
		}
		const m = Math.hypot(ex, ey);
		if (!(m > 0) || !Number.isFinite(m)) return false;
		u.x = (sense * ex) / m;
		u.y = (sense * ey) / m;
		return true;
	};

	const lines: FieldLine[] = [];
	let steps = 0;
	for (let li = 0; li < seeds.length; li++) {
		const seed = seeds[li] as (typeof seeds)[number];
		const remaining = seeds.length - li;
		const maxSteps = Math.max(60, Math.min(900, Math.floor((budget - steps) / remaining)));
		let x = seed.x;
		let y = seed.y;
		const pts = [x, y];
		let lx = x;
		let ly = y;
		let length = 0;
		let to = -1;
		let px = Number.NaN;
		let py = Number.NaN;
		for (let i = 0; i < maxSteps && steps < budget; i++) {
			if (!dir(x, y, seed.sense)) break;
			const k1x = u.x;
			const k1y = u.y;
			// Punto neutro: la dirección se invierte de un paso al siguiente.
			if (Number.isFinite(px) && k1x * px + k1y * py < -0.5) break;
			px = k1x;
			py = k1y;
			let dmin = Number.POSITIVE_INFINITY;
			for (const c of active) dmin = Math.min(dmin, Math.hypot(x - c.x, y - c.y));
			let h = Math.min(stepMax, Math.max(stepMin, 0.2 * dmin));
			let nx = x;
			let ny = y;
			let ok = false;
			for (let tries = 0; tries < 6; tries++) {
				steps++;
				if (!dir(x + 0.5 * h * k1x, y + 0.5 * h * k1y, seed.sense)) break;
				const k2x = u.x;
				const k2y = u.y;
				if (!dir(x + 0.5 * h * k2x, y + 0.5 * h * k2y, seed.sense)) break;
				const k3x = u.x;
				const k3y = u.y;
				if (!dir(x + h * k3x, y + h * k3y, seed.sense)) break;
				const k4x = u.x;
				const k4y = u.y;
				if (k1x * k4x + k1y * k4y < COS_TURN && h > stepMin * 1.001) {
					h = Math.max(stepMin, h / 2);
					continue;
				}
				nx = x + (h / 6) * (k1x + 2 * k2x + 2 * k3x + k4x);
				ny = y + (h / 6) * (k1y + 2 * k2y + 2 * k3y + k4y);
				ok = true;
				break;
			}
			if (!ok || !Number.isFinite(nx) || !Number.isFinite(ny)) break;
			length += Math.hypot(nx - x, ny - y);
			x = nx;
			y = ny;

			// ¿Entra en una carga? (la de origen solo cuenta si la línea ya se alejó de ella)
			let hit = -1;
			for (let j = 0; j < charges.length; j++) {
				const c = charges[j] as PointCharge;
				if (c.q === 0) continue;
				const d = Math.hypot(x - c.x, y - c.y);
				if (d < R && (j !== seed.from || length > 2 * R)) {
					hit = j;
					const k = d > 1e-12 ? R / d : 0;
					x = c.x + (x - c.x) * k;
					y = c.y + (y - c.y) * k;
					break;
				}
			}
			if (hit >= 0) {
				to = hit;
				pts.push(x, y);
				break;
			}
			if (x < B.xMin || x > B.xMax || y < B.yMin || y > B.yMax) {
				pts.push(x, y);
				break;
			}
			if (Math.hypot(x - lx, y - ly) >= emitMin) {
				pts.push(x, y);
				lx = x;
				ly = y;
			}
		}
		if (pts[pts.length - 2] !== x || pts[pts.length - 1] !== y) pts.push(x, y);
		lines.push({ pts, sense: seed.sense, from: seed.from, to, length });
	}
	return { lines, steps };
}

export interface LineMark {
	x: number;
	y: number;
	/** Dirección unitaria del campo E en la marca. */
	ux: number;
	uy: number;
}

/**
 * Posiciones de las puntas de flecha que indican el sentido de E a lo largo
 * de una línea: una en el centro si es corta; si no, a `first` del origen y
 * luego cada `spacing`, sin acercarse a menos de `endGap` del final.
 */
export function lineMarks(line: FieldLine, opts: { first: number; spacing: number; minLength: number; endGap: number }): LineMark[] {
	const p = line.pts;
	const n = p.length / 2;
	if (n < 2) return [];
	const cum: number[] = [0];
	for (let i = 1; i < n; i++) {
		cum.push((cum[i - 1] as number) + Math.hypot((p[2 * i] as number) - (p[2 * i - 2] as number), (p[2 * i + 1] as number) - (p[2 * i - 1] as number)));
	}
	const L = cum[n - 1] as number;
	if (!(L >= opts.minLength)) return [];
	const targets: number[] = [];
	if (L < opts.first + opts.endGap + opts.spacing * 0.25) targets.push(L / 2);
	else for (let s = opts.first; s <= L - opts.endGap; s += opts.spacing) targets.push(s);
	const out: LineMark[] = [];
	let i = 1;
	for (const s of targets) {
		while (i < n - 1 && (cum[i] as number) < s) i++;
		const s0 = cum[i - 1] as number;
		const s1 = cum[i] as number;
		const x0 = p[2 * i - 2] as number;
		const y0 = p[2 * i - 1] as number;
		const x1 = p[2 * i] as number;
		const y1 = p[2 * i + 1] as number;
		const seg = Math.hypot(x1 - x0, y1 - y0);
		if (!(seg > 0)) continue;
		const t = s1 > s0 ? (s - s0) / (s1 - s0) : 0;
		out.push({
			x: x0 + (x1 - x0) * t,
			y: y0 + (y1 - y0) * t,
			ux: (line.sense * (x1 - x0)) / seg,
			uy: (line.sense * (y1 - y0)) / seg,
		});
	}
	return out;
}
