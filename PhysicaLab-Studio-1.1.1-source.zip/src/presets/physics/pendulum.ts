import type { AnimationClock } from '../../core/lifecycle';
import { clamp, deg2rad, fmt, rad2deg, texNum, texSI, texSig } from '../../core/numeric';
import type { PresetContext, PresetDefinition, PresetInstance } from '../../core/preset';
import type { ChangeSource, NumberParamSpec, ParamSpec, Point } from '../../core/types';
import type { Place } from '../../render/svg/math-layer';
import { Arrow, arcPath, Axes, Dimension, Handle, hatch } from '../../render/svg/primitives';
import type { SvgScene } from '../../render/svg/scene';
import { functionPath, polyPath, r2, setAttrs, show, svgEl, Viewport } from '../../render/svg/svg';
import {
	advanceSim,
	angleOf,
	bobPosition,
	bobRadius,
	ellipticK,
	ellipticModulus,
	exactPeriod,
	forceLength,
	heightAbove,
	kineticEnergy,
	periodRatio,
	planetFor,
	planetGravity,
	potentialEnergy,
	SMALL_ANGLE_LIMIT_DEG,
	smallAnglePeriod,
	smallAngleError,
	startSim,
	type PendulumSim,
} from './pendulum-model';

/**
 * Geometría fija de la figura principal (unidades del viewBox). La escala
 * es constante en metros: con L pequeña la varilla se ve corta.
 */
export const PENDULUM_LAYOUT = Object.freeze({
	width: 640,
	height: 440,
	/** Unidades de escena por metro. */
	scale: 130,
	pivot: Object.freeze({ x: 320, y: 54 }),
	/** Altura del techo (el pivote cuelga de un soporte). */
	ceilingY: 28,
});

const M_MIN = 0.05;
const M_MAX = 5;
const G_MIN = 1;
const G_MAX = 25;
/** Radio ilustrativo de la lenteja (escena). */
const R_MIN = 7;
const R_MAX = 15;
/** Longitud esquemática del vector peso (escena). */
const W_MIN = 24;
const W_MAX = 78;
/** Separación de las cotas L cos θ y h respecto de la vertical (escena). */
const CHAIN_OFFSET = 36;
/** Longitud mínima de una cota para que quepan sus dos puntas (escena). */
const MIN_DIM = 12;

const params: ParamSpec[] = [
	{
		id: 'theta0',
		type: 'number',
		name: 'Amplitud (ángulo inicial)',
		description: 'Ángulo con la vertical desde el que se suelta la masa en reposo',
		label: '\\theta_0',
		initial: 30,
		min: -90,
		max: 90,
		step: 0.5,
		precision: 1,
		unit: '{}^{\\circ}',
		unitText: '°',
		group: 'Péndulo',
	} satisfies NumberParamSpec,
	{
		id: 'L',
		type: 'number',
		name: 'Longitud de la varilla',
		label: 'L',
		initial: 1.5,
		min: 0.2,
		max: 2,
		step: 0.01,
		unit: '\\mathrm{m}',
		unitText: 'm',
		group: 'Péndulo',
	} satisfies NumberParamSpec,
	{
		id: 'm',
		type: 'number',
		name: 'Masa de la lenteja',
		description: 'No influye en el movimiento; sí en el peso y la energía',
		label: 'm',
		initial: 1,
		min: M_MIN,
		max: M_MAX,
		step: 0.01,
		scale: 'log',
		unit: '\\mathrm{kg}',
		unitText: 'kg',
		group: 'Péndulo',
	} satisfies NumberParamSpec,
	{
		id: 'g',
		type: 'number',
		name: 'Aceleración de la gravedad',
		label: 'g',
		initial: 9.81,
		min: G_MIN,
		max: G_MAX,
		step: 0.01,
		unit: '\\mathrm{m/s^2}',
		unitText: 'm/s²',
		group: 'Gravedad',
	} satisfies NumberParamSpec,
	{
		id: 'planet',
		type: 'enum',
		name: 'Cuerpo celeste',
		description: 'Al elegirlo fija g; después refleja el valor de g (que es el que se guarda)',
		initial: 'earth',
		options: [
			{ value: 'earth', label: 'Tierra (9.81 m/s²)' },
			{ value: 'moon', label: 'Luna (1.62 m/s²)' },
			{ value: 'mars', label: 'Marte (3.71 m/s²)' },
			{ value: 'jupiter', label: 'Júpiter (24.79 m/s²)' },
			{ value: 'custom', label: 'Personalizado' },
		],
		persist: false,
		group: 'Gravedad',
	},
	{ id: 'showWeight', type: 'boolean', name: 'Vector peso', label: 'm\\vec{g}', initial: true, group: 'Mostrar' },
	{ id: 'showComponents', type: 'boolean', name: 'Componentes tangencial y radial', initial: false, group: 'Mostrar' },
	{ id: 'showProjection', type: 'boolean', name: 'Proyección vertical y cotas', initial: true, group: 'Mostrar' },
	{
		id: 'dragLength',
		type: 'boolean',
		name: 'Arrastrar también la longitud',
		description: 'Al arrastrar la masa, la distancia al pivote fija L',
		initial: false,
		group: 'Mostrar',
	},
];

export const pendulumPreset: PresetDefinition = {
	id: 'physics.pendulum',
	version: 1,
	mode: 'physics',
	title: 'Péndulo simple',
	summary: 'Péndulo ideal: período exacto con la integral elíptica frente a T₀ = 2π√(L/g), fuerzas y energía.',
	keywords: [
		'péndulo',
		'pendulo',
		'péndulo simple',
		'oscilación',
		'oscilacion',
		'período',
		'periodo',
		'gravedad',
		'amplitud',
		'ángulos pequeños',
		'integral elíptica',
		'AGM',
		'RK4',
		'energía potencial',
		'MAS',
		'movimiento armónico simple',
	],
	params,
	fidelity:
		'Exacto: período T = 4√(L/g)·K(sin(θ₀/2)) con la integral elíptica K evaluada por la media aritmético-geométrica (precisión de máquina); T₀ = 2π√(L/g) es la aproximación de ángulos pequeños (sin θ ≈ θ). ' +
		'Animación: integración numérica RK4 de paso fijo (1 ms) de la ecuación exacta d²θ/dt² = −(g/L)·sin θ del péndulo ideal (sin rozamiento, varilla rígida sin masa, masa puntual). ' +
		'La figura está a escala fija en metros; el radio de la lenteja y la longitud de los vectores de fuerza son esquemáticos.',
	examples: [
		{ title: 'Pequeñas oscilaciones (θ₀ = 10°)', parameters: { theta0: 10, L: 1 } },
		{ title: 'Gran amplitud (θ₀ = 90°)', parameters: { theta0: 90, L: 1 } },
		{ title: 'Péndulo en la Luna', parameters: { theta0: 20, L: 1.5, g: 1.62 } },
	],
	create: (ctx) => new PendulumLab(ctx),
};

/** Orígenes de cambio en los que el selector de cuerpo celeste actúa sobre g. */
const PICK_SOURCES: ReadonlySet<ChangeSource> = new Set<ChangeSource>(['panel', 'api', 'keyboard']);

class PendulumLab implements PresetInstance {
	private readonly main: SvgScene;
	private readonly inset: SvgScene;
	private readonly vp: Viewport;
	private readonly vpI: Viewport;
	private readonly vertical: SVGLineElement;
	private readonly path: SVGPathElement;
	private readonly ghost: SVGCircleElement;
	private readonly projection: SVGLineElement;
	private readonly dimL: Dimension;
	private readonly dimLcos: Dimension;
	private readonly dimH: Dimension;
	private readonly rod: SVGLineElement;
	private readonly arc: SVGPathElement;
	private readonly bob: Handle;
	private readonly bobDisk: SVGCircleElement;
	private readonly weight: Arrow;
	private readonly compT: Arrow;
	private readonly compR: Arrow;
	private readonly compGuides: SVGPathElement;
	private readonly errSeg: SVGLineElement;
	private readonly approxPt: SVGCircleElement;
	private readonly hT: Handle;
	private readonly clock: AnimationClock;
	/** Estado derivado de la animación (no es un parámetro del almacén). */
	private sim: PendulumSim = startSim(0);

	constructor(private readonly ctx: PresetContext) {
		const store = ctx.store;
		const Ly = PENDULUM_LAYOUT;
		const main = (this.main = ctx.createScene({
			width: Ly.width,
			height: Ly.height,
			label: 'Péndulo simple: pivote, varilla de longitud L, masa m, ángulo θ con la vertical y peso m g',
		}));
		const inset = (this.inset = ctx.createScene({
			width: 300,
			height: Ly.height,
			label: 'Cociente entre el período exacto y el de pequeñas oscilaciones en función de la amplitud',
			className: 'pl-stage-inset',
		}));

		// Mundo en metros con el pivote en el origen y escala fija.
		const S = Ly.scale;
		this.vp = new Viewport(
			{
				xMin: -Ly.pivot.x / S,
				xMax: (Ly.width - Ly.pivot.x) / S,
				yMin: (Ly.pivot.y - Ly.height) / S,
				yMax: Ly.pivot.y / S,
			},
			{ x: 0, y: 0, width: Ly.width, height: Ly.height },
		);
		const P = Ly.pivot;

		// Soporte: techo rayado y escuadra que sostiene el pasador.
		const back = main.layers.back;
		hatch(back, { x: P.x - 92, y: Ly.ceilingY }, { x: P.x + 92, y: Ly.ceilingY }, -1, 8, 8);
		svgEl(back, 'path', {
			class: 'pl-pend-bracket',
			d: `M${P.x - 9} ${Ly.ceilingY}L${P.x + 9} ${Ly.ceilingY}L${P.x} ${P.y}Z`,
		});
		this.vertical = svgEl(back, 'line', { class: 'pl-line pl-thin pl-dashed pl-s-muted' });
		this.path = svgEl(back, 'path', { class: 'pl-line pl-thin pl-dotted pl-s-muted' });
		this.ghost = svgEl(back, 'circle', { class: 'pl-pend-ghost' });
		this.projection = svgEl(back, 'line', { class: 'pl-guide' });
		this.dimL = new Dimension(back);
		this.dimLcos = new Dimension(back);
		this.dimH = new Dimension(back);

		// Barra de escala discreta, junto al techo (pegada a la figura, no en una esquina vacía).
		// A esa altura la masa nunca la alcanza: con |θ0| ≤ 90° la lenteja no sube por encima del pivote.
		const sb = { x: P.x + 118, y: Ly.ceilingY + 4, w: 0.5 * S };
		svgEl(back, 'path', {
			class: 'pl-pend-scale',
			d: `M${sb.x} ${sb.y - 5}V${sb.y}H${r2(sb.x + sb.w)}V${sb.y - 5}`,
		});
		main.labels
			.label('scale', '0.5\\,\\mathrm{m}')
			.at({ x: sb.x + sb.w / 2, y: sb.y - 3 }, 'n', 2)
			.color('muted')
			.fontSize('sm');

		this.rod = svgEl(main.layers.main, 'line', { class: 'pl-line pl-s-text' });
		this.arc = svgEl(main.layers.main, 'path', { class: 'pl-line pl-thin pl-s-green' });
		svgEl(main.layers.front, 'circle', { class: 'pl-pend-pin', cx: P.x, cy: P.y, r: 3.2 });

		this.bob = new Handle(main.layers.handles, 'pl-pend-bob-handle', R_MAX);
		this.bobDisk = svgEl(this.bob.body, 'circle', { class: 'pl-pend-bob', r: R_MAX });
		// Vectores sobre la lenteja (aplicados en su centro); no capturan el puntero.
		const over = svgEl(main.layers.handles, 'g', { class: 'pl-pend-over' });
		this.compGuides = svgEl(over, 'path', { class: 'pl-guide' });
		this.compT = new Arrow(over, 'pl-s-violet pl-thin', 8, 6);
		this.compR = new Arrow(over, 'pl-s-violet pl-thin', 8, 6);
		this.weight = new Arrow(over, 'pl-s-amber', 10, 7);

		// Inserto: T/T₀ frente a θ₀ (no depende de L ni de g).
		this.vpI = new Viewport({ xMin: -90, xMax: 90, yMin: 0.99, yMax: 1.2 }, { x: 52, y: 34, width: 222, height: 366 });
		const vi = this.vpI;
		svgEl(inset.layers.grid, 'rect', {
			class: 'pl-pend-band',
			x: vi.X(-SMALL_ANGLE_LIMIT_DEG),
			y: vi.Y(1.2),
			width: vi.X(SMALL_ANGLE_LIMIT_DEG) - vi.X(-SMALL_ANGLE_LIMIT_DEG),
			height: vi.Y(0.99) - vi.Y(1.2),
		});
		new Axes(inset.layers.grid, inset.layers.back).draw(vi, {
			xTicks: [-90, -45, 0, 45, 90],
			yTicks: [1, 1.05, 1.1, 1.15, 1.2],
			cross: false,
			xFormat: (v) => `${fmt(v, 0)}°`,
			yDecimals: 2,
		});
		svgEl(inset.layers.main, 'line', {
			class: 'pl-line pl-s-green pl-dashed',
			x1: vi.X(-90),
			y1: vi.Y(1),
			x2: vi.X(90),
			y2: vi.Y(1),
		});
		svgEl(inset.layers.main, 'path', {
			class: 'pl-curve pl-s-blue',
			d: functionPath(vi, (x) => periodRatio(deg2rad(x)), -90, 90, 180),
		});
		this.errSeg = svgEl(inset.layers.main, 'line', { class: 'pl-line pl-s-rose' });
		this.approxPt = svgEl(inset.layers.front, 'circle', { class: 'pl-hole', r: 3.5 });
		this.hT = new Handle(inset.layers.handles, 'pl-pt pl-pt-blue', 5);
		svgEl(this.hT.body, 'circle', { r: 5, class: 'pl-pt-dot' });
		const IL = inset.labels;
		IL.label('ax-y', 'T/T_0').at({ x: vi.X(-90), y: vi.Y(1.2) }, 'n', 6).color('muted').fontSize('sm');
		IL.label('ax-x', '\\theta_0').at({ x: vi.X(90), y: vi.Y(0.99) }, 'ne', 2).color('muted').fontSize('sm');
		IL.label('exact', '\\tfrac{2}{\\pi}K\\!\\left(\\sin\\tfrac{\\theta_0}{2}\\right)')
			.at({ x: vi.X(0), y: vi.Y(1.155) }, 'c')
			.color('blue')
			.fontSize('sm');
		IL.label('approx', '\\sin\\theta\\approx\\theta').color('green').fontSize('sm');
		IL.label('band', `|\\theta_0|\\le ${SMALL_ANGLE_LIMIT_DEG}^{\\circ}`)
			.at({ x: vi.X(0), y: vi.Y(1.2) }, 's', 5)
			.color('muted')
			.fontSize('sm');

		const fitHits = (): void => {
			this.bob.setHitRadius(main.touchRadius(22));
			this.hT.setHitRadius(inset.touchRadius(22));
		};
		fitHits();
		ctx.scope.add(main.onResize(fitHits));
		ctx.scope.add(inset.onResize(fitHits));

		// Arrastre de la masa: proyección sobre la circunferencia de radio L (o también L).
		ctx.draggable(
			main,
			this.bob.g,
			{
				onStart: () => this.interrupt(),
				onMove: (p) => {
					const w = this.vp.toWorld(p);
					const theta0 = rad2deg(angleOf(w.x, w.y));
					if (store.bool('dragLength')) store.update({ theta0, L: Math.hypot(w.x, w.y) }, 'drag');
					else store.set('theta0', theta0, 'drag');
				},
				onKey: (dx, dy, mods) => {
					const changeL = dy !== 0 && store.bool('dragLength');
					if (dx === 0 && !changeL) return;
					this.interrupt();
					if (dx !== 0) store.set('theta0', store.num('theta0') + dx * (mods.coarse ? 5 : mods.fine ? 0.5 : 1), 'keyboard');
					if (changeL) store.set('L', store.num('L') - dy * (mods.coarse ? 0.1 : 0.01), 'keyboard');
				},
			},
			'Masa del péndulo: gira alrededor del pivote (flechas izquierda y derecha cambian θ₀)',
		);

		ctx.draggable(
			inset,
			this.hT.g,
			{
				onStart: () => this.interrupt(),
				onMove: (p) => store.set('theta0', this.vpI.toWorld(p).x, 'drag'),
				onKey: (dx, _dy, mods) => {
					if (dx === 0) return;
					this.interrupt();
					store.set('theta0', store.num('theta0') + dx * (mods.coarse ? 5 : mods.fine ? 0.5 : 1), 'keyboard');
				},
			},
			'Amplitud θ₀ sobre la curva T/T₀',
		);

		// Animación: integra la ecuación no lineal desde θ₀ en reposo.
		this.clock = ctx.clock((dt) => {
			this.sim = advanceSim(this.sim, dt, store.num('g'), store.num('L'));
			ctx.requestRender();
			return true;
		});
		if (ctx.features.animation) {
			ctx.panel.addAnimationControls(this.clock, {
				label: 'oscilación (RK4)',
				onRestart: () => {
					this.resetSim();
					ctx.requestRender();
				},
				speeds: [0.25, 0.5, 1, 2],
			});
		}

		// Cambiar θ₀, L o g reinicia la simulación (θ(t) se deriva del estado).
		ctx.scope.add(
			store.subscribe((changed, source) => {
				if (changed.has('theta0') || changed.has('L') || changed.has('g')) this.resetSim();
				this.syncPlanet(changed, source);
			}),
		);
		this.resetSim();
		this.syncPlanet(new Set(['g']), 'init');

		ctx.setNote(pendulumPreset.fidelity);
	}

	render(): void {
		const { store, equations } = this.ctx;
		const th0Deg = store.num('theta0');
		const th0 = deg2rad(th0Deg);
		const L = store.num('L');
		const m = store.num('m');
		const g = store.num('g');
		const active = this.sim.t > 0;
		const th = active ? this.sim.theta : th0;
		const omega = active ? this.sim.omega : 0;
		const showProj = store.bool('showProjection');
		const showW = store.bool('showWeight');
		const showC = store.bool('showComponents');

		/* ── Figura principal ── */
		const vp = this.vp;
		const P: Point = { ...PENDULUM_LAYOUT.pivot };
		const R = vp.len(L);
		const B = vp.toScene(bobPosition(L, th));
		const s = th >= 0 ? 1 : -1; // lado de la masa
		const r = bobRadius(m, M_MIN, M_MAX, R_MIN, R_MAX);
		const ux = Math.sin(th); // unidad pivote → masa (escena, y hacia abajo)
		const uy = Math.cos(th);
		const bottom: Point = { x: P.x, y: P.y + R };
		const absTh = Math.abs(th);

		setAttrs(this.rod, { x1: P.x, y1: P.y, x2: B.x, y2: B.y });
		this.bob.moveTo(B);
		this.bobDisk.setAttribute('r', r2(r));
		this.bob.halo.setAttribute('r', r2(r + 5));
		this.bob.g.setAttribute('aria-valuetext', `θ = ${fmt(rad2deg(th), 1)}°, L = ${fmt(L, 2)} m`);

		setAttrs(this.vertical, { x1: P.x, y1: P.y, x2: P.x, y2: bottom.y + Math.max(r, 8) + 14 });
		// Trayectoria: en reposo, del punto más bajo a θ₀ (se omite con las componentes,
		// que ocupan esa zona); en la animación, todo el vaivén ±θ₀.
		const amp = Math.abs(th0);
		const pathOn = amp > 1e-4 && (active || !showC);
		if (pathOn) {
			const a0 = active ? -Math.PI / 2 - amp : -Math.PI / 2;
			this.path.setAttribute('d', arcPath(P, R, a0, -Math.PI / 2 + (active ? amp : th0)));
		}
		show(this.path, pathOn);

		// Ángulo con la vertical.
		const ra = clamp(0.4 * R, 16, 46);
		const arcVisible = absTh > deg2rad(0.75);
		if (arcVisible) this.arc.setAttribute('d', arcPath(P, ra, -Math.PI / 2, -Math.PI / 2 + th));
		show(this.arc, arcVisible);
		const thTex = active ? '\\theta' : '\\theta_0';
		const ML = this.main.labels;
		// Dentro de la cuña si cabe; si no, al otro lado de la vertical (antes de las cotas).
		const rho = Math.max(ra + 12, 15 / Math.max(absTh / 2, 1e-3));
		const rhoMax = Math.min(R - r - 8, 92);
		if (rho <= rhoMax) {
			const bis = th / 2;
			ML.label('theta', thTex).at({ x: P.x + rho * Math.sin(bis), y: P.y + rho * Math.cos(bis) }, 'c').color('green').visible(arcVisible);
		} else {
			ML.label('theta', thTex)
				.at({ x: P.x, y: P.y + ra }, s > 0 ? 'w' : 'e', 4)
				.color('green')
				.visible(arcVisible);
		}

		// Cota de L por el lado exterior de la varilla.
		this.dimL.set(P, B, -s * 18);
		ML.label('L', 'L').at(this.dimL.mid, placeFor(this.dimL.normal.x, this.dimL.normal.y), 3).visible(R > 24);

		// Proyección vertical: L cos θ y h = L(1 − cos θ) encadenadas sobre la vertical.
		const F: Point = { x: P.x, y: B.y };
		const hScene = bottom.y - F.y;
		const projOn = showProj && absTh > deg2rad(0.75);
		setAttrs(this.projection, { x1: B.x, y1: B.y, x2: F.x, y2: F.y });
		show(this.projection, projOn);
		// Separadas de la vertical lo bastante para que quepa la etiqueta de θ entre ambas.
		this.dimLcos.set(P, F, s * CHAIN_OFFSET).visible(projOn && F.y - P.y > MIN_DIM);
		this.dimH.set(F, bottom, s * CHAIN_OFFSET).visible(projOn && hScene > MIN_DIM);
		setAttrs(this.ghost, { cx: bottom.x, cy: bottom.y, r });
		show(this.ghost, projOn && hScene > 2 && !showC);
		const side: Place = s > 0 ? 'w' : 'e';
		ML.label('Lcos', 'L\\cos\\theta')
			.at(this.dimLcos.mid, side, 3)
			.fontSize('sm')
			.visible(projOn && F.y - P.y > 30);
		ML.label('h', 'h')
			.at(this.dimH.mid, side, 3)
			.fontSize('sm')
			.visible(projOn && hScene > MIN_DIM);

		// Peso y sus componentes (longitud esquemática, logarítmica en mg).
		const len = forceLength(m * g, M_MIN * G_MIN, M_MAX * G_MAX, W_MIN, W_MAX);
		const Wtip: Point = { x: B.x, y: B.y + len };
		this.weight.set(B.x, B.y, Wtip.x, Wtip.y).visible(showW);
		ML.label('W', 'm\\vec{g}').at(Wtip, 's', 3).color('amber').visible(showW);
		const tl = len * Math.sin(th); // con signo
		const rl = len * Math.cos(th);
		const Ttip: Point = { x: B.x - tl * uy, y: B.y + tl * ux };
		const Rtip: Point = { x: B.x + rl * ux, y: B.y + rl * uy };
		this.compT.set(B.x, B.y, Ttip.x, Ttip.y).visible(showC);
		this.compR.set(B.x, B.y, Rtip.x, Rtip.y).visible(showC);
		this.compGuides.setAttribute('d', `${polyPath([Ttip, Wtip])}${polyPath([Rtip, Wtip])}`);
		show(this.compGuides, showC && showW && absTh > deg2rad(2));
		// Etiquetas solo si ambas componentes se separan del peso (cada punta dista
		// de la del peso lo que mide la otra componente): evita solapes con m g.
		const compLabels = showC && Math.abs(tl) > 22 && Math.abs(rl) > 22;
		ML.label('Ft', 'mg\\sin\\theta')
			.at(Ttip, placeFor(Ttip.x - B.x, Ttip.y - B.y), 4)
			.color('violet')
			.fontSize('sm')
			.visible(compLabels);
		ML.label('Fr', 'mg\\cos\\theta')
			.at(Rtip, placeFor(Rtip.x - B.x, 0.35 * (Rtip.y - B.y)), 4)
			.color('violet')
			.fontSize('sm')
			.visible(compLabels);

		/* ── Inserto T/T₀ ── */
		const vi = this.vpI;
		const ratio = periodRatio(th0);
		const xI = vi.X(th0Deg);
		this.hT.moveTo({ x: xI, y: vi.Y(ratio) });
		setAttrs(this.errSeg, { x1: xI, y1: vi.Y(1), x2: xI, y2: vi.Y(ratio) });
		show(this.errSeg, vi.Y(1) - vi.Y(ratio) > 1);
		setAttrs(this.approxPt, { cx: xI, cy: vi.Y(1) });
		// La etiqueta de la recta T/T₀ = 1 se aparta del segmento de error.
		const approxRight = th0Deg < SMALL_ANGLE_LIMIT_DEG;
		this.inset.labels
			.label('approx')
			.at({ x: vi.X(approxRight ? 88 : -88), y: vi.Y(1) }, approxRight ? 'nw' : 'ne', 5);

		/* ── Ecuaciones y lecturas ── */
		const n = texNum;
		const deg = (v: number): string => `${n(v, 1)}^{\\circ}`;
		const T0 = smallAnglePeriod(L, g);
		const T = exactPeriod(L, g, th0);
		const k = ellipticModulus(th0);
		const K = ellipticK(k);
		const eps = smallAngleError(th0);
		const h = heightAbove(L, th);
		const Ep = potentialEnergy(m, g, L, th);
		const Ec = kineticEnergy(m, L, omega);
		const warn = Math.abs(th0Deg) > SMALL_ANGLE_LIMIT_DEG;
		const uL = (v: number): string => `${n(v, 2)}\\,\\mathrm{m}`;
		const ug = `${n(g, 2)}\\,\\mathrm{m/s^2}`;

		// Ecuaciones largas en dos renglones (aligned) para que quepan en móvil.
		equations.set(
			'ode',
			`\\ddot{\\theta}=-\\frac{g}{L}\\sin\\theta,\\qquad \\frac{g}{L}=${n(g / L, 2)}\\,\\mathrm{s^{-2}}`,
			'Ecuación del movimiento (exacta, no lineal)',
		);
		equations.set(
			'small',
			`T_0=2\\pi\\sqrt{\\frac{L}{g}}=2\\pi\\sqrt{\\frac{${uL(L)}}{${ug}}}=${n(T0, 3)}\\,\\mathrm{s}`,
			'Período de pequeñas oscilaciones (aproximación lineal)',
		);
		equations.set(
			'exact',
			`\\begin{aligned}T&=4\\sqrt{\\frac{L}{g}}\\,K(k),\\qquad k=\\sin\\frac{\\theta_0}{2}=${n(k, 4)}\\\\[4pt]` +
				`&=4\\,(${n(Math.sqrt(L / g), 4)}\\,\\mathrm{s})(${n(K, 4)})=${n(T, 3)}\\,\\mathrm{s}\\end{aligned}`,
			'Período exacto para la amplitud θ₀',
		);
		equations.set(
			'K',
			`\\begin{aligned}K(k)&=\\int_0^{\\pi/2}\\frac{d\\varphi}{\\sqrt{1-k^2\\sin^2\\varphi}}\\\\[12pt]` +
				`&=\\frac{\\pi}{2\\,\\operatorname{AGM}\\!\\left(1,\\sqrt{1-k^2}\\right)}=${n(K, 4)}\\end{aligned}`,
			'Integral elíptica completa de primera especie (media aritmético-geométrica)',
		);
		equations.set(
			'err',
			`\\frac{T}{T_0}=\\frac{2}{\\pi}K(k)=${n(ratio, 5)},\\quad \\varepsilon=1-\\frac{T_0}{T}=${n(100 * eps, 2)}\\,\\%`,
			warn
				? `Error de la aproximación de ángulos pequeños: con |θ₀| > ${SMALL_ANGLE_LIMIT_DEG}° deja de ser buena`
				: 'Error relativo de la aproximación de ángulos pequeños',
		);
		equations.highlight('err', warn);
		equations.set(
			'Ep',
			`\\begin{aligned}E_p&=mgh=mgL(1-\\cos${thTex})\\\\[2pt]` +
				`&=(${fmtSig(m)}\\,\\mathrm{kg})(${ug})(${texSig(h, 3)}\\,\\mathrm{m})=${texSI(Ep, 'J')}\\end{aligned}`,
			'Energía potencial respecto del punto más bajo',
		);

		equations.readout('theta', active ? `\\theta(t)=${deg(rad2deg(th))}` : `\\theta_0=${deg(th0Deg)}`);
		equations.readout('t', `t=${n(this.sim.t, 2)}\\,\\mathrm{s}`);
		equations.visible('t', active);
		equations.readout('T0', `T_0=${n(T0, 3)}\\,\\mathrm{s}`);
		equations.readout('T', `T=${n(T, 3)}\\,\\mathrm{s}`);
		equations.readout('f', `f=1/T=${n(1 / T, 3)}\\,\\mathrm{Hz}`);
		equations.readout('eps', `\\varepsilon=${n(100 * eps, 2)}\\,\\%`);
		equations.highlight('eps', warn);
		equations.readout('h', `h=${texSig(h, 3)}\\,\\mathrm{m}`);
		equations.readout(
			'E',
			active ? `E=E_c+E_p=${texSI(Ec + Ep, 'J')}` : `E=E_p=${texSI(Ep, 'J')}`,
		);

		this.ctx.status(
			warn
				? `|θ₀| > ${SMALL_ANGLE_LIMIT_DEG}°: T₀ subestima el período real un ${fmt(100 * eps, 1)} %`
				: null,
		);
	}

	setVisible(v: boolean): void {
		if (!v) this.clock.pause();
	}

	/** Al manipular la masa: pausa la animación y vuelve a θ₀ en reposo. */
	private interrupt(): void {
		this.clock.pause();
		if (this.sim.t > 0) {
			this.resetSim();
			this.ctx.requestRender();
		}
	}

	private resetSim(): void {
		this.sim = startSim(deg2rad(this.ctx.store.num('theta0')));
		this.clock.resetTime();
	}

	/**
	 * El selector de cuerpo celeste solo actúa cuando el usuario lo cambia:
	 * entonces fija g. En cualquier otro caso refleja g (fuente de verdad).
	 */
	private syncPlanet(changed: ReadonlySet<string>, source: ChangeSource): void {
		if (!changed.has('planet') && !changed.has('g')) return;
		const store = this.ctx.store;
		const picked = store.str('planet');
		if (changed.has('planet') && !changed.has('g') && PICK_SOURCES.has(source)) {
			const gPicked = planetGravity(picked);
			if (gPicked === null) return; // «Personalizado»: g no cambia
			if (store.num('g') === gPicked || store.set('g', gPicked, source)) return;
		}
		const derived = planetFor(store.num('g'));
		if (picked !== derived) store.set('planet', derived, 'init');
	}
}

/** Posición de etiqueta (punto cardinal) en la dirección (dx, dy) de escena. */
function placeFor(dx: number, dy: number): Place {
	if (!(Math.abs(dx) + Math.abs(dy) > 0)) return 'e';
	const k = Math.round(Math.atan2(dy, dx) / (Math.PI / 4));
	const places: Place[] = ['w', 'nw', 'n', 'ne', 'e', 'se', 's', 'sw', 'w'];
	return places[k + 4] ?? 'e';
}

/** Tres cifras significativas (masa en escala logarítmica). */
function fmtSig(v: number): string {
	if (v === 0 || !Number.isFinite(v)) return texNum(v, 2);
	const d = Math.max(0, 2 - Math.floor(Math.log10(Math.abs(v))));
	return texNum(v, Math.min(d, 6));
}
