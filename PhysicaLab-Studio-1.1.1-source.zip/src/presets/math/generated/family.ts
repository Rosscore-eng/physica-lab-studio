import { genericPlotPreset } from '../generic-plot';

/**
 * Generado por scripts/nuevo-lab.mjs desde labs/familia-primitivas.json.
 * Edita el JSON y vuelve a ejecutar el script; no edites este archivo a mano.
 */
export const familyPreset = genericPlotPreset({
	"id": "math.family",
	"title": "Familia de primitivas",
	"summary": "F(x) = x³/3 + C: todas las primitivas se desplazan en vertical.",
	"keywords": [
		"integral",
		"integral indefinida",
		"primitiva",
		"antiderivada",
		"familia de curvas",
		"constante de integración",
		"constante de integracion",
		"x^3"
	],
	"fidelity": "Exacto: F(x) = x³/3 + C y F′(x) = x² se evalúan analíticamente. Solo se dibuja el dominio indicado.",
	"xMin": -3,
	"xMax": 3,
	"params": [
		{
			"id": "c",
			"name": "Constante de integración C",
			"label": "C",
			"initial": 0,
			"min": -6,
			"max": 6,
			"step": 0.25,
			"group": "Familia"
		},
		{
			"id": "x0",
			"name": "Punto de evaluación",
			"label": "x_0",
			"initial": 1.5,
			"min": -3,
			"max": 3,
			"step": 0.01,
			"group": "Cursor"
		}
	],
	"curves": [
		{
			"expr": "x^3/3 + c",
			"color": "blue",
			"label": "F(x)"
		},
		{
			"expr": "x^3/3 + c - 2",
			"color": "green"
		},
		{
			"expr": "x^3/3 + c + 2",
			"color": "green"
		}
	],
	"cursor": "x0",
	"equation": "F(x)=\\frac{x^3}{3}+C \\qquad F'(x)=x^2",
	"readout": "F(x_0)"
});
