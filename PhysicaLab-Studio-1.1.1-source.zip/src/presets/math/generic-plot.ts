import type { PresetContext, PresetDefinition, PresetInstance } from '../../core/preset';
import { compileExpr, type CompiledExpr } from '../../core/expr';
import { fmt } from '../../core/numeric';
import type { NumberParamSpec, ParamSpec } from '../../core/types';
import { Axes, Handle } from '../../render/svg/primitives';
import type { SvgScene } from '../../render/svg/scene';
import { functionPath, setAttrs, svgEl, Viewport } from '../../render/svg/svg';

/**
 * Motor de laboratorios declarativos: una lista de curvas y = f(x; parámetros)
 * más un cursor arrastrable. Lo usan los presets generados con
 * `scripts/nuevo-lab.mjs`; no hay código específico por laboratorio.
 */

export type CurveColor = 'blue' | 'green' | 'amber' | 'violet' | 'rose';

export interface PlotParamJson {
	id: string;
	name: string;
	label?: string;
	initial: number;
	min: number;
	max: number;
	step: number;
	unit?: string;
	unitText?: string;
	group?: string;
}

export interface PlotCurveJson {
	/** Expresión en notación de calculadora: x^2, sin(x), a*x + b… */
	expr: string;
	color?: CurveColor;
	label?: string;
	width?: number;
}

export interface PlotSpecJson {
	id: string;
	title: string;
	summary: string;
	keywords: string[];
	fidelity: string;
	/** Dominio dibujado. */
	xMin: number;
	xMax: number;
	params: PlotParamJson[];
	curves: PlotCurveJson[];
	/** Identificador del parámetro que mueve el cursor (normalmente x0). */
	cursor?: string;
	/** Ecuación que se muestra bajo la figura (LaTeX). */
	equation?: string;
	/** Leyenda corta junto al cursor; por defecto, el valor de la primera curva. */
	readout?: string;
}

const COLORS: Record<CurveColor, string> = {
	blue: 'pl-s-blue',
	green: 'pl-s-green',
	amber: 'pl-s-amber',
	violet: 'pl-s-violet',
	rose: 'pl-s-rose',
};

export function genericPlotPreset(spec: PlotSpecJson): PresetDefinition {
	const params: ParamSpec[] = spec.params.map(
		(p): NumberParamSpec => ({
			id: p.id,
			type: 'number',
			name: p.name,
			label: p.label,
			initial: p.initial,
			min: p.min,
			max: p.max,
			step: p.step,
			unit: p.unit,
			unitText: p.unitText,
			group: p.group,
		}),
	);
	return {
		id: spec.id,
		version: 1,
		mode: 'math',
		title: spec.title,
		summary: spec.summary,
		keywords: spec.keywords,
		params,
		fidelity: spec.fidelity,
		create: (ctx) => new GenericPlotLab(ctx, spec),
	};
}

class GenericPlotLab implements PresetInstance {
	private readonly scene: SvgScene;
	private readonly axes: Axes;
	private readonly paths: SVGPathElement[] = [];
	private readonly cursor?: Handle;
	private readonly curves: CompiledExpr[];
	private readonly errors: string[];
	private vp: Viewport;
	private readonly rect = { x: 48, y: 26, width: 640, height: 356 };

	constructor(
		private readonly ctx: PresetContext,
		private readonly spec: PlotSpecJson,
	) {
		this.scene = ctx.createScene({
			width: 720,
			height: 420,
			label: spec.title,
		});
		this.curves = spec.curves.map((c) => {
			try {
				return compileExpr(c.expr);
			} catch {
				return compileExpr('0/0');
			}
		});
		this.errors = spec.curves.map((c) => {
			try {
				compileExpr(c.expr);
				return '';
			} catch (e) {
				return e instanceof Error ? e.message : String(e);
			}
		});
		this.vp = this.viewport(0, 1);

		this.axes = new Axes(this.scene.layers.grid, this.scene.layers.back);
		const clipId = this.scene.id('clip');
		const cp = svgEl(this.scene.defs, 'clipPath', { id: clipId });
		const r = this.rect;
		svgEl(cp, 'rect', { x: r.x, y: r.y, width: r.width, height: r.height });
		const group = svgEl(this.scene.layers.main, 'g', { 'clip-path': `url(#${clipId})` });
		for (const c of spec.curves) {
			this.paths.push(
				svgEl(group, 'path', {
					class: `pl-curve ${COLORS[c.color ?? 'blue']}`,
					'stroke-width': c.width ?? 2.2,
				}),
			);
		}

		this.scene.labels.label('ax-x', 'x').at({ x: 692, y: 388 }, 'e', 4).color('muted').fontSize('sm');
		this.scene.labels.label('ax-y', 'y').at({ x: 52, y: 30 }, 'ne', 2).color('muted').fontSize('sm');

		if (spec.cursor) {
			const x0 = ctx.store.num(spec.cursor);
			this.cursor = new Handle(this.scene.layers.handles, 'pl-pt pl-pt-amber', 6);
			svgEl(this.cursor.body, 'circle', { r: 5, class: 'pl-pt-dot' });
			const fit = (): void => this.cursor?.setHitRadius(this.scene.touchRadius(22));
			fit();
			ctx.scope.add(this.scene.onResize(fit));
			ctx.draggable(
				this.scene,
				this.cursor.g,
				{
					onMove: (p) => {
						const x = this.vp.toWorld(p).x;
						ctx.store.set(spec.cursor as string, x, 'drag');
					},
					onKey: (dx, _dy, m) => {
						const step = m.coarse ? (spec.xMax - spec.xMin) / 20 : (spec.xMax - spec.xMin) / 200;
						ctx.store.set(spec.cursor as string, ctx.store.num(spec.cursor as string) + dx * step, 'keyboard');
					},
				},
				'Punto sobre la curva (mueve x_0)',
			);
			void x0;
		}

		ctx.setNote(spec.fidelity);
		if (spec.equation) ctx.equations.set('eq', spec.equation, 'Modelo');
	}

	render(): void {
		const store = this.ctx.store;
		const vars: Record<string, number> = { x: 0 };
		for (const p of this.spec.params) vars[p.id] = store.num(p.id);

		// Rango vertical automático con margen.
		let lo = Number.POSITIVE_INFINITY;
		let hi = Number.NEGATIVE_INFINITY;
		const samples = 240;
		for (const c of this.curves) {
			for (let i = 0; i <= samples; i++) {
				const x = this.spec.xMin + ((this.spec.xMax - this.spec.xMin) * i) / samples;
				const y = c.eval({ ...vars, x });
				if (Number.isFinite(y) && Math.abs(y) < 1e12) {
					if (y < lo) lo = y;
					if (y > hi) hi = y;
				}
			}
		}
		if (!Number.isFinite(lo) || !Number.isFinite(hi)) {
			lo = -1;
			hi = 1;
		}
		if (hi - lo < 1e-9) {
			lo -= 1;
			hi += 1;
		}
		const pad = (hi - lo) * 0.1;
		this.vp = this.viewport(lo - pad, hi + pad);
		const vp = this.vp;

		this.axes.draw(vp, { tickCount: 6 });
		this.spec.curves.forEach((_c, i) => {
			const comp = this.curves[i] as CompiledExpr;
			setAttrs(this.paths[i] as SVGPathElement, {
				d: functionPath(vp, (x) => comp.eval({ ...vars, x }), this.spec.xMin, this.spec.xMax, 320),
			});
		});

		const eq = this.ctx.equations;
		const n = (v: number, k = this.ctx.decimals): string => fmt(v, k);
		const first = this.curves[0];
		if (this.spec.cursor && first) {
			const x0 = store.num(this.spec.cursor);
			const y0 = first.eval({ ...vars, x: x0 });
			this.cursor?.moveTo({ x: vp.X(x0), y: vp.Y(y0) });
			eq.readout('x0', `x_0=${n(x0)}`);
			eq.readout(
				'y0',
				Number.isFinite(y0) ? `${this.spec.readout ?? 'f(x_0)'}=${n(y0, 4)}` : 'f(x_0)\\ \\text{no definido}',
			);
			eq.highlight('y0', !Number.isFinite(y0));
		}
		eq.readout(
			'vals',
			this.spec.params.map((p) => `${p.label ?? p.id}=${n(store.num(p.id), 3)}`).join('\\quad '),
		);

		const bad = this.errors.filter(Boolean);
		this.ctx.status(bad.length ? `Expresión no válida: ${bad[0]}` : null);
	}

	private viewport(yMin: number, yMax: number): Viewport {
		return new Viewport({ xMin: this.spec.xMin, xMax: this.spec.xMax, yMin, yMax }, this.rect);
	}
}
