import type { AnimationClock } from '../../core/lifecycle';
import { fmt, texNum } from '../../core/numeric';
import type { PresetContext, PresetDefinition, PresetInstance } from '../../core/preset';
import type { NumberParamSpec, ParamSpec, Point } from '../../core/types';
import { Axes, Handle } from '../../render/svg/primitives';
import type { SvgScene } from '../../render/svg/scene';
import { functionPath, setAttrs, show, svgEl, Viewport } from '../../render/svg/svg';
import { f, secantSlope, tangentSlope } from './secant-math';

const X_MIN = -3;
const X_MAX = 3;

const params: ParamSpec[] = [
	{
		id: 'x0',
		type: 'number',
		name: 'Abscisa del punto A',
		label: 'x_0',
		initial: 1,
		min: -2.5,
		max: 2.5,
		step: 0.01,
		group: 'Puntos',
	},
	{
		id: 'h',
		type: 'number',
		name: 'Separación entre B y A',
		description: 'h = x_B − x_A',
		label: 'h',
		initial: 0.75,
		min: -2,
		max: 2,
		step: 0.001,
		precision: 3,
		group: 'Puntos',
		// B debe quedar dentro del dominio dibujado.
		range: (v) => ({ min: X_MIN - (v.x0 as number), max: X_MAX - (v.x0 as number) }),
	} satisfies NumberParamSpec,
	{ id: 'showSecant', type: 'boolean', name: 'Recta secante', initial: true, group: 'Mostrar' },
	{ id: 'showTangent', type: 'boolean', name: 'Recta tangente en A', initial: true, group: 'Mostrar' },
	{ id: 'showIncrements', type: 'boolean', name: 'Incrementos Δx y Δy', initial: true, group: 'Mostrar' },
];

export const secantTangentPreset: PresetDefinition = {
	id: 'math.secant-tangent',
	version: 1,
	mode: 'math',
	title: 'Secante y tangente',
	summary: 'Pendiente de la secante de f(x) = x² y su límite: la derivada.',
	keywords: [
		'secante',
		'tangente',
		'derivada',
		'límite',
		'limite',
		'pendiente',
		'cociente incremental',
		'parábola',
		'parabola',
		'x^2',
		'cálculo',
		'calculo',
	],
	params,
	fidelity:
		'Exacto: f(x) = x², cociente incremental y derivada calculados analíticamente. En h = 0 el cociente 0/0 no está definido; se muestra su límite.',
	examples: [
		{ title: 'Punto A en x₀ = 1', parameters: { x0: 1, h: 0.75 } },
		{ title: 'Secante casi tangente', parameters: { x0: -1.5, h: 0.05 } },
	],
	create: (ctx) => new SecantTangentLab(ctx),
};

class SecantTangentLab implements PresetInstance {
	private readonly main: SvgScene;
	private readonly inset: SvgScene;
	private readonly vp: Viewport;
	private vpInset: Viewport;
	private readonly insetAxes: Axes;
	private readonly secant: SVGLineElement;
	private readonly tangent: SVGLineElement;
	private readonly dx: SVGLineElement;
	private readonly dy: SVGLineElement;
	private readonly guideA: SVGLineElement;
	private readonly guideB: SVGLineElement;
	private readonly hA: Handle;
	private readonly hB: Handle;
	private readonly insetLine: SVGLineElement;
	private readonly insetLimit: SVGLineElement;
	private readonly insetHole: SVGCircleElement;
	private readonly hM: Handle;
	private insetCenter = Number.NaN;
	private readonly toZero: AnimationClock;

	constructor(private readonly ctx: PresetContext) {
		const store = ctx.store;
		const main = (this.main = ctx.createScene({
			width: 640,
			height: 420,
			label: 'Parábola f(x) = x² con la secante AB y la tangente en A',
		}));
		const inset = (this.inset = ctx.createScene({
			width: 300,
			height: 420,
			label: 'Pendiente de la secante en función de h',
			className: 'pl-stage-inset',
		}));

		this.vp = new Viewport({ xMin: X_MIN, xMax: X_MAX, yMin: -1.2, yMax: 9.4 }, { x: 34, y: 14, width: 592, height: 386 });
		new Axes(main.layers.grid, main.layers.back).draw(this.vp, { xTicks: [-3, -2, -1, 0, 1, 2, 3], yTicks: [0, 2, 4, 6, 8] });
		main.labels.label('ax-x', 'x').at({ x: this.vp.X(X_MAX), y: this.vp.Y(0) }, 'nw', 4).color('muted').fontSize('sm');
		main.labels.label('ax-y', 'y').at({ x: this.vp.X(0), y: this.vp.Y(9.4) }, 'e', 6).color('muted').fontSize('sm');

		// Recorte al área del gráfico para las rectas «infinitas».
		const clipId = main.id('clip');
		const cp = svgEl(main.defs, 'clipPath', { id: clipId });
		const r = this.vp.sceneRect;
		svgEl(cp, 'rect', { x: r.x, y: r.y, width: r.width, height: r.height });
		const lines = svgEl(main.layers.main, 'g', { 'clip-path': `url(#${clipId})` });

		svgEl(lines, 'path', { class: 'pl-curve pl-s-blue', d: functionPath(this.vp, f, X_MIN, X_MAX, 240) });
		this.tangent = svgEl(lines, 'line', { class: 'pl-line pl-s-green pl-dashed' });
		this.secant = svgEl(lines, 'line', { class: 'pl-line pl-s-amber' });
		this.guideA = svgEl(lines, 'line', { class: 'pl-guide' });
		this.guideB = svgEl(lines, 'line', { class: 'pl-guide' });
		this.dx = svgEl(lines, 'line', { class: 'pl-leg pl-s-violet' });
		this.dy = svgEl(lines, 'line', { class: 'pl-leg pl-s-violet' });
		main.labels.label('curve', 'f(x) = x^2').at({ x: this.vp.X(2.5), y: this.vp.Y(f(2.5)) }, 'w', 12).color('blue');

		this.hA = new Handle(main.layers.handles, 'pl-pt pl-pt-blue', 6);
		svgEl(this.hA.body, 'circle', { r: 6, class: 'pl-pt-dot' });
		this.hB = new Handle(main.layers.handles, 'pl-pt pl-pt-amber', 6);
		svgEl(this.hB.body, 'circle', { r: 6, class: 'pl-pt-dot' });

		// Inserto: m_sec(h) = 2x0 + h, con un hueco en h = 0 (discontinuidad evitable).
		this.vpInset = new Viewport({ xMin: -2.2, xMax: 2.2, yMin: -3, yMax: 3 }, { x: 50, y: 30, width: 232, height: 352 });
		this.insetAxes = new Axes(inset.layers.grid, inset.layers.back);
		this.insetLimit = svgEl(inset.layers.main, 'line', { class: 'pl-line pl-s-green pl-dashed' });
		this.insetLine = svgEl(inset.layers.main, 'line', { class: 'pl-line pl-s-amber' });
		this.insetHole = svgEl(inset.layers.front, 'circle', { r: 4.5, class: 'pl-hole' });
		this.hM = new Handle(inset.layers.handles, 'pl-pt pl-pt-amber', 5);
		svgEl(this.hM.body, 'circle', { r: 5, class: 'pl-pt-dot' });
		inset.labels.label('ax-h', 'h').at({ x: 282, y: 382 }, 'ne', 2).color('muted').fontSize('sm');
		inset.labels.label('ax-m', 'm_{\\text{sec}}(h)').at({ x: 50, y: 26 }, 'n', 2).color('muted').fontSize('sm');

		const fitHits = (): void => {
			for (const hd of [this.hA, this.hB]) hd.setHitRadius(main.touchRadius(22));
			this.hM.setHitRadius(inset.touchRadius(22));
		};
		fitHits();
		ctx.scope.add(main.onResize(fitHits));
		ctx.scope.add(inset.onResize(fitHits));

		ctx.draggable(
			main,
			this.hA.g,
			{
				onMove: (p) => store.set('x0', this.vp.toWorld(p).x, 'drag'),
				onKey: (dx, _dy, m) => store.set('x0', store.num('x0') + dx * (m.coarse ? 0.1 : 0.01), 'keyboard'),
			},
			'Punto A sobre la parábola (se desplaza a lo largo de la curva)',
		);

		ctx.draggable(
			main,
			this.hB.g,
			{
				onMove: (p) => {
					let h = this.vp.toWorld(p).x - store.num('x0');
					// Imán: si B queda a menos de 6 px de A, h = 0 (caso límite).
					if (Math.abs(this.vp.len(h)) * main.pxPerUnit < 6) h = 0;
					store.set('h', h, 'drag');
				},
				onKey: (dx, _dy, m) => store.set('h', store.num('h') + dx * (m.coarse ? 0.1 : m.fine ? 0.001 : 0.01), 'keyboard'),
			},
			'Punto B sobre la parábola (cambia la separación h)',
		);

		ctx.draggable(
			inset,
			this.hM.g,
			{
				onMove: (p) => {
					let h = this.vpInset.toWorld(p).x;
					if (Math.abs(this.vpInset.len(h)) * inset.pxPerUnit < 5) h = 0;
					store.set('h', h, 'drag');
				},
				onKey: (dx, _dy, m) => store.set('h', store.num('h') + dx * (m.coarse ? 0.1 : 0.01), 'keyboard'),
			},
			'Valor de h en la gráfica de la pendiente',
		);

		// «h → 0»: acerca B a A de forma geométrica y se detiene en |h| = 0.001.
		this.toZero = ctx.clock((dt) => {
			const h = store.num('h');
			if (h === 0 || Math.abs(h) <= 0.001) return false;
			let next = h * Math.exp(-1.6 * dt);
			// El paso de h es 0.001: garantiza al menos un paso de avance por frame.
			if (Math.abs(h - next) < 0.001) next = h - Math.sign(h) * 0.001;
			if (Math.abs(next) < 0.001) next = Math.sign(h) * 0.001;
			store.set('h', next, 'animation');
			return true;
		});
		if (ctx.features.animation) {
			ctx.panel.addAnimationControls(this.toZero, { label: 'acercar B a A (h → 0)', speeds: [0.5, 1, 2] });
		}
		ctx.panel.addButton(
			'h = 0',
			() => {
				this.toZero.pause();
				store.set('h', 0, 'api');
			},
			{ title: 'Coloca B sobre A: el cociente 0/0 queda indefinido y solo existe el límite', quiet: true },
		);

		ctx.setNote(secantTangentPreset.fidelity);
		ctx.equations.set(
			'def',
			'm_{\\text{sec}}(h)=\\frac{f(x_0+h)-f(x_0)}{h}=\\frac{(x_0+h)^2-x_0^2}{h}=2x_0+h\\qquad (h\\neq 0)',
			'Cociente incremental',
		);
	}

	render(): void {
		const { store, equations } = this.ctx;
		const x0 = store.num('x0');
		const h = store.num('h');
		const xB = x0 + h;
		const yA = f(x0);
		const yB = f(xB);
		const limitCase = h === 0;
		const mSec = secantSlope(x0, h);
		const mTan = tangentSlope(x0);
		const vp = this.vp;
		const A: Point = { x: vp.X(x0), y: vp.Y(yA) };
		const B: Point = { x: vp.X(xB), y: vp.Y(yB) };
		const showSec = store.bool('showSecant') && !limitCase;
		const showTan = store.bool('showTangent') || limitCase;
		const showInc = store.bool('showIncrements') && !limitCase;

		this.hA.moveTo(A);
		this.hB.moveTo(B);
		this.hB.g.classList.toggle('pl-pt-merged', limitCase);

		if (showSec) setAttrs(this.secant, lineAcross(vp, mSec, x0, yA));
		show(this.secant, showSec);
		setAttrs(this.tangent, lineAcross(vp, mTan, x0, yA));
		show(this.tangent, showTan);

		setAttrs(this.guideA, { x1: A.x, y1: A.y, x2: A.x, y2: vp.Y(0) });
		setAttrs(this.guideB, { x1: B.x, y1: B.y, x2: B.x, y2: vp.Y(0) });
		show(this.guideB, !limitCase);
		setAttrs(this.dx, { x1: A.x, y1: A.y, x2: B.x, y2: A.y });
		setAttrs(this.dy, { x1: B.x, y1: A.y, x2: B.x, y2: B.y });
		show(this.dx, showInc);
		show(this.dy, showInc);

		const L = this.main.labels;
		L.label('A', 'A').at(A, h >= 0 ? 'nw' : 'ne', 8);
		L.label('B', 'B')
			.at(B, h >= 0 ? 'se' : 'sw', 8)
			.visible(!limitCase);
		L.label('dx', '\\Delta x = h')
			.at({ x: (A.x + B.x) / 2, y: A.y }, 's', 6)
			.color('violet')
			.fontSize('sm')
			.visible(showInc && Math.abs(B.x - A.x) > 40);
		L.label('dy', '\\Delta y')
			.at({ x: B.x, y: (A.y + B.y) / 2 }, h >= 0 ? 'e' : 'w', 8)
			.color('violet')
			.fontSize('sm')
			.visible(showInc && Math.abs(B.y - A.y) > 24);

		// Inserto: ventana vertical centrada en f'(x0), redondeada para no redibujar los ejes en cada frame.
		const center = Math.round(mTan * 2) / 2;
		if (center !== this.insetCenter) {
			this.insetCenter = center;
			this.vpInset = new Viewport({ xMin: -2.2, xMax: 2.2, yMin: center - 3, yMax: center + 3 }, this.vpInset.rect);
			this.insetAxes.draw(this.vpInset, { xTicks: [-2, -1, 0, 1, 2], tickCount: 6, cross: false });
		}
		const vi = this.vpInset;
		const hMin = Math.max(-2.2, X_MIN - x0);
		const hMax = Math.min(2.2, X_MAX - x0);
		setAttrs(this.insetLine, { x1: vi.X(hMin), y1: vi.Y(mTan + hMin), x2: vi.X(hMax), y2: vi.Y(mTan + hMax) });
		setAttrs(this.insetLimit, { x1: vi.X(-2.2), y1: vi.Y(mTan), x2: vi.X(2.2), y2: vi.Y(mTan) });
		setAttrs(this.insetHole, { cx: vi.X(0), cy: vi.Y(mTan) });
		this.hM.moveTo({ x: vi.X(h), y: vi.Y(limitCase ? mTan : mSec) });
		this.hM.g.classList.toggle('pl-pt-merged', limitCase);
		const I = this.inset.labels;
		I.label('lim', "f'(x_0)").at({ x: vi.X(2.2), y: vi.Y(mTan) }, 'nw', 4).color('green').fontSize('sm');
		I.label('hole', '\\tfrac{0}{0}')
			.at({ x: vi.X(0), y: vi.Y(mTan) }, 'se', 6)
			.color('rose')
			.fontSize('sm')
			.visible(limitCase);

		// Ecuaciones y lecturas
		const d = this.ctx.decimals;
		const n = (v: number, k = d): string => texNum(v, k);
		if (limitCase) {
			equations.set(
				'num',
				`m_{\\text{sec}}(0)=\\frac{f(${n(x0)})-f(${n(x0)})}{0}=\\frac{0}{0}\\;\\Rightarrow\\;\\text{no definido}`,
				'Con h = 0 el cociente incremental no existe',
			);
		} else {
			equations.set(
				'num',
				`m_{\\text{sec}}=\\frac{f(${n(xB, 3)})-f(${n(x0)})}{${n(h, 3)}}=\\frac{${exact(yB)}-${exact(yA)}}{${n(h, 3)}}=${n(mSec, 4)}`,
				'Valores actuales',
			);
		}
		equations.highlight('num', limitCase);
		equations.set(
			'lim',
			`f'(x_0)=\\lim_{h\\to 0} m_{\\text{sec}}(h)=\\lim_{h\\to 0}\\,(2x_0+h)=2x_0=${n(mTan)}`,
			'Pendiente de la tangente (límite)',
		);
		equations.set('tan', `y_{\\tan}=${n(mTan)}\\,(x-${n(x0)})+${n(yA)}`, 'Recta tangente en A');

		equations.readout('x0', `x_0=${n(x0)}`);
		equations.readout('h', `h=${n(h, 3)}`);
		equations.readout(
			'msec',
			limitCase ? 'm_{\\text{sec}}=\\tfrac{0}{0}\\ (\\text{indefinida})' : `m_{\\text{sec}}=${n(mSec, 4)}`,
		);
		equations.readout('mtan', `m_{\\tan}=${n(mTan, 4)}`);
		equations.readout(
			'err',
			limitCase
				? '\\lim_{h\\to0}|m_{\\text{sec}}-m_{\\tan}|=0'
				: `|m_{\\text{sec}}-m_{\\tan}|=|h|=${n(Math.abs(mSec - mTan), 4)}`,
		);

		this.ctx.status(
			limitCase
				? 'h = 0: el cociente 0/0 no está definido; se muestra el límite'
				: Math.abs(h) <= 0.01
					? `h = ${fmt(h, 3)}: la secante casi coincide con la tangente`
					: null,
		);
	}

	setVisible(v: boolean): void {
		if (!v) this.toZero.pause();
	}
}

/** Segmento de la recta y = m (x − x0) + y0 que cruza todo el viewport. */
function lineAcross(vp: Viewport, m: number, x0: number, y0: number): Record<string, number> {
	const xa = vp.world.xMin - 1;
	const xb = vp.world.xMax + 1;
	return { x1: vp.X(xa), y1: vp.Y(m * (xa - x0) + y0), x2: vp.X(xb), y2: vp.Y(m * (xb - x0) + y0) };
}

/**
 * f(x) = x² con x de hasta 3 decimales es exacto con 6 decimales. Se muestra
 * así (sin ceros sobrantes, mínimo 4 decimales) para que la fracción
 * sustituida reproduzca m_sec incluso con |h| = 0.001.
 */
function exact(v: number): string {
	let s = (Object.is(v, -0) ? 0 : v).toFixed(6);
	while (s.endsWith('0') && s.length - s.indexOf('.') - 1 > 4) s = s.slice(0, -1);
	return s;
}
