import { fmt } from '../../core/numeric';
import type { PresetContext, PresetDefinition, PresetInstance } from '../../core/preset';
import type { ParamSpec, Rect } from '../../core/types';
import { Axes, Handle } from '../../render/svg/primitives';
import type { SvgScene } from '../../render/svg/scene';
import { functionPath, setAttrs, svgEl, Viewport } from '../../render/svg/svg';

const params: ParamSpec[] = [
	{
		id: 'vs',
		type: 'number',
		name: 'Tensión de la fuente',
		label: 'V_s',
		initial: 12,
		min: 1,
		max: 24,
		step: 0.5,
		unit: '\\mathrm{V}',
		unitText: 'V',
		group: 'Circuito',
	},
	{
		id: 'r1',
		type: 'number',
		name: 'Resistencia serie R1',
		label: 'R_1',
		initial: 1000,
		min: 100,
		max: 10000,
		step: 100,
		unit: '\\Omega',
		unitText: 'Ω',
		group: 'Circuito',
	},
	{
		id: 'r2',
		type: 'number',
		name: 'Resistencia de salida R2',
		label: 'R_2',
		initial: 1000,
		min: 100,
		max: 10000,
		step: 100,
		unit: '\\Omega',
		unitText: 'Ω',
		group: 'Circuito',
	},
	{
		id: 'rl',
		type: 'number',
		name: 'Carga R_L',
		label: 'R_L',
		initial: 1000,
		min: 50,
		max: 20000,
		step: 50,
		unit: '\\Omega',
		unitText: 'Ω',
		group: 'Carga',
	},
];

export const theveninPreset: PresetDefinition = {
	id: 'math.thevenin',
	version: 1,
	mode: 'math',
	title: 'Equivalente de Thévenin',
	summary: 'Divisor con carga: V_th, R_th, Norton y máxima transferencia de potencia.',
	keywords: [
		'thévenin',
		'thevenin',
		'norton',
		'equivalente',
		'divisor de tensión',
		'divisor de tension',
		'máxima transferencia',
		'maxima transferencia',
		'potencia',
		'resistencia equivalente',
		'fuente equivalente',
		'circuito equivalente',
	],
	params,
	fidelity:
		'Exacto: divisor resistivo, equivalente de Thévenin/Norton y potencia calculados analíticamente. No se modelan efectos parásitos, tolerancias ni límites de disipación.',
	examples: [
		{ title: 'Divisor simétrico con carga igual', parameters: { vs: 12, r1: 1000, r2: 1000, rl: 1000 } },
		{ title: 'Máxima transferencia (R_L = R_th)', parameters: { vs: 12, r1: 1000, r2: 1000, rl: 500 } },
		{ title: 'Fuente fuerte y carga pequeña', parameters: { vs: 24, r1: 100, r2: 100, rl: 50 } },
	],
	create: (ctx) => new TheveninLab(ctx),
};

class TheveninLab implements PresetInstance {
	private readonly scene: SvgScene;
	private readonly rect: Rect = { x: 74, y: 300, width: 646, height: 200 };
	private readonly axes: Axes;
	private readonly curva: SVGPathElement;
	private readonly hRl: Handle;
	private readonly guiaRth: SVGLineElement;
	private vp: Viewport;

	constructor(private readonly ctx: PresetContext) {
		const scene = (this.scene = ctx.createScene({
			width: 760,
			height: 560,
			label: 'Divisor de tensión, su equivalente de Thévenin y la potencia en la carga',
		}));

		const wire = (x1: number, y1: number, x2: number, y2: number): SVGLineElement =>
			svgEl(scene.layers.main, 'line', { class: 'pl-line pl-s-muted', x1, y1, x2, y2 });
		const body = (x: number, y: number, w: number, h: number): SVGRectElement =>
			svgEl(scene.layers.main, 'rect', { class: 'pl-line pl-s-muted pl-f-none', x, y, width: w, height: h, rx: 2 });
		const dot = (x: number, y: number): SVGCircleElement =>
			svgEl(scene.layers.main, 'circle', { class: 'pl-f-muted', cx: x, cy: y, r: 2.6 });
		const source = (x: number, y: number): void => {
			svgEl(scene.layers.main, 'circle', { class: 'pl-line pl-s-muted pl-f-none', cx: x, cy: y, r: 16 });
			let d = '';
			for (let i = 0; i <= 18; i++) {
				const u = i / 18;
				d += `${i ? 'L' : 'M'}${(x - 8 + 16 * u).toFixed(1)} ${(y - 6 * Math.sin(2 * Math.PI * u)).toFixed(1)}`;
			}
			svgEl(scene.layers.main, 'path', { class: 'pl-line pl-s-amber', d });
		};

		// Esquema: circuito original.
		wire(60, 60, 60, 104);
		source(60, 120);
		wire(60, 136, 60, 180);
		wire(60, 180, 300, 180);
		wire(60, 60, 100, 60);
		body(100, 54, 60, 12);
		wire(160, 60, 210, 60);
		wire(210, 60, 210, 95);
		body(204, 95, 12, 50);
		wire(210, 145, 210, 180);
		wire(210, 60, 300, 60);
		wire(300, 60, 300, 95);
		body(294, 95, 12, 50);
		wire(300, 145, 300, 180);
		dot(210, 60);
		dot(300, 60);
		dot(210, 180);
		dot(300, 180);

		// Esquema: equivalente de Thévenin.
		wire(440, 60, 440, 104);
		source(440, 120);
		wire(440, 136, 440, 180);
		wire(440, 180, 680, 180);
		wire(440, 60, 480, 60);
		body(480, 54, 60, 12);
		wire(540, 60, 680, 60);
		wire(680, 60, 680, 95);
		body(674, 95, 12, 50);
		wire(680, 145, 680, 180);
		dot(680, 60);
		dot(680, 180);

		const L = scene.labels;
		L.label('tituloA', '\\text{circuito original}').at({ x: 40, y: 30 }, 'ne', 2).color('text').fontSize('sm');
		L.label('tituloB', '\\text{equivalente Thévenin}').at({ x: 420, y: 30 }, 'ne', 2).color('text').fontSize('sm');
		L.label('r1', 'R_1').at({ x: 130, y: 50 }, 'n', 2).color('text').fontSize('sm');
		L.label('r2', 'R_2').at({ x: 196, y: 112 }, 'w', 6).color('text').fontSize('sm');
		L.label('rlA', 'R_L').at({ x: 314, y: 112 }, 'e', 6).color('text').fontSize('sm');
		L.label('rlB', 'R_L').at({ x: 694, y: 112 }, 'e', 6).color('text').fontSize('sm');
		L.label('rth', 'R_{th}').at({ x: 510, y: 50 }, 'n', 2).color('text').fontSize('sm');
		L.label('nodeA', 'A').at({ x: 306, y: 46 }, 'e', 4).color('blue').fontSize('sm');
		L.label('nodeB', 'B').at({ x: 306, y: 198 }, 'e', 4).color('blue').fontSize('sm');
		L.label('nodeA2', 'A').at({ x: 686, y: 46 }, 'e', 4).color('blue').fontSize('sm');
		L.label('nodeB2', 'B').at({ x: 686, y: 198 }, 'e', 4).color('blue').fontSize('sm');
		L.label('vs', 'V_s').at({ x: 84, y: 108 }, 'e', 4).color('amber').fontSize('sm');
		L.label('vth', 'V_{th}').at({ x: 464, y: 108 }, 'e', 4).color('amber').fontSize('sm');
		L.label('vsVal', '').at({ x: 84, y: 124 }, 'e', 4).color('muted').fontSize('sm');
		L.label('vthVal', '').at({ x: 464, y: 124 }, 'e', 4).color('muted').fontSize('sm');
		L.label('r1Val', '').at({ x: 130, y: 82 }, 'n', 2).color('muted').fontSize('sm');
		L.label('r2Val', '').at({ x: 196, y: 128 }, 'w', 6).color('muted').fontSize('sm');
		L.label('rlAVal', '').at({ x: 314, y: 128 }, 'e', 6).color('muted').fontSize('sm');
		L.label('rlBVal', '').at({ x: 694, y: 128 }, 'e', 6).color('muted').fontSize('sm');
		L.label('rthVal', '').at({ x: 510, y: 82 }, 'n', 2).color('muted').fontSize('sm');

		// Gráfica de potencia.
		this.vp = new Viewport({ xMin: 0, xMax: 2000, yMin: 0, yMax: 20 }, this.rect);
		this.axes = new Axes(scene.layers.grid, scene.layers.back);
		this.guiaRth = svgEl(scene.layers.main, 'line', { class: 'pl-line pl-s-green pl-dashed' });
		this.curva = svgEl(scene.layers.main, 'path', { class: 'pl-curve pl-s-blue' });
		this.hRl = new Handle(scene.layers.handles, 'pl-pt pl-pt-amber', 6);
		svgEl(this.hRl.body, 'circle', { r: 4.2, class: 'pl-pt-dot' });
		const fitHit = (): void => this.hRl.setHitRadius(scene.touchRadius(22));
		fitHit();
		ctx.scope.add(scene.onResize(fitHit));
		ctx.draggable(
			scene,
			this.hRl.g,
			{
				onMove: (p) => {
					const r = this.vp.toWorld(p).x;
					ctx.store.set('rl', Math.min(20000, Math.max(50, Math.round(r / 50) * 50)), 'drag');
				},
				onKey: (dx, _dy, m) => {
					ctx.store.set('rl', ctx.store.num('rl') + dx * (m.coarse ? 500 : 50), 'keyboard');
				},
			},
			'Carga R_L: se arrastra sobre la curva de potencia',
		);

		L.label('plotTitle', '\\text{potencia en la carga }(\\mathrm{mW})')
			.at({ x: 80, y: 294 }, 'ne', 2)
			.color('text')
			.fontSize('sm');
		L.label('xLabel', 'R_L\\ (\\Omega)').at({ x: 720, y: 542 }, 'w', 4).color('muted').fontSize('sm');
		L.label('rthMark', 'R_{th}').at({ x: 200, y: 492 }, 'n', 3).color('green').fontSize('sm');

		ctx.setNote(theveninPreset.fidelity);
		ctx.equations.set('vth', 'V_{th}=\\frac{V_s\\,R_2}{R_1+R_2}', 'Tensión equivalente de Thévenin');
		ctx.equations.set('rth', 'R_{th}=\\frac{R_1R_2}{R_1+R_2}', 'Resistencia equivalente de Thévenin');
		ctx.equations.set(
			'load',
			'I_L=\\frac{V_{th}}{R_{th}+R_L},\\qquad V_L=I_LR_L,\\qquad P_L=\\frac{V_{th}^2R_L}{(R_{th}+R_L)^2}',
			'Carga',
		);
		ctx.equations.set('max', 'R_L=R_{th}\\;\\Rightarrow\\;P_{max}=\\frac{V_{th}^2}{4R_{th}}', 'Máxima transferencia');

		ctx.panel.addButton(
			'R_L = R_th',
			() => {
				const r1 = ctx.store.num('r1');
				const r2 = ctx.store.num('r2');
				ctx.store.set('rl', (r1 * r2) / (r1 + r2), 'api');
			},
			{ title: 'Coloca la carga en el valor de máxima transferencia (R_L = R_th)', quiet: true },
		);
	}

	render(): void {
		const store = this.ctx.store;
		const vs = store.num('vs');
		const r1 = store.num('r1');
		const r2 = store.num('r2');
		const rl = store.num('rl');

		const vth = (vs * r2) / (r1 + r2);
		const rth = (r1 * r2) / (r1 + r2);
		const il = vth / (rth + rl);
		const vl = il * rl;
		const pl = (vl * vl) / rl;
		const pmax = (vth * vth) / (4 * rth);
		const inn = vth / rth;

		const n = (v: number, k = this.ctx.decimals): string => fmt(v, k);
		const L = this.scene.labels;

		L.label('vsVal', `${n(vs, 1)}\\ \\mathrm{V}`);
		L.label('vthVal', `${n(vth, 2)}\\ \\mathrm{V}`);
		L.label('r1Val', `${n(r1, 0)}\\ \\Omega`);
		L.label('r2Val', `${n(r2, 0)}\\ \\Omega`);
		L.label('rlAVal', `${n(rl, 0)}\\ \\Omega`);
		L.label('rlBVal', `${n(rl, 0)}\\ \\Omega`);
		L.label('rthVal', `${n(rth, 0)}\\ \\Omega`);

		const xMax = Math.ceil(Math.max(4 * rth, 2 * rl) / 100) * 100;
		const yMax = Math.max(0.001, pmax * 1000 * 1.15);
		this.vp = new Viewport({ xMin: 0, xMax, yMin: 0, yMax }, this.rect);
		const vp = this.vp;

		this.axes.draw(vp, { tickCount: 6 });
		this.curva.setAttribute(
			'd',
			functionPath(vp, (r) => (r <= 0 ? 0 : ((vth * vth * r) / ((rth + r) * (rth + r))) * 1000), 0, xMax, 240),
		);
		setAttrs(this.guiaRth, { x1: vp.X(rth), y1: vp.Y(0), x2: vp.X(rth), y2: vp.Y(yMax) });
		this.hRl.moveTo({ x: vp.X(rl), y: vp.Y(Math.min(pl * 1000, yMax)) });
		L.label('rthMark').at({ x: vp.X(rth), y: vp.Y(0) - 6 }, 'n', 3);

		const eq = this.ctx.equations;
		eq.readout('vthNum', `V_{th}=${n(vth, 3)}\\;\\mathrm{V}`);
		eq.readout('rthNum', `R_{th}=${n(rth, 0)}\\;\\Omega`);
		eq.readout('vlNum', `V_L=${n(vl, 3)}\\;\\mathrm{V}`);
		eq.readout('ilNum', `I_L=${n(il * 1000, 2)}\\;\\mathrm{mA}`);
		eq.readout('plNum', `P_L=${n(pl * 1000, 2)}\\;\\mathrm{mW}`);
		eq.readout('pmaxNum', `P_{max}=${n(pmax * 1000, 2)}\\;\\mathrm{mW}\\;(R_L=R_{th})`);
		eq.readout('nortonNum', `I_N=${n(inn * 1000, 2)}\\;\\mathrm{mA}\\quad R_N=${n(rth, 0)}\\;\\Omega`);

		this.ctx.status(
			Math.abs(rl - rth) <= Math.max(rth * 0.005, 1)
				? 'R_L ≈ R_th: transferencia de potencia máxima'
				: `R_L/R_th = ${n(rl / rth, 2)}`,
		);
	}
}
