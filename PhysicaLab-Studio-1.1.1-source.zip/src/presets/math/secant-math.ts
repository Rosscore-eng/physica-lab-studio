/** Modelo matemático del laboratorio secante–tangente (funciones puras). */

export const f = (x: number): number => x * x;
export const fPrime = (x: number): number => 2 * x;

/**
 * Cociente incremental [f(x0+h) − f(x0)] / h.
 * Para h = 0 el cociente es 0/0: se devuelve `NaN` (indefinido), nunca el límite.
 */
export function secantSlope(x0: number, h: number): number {
	if (h === 0) return Number.NaN;
	return (f(x0 + h) - f(x0)) / h;
}

/** Límite del cociente incremental cuando h → 0 (derivada): 2·x0. */
export function tangentSlope(x0: number): number {
	return fPrime(x0);
}

/** Recta y = m (x − x0) + y0 evaluada en x. */
export function lineAt(m: number, x0: number, y0: number, x: number): number {
	return m * (x - x0) + y0;
}

/** Error de la secante respecto de la tangente: |m_sec − f'(x0)| = |h| para f = x². */
export function slopeError(x0: number, h: number): number {
	return Math.abs(secantSlope(x0, h) - tangentSlope(x0));
}
