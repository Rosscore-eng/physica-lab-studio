import type { PresetDefinition } from '../core/preset';
import { PresetRegistry } from '../core/registry';
import { rcChargingPreset } from './circuits/rc-charging';
import { secantTangentPreset } from './math/secant-tangent';
import { theveninPreset } from './math/thevenin';
import { pendulumPreset } from './physics/pendulum';
import { twoChargesPreset } from './physics/two-charges';
import { familyPreset } from './math/generated/family';

/**
 * Presets incluidos. Para añadir uno nuevo: crea su módulo en la carpeta
 * de su modo y añádelo a esta lista. El núcleo no cambia.
 */
export const BUILTIN_PRESETS: PresetDefinition[] = [
	secantTangentPreset,
	theveninPreset,
	pendulumPreset,
	twoChargesPreset,
	rcChargingPreset,
	familyPreset,
];

export function createBuiltinRegistry(): PresetRegistry {
	const r = new PresetRegistry();
	for (const p of BUILTIN_PRESETS) r.register(p);
	return r;
}
