import type { ResourceScope } from '../core/lifecycle';
import type { Point } from '../core/types';
import type { RenderSurface } from '../render/svg/scene';

export interface DragHandlers {
	/** Inicio del arrastre (coordenadas de escena). */
	onStart?(p: Point, ev: PointerEvent): void;
	/** Movimiento: el preset aplica sus restricciones y escribe en el estado. */
	onMove(p: Point, ev: PointerEvent): void;
	/** Fin (soltar, cancelar o perder la captura). */
	onEnd?(cancelled: boolean): void;
	/**
	 * Teclado (accesibilidad): flechas con `dx`,`dy` ∈ {-1,0,1}. `fine`
	 * indica Alt (paso fino) y `coarse`, Mayús (paso grande).
	 */
	onKey?(dx: number, dy: number, mods: { fine: boolean; coarse: boolean }): void;
}

export interface DragOptions {
	/** Nombre accesible del objeto manipulable. */
	label: string;
	/** Elemento raíz del laboratorio (recibe la clase `pl-is-dragging`). */
	root?: HTMLElement;
}

export interface DragHandle {
	setEnabled(enabled: boolean): void;
	readonly active: boolean;
	destroy(): void;
}

/**
 * Hace manipulable un elemento SVG con Pointer Events (ratón, lápiz y
 * táctil). Usa captura de puntero, convierte coordenadas de pantalla a
 * escena y evita el desplazamiento de la página solo mientras se arrastra
 * (CSS `touch-action: none` en el asa + `preventDefault` durante el gesto).
 */
export function makeDraggable(
	surface: RenderSurface,
	el: SVGElement,
	handlers: DragHandlers,
	parentScope: ResourceScope,
	opts: DragOptions,
): DragHandle {
	const scope = parentScope.child();
	let enabled = true;
	let pointerId: number | null = null;

	el.classList.add('pl-draggable');
	el.setAttribute('tabindex', '0');
	el.setAttribute('role', 'slider');
	el.setAttribute('aria-label', opts.label);
	el.setAttribute('focusable', 'true');

	const setActive = (on: boolean): void => {
		el.classList.toggle('pl-is-active', on);
		opts.root?.classList.toggle('pl-is-dragging', on);
	};

	const finish = (cancelled: boolean): void => {
		if (pointerId === null) return;
		const id = pointerId;
		pointerId = null;
		try {
			if (el.hasPointerCapture?.(id)) el.releasePointerCapture(id);
		} catch {
			/* el puntero ya no existe */
		}
		setActive(false);
		handlers.onEnd?.(cancelled);
	};

	scope.listen(el, 'pointerdown', (ev: PointerEvent) => {
		if (!enabled || pointerId !== null) return;
		if (ev.pointerType === 'mouse' && ev.button !== 0) return;
		ev.preventDefault();
		ev.stopPropagation();
		pointerId = ev.pointerId;
		try {
			el.setPointerCapture?.(ev.pointerId);
		} catch {
			/* jsdom o navegadores antiguos */
		}
		setActive(true);
		(el as SVGElement & { focus?: (o?: FocusOptions) => void }).focus?.({ preventScroll: true });
		const p = surface.clientToScene(ev.clientX, ev.clientY);
		handlers.onStart?.(p, ev);
		handlers.onMove(p, ev);
	});

	scope.listen(el, 'pointermove', (ev: PointerEvent) => {
		if (ev.pointerId !== pointerId) return;
		ev.preventDefault();
		handlers.onMove(surface.clientToScene(ev.clientX, ev.clientY), ev);
	});

	scope.listen(el, 'pointerup', (ev: PointerEvent) => {
		if (ev.pointerId === pointerId) finish(false);
	});
	scope.listen(el, 'pointercancel', (ev: PointerEvent) => {
		if (ev.pointerId === pointerId) finish(true);
	});
	scope.listen(el, 'lostpointercapture', (ev: PointerEvent) => {
		if (ev.pointerId === pointerId) finish(false);
	});

	// Respaldo para WebViews antiguos: bloquea el scroll táctil solo durante el gesto.
	scope.listen(
		el,
		'touchmove',
		(ev: TouchEvent) => {
			if (pointerId !== null && ev.cancelable) ev.preventDefault();
		},
		{ passive: false },
	);

	// Evita que el editor (Live Preview) tome el foco al pulsar el asa.
	scope.listen(el, 'mousedown', (ev: MouseEvent) => ev.stopPropagation());
	scope.listen(el, 'click', (ev: MouseEvent) => ev.stopPropagation());

	scope.listen(el, 'keydown', (ev: KeyboardEvent) => {
		if (!enabled || !handlers.onKey) return;
		const map: Record<string, [number, number]> = {
			ArrowLeft: [-1, 0],
			ArrowRight: [1, 0],
			ArrowUp: [0, 1],
			ArrowDown: [0, -1],
		};
		const d = map[ev.key];
		if (!d) return;
		ev.preventDefault();
		ev.stopPropagation();
		handlers.onKey(d[0], d[1], { fine: ev.altKey, coarse: ev.shiftKey });
	});

	scope.add(() => {
		finish(true);
		el.classList.remove('pl-draggable', 'pl-is-active');
	});

	return {
		setEnabled(v: boolean) {
			enabled = v;
			if (!v) finish(true);
			el.classList.toggle('pl-drag-disabled', !v);
			el.setAttribute('aria-disabled', String(!v));
			el.setAttribute('tabindex', v ? '0' : '-1');
		},
		get active() {
			return pointerId !== null;
		},
		destroy() {
			scope.dispose();
		},
	};
}
