import { isPlainObject } from '../core/schema';
import type { ParamValues } from '../core/types';

/**
 * Persistencia en archivos legibles del vault (sin base de datos):
 *
 *   PhysicaLab/labs/       definiciones de laboratorio (YAML o JSON), usables con `file:`
 *   PhysicaLab/states/     un JSON por laboratorio (`<id>.json`), solo al pulsar «Guardar»
 *   PhysicaLab/templates/  plantillas propias para la biblioteca
 *
 * Un archivo por laboratorio evita conflictos de sincronización entre
 * dispositivos: dos equipos solo chocan si guardan el MISMO laboratorio.
 */

export interface FileAdapter {
	exists(path: string): Promise<boolean>;
	read(path: string): Promise<string>;
	write(path: string, data: string): Promise<void>;
	mkdir(path: string): Promise<void>;
	/** Archivos (rutas completas) directamente dentro de `dir`. */
	listFiles(dir: string): Promise<string[]>;
	remove(path: string): Promise<void>;
}

export interface LabPaths {
	labs: string;
	states: string;
	templates: string;
}

export const DEFAULT_PATHS: Readonly<LabPaths> = Object.freeze({
	labs: 'PhysicaLab/labs',
	states: 'PhysicaLab/states',
	templates: 'PhysicaLab/templates',
});

export interface StateFile {
	format: 'physlab-state';
	schema: 1;
	id: string;
	preset: string;
	presetVersion: number;
	savedAt: string;
	values: ParamValues;
}

export interface TemplateEntry {
	path: string;
	name: string;
	raw: unknown;
	error?: string;
}

const MAX_FILE = 200_000;

/** Ruta relativa al vault, sin «..», sin barras iniciales ni dobles. */
export function cleanVaultPath(p: string): string | null {
	const s = p
		.trim()
		.replace(/\\/g, '/')
		.replace(/\/+/g, '/')
		.replace(/^\/+|\/+$/g, '');
	if (s === '' || s.split('/').some((seg) => seg === '..' || seg === '.')) return null;
	if (/[<>:"|?*\u0000-\u001f]/.test(s)) return null;
	return s;
}

export class LabFiles {
	constructor(
		private readonly fs: FileAdapter,
		private readonly paths: () => LabPaths,
	) {}

	statePath(id: string): string {
		return `${this.dir('states')}/${id}.json`;
	}

	async loadState(id: string): Promise<StateFile | null> {
		const path = this.statePath(id);
		if (!(await this.fs.exists(path))) return null;
		const text = await this.fs.read(path);
		if (text.length > MAX_FILE) throw new Error(`${path} es demasiado grande`);
		let data: unknown;
		try {
			data = JSON.parse(text);
		} catch {
			throw new Error(`${path} no es un JSON válido (¿conflicto de sincronización?)`);
		}
		if (!isPlainObject(data) || data.format !== 'physlab-state' || !isPlainObject(data.values)) {
			throw new Error(`${path} no es un estado de PhysicaLab`);
		}
		const values: ParamValues = {};
		for (const [k, v] of Object.entries(data.values)) {
			if (typeof v === 'number' || typeof v === 'boolean' || typeof v === 'string') values[k] = v;
		}
		return {
			format: 'physlab-state',
			schema: 1,
			id: String(data.id ?? id),
			preset: String(data.preset ?? ''),
			presetVersion: Number(data.presetVersion ?? 1),
			savedAt: String(data.savedAt ?? ''),
			values,
		};
	}

	async saveState(id: string, preset: string, presetVersion: number, values: ParamValues, now: Date = new Date()): Promise<StateFile> {
		const file: StateFile = {
			format: 'physlab-state',
			schema: 1,
			id,
			preset,
			presetVersion,
			savedAt: now.toISOString(),
			values: sortKeys(values),
		};
		await this.ensureDir(this.dir('states'));
		await this.fs.write(this.statePath(id), JSON.stringify(file, null, 2) + '\n');
		return file;
	}

	async deleteState(id: string): Promise<boolean> {
		const path = this.statePath(id);
		if (!(await this.fs.exists(path))) return false;
		await this.fs.remove(path);
		return true;
	}

	/**
	 * Lee una definición de laboratorio. Admite ruta completa dentro del vault
	 * o un nombre de archivo de la carpeta de laboratorios.
	 */
	async loadLabFile(ref: string, parseYaml: (s: string) => unknown): Promise<unknown> {
		const clean = cleanVaultPath(ref);
		if (!clean) throw new Error(`Ruta no válida: ${ref}`);
		const candidates = clean.includes('/') ? [clean, `${this.dir('labs')}/${clean}`] : [`${this.dir('labs')}/${clean}`];
		for (const p of candidates) {
			if (await this.fs.exists(p)) return this.readData(p, parseYaml);
		}
		throw new Error(`No se encontró el laboratorio «${ref}» (buscado en: ${candidates.join(', ')})`);
	}

	async listTemplates(parseYaml: (s: string) => unknown): Promise<TemplateEntry[]> {
		const dir = this.dir('templates');
		if (!(await this.fs.exists(dir))) return [];
		const files = (await this.fs.listFiles(dir))
			.filter((p) => /\.(ya?ml|json)$/i.test(p) && !/sync-conflict|conflicted copy/i.test(p))
			.sort((a, b) => a.replace(/\.\w+$/, '').localeCompare(b.replace(/\.\w+$/, ''), 'es', { numeric: true }));
		const out: TemplateEntry[] = [];
		for (const path of files) {
			const name = path.split('/').pop()?.replace(/\.(ya?ml|json)$/i, '') ?? path;
			try {
				out.push({ path, name, raw: await this.readData(path, parseYaml) });
			} catch (err) {
				out.push({ path, name, raw: null, error: err instanceof Error ? err.message : String(err) });
			}
		}
		return out;
	}

	/** Guarda una plantilla YAML y devuelve su ruta (sin sobrescribir: añade sufijo). */
	async saveTemplate(name: string, yamlText: string): Promise<string> {
		const dir = this.dir('templates');
		await this.ensureDir(dir);
		const base =
			name
				.normalize('NFD')
				.replace(/[̀-ͯ]/g, '')
				.replace(/[^A-Za-z0-9._ -]+/g, '')
				.trim()
				.replace(/\s+/g, '-')
				.slice(0, 60) || 'plantilla';
		let path = `${dir}/${base}.yaml`;
		for (let i = 2; await this.fs.exists(path); i++) path = `${dir}/${base}-${i}.yaml`;
		await this.fs.write(path, yamlText.endsWith('\n') ? yamlText : yamlText + '\n');
		return path;
	}

	async ensureDir(dir: string): Promise<void> {
		const parts = dir.split('/');
		let cur = '';
		for (const p of parts) {
			cur = cur ? `${cur}/${p}` : p;
			if (!(await this.fs.exists(cur))) await this.fs.mkdir(cur);
		}
	}

	private dir(kind: keyof LabPaths): string {
		const p = cleanVaultPath(this.paths()[kind]) ?? DEFAULT_PATHS[kind];
		return p;
	}

	private async readData(path: string, parseYaml: (s: string) => unknown): Promise<unknown> {
		const text = await this.fs.read(path);
		if (text.length > MAX_FILE) throw new Error(`${path} es demasiado grande`);
		return /\.json$/i.test(path) ? JSON.parse(text) : parseYaml(text);
	}
}

function sortKeys(v: ParamValues): ParamValues {
	const out: ParamValues = {};
	for (const k of Object.keys(v).sort()) out[k] = v[k] as ParamValues[string];
	return out;
}

/** Adaptador en memoria (pruebas y vista previa). */
export class MemoryFileAdapter implements FileAdapter {
	readonly files = new Map<string, string>();
	readonly dirs = new Set<string>();
	async exists(p: string): Promise<boolean> {
		return this.files.has(p) || this.dirs.has(p);
	}
	async read(p: string): Promise<string> {
		const v = this.files.get(p);
		if (v === undefined) throw new Error(`no existe ${p}`);
		return v;
	}
	async write(p: string, d: string): Promise<void> {
		this.files.set(p, d);
	}
	async mkdir(p: string): Promise<void> {
		this.dirs.add(p);
	}
	async listFiles(dir: string): Promise<string[]> {
		return [...this.files.keys()].filter((k) => k.startsWith(dir + '/') && !k.slice(dir.length + 1).includes('/'));
	}
	async remove(p: string): Promise<void> {
		this.files.delete(p);
	}
}
