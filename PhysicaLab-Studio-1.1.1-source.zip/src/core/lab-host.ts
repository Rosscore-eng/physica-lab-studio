import { ControlPanel } from '../controls/panel';
import { iconSvg, type IconName } from '../controls/icons';
import { makeDraggable, type DragHandle } from '../interaction/drag';
import type { MathEngine } from '../render/math/math-renderer';
import { SvgScene, type SceneOptions } from '../render/svg/scene';
import { applyTheme, type ThemeId, type ThemeTokens } from '../theme/tokens';
import { EquationBoard } from './equations';
import { AnimationClock, FrameScheduler, ResourceScope } from './lifecycle';
import type { PresetContext, PresetDefinition, PresetInstance } from './preset';
import { DEFAULT_FEATURES, makeLabId, serializeLab, type LabConfig, type LabFeatures } from './schema';
import { ParamStore } from './store';
import { MODE_LABEL, type ChangeSource } from './types';

/** Servicios que aporta el anfitrión (Obsidian o el banco de pruebas). */
export interface HostServices {
	/** Guarda el estado. Si falta, no se muestra el botón de guardar. */
	save?(lab: LabInstance): Promise<void>;
	/** Copia texto al portapapeles. */
	copy?(text: string): Promise<void>;
	/** Abre la vista ampliada compartiendo el mismo estado. */
	expand?(lab: LabInstance): void;
	notify(message: string, kind?: 'info' | 'error'): void;
}

export interface LabInstanceOptions {
	preset: PresetDefinition;
	config: LabConfig;
	engine: MathEngine;
	services: HostServices;
	theme?: ThemeId;
	tokenOverrides?: Partial<Record<keyof ThemeTokens, string>>;
	/** Almacén compartido (vista ampliada). */
	store?: ParamStore;
	variant?: 'inline' | 'expanded';
	decimals?: number;
	/** Avisos de validación que se muestran discretamente. */
	warnings?: string[];
	/** Fecha del estado guardado cargado, si lo hay. */
	savedAt?: string | null;
	/** Intervalo mínimo entre re-tipografías durante el arrastre (ms). */
	mathThrottleMs?: number;
	/** Panel plegado al abrir (p. ej. en móvil). */
	collapsePanel?: boolean;
}

let uidCounter = 0;

/** Instancias vivas (diagnóstico y pruebas de fugas). */
export const liveInstances = new Set<LabInstance>();

/**
 * Una instancia de laboratorio montada en el DOM. Crea el estado, el
 * panel, las escenas y el preset; `destroy()` lo libera todo.
 */
export class LabInstance {
	readonly root: HTMLElement;
	readonly store: ParamStore;
	readonly preset: PresetDefinition;
	readonly config: LabConfig;
	readonly scope: ResourceScope;
	readonly uid: string;
	private readonly ownsStore: boolean;
	private readonly doc: Document;
	private readonly engine: MathEngine;
	private readonly services: HostServices;
	private readonly features: LabFeatures;
	private readonly scheduler: FrameScheduler;
	private readonly scenes: SvgScene[] = [];
	private readonly clocks: AnimationClock[] = [];
	private readonly figures: HTMLElement;
	private readonly noteEl: HTMLElement;
	private readonly statusEl: HTMLElement;
	private readonly dirtyEl: HTMLElement;
	private panel!: ControlPanel;
	private equations!: EquationBoard;
	private instance: PresetInstance | null = null;
	private finishQueued = false;
	private visible = true;
	private destroyed = false;
	private savedAt: string | null;

	constructor(container: HTMLElement, private readonly opts: LabInstanceOptions) {
		this.preset = opts.preset;
		this.config = opts.config;
		this.engine = opts.engine;
		this.services = opts.services;
		this.doc = container.ownerDocument;
		this.uid = `pl${++uidCounter}`;
		this.savedAt = opts.savedAt ?? opts.store?.savedAt ?? null;
		this.features = { ...DEFAULT_FEATURES, ...(opts.preset.features ?? {}), ...opts.config.explicitFeatures };
		this.scope = new ResourceScope(this.doc.defaultView ?? window);

		this.ownsStore = !opts.store;
		this.store =
			opts.store ??
			new ParamStore(opts.preset.params, opts.config.parameters, { hide: opts.config.hide, lock: opts.config.lock });

		const variant = opts.variant ?? 'inline';
		this.root = this.el('div', `physlab pl-mode-${this.preset.mode} pl-variant-${variant}`, container);
		this.root.dataset.preset = this.preset.id;
		if (this.config.id) this.root.dataset.labId = this.config.id;
		applyTheme(this.root, opts.theme ?? this.config.theme ?? 'scientific-dark', opts.tokenOverrides);
		if (!this.features.latex) this.root.classList.add('pl-no-latex');
		if (opts.collapsePanel ?? this.features.controlsCollapsed) this.root.classList.add('pl-panel-collapsed');

		// Cabecera
		const header = this.el('div', 'pl-header', this.root);
		const badge = this.el('span', 'pl-badge', header);
		badge.textContent = MODE_LABEL[this.preset.mode];
		const title = this.el('span', 'pl-title', header);
		title.textContent = this.config.title ?? this.preset.title;
		this.dirtyEl = this.el('span', 'pl-dirty', header);
		this.dirtyEl.title = 'Hay cambios sin guardar';
		this.statusEl = this.el('span', 'pl-status pl-hidden', header);
		const tools = this.el('div', 'pl-tools', header);

		// Cuerpo
		const body = this.el('div', 'pl-body', this.root);
		const figureCol = this.el('div', 'pl-figure-col', body);
		this.figures = this.el('div', 'pl-figures', figureCol);
		if (this.config.caption) {
			const cap = this.el('div', 'pl-figcaption', figureCol);
			cap.textContent = this.config.caption;
		}
		const side = this.el('div', 'pl-side', body);

		// Orden: figura → panel (al lado en pantallas anchas) → ecuaciones → nota.
		const onMath = (): void => this.queueFinish();
		const throttle = opts.mathThrottleMs ?? 50;
		this.panel = new ControlPanel(side, this.store, this.engine, this.scope, onMath);
		if (!this.features.controls) side.classList.add('pl-hidden');
		this.equations = new EquationBoard(this.root, this.engine, this.scope, onMath, throttle);
		if (!this.features.equations || !this.features.latex) this.equations.el.classList.add('pl-hidden');
		this.noteEl = this.el('div', 'pl-note pl-hidden', this.root);

		this.buildTools(tools, variant);

		if (opts.warnings && opts.warnings.length > 0) {
			const w = this.el('details', 'pl-warnings', this.root);
			const s = this.el('summary', '', w);
			s.textContent = `${opts.warnings.length} aviso(s) de configuración`;
			const ul = this.el('ul', '', w);
			for (const msg of opts.warnings) this.el('li', '', ul).textContent = msg;
		}

		this.scheduler = new FrameScheduler(this.scope, (changed, full) => this.renderNow(changed, full));
		this.scope.add(
			this.store.subscribe((changed, source) => {
				this.scheduler.request(changed);
				this.updateDirty();
				if (source === 'reset' || source === 'load') this.flushMath();
			}),
		);
		// Guardar desde otra vista del mismo almacén (vista ampliada) actualiza también esta.
		this.scope.add(
			this.store.onSaved((at) => {
				if (at) this.savedAt = at;
				this.updateDirty();
			}),
		);
		this.scope.observeVisibility(this.root, (v) => this.setVisible(v));
		// En Live Preview, que el editor no capture los gestos hechos dentro del laboratorio
		// (si no, un clic movería el cursor al bloque y lo mostraría como código).
		this.scope.listen(this.root, 'pointerdown', (ev: PointerEvent) => ev.stopPropagation());
		this.scope.listen(this.root, 'mousedown', (ev: MouseEvent) => ev.stopPropagation());

		liveInstances.add(this);
		this.scope.add(() => liveInstances.delete(this));

		try {
			this.instance = this.preset.create(this.context());
			this.renderNow(new Set(), true);
			this.flushMath();
		} catch (err) {
			console.error('[PhysicaLab] error al crear el laboratorio', err);
			this.showError(err instanceof Error ? err.message : String(err));
		}
		this.updateDirty();
		this.scope.add(() => this.root.remove());
	}

	/* ── API pública ─────────────────────────────────────────── */

	get isDestroyed(): boolean {
		return this.destroyed;
	}

	/** Fuerza el dibujo pendiente (pruebas). */
	flush(): void {
		this.scheduler.flush();
		this.flushMath();
	}

	/**
	 * Configuración actual como YAML de bloque. Por defecto con un `id` nuevo:
	 * un bloque copiado no debe compartir (ni pisar) el archivo de estado del original.
	 */
	toBlockYaml(freshId = true): string {
		const id = freshId ? makeLabId(this.config.title ?? this.preset.title) : this.config.id;
		return serializeLab({ ...this.config, id, parameters: this.store.snapshot().values });
	}

	markSaved(at: string): void {
		this.savedAt = at;
		this.store.markSaved(at);
	}

	/** Detiene las animaciones de esta vista (p. ej. al abrir la vista ampliada). */
	pauseAnimations(): void {
		for (const c of this.clocks) c.pause();
	}

	get lastSaved(): string | null {
		return this.savedAt;
	}

	resetParameters(): void {
		for (const c of this.clocks) c.pause();
		this.store.reset('reset');
	}

	destroy(): void {
		if (this.destroyed) return;
		this.destroyed = true;
		try {
			this.instance?.destroy?.();
		} catch (err) {
			console.error('[PhysicaLab] error al destruir el preset', err);
		}
		this.instance = null;
		this.scope.dispose();
	}

	/* ── Internos ────────────────────────────────────────────── */

	private context(): PresetContext {
		const ctx: PresetContext = {
			store: this.store,
			scope: this.scope,
			features: this.features,
			panel: this.panel,
			equations: this.equations,
			root: this.root,
			doc: this.doc,
			uid: this.uid,
			decimals: this.opts.decimals ?? 2,
			createScene: (o: SceneOptions) => this.createScene(o),
			draggable: (scene, el, handlers, label): DragHandle => {
				if (!this.features.draggable) return noopDrag;
				return makeDraggable(
					scene,
					el,
					{
						...handlers,
						onEnd: (cancelled) => {
							handlers.onEnd?.(cancelled);
							this.flushMath();
						},
					},
					this.scope,
					{ label, root: this.root },
				);
			},
			clock: (onTick) => {
				const c = new AnimationClock(this.scope, onTick, this.doc);
				c.setVisible(this.visible);
				this.clocks.push(c);
				return c;
			},
			requestRender: () => this.scheduler.request(),
			setNote: (text) => {
				this.noteEl.textContent = text;
				this.noteEl.classList.toggle('pl-hidden', !text);
			},
			status: (text) => {
				this.statusEl.textContent = text ?? '';
				this.statusEl.classList.toggle('pl-hidden', !text);
			},
		};
		return ctx;
	}

	private createScene(o: SceneOptions): SvgScene {
		const scene = new SvgScene(
			this.figures,
			o,
			this.scope,
			this.engine,
			`${this.uid}s${this.scenes.length}`,
			() => this.queueFinish(),
			this.opts.mathThrottleMs ?? 50,
		);
		this.scenes.push(scene);
		this.figures.dataset.scenes = String(this.scenes.length);
		scene.onResize(() => this.scheduler.request());
		return scene;
	}

	private renderNow(changed: ReadonlySet<string>, full: boolean): void {
		if (!this.instance || this.destroyed) return;
		try {
			this.instance.render(changed, full);
		} catch (err) {
			console.error('[PhysicaLab] error al dibujar', err);
			this.showError(err instanceof Error ? err.message : String(err));
			this.instance = null;
		}
	}

	private flushMath(): void {
		for (const s of this.scenes) s.labels.flush();
		this.equations?.flush();
		this.queueFinish();
	}

	private queueFinish(): void {
		if (this.finishQueued) return;
		this.finishQueued = true;
		queueMicrotask(() => {
			this.finishQueued = false;
			if (!this.destroyed) this.engine.finish();
		});
	}

	private setVisible(v: boolean): void {
		if (v === this.visible) return;
		this.visible = v;
		for (const c of this.clocks) c.setVisible(v);
		this.instance?.setVisible?.(v);
		if (v) for (const s of this.scenes) s.remeasure();
	}

	private updateDirty(): void {
		const dirty = this.store.isDirty();
		this.dirtyEl.classList.toggle('pl-is-dirty', dirty && this.canSave());
		this.dirtyEl.textContent = dirty && this.canSave() ? '●' : '';
	}

	private canSave(): boolean {
		return this.features.saveState && !!this.config.id && !!this.services.save;
	}

	private buildTools(tools: HTMLElement, variant: 'inline' | 'expanded'): void {
		const btn = (icon: IconName, title: string, onClick: () => void, cls = ''): HTMLButtonElement => {
			const b = this.el('button', `pl-tool ${cls}`, tools) as HTMLButtonElement;
			b.type = 'button';
			b.title = title;
			b.setAttribute('aria-label', title);
			b.appendChild(iconSvg(this.doc, icon));
			this.scope.listen(b, 'click', (ev: MouseEvent) => {
				ev.preventDefault();
				ev.stopPropagation();
				onClick();
			});
			return b;
		};
		btn('reset', 'Restablecer parámetros', () => this.resetParameters(), 'pl-tool-reset');
		if (this.features.saveState && this.services.save) {
			const save = btn(
				'save',
				this.config.id ? 'Guardar estado' : 'Añade «id:» al bloque para poder guardar el estado',
				() => {
					if (!this.config.id) {
						this.services.notify('Este laboratorio no tiene «id:». Añádelo al bloque para guardar su estado.', 'error');
						return;
					}
					void this.services.save?.(this).catch((err: unknown) => {
						this.services.notify(`No se pudo guardar: ${err instanceof Error ? err.message : String(err)}`, 'error');
					});
				},
				'pl-tool-save',
			);
			if (!this.config.id) save.classList.add('pl-tool-muted');
		}
		if (this.services.copy) {
			btn('copy', 'Copiar bloque con los parámetros actuales', () => {
				void this.services.copy?.('```physlab\n' + this.toBlockYaml() + '\n```\n').then(
					() => this.services.notify('Bloque copiado al portapapeles.'),
					() => this.services.notify('No se pudo copiar al portapapeles.', 'error'),
				);
			});
		}
		if (variant === 'inline' && this.services.expand) {
			btn('expand', 'Vista ampliada', () => this.services.expand?.(this), 'pl-tool-expand');
		}
		if (this.features.controls) {
			const toggle = btn(
				'panel',
				'Mostrar u ocultar el panel de parámetros',
				() => {
					const collapsed = this.root.classList.toggle('pl-panel-collapsed');
					toggle.setAttribute('aria-expanded', String(!collapsed));
					for (const s of this.scenes) s.remeasure();
				},
				'pl-tool-panel',
			);
			toggle.setAttribute('aria-expanded', String(!this.root.classList.contains('pl-panel-collapsed')));
		}
	}

	private showError(message: string): void {
		const box = this.el('div', 'pl-error', this.root);
		box.textContent = `Error en el laboratorio «${this.preset.id}»: ${message}`;
	}

	private el(tag: string, cls: string, parent: HTMLElement): HTMLElement {
		const e = this.doc.createElement(tag);
		if (cls) e.className = cls;
		parent.appendChild(e);
		return e;
	}

	/** Diagnóstico: recursos vivos de esta instancia. */
	get resourceCount(): number {
		return this.scope.size;
	}

	/** Diagnóstico: suscriptores del almacén (para detectar fugas en almacenes compartidos). */
	get ownsItsStore(): boolean {
		return this.ownsStore;
	}
}

const noopDrag: DragHandle = {
	setEnabled() {},
	get active() {
		return false;
	},
	destroy() {},
};

export type { ChangeSource };
