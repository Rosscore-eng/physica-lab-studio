import { isThemeId, type ThemeId } from '../theme/tokens';
import type { ParamSpec, ParamValue } from './types';

/**
 * Esquema de los bloques `physlab` (versión 1).
 *
 * ```physlab
 * physlab: 1                     # versión del esquema (opcional)
 * id: calculo-secantes-01        # necesario para guardar estado
 * preset: math.secant-tangent
 * title: Secante y tangente      # opcional
 * theme: scientific-dark         # scientific-dark | scientific-light | obsidian
 * parameters:
 *   x0: 1
 *   h: 0.75
 * features:
 *   draggable: true
 *   controls: true
 *   equations: true
 *   saveState: true
 * hide: [showGrid]               # parámetros sin control en el panel
 * lock: [x0]                     # parámetros bloqueados
 * ```
 *
 * Es solo datos: ninguna clave se evalúa como código.
 */

export const SCHEMA_VERSION = 1;

export interface LabFeatures {
	/** Manipulación directa de la figura. */
	draggable: boolean;
	/** Panel de parámetros. */
	controls: boolean;
	/** Panel plegado al abrir. */
	controlsCollapsed: boolean;
	/** Ecuaciones y lecturas bajo la figura. */
	equations: boolean;
	/** Tipografía LaTeX (etiquetas y ecuaciones). `false` = versión ligera sin ellas. */
	latex: boolean;
	/** Botón de guardar estado (requiere `id`). */
	saveState: boolean;
	/** Controles de animación cuando el preset los ofrece. */
	animation: boolean;
}

export const DEFAULT_FEATURES: Readonly<LabFeatures> = Object.freeze({
	draggable: true,
	controls: true,
	controlsCollapsed: false,
	equations: true,
	latex: true,
	saveState: true,
	animation: true,
});

const FEATURE_KEYS = Object.keys(DEFAULT_FEATURES) as (keyof LabFeatures)[];

export interface LabConfig {
	schema: number;
	id: string | null;
	preset: string;
	title: string | null;
	caption: string | null;
	theme: ThemeId | null;
	parameters: Record<string, ParamValue>;
	/** Interruptores resueltos (valores por defecto + bloque). */
	features: LabFeatures;
	/** Solo los interruptores escritos explícitamente en el bloque. */
	explicitFeatures: Partial<LabFeatures>;
	hide: string[];
	lock: string[];
	/** Definición externa en la carpeta de laboratorios (se fusiona; el bloque manda). */
	file: string | null;
}

export interface ParseResult {
	config: LabConfig | null;
	errors: string[];
	warnings: string[];
}

const KNOWN_KEYS = new Set([
	'physlab',
	'schema',
	'version',
	'id',
	'preset',
	'title',
	'caption',
	'theme',
	'parameters',
	'params',
	'features',
	'hide',
	'lock',
	'file',
]);

export const ID_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$/;
/** Nombre de parámetro (claves de `parameters` y elementos de `hide`/`lock`). */
export const PARAM_NAME = /^[A-Za-z_][A-Za-z0-9_]{0,40}$/;
export const PRESET_PATTERN = /^[a-z][a-z0-9-]*\.[a-z0-9][a-z0-9.-]*$/;

/** Analiza el texto de un bloque. `parseYaml` lo aporta el anfitrión (Obsidian o pruebas). */
export function parseLabSource(source: string, parseYaml: (s: string) => unknown): ParseResult {
	const trimmed = source.trim();
	if (trimmed === '') {
		return { config: null, errors: ['El bloque está vacío. Indica al menos `preset:`.'], warnings: [] };
	}
	if (trimmed.length > 20000) {
		return { config: null, errors: ['El bloque es demasiado grande (más de 20 000 caracteres).'], warnings: [] };
	}
	let data: unknown;
	try {
		data = trimmed.startsWith('{') ? JSON.parse(trimmed) : parseYaml(trimmed);
	} catch (err) {
		const msg = err instanceof Error ? err.message.split('\n')[0] : String(err);
		return { config: null, errors: [`No se pudo leer el bloque (YAML/JSON): ${msg}`], warnings: [] };
	}
	return normalizeLabObject(data);
}

/** Valida y normaliza un objeto ya analizado (bloque, archivo de laboratorio o salida de IA). */
export function normalizeLabObject(data: unknown): ParseResult {
	const errors: string[] = [];
	const warnings: string[] = [];
	if (typeof data === 'string' && PRESET_PATTERN.test(data.trim())) {
		data = { preset: data.trim() };
	}
	if (!isPlainObject(data)) {
		return { config: null, errors: ['El bloque debe ser un mapa de claves (YAML) con al menos `preset:`.'], warnings };
	}
	for (const k of Object.keys(data)) {
		if (!KNOWN_KEYS.has(k)) warnings.push(`Clave desconocida ignorada: «${k}».`);
	}

	const versionRaw = data.physlab ?? data.schema ?? data.version;
	let schema = SCHEMA_VERSION;
	if (versionRaw !== undefined) {
		const v = Number(versionRaw);
		if (!Number.isInteger(v) || v < 1) errors.push('La versión del esquema debe ser un entero ≥ 1.');
		else if (v > SCHEMA_VERSION) errors.push(`Este bloque usa el esquema v${v}; el plugin admite hasta v${SCHEMA_VERSION}. Actualiza PhysicaLab Studio.`);
		else schema = v;
	}

	let preset = '';
	if (typeof data.preset !== 'string' || data.preset.trim() === '') {
		if (typeof data.file !== 'string') errors.push('Falta `preset:` (por ejemplo `preset: physics.pendulum`).');
	} else if (!PRESET_PATTERN.test(data.preset.trim())) {
		errors.push(`El preset «${data.preset}» no tiene un formato válido (modo.nombre).`);
	} else {
		preset = data.preset.trim();
	}

	let id: string | null = null;
	if (data.id !== undefined && data.id !== null) {
		const s = String(data.id).trim();
		if (ID_PATTERN.test(s)) id = s;
		else errors.push('`id` solo admite letras, números, «.», «_» y «-» (máx. 64) y debe empezar por letra o número.');
	}

	const str = (k: string, max: number): string | null => {
		const v = data[k];
		if (v === undefined || v === null) return null;
		if (typeof v !== 'string' && typeof v !== 'number') {
			warnings.push(`\`${k}\` debe ser texto; se ignora.`);
			return null;
		}
		const s = String(v).trim();
		if (s.length > max) {
			warnings.push(`\`${k}\` es demasiado largo; se recorta a ${max} caracteres.`);
			return s.slice(0, max);
		}
		return s || null;
	};
	const title = str('title', 120);
	const caption = str('caption', 400);

	let theme: ThemeId | null = null;
	if (data.theme !== undefined && data.theme !== null) {
		if (isThemeId(data.theme)) theme = data.theme;
		else warnings.push(`Tema desconocido «${String(data.theme)}»; se usa el predeterminado.`);
	}

	const parameters: Record<string, ParamValue> = {};
	const rawParams = data.parameters ?? data.params;
	if (rawParams !== undefined && rawParams !== null) {
		if (!isPlainObject(rawParams)) {
			warnings.push('`parameters` debe ser un mapa `nombre: valor`; se ignora.');
		} else {
			for (const [k, v] of Object.entries(rawParams)) {
				if (!PARAM_NAME.test(k)) {
					warnings.push(`Nombre de parámetro no válido: «${k}».`);
					continue;
				}
				if (typeof v === 'number' || typeof v === 'boolean' || typeof v === 'string') parameters[k] = v;
				else warnings.push(`El parámetro «${k}» debe ser número, booleano o texto.`);
			}
		}
	}

	const features: LabFeatures = { ...DEFAULT_FEATURES };
	const explicitFeatures: Partial<LabFeatures> = {};
	if (data.features !== undefined && data.features !== null) {
		if (!isPlainObject(data.features)) {
			warnings.push('`features` debe ser un mapa de interruptores; se ignora.');
		} else {
			for (const [k, v] of Object.entries(data.features)) {
				if (!(FEATURE_KEYS as string[]).includes(k)) {
					warnings.push(`Opción desconocida en features: «${k}».`);
					continue;
				}
				if (typeof v !== 'boolean') {
					warnings.push(`features.${k} debe ser true o false.`);
					continue;
				}
				features[k as keyof LabFeatures] = v;
				explicitFeatures[k as keyof LabFeatures] = v;
			}
		}
	}

	const list = (k: 'hide' | 'lock'): string[] => {
		const v = data[k];
		if (v === undefined || v === null) return [];
		const arr = Array.isArray(v) ? v : typeof v === 'string' ? v.split(',') : null;
		if (!arr) {
			warnings.push(`\`${k}\` debe ser una lista de parámetros.`);
			return [];
		}
		const out: string[] = [];
		for (const x of arr) {
			const name = typeof x === 'string' || typeof x === 'number' ? String(x).trim() : '';
			if (name === '') continue;
			// Solo nombres de parámetro: nada que pueda romper el YAML o la valla del bloque al reescribirlo.
			if (PARAM_NAME.test(name)) out.push(name);
			else warnings.push(`\`${k}\` contiene un nombre de parámetro no válido; se ignora.`);
		}
		return out;
	};

	let file: string | null = null;
	if (data.file !== undefined && data.file !== null) {
		const f = String(data.file).trim();
		if (!/^[^<>:"|?*]+\.(ya?ml|json)$/i.test(f) || f.includes('..')) {
			errors.push('`file` debe ser una ruta relativa a un .yaml/.yml/.json, sin «..».');
		} else file = f;
	}

	if (errors.length > 0) return { config: null, errors, warnings };
	return {
		config: {
			schema,
			id,
			preset,
			title,
			caption,
			theme,
			parameters,
			features,
			explicitFeatures,
			hide: list('hide'),
			lock: list('lock'),
			file,
		},
		errors,
		warnings,
	};
}

/**
 * Fusiona (antes de validar) una definición externa con la del bloque: el
 * bloque manda clave a clave; `parameters` y `features` se fusionan por
 * dentro. Se descarta `file` para no encadenar archivos.
 */
export function mergeRawLabObjects(base: unknown, block: unknown): Record<string, unknown> {
	const b = isPlainObject(base) ? base : {};
	const o = isPlainObject(block) ? block : {};
	const out: Record<string, unknown> = { ...b, ...o };
	for (const k of ['parameters', 'params', 'features']) {
		if (isPlainObject(b[k]) || isPlainObject(o[k])) {
			out[k] = { ...(isPlainObject(b[k]) ? b[k] : {}), ...(isPlainObject(o[k]) ? o[k] : {}) };
		}
	}
	if (isPlainObject(b.params) && !isPlainObject(o.params) && isPlainObject(o.parameters)) {
		out.parameters = { ...b.params, ...o.parameters };
		delete out.params;
	}
	delete out.file;
	return out;
}

/** Avisos al contrastar la configuración con las especificaciones del preset. */
export function checkParameters(config: LabConfig, specs: readonly ParamSpec[]): string[] {
	const warnings: string[] = [];
	const byId = new Map(specs.map((s) => [s.id, s]));
	for (const [k, v] of Object.entries(config.parameters)) {
		const s = byId.get(k);
		if (!s) {
			warnings.push(`El preset no tiene el parámetro «${k}»; se ignora.`);
			continue;
		}
		if (s.type === 'number') {
			const n = typeof v === 'string' ? Number(v.replace(',', '.')) : v;
			if (typeof n !== 'number' || !Number.isFinite(n)) warnings.push(`«${k}» debe ser numérico.`);
			else if (n < s.min || n > s.max) warnings.push(`«${k}» = ${n} está fuera de [${s.min}, ${s.max}]; se ajusta al límite.`);
		} else if (s.type === 'boolean') {
			if (typeof v !== 'boolean') warnings.push(`«${k}» debe ser true o false.`);
		} else if (!s.options.some((o) => o.value === String(v))) {
			warnings.push(`«${k}» admite: ${s.options.map((o) => o.value).join(', ')}.`);
		}
	}
	for (const k of [...config.hide, ...config.lock]) {
		if (!byId.has(k)) warnings.push(`hide/lock menciona un parámetro inexistente: «${k}».`);
	}
	return warnings;
}

/** Serializa una configuración como YAML determinista (solo claves útiles). */
export function serializeLab(config: Partial<LabConfig> & { preset: string }): string {
	if (!PRESET_PATTERN.test(config.preset)) throw new Error(`Preset no válido: ${JSON.stringify(config.preset)}`);
	const lines: string[] = [];
	if (config.id) lines.push(`id: ${yamlScalar(config.id)}`);
	lines.push(`preset: ${config.preset}`);
	if (config.title) lines.push(`title: ${yamlScalar(config.title)}`);
	if (config.caption) lines.push(`caption: ${yamlScalar(config.caption)}`);
	if (config.theme) lines.push(`theme: ${config.theme}`);
	const params = Object.entries(config.parameters ?? {});
	if (params.length) {
		lines.push('parameters:');
		for (const [k, v] of params) if (PARAM_NAME.test(k)) lines.push(`  ${k}: ${yamlScalar(v)}`);
	}
	const explicit = config.explicitFeatures ?? {};
	const keys = FEATURE_KEYS.filter((k) => explicit[k] !== undefined);
	if (keys.length) {
		lines.push('features:');
		for (const k of keys) lines.push(`  ${k}: ${String(explicit[k])}`);
	}
	const names = (xs: readonly string[] | undefined): string[] => (xs ?? []).filter((x) => PARAM_NAME.test(x));
	if (names(config.hide).length) lines.push(`hide: [${names(config.hide).join(', ')}]`);
	if (names(config.lock).length) lines.push(`lock: [${names(config.lock).join(', ')}]`);
	const text = lines.join('\n');
	// Defensa final: ninguna línea puede abrir o cerrar una valla de código.
	if (/^\s{0,3}(`{3,}|~{3,})/m.test(text)) throw new Error('El bloque generado contiene una valla de código; se rechaza.');
	return text;
}

/** Bloque Markdown completo listo para insertar. */
export function toCodeBlock(config: Partial<LabConfig> & { preset: string }): string {
	return '```physlab\n' + serializeLab(config) + '\n```\n';
}

function yamlScalar(v: ParamValue): string {
	if (typeof v === 'number') return Number.isFinite(v) ? String(v) : '0';
	if (typeof v === 'boolean') return String(v);
	return /^[A-Za-z0-9][A-Za-z0-9 ._-]*$/.test(v) && !/^(true|false|null|yes|no|on|off|~)$/i.test(v) && !/^[\d.+-]/.test(v)
		? v
		: JSON.stringify(v);
}

/** Identificador legible y único: `pendulo-k3f9`. */
export function makeLabId(base: string, random: () => number = Math.random): string {
	const slug =
		base
			.normalize('NFD')
			.replace(/[̀-ͯ]/g, '')
			.toLowerCase()
			.replace(/[^a-z0-9]+/g, '-')
			.replace(/^-+|-+$/g, '')
			.slice(0, 40) || 'lab';
	const suffix = Math.floor(random() * 36 ** 4)
		.toString(36)
		.padStart(4, '0');
	return `${slug}-${suffix}`;
}

export function isPlainObject(v: unknown): v is Record<string, unknown> {
	return typeof v === 'object' && v !== null && !Array.isArray(v);
}
