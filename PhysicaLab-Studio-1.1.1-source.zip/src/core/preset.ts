import type { AnimationClock, ResourceScope } from './lifecycle';
import type { EquationBoard } from './equations';
import type { LabFeatures } from './schema';
import type { ParamStore } from './store';
import type { LabMode, ParamSpec } from './types';
import type { PanelApi } from '../controls/panel';
import type { DragHandle, DragHandlers } from '../interaction/drag';
import type { SceneOptions, SvgScene } from '../render/svg/scene';

/**
 * Contrato de un preset (tipo de laboratorio). Para añadir uno nuevo basta
 * con crear un módulo que exporte un `PresetDefinition` y registrarlo en
 * src/presets/index.ts (o desde otro plugin con `api.registerPreset`).
 * El núcleo no cambia.
 */
export interface PresetDefinition {
	/** `modo.nombre`, p. ej. `physics.pendulum`. */
	id: string;
	/** Versión del preset (compatibilidad de estados guardados). */
	version: number;
	mode: LabMode;
	title: string;
	/** Resumen de una línea. */
	summary: string;
	/** Palabras clave (búsqueda y generador sin IA). */
	keywords: string[];
	/** Especificación de parámetros: única fuente para panel, validación y estado. */
	params: ParamSpec[];
	/** Valores por defecto de `features` propios del preset. */
	features?: Partial<LabFeatures>;
	/** Qué es exacto y qué es aproximación educativa (se muestra bajo la figura). */
	fidelity: string;
	/** Ejemplos de bloques (biblioteca de plantillas). */
	examples?: Array<{ title: string; parameters: Record<string, number | boolean | string> }>;
	create(ctx: PresetContext): PresetInstance;
}

export interface PresetInstance {
	/**
	 * Redibuja a partir del estado del almacén. `full` = redibujar todo
	 * (primera vez, cambio de tamaño, tema). Debe ser determinista.
	 */
	render(changed: ReadonlySet<string>, full: boolean): void;
	/** El laboratorio entra o sale de la vista. */
	setVisible?(visible: boolean): void;
	destroy?(): void;
}

export interface PresetContext {
	readonly store: ParamStore;
	readonly scope: ResourceScope;
	readonly features: Readonly<LabFeatures>;
	readonly panel: PanelApi;
	readonly equations: EquationBoard;
	readonly root: HTMLElement;
	readonly doc: Document;
	/** Prefijo único para ids del documento. */
	readonly uid: string;
	/** Decimales preferidos para lecturas. */
	readonly decimals: number;
	/** Crea una escena SVG (varias escenas se reparten el ancho). */
	createScene(opts: SceneOptions): SvgScene;
	/** Hace manipulable un elemento (no hace nada si `draggable` está desactivado). */
	draggable(scene: SvgScene, el: SVGElement, handlers: DragHandlers, label: string): DragHandle;
	/** Reloj de animación pausable (nunca arranca solo). */
	clock(onTick: (dt: number, t: number) => boolean | void): AnimationClock;
	/** Pide redibujar todo en el próximo frame. */
	requestRender(): void;
	/** Nota de fidelidad o aviso bajo la figura (texto plano). */
	setNote(text: string): void;
	/** Mensaje de estado efímero (p. ej. «Caso límite h = 0»). */
	status(text: string | null): void;
}
