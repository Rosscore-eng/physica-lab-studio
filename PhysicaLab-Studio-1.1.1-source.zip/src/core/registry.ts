import type { PresetDefinition } from './preset';
import { PRESET_PATTERN } from './schema';
import type { LabMode } from './types';

/** Biblioteca de presets disponibles. */
export class PresetRegistry {
	private readonly presets = new Map<string, PresetDefinition>();

	register(def: PresetDefinition): void {
		if (!PRESET_PATTERN.test(def.id)) throw new Error(`Id de preset no válido: ${def.id}`);
		if (!def.id.startsWith(`${def.mode}.`)) throw new Error(`El id ${def.id} debe empezar por «${def.mode}.»`);
		if (this.presets.has(def.id)) throw new Error(`Preset duplicado: ${def.id}`);
		const ids = new Set<string>();
		for (const p of def.params) {
			if (ids.has(p.id)) throw new Error(`Parámetro duplicado ${p.id} en ${def.id}`);
			ids.add(p.id);
		}
		this.presets.set(def.id, def);
	}

	unregister(id: string): void {
		this.presets.delete(id);
	}

	get(id: string): PresetDefinition | undefined {
		return this.presets.get(id);
	}

	list(mode?: LabMode): PresetDefinition[] {
		const all = [...this.presets.values()];
		return mode ? all.filter((p) => p.mode === mode) : all;
	}

	ids(): string[] {
		return [...this.presets.keys()];
	}
}
