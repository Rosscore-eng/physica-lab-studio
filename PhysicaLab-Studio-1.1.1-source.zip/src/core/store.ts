import { clamp, isFiniteNumber, roundSig, snapToStep } from './numeric';
import type {
	ChangeSource,
	NumberParamSpec,
	ParamSpec,
	ParamValue,
	ParamValues,
	Presentation,
} from './types';

export type StoreListener = (changed: ReadonlySet<string>, source: ChangeSource) => void;

export interface StoreSnapshot {
	values: ParamValues;
}

/**
 * Almacén central de parámetros de un laboratorio.
 *
 * Es la única fuente de verdad: el panel y el arrastre escriben aquí y
 * ambos se redibujan a partir de aquí. Cada escritura se valida (tipo,
 * límites, paso, rango dinámico y regla propia del preset).
 */
export class ParamStore {
	private readonly specs = new Map<string, ParamSpec>();
	private readonly order: string[] = [];
	private values: ParamValues = {};
	private baseline: ParamValues = {};
	private readonly listeners = new Set<StoreListener>();
	private readonly presentation = new Map<string, Presentation>();
	private emitting = false;
	private readonly queue: Array<{ changed: Set<string>; source: ChangeSource }> = [];
	private savedSignature = '';
	private savedAtValue: string | null = null;
	private readonly savedListeners = new Set<(savedAt: string | null) => void>();

	constructor(
		specs: readonly ParamSpec[],
		overrides: Readonly<Partial<ParamValues>> = {},
		presentation: { hide?: readonly string[]; lock?: readonly string[] } = {},
	) {
		for (const s of specs) {
			if (this.specs.has(s.id)) throw new Error(`Parámetro duplicado: ${s.id}`);
			if (s.type === 'number' && s.scale === 'log' && !(s.min > 0)) {
				throw new Error(`El parámetro ${s.id} usa escala logarítmica y requiere min > 0`);
			}
			this.specs.set(s.id, s);
			this.order.push(s.id);
			this.values[s.id] = s.initial;
		}
		for (const id of this.order) {
			this.presentation.set(id, {
				visible: !(presentation.hide ?? []).includes(id),
				locked: (presentation.lock ?? []).includes(id),
			});
		}
		// Aplica overrides con validación, sin notificar.
		for (const [id, raw] of Object.entries(overrides)) {
			const spec = this.specs.get(id);
			if (!spec || raw === undefined) continue;
			const v = this.coerce(spec, raw, this.values);
			if (v !== undefined) this.values[id] = v;
		}
		this.revalidateDependents(new Set());
		this.baseline = { ...this.values };
		this.savedSignature = this.signature();
	}

	/* ── Lectura ─────────────────────────────────────────────── */

	spec(id: string): ParamSpec | undefined {
		return this.specs.get(id);
	}

	specList(): ParamSpec[] {
		return this.order.map((id) => this.specs.get(id) as ParamSpec);
	}

	has(id: string): boolean {
		return this.specs.has(id);
	}

	get(id: string): ParamValue {
		const v = this.values[id];
		if (v === undefined) throw new Error(`Parámetro desconocido: ${id}`);
		return v;
	}

	num(id: string): number {
		const v = this.get(id);
		if (typeof v !== 'number') throw new Error(`El parámetro ${id} no es numérico`);
		return v;
	}

	bool(id: string): boolean {
		const v = this.get(id);
		if (typeof v !== 'boolean') throw new Error(`El parámetro ${id} no es booleano`);
		return v;
	}

	str(id: string): string {
		const v = this.get(id);
		if (typeof v !== 'string') throw new Error(`El parámetro ${id} no es de selección`);
		return v;
	}

	all(): Readonly<ParamValues> {
		return Object.freeze({ ...this.values });
	}

	/** Rango efectivo (estático o dinámico) de un parámetro numérico. */
	range(id: string): { min: number; max: number } {
		const spec = this.specs.get(id);
		if (!spec || spec.type !== 'number') throw new Error(`El parámetro ${id} no es numérico`);
		return this.effectiveRange(spec, this.values);
	}

	getPresentation(id: string): Presentation {
		return this.presentation.get(id) ?? { visible: true, locked: false };
	}

	/* ── Escritura ───────────────────────────────────────────── */

	/** Escribe un valor. Devuelve `true` si el estado cambió. */
	set(id: string, value: ParamValue, source: ChangeSource = 'api'): boolean {
		return this.update({ [id]: value }, source).size > 0;
	}

	/** Escribe varios valores de una vez y notifica una sola vez. */
	update(patch: Readonly<Partial<ParamValues>>, source: ChangeSource = 'api'): ReadonlySet<string> {
		const changed = new Set<string>();
		const next: ParamValues = { ...this.values };
		for (const [id, raw] of Object.entries(patch)) {
			const spec = this.specs.get(id);
			if (!spec || raw === undefined) continue;
			if (this.getPresentation(id).locked && (source === 'panel' || source === 'drag' || source === 'keyboard')) {
				continue;
			}
			const v = this.coerce(spec, raw, next);
			if (v === undefined) continue;
			if (next[id] !== v) {
				next[id] = v;
				changed.add(id);
			}
		}
		if (changed.size === 0) return changed;
		this.values = next;
		this.revalidateDependents(changed);
		this.emit(changed, source);
		return changed;
	}

	/** Vuelve a los valores iniciales del bloque (no a los guardados). */
	reset(source: ChangeSource = 'reset'): ReadonlySet<string> {
		return this.update(this.baseline, source);
	}

	/** Valores de partida (bloque + preset) usados por `reset`. */
	initialValues(): Readonly<ParamValues> {
		return Object.freeze({ ...this.baseline });
	}

	/* ── Persistencia ────────────────────────────────────────── */

	snapshot(): StoreSnapshot {
		const values: ParamValues = {};
		for (const id of this.order) {
			const spec = this.specs.get(id) as ParamSpec;
			if (spec.persist === false) continue;
			values[id] = this.values[id] as ParamValue;
		}
		return { values };
	}

	/** Carga valores guardados (validados). Devuelve los ids ignorados. */
	load(values: Readonly<Record<string, unknown>>, source: ChangeSource = 'load'): string[] {
		const ignored: string[] = [];
		const patch: Partial<ParamValues> = {};
		for (const [id, raw] of Object.entries(values)) {
			const spec = this.specs.get(id);
			if (!spec) {
				ignored.push(id);
				continue;
			}
			if (typeof raw !== 'number' && typeof raw !== 'boolean' && typeof raw !== 'string') {
				ignored.push(id);
				continue;
			}
			patch[id] = raw;
		}
		this.update(patch, source);
		return ignored;
	}

	/**
	 * Marca el estado actual como guardado y avisa a todas las vistas que
	 * comparten el almacén (bloque y vista ampliada).
	 */
	markSaved(at: string | null = null): void {
		this.savedSignature = this.signature();
		if (at !== null) this.savedAtValue = at;
		for (const l of [...this.savedListeners]) {
			try {
				l(this.savedAtValue);
			} catch (err) {
				console.error('[PhysicaLab] error en un suscriptor de guardado', err);
			}
		}
	}

	isDirty(): boolean {
		return this.signature() !== this.savedSignature;
	}

	/** Fecha ISO del último guardado conocido (o `null`). */
	get savedAt(): string | null {
		return this.savedAtValue;
	}

	/* ── Suscripción ─────────────────────────────────────────── */

	subscribe(listener: StoreListener): () => void {
		this.listeners.add(listener);
		return () => this.listeners.delete(listener);
	}

	/** Aviso de guardado (para actualizar el indicador «sin guardar» de cada vista). */
	onSaved(listener: (savedAt: string | null) => void): () => void {
		this.savedListeners.add(listener);
		return () => this.savedListeners.delete(listener);
	}

	get listenerCount(): number {
		return this.listeners.size + this.savedListeners.size;
	}

	/* ── Internos ────────────────────────────────────────────── */

	private signature(): string {
		return JSON.stringify(this.snapshot().values);
	}

	private effectiveRange(spec: NumberParamSpec, values: Readonly<ParamValues>): { min: number; max: number } {
		if (!spec.range) return { min: spec.min, max: spec.max };
		const r = spec.range(values);
		const min = isFiniteNumber(r.min) ? Math.max(spec.min, r.min) : spec.min;
		const max = isFiniteNumber(r.max) ? Math.min(spec.max, r.max) : spec.max;
		return max >= min ? { min, max } : { min: spec.min, max: spec.max };
	}

	/** Convierte y valida un valor crudo. `undefined` = rechazado. */
	private coerce(spec: ParamSpec, raw: unknown, values: Readonly<ParamValues>): ParamValue | undefined {
		switch (spec.type) {
			case 'number': {
				let n: number;
				if (typeof raw === 'number') n = raw;
				else if (typeof raw === 'string' && raw.trim() !== '') n = Number(raw.replace(',', '.'));
				else return undefined;
				if (!Number.isFinite(n)) return undefined;
				const { min, max } = this.effectiveRange(spec, values);
				n = clamp(n, min, max);
				n = spec.scale === 'log' ? roundSig(n, 3) : snapToStep(n, spec.step, spec.min);
				n = clamp(n, min, max);
				if (spec.validate) {
					const v = spec.validate(n, values);
					if (!Number.isFinite(v)) return undefined;
					n = clamp(v, min, max);
				}
				return Object.is(n, -0) ? 0 : n;
			}
			case 'boolean': {
				if (typeof raw === 'boolean') return raw;
				if (raw === 'true' || raw === 1) return true;
				if (raw === 'false' || raw === 0) return false;
				return undefined;
			}
			case 'enum': {
				const s = typeof raw === 'string' ? raw : String(raw);
				return spec.options.some((o) => o.value === s) ? s : undefined;
			}
		}
	}

	/** Reajusta parámetros con rango dinámico tras un cambio. */
	private revalidateDependents(changed: Set<string>): void {
		for (let pass = 0; pass < 3; pass++) {
			let any = false;
			for (const id of this.order) {
				const spec = this.specs.get(id) as ParamSpec;
				if (spec.type !== 'number' || !spec.range) continue;
				const cur = this.values[id] as number;
				const { min, max } = this.effectiveRange(spec, this.values);
				const v = clamp(cur, min, max);
				if (v !== cur) {
					this.values[id] = v;
					changed.add(id);
					any = true;
				}
			}
			if (!any) break;
		}
	}

	private emit(changed: Set<string>, source: ChangeSource): void {
		if (this.emitting) {
			this.queue.push({ changed, source });
			return;
		}
		this.emitting = true;
		try {
			let item: { changed: Set<string>; source: ChangeSource } | undefined = { changed, source };
			while (item) {
				for (const l of [...this.listeners]) {
					try {
						l(item.changed, item.source);
					} catch (err) {
						console.error('[PhysicaLab] error en un suscriptor del estado', err);
					}
				}
				item = this.queue.shift();
			}
		} finally {
			this.emitting = false;
		}
	}
}
