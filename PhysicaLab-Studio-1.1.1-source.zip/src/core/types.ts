/**
 * Tipos compartidos del núcleo de PhysicaLab Studio.
 *
 * El núcleo (src/core, src/render, src/interaction, src/controls, src/theme)
 * no importa `obsidian`: así puede probarse en jsdom y en el banco visual.
 */

export type LabMode = 'math' | 'physics' | 'circuits';

export const LAB_MODES: readonly LabMode[] = ['math', 'physics', 'circuits'];

export const MODE_LABEL: Record<LabMode, string> = {
	math: 'MathLab',
	physics: 'PhysicsLab',
	circuits: 'CircuitLab',
};

export type ParamValue = number | boolean | string;
export type ParamValues = Record<string, ParamValue>;

/** Origen de un cambio de estado. Permite evitar bucles y decidir qué refrescar. */
export type ChangeSource =
	| 'init'
	| 'panel'
	| 'drag'
	| 'keyboard'
	| 'reset'
	| 'load'
	| 'animation'
	| 'api';

interface ParamSpecBase {
	/** Identificador estable; es la clave en `parameters:` del bloque. */
	id: string;
	/** Nombre en texto plano (accesibilidad, tooltips, mensajes). */
	name: string;
	/** Etiqueta LaTeX opcional, p. ej. `\theta_0`. */
	label?: string;
	description?: string;
	/** Agrupación visual en el panel. */
	group?: string;
	/** `none`: sin control en el panel (solo arrastre o código). */
	control?: 'auto' | 'none';
	/** Si es `false`, el valor no se guarda en el archivo de estado. */
	persist?: boolean;
}

export interface NumberParamSpec extends ParamSpecBase {
	type: 'number';
	initial: number;
	min: number;
	max: number;
	step: number;
	/** Unidad en LaTeX, p. ej. `\mathrm{m}`. */
	unit?: string;
	/** Unidad en texto plano, p. ej. `m`. */
	unitText?: string;
	/** Escala del deslizador. `log` exige min > 0. */
	scale?: 'linear' | 'log';
	/** Decimales al mostrar; por defecto se deducen de `step`. */
	precision?: number;
	/**
	 * Rango dependiente de otros parámetros. Lo define el preset (código
	 * revisado), nunca el Markdown. Debe quedar dentro de [min, max].
	 */
	range?: (values: Readonly<ParamValues>) => { min: number; max: number };
	/** Regla de validación adicional: devuelve el valor corregido. */
	validate?: (value: number, values: Readonly<ParamValues>) => number;
}

export interface BooleanParamSpec extends ParamSpecBase {
	type: 'boolean';
	initial: boolean;
}

export interface EnumOption {
	value: string;
	label: string;
}

export interface EnumParamSpec extends ParamSpecBase {
	type: 'enum';
	initial: string;
	options: EnumOption[];
}

export type ParamSpec = NumberParamSpec | BooleanParamSpec | EnumParamSpec;

/** Estado de presentación de un parámetro (configurable desde el bloque). */
export interface Presentation {
	visible: boolean;
	locked: boolean;
}

export interface Point {
	x: number;
	y: number;
}

export interface Size {
	width: number;
	height: number;
}

export interface Rect extends Point, Size {}

export interface WorldBounds {
	xMin: number;
	xMax: number;
	yMin: number;
	yMax: number;
}
