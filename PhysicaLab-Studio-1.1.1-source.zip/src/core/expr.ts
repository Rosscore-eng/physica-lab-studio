/**
 * Evaluador de expresiones matemáticas para laboratorios declarativos.
 *
 * No usa `eval` ni `new Function`: tokeniza, construye un árbol y devuelve
 * una función `(vars) => number`. Solo admite lo que está en la tabla de
 * funciones; cualquier otro identificador es un error.
 */

export type Vars = Record<string, number>;

type Node = (v: Vars) => number;

const FUNCTIONS: Record<string, { arity: number | 'variadic'; fn: (...a: number[]) => number }> = {
	sin: { arity: 1, fn: Math.sin },
	cos: { arity: 1, fn: Math.cos },
	tan: { arity: 1, fn: Math.tan },
	asin: { arity: 1, fn: Math.asin },
	acos: { arity: 1, fn: Math.acos },
	atan: { arity: 1, fn: Math.atan },
	sinh: { arity: 1, fn: Math.sinh },
	cosh: { arity: 1, fn: Math.cosh },
	tanh: { arity: 1, fn: Math.tanh },
	sqrt: { arity: 1, fn: Math.sqrt },
	abs: { arity: 1, fn: Math.abs },
	exp: { arity: 1, fn: Math.exp },
	ln: { arity: 1, fn: Math.log },
	log: { arity: 1, fn: Math.log10 },
	floor: { arity: 1, fn: Math.floor },
	ceil: { arity: 1, fn: Math.ceil },
	round: { arity: 1, fn: Math.round },
	sign: { arity: 1, fn: Math.sign },
	min: { arity: 'variadic', fn: Math.min },
	max: { arity: 'variadic', fn: Math.max },
	pow: { arity: 2, fn: Math.pow },
	atan2: { arity: 2, fn: Math.atan2 },
};

const CONSTANTS: Record<string, number> = { pi: Math.PI, e: Math.E, tau: Math.PI * 2 };

export interface CompiledExpr {
	/** Evalúa la expresión; devuelve NaN si falta una variable o el dominio falla. */
	eval(vars: Vars): number;
	/** Variables libres que necesita, en orden alfabético. */
	readonly vars: string[];
}

interface Token {
	kind: 'num' | 'id' | 'op' | 'end';
	text: string;
	value?: number;
	pos: number;
}

function tokenize(src: string): Token[] {
	const out: Token[] = [];
	let i = 0;
	while (i < src.length) {
		const c = src[i] as string;
		if (/\s/.test(c)) {
			i++;
			continue;
		}
		if (/[0-9.]/.test(c)) {
			const start = i;
			while (i < src.length && /[0-9.eE]/.test(src[i] as string)) {
				// Solo un exponente decimal: 1e-3, no 1e-3-2.
				if (/[eE]/.test(src[i] as string)) {
					i++;
					if (src[i] === '+' || src[i] === '-') i++;
					continue;
				}
				i++;
			}
			const text = src.slice(start, i);
			const value = Number(text);
			if (!Number.isFinite(value)) throw new Error(`Número no válido: «${text}»`);
			out.push({ kind: 'num', text, value, pos: start });
			continue;
		}
		if (/[A-Za-z_]/.test(c)) {
			const start = i;
			while (i < src.length && /[A-Za-z0-9_]/.test(src[i] as string)) i++;
			out.push({ kind: 'id', text: src.slice(start, i).toLowerCase(), pos: start });
			continue;
		}
		if ('+-*/^(),'.includes(c)) {
			out.push({ kind: 'op', text: c, pos: i });
			i++;
			continue;
		}
		throw new Error(`Carácter no admitido: «${c}»`);
	}
	out.push({ kind: 'end', text: '', pos: src.length });
	return out;
}

/** Compila una expresión; lanza `Error` con un mensaje en español si no es válida. */
export function compileExpr(src: string): CompiledExpr {
	const tokens = tokenize(src);
	let k = 0;
	const used = new Set<string>();
	const peek = (): Token => tokens[k] as Token;
	const next = (): Token => tokens[k++] as Token;
	const expect = (text: string): Token => {
		const t = next();
		if (t.kind !== 'op' || t.text !== text) throw new Error(`Se esperaba «${text}» en la posición ${t.pos}`);
		return t;
	};

	const parseExpr = (): Node => {
		let left = parseTerm();
		for (;;) {
			const t = peek();
			if (t.kind === 'op' && (t.text === '+' || t.text === '-')) {
				next();
				const right = parseTerm();
				const a = left;
				left = t.text === '+' ? (v) => a(v) + right(v) : (v) => a(v) - right(v);
			} else return left;
		}
	};

	const parseTerm = (): Node => {
		let left = parseUnary();
		for (;;) {
			const t = peek();
			if (t.kind === 'op' && (t.text === '*' || t.text === '/')) {
				next();
				const right = parseUnary();
				const a = left;
				left = t.text === '*' ? (v) => a(v) * right(v) : (v) => a(v) / right(v);
			} else return left;
		}
	};

	const parseUnary = (): Node => {
		const t = peek();
		if (t.kind === 'op' && (t.text === '+' || t.text === '-')) {
			next();
			const inner = parseUnary();
			return t.text === '-' ? (v) => -inner(v) : inner;
		}
		return parsePower();
	};

	const parsePower = (): Node => {
		const base = parsePrimary();
		const t = peek();
		if (t.kind === 'op' && t.text === '^') {
			next();
			// Asociativo a la derecha: 2^3^2 = 2^(3^2).
			const exp = parseUnary();
			return (v) => Math.pow(base(v), exp(v));
		}
		return base;
	};

	const parsePrimary = (): Node => {
		const t = next();
		if (t.kind === 'num') {
			const value = t.value as number;
			return () => value;
		}
		if (t.kind === 'op' && t.text === '(') {
			const inner = parseExpr();
			expect(')');
			return inner;
		}
		if (t.kind === 'id') {
			const name = t.text;
			if (peek().kind === 'op' && peek().text === '(') {
				next();
				const args: Node[] = [];
				if (!(peek().kind === 'op' && peek().text === ')')) {
					args.push(parseExpr());
					while (peek().kind === 'op' && peek().text === ',') {
						next();
						args.push(parseExpr());
					}
				}
				expect(')');
				const def = FUNCTIONS[name];
				if (!def) throw new Error(`Función desconocida: «${name}»`);
				if (def.arity !== 'variadic' && args.length !== def.arity) {
					throw new Error(`«${name}» espera ${def.arity} argumento(s), recibió ${args.length}`);
				}
				if (def.arity === 'variadic' && args.length === 0) throw new Error(`«${name}» necesita argumentos`);
				const fn = def.fn;
				return (v) => fn(...args.map((a) => a(v)));
			}
			if (name in CONSTANTS) {
				const value = CONSTANTS[name] as number;
				return () => value;
			}
			used.add(name);
			return (v) => {
				const x = v[name];
				return typeof x === 'number' ? x : Number.NaN;
			};
		}
		throw new Error(`Expresión incompleta en la posición ${t.pos}`);
	};

	const root = parseExpr();
	if (peek().kind !== 'end') throw new Error(`Sobra algo en la expresión: «${peek().text}»`);
	return {
		eval: (v) => root(v),
		vars: [...used].sort(),
	};
}

/** Devuelve el error en texto o `null` si la expresión compila. */
export function checkExpr(src: string): string | null {
	try {
		compileExpr(src);
		return null;
	} catch (e) {
		return e instanceof Error ? e.message : String(e);
	}
}
