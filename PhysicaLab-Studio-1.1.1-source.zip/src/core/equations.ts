import type { ResourceScope } from './lifecycle';
import { MathSlot, type MathEngine } from '../render/math/math-renderer';

interface Entry {
	row: HTMLElement;
	slot: MathSlot;
	caption: HTMLElement | null;
}

/**
 * Zona de ecuaciones (modo display) y lecturas (modo en línea) que cambian
 * con el estado. Cada hueco solo se re-tipografía si cambia su LaTeX.
 */
export class EquationBoard {
	readonly el: HTMLElement;
	private readonly eqList: HTMLElement;
	private readonly readoutList: HTMLElement;
	private readonly eqs = new Map<string, Entry>();
	private readonly readouts = new Map<string, Entry>();
	private readonly doc: Document;

	constructor(
		parent: HTMLElement,
		private readonly engine: MathEngine,
		scope: ResourceScope,
		private readonly onRendered: () => void,
		private readonly throttleMs = 0,
	) {
		this.doc = parent.ownerDocument;
		this.el = this.doc.createElement('div');
		this.el.className = 'pl-equations';
		parent.appendChild(this.el);
		this.readoutList = this.doc.createElement('div');
		this.readoutList.className = 'pl-readouts';
		this.el.appendChild(this.readoutList);
		this.eqList = this.doc.createElement('div');
		this.eqList.className = 'pl-eq-list';
		this.el.appendChild(this.eqList);
		scope.add(() => {
			for (const e of this.eqs.values()) e.slot.dispose();
			for (const e of this.readouts.values()) e.slot.dispose();
			this.eqs.clear();
			this.readouts.clear();
			this.el.remove();
		});
	}

	/** Ecuación en modo display, con leyenda opcional (texto plano). */
	set(id: string, tex: string, caption?: string): void {
		const e = this.entry(this.eqs, this.eqList, id, true, 'pl-eq');
		this.setCaption(e, caption);
		e.slot.set(tex);
	}

	/** Lectura en línea (p. ej. `m_{\text{sec}} = 2.75`). */
	readout(id: string, tex: string, caption?: string): void {
		const e = this.entry(this.readouts, this.readoutList, id, false, 'pl-readout');
		this.setCaption(e, caption);
		e.slot.set(tex);
	}

	/** Muestra u oculta una ecuación o lectura. */
	visible(id: string, v: boolean): void {
		const e = this.eqs.get(id) ?? this.readouts.get(id);
		e?.row.classList.toggle('pl-hidden', !v);
	}

	/** Resalta una ecuación o lectura (p. ej. caso límite). */
	highlight(id: string, on: boolean): void {
		const e = this.eqs.get(id) ?? this.readouts.get(id);
		e?.row.classList.toggle('pl-emph', on);
	}

	remove(id: string): void {
		for (const m of [this.eqs, this.readouts]) {
			const e = m.get(id);
			if (e) {
				e.slot.dispose();
				e.row.remove();
				m.delete(id);
			}
		}
	}

	tex(id: string): string | null {
		return (this.eqs.get(id) ?? this.readouts.get(id))?.slot.tex ?? null;
	}

	flush(): void {
		for (const e of this.eqs.values()) e.slot.flush();
		for (const e of this.readouts.values()) e.slot.flush();
	}

	private entry(map: Map<string, Entry>, list: HTMLElement, id: string, display: boolean, cls: string): Entry {
		let e = map.get(id);
		if (e) return e;
		const row = this.doc.createElement('div');
		row.className = cls;
		row.dataset.eq = id;
		list.appendChild(row);
		const mathEl = this.doc.createElement(display ? 'div' : 'span');
		mathEl.className = `${cls}-math`;
		row.appendChild(mathEl);
		const slot = new MathSlot(mathEl, this.engine, display, this.onRendered, this.throttleMs, this.doc.defaultView ?? window);
		e = { row, slot, caption: null };
		map.set(id, e);
		return e;
	}

	private setCaption(e: Entry, caption: string | undefined): void {
		if (caption === undefined) return;
		if (!e.caption) {
			e.caption = this.doc.createElement('span');
			e.caption.className = 'pl-caption';
			e.row.insertBefore(e.caption, e.row.firstChild);
		}
		if (e.caption.textContent !== caption) e.caption.textContent = caption;
	}
}
