/**
 * Ámbito de recursos: registra listeners, observadores, temporizadores y
 * frames de animación para liberarlos todos juntos en `dispose()`.
 *
 * `ResourceScope.live` cuenta los recursos vivos de todos los ámbitos; las
 * pruebas lo usan para comprobar que cerrar una nota no deja nada activo.
 */
export class ResourceScope {
	private static liveCount = 0;

	static get live(): number {
		return ResourceScope.liveCount;
	}

	private readonly disposers = new Set<() => void>();
	private readonly children = new Set<ResourceScope>();
	private disposed = false;

	constructor(private readonly win: Window = window) {}

	get isDisposed(): boolean {
		return this.disposed;
	}

	get size(): number {
		let n = this.disposers.size;
		for (const c of this.children) n += c.size;
		return n;
	}

	/** Registra una función de limpieza. Devuelve otra que la ejecuta antes de tiempo. */
	add(disposer: () => void): () => void {
		if (this.disposed) {
			disposer();
			return () => {};
		}
		let done = false;
		const run = (): void => {
			if (done) return;
			done = true;
			this.disposers.delete(run);
			ResourceScope.liveCount--;
			try {
				disposer();
			} catch (err) {
				console.error('[PhysicaLab] error al liberar un recurso', err);
			}
		};
		this.disposers.add(run);
		ResourceScope.liveCount++;
		return run;
	}

	listen<K extends keyof HTMLElementEventMap>(
		target: HTMLElement,
		type: K,
		handler: (ev: HTMLElementEventMap[K]) => void,
		options?: AddEventListenerOptions | boolean,
	): () => void;
	listen<K extends keyof SVGElementEventMap>(
		target: SVGElement,
		type: K,
		handler: (ev: SVGElementEventMap[K]) => void,
		options?: AddEventListenerOptions | boolean,
	): () => void;
	listen<K extends keyof DocumentEventMap>(
		target: Document,
		type: K,
		handler: (ev: DocumentEventMap[K]) => void,
		options?: AddEventListenerOptions | boolean,
	): () => void;
	listen<K extends keyof WindowEventMap>(
		target: Window,
		type: K,
		handler: (ev: WindowEventMap[K]) => void,
		options?: AddEventListenerOptions | boolean,
	): () => void;
	listen(target: EventTarget, type: string, handler: (ev: Event) => void, options?: AddEventListenerOptions | boolean): () => void;
	listen(target: EventTarget, type: string, handler: (ev: Event) => void, options?: AddEventListenerOptions | boolean): () => void {
		target.addEventListener(type, handler, options);
		return this.add(() => target.removeEventListener(type, handler, options));
	}

	/** ResizeObserver con limpieza automática (no hace nada si no existe). */
	observeResize(el: Element, cb: (entry: ResizeObserverEntry) => void): () => void {
		const RO = (this.win as Window & { ResizeObserver?: typeof ResizeObserver }).ResizeObserver;
		if (!RO) return () => {};
		const ro = new RO((entries) => {
			for (const e of entries) cb(e);
		});
		ro.observe(el);
		return this.add(() => ro.disconnect());
	}

	/** IntersectionObserver con limpieza automática. Sin soporte, llama `cb(true)`. */
	observeVisibility(el: Element, cb: (visible: boolean) => void, rootMargin = '200px'): () => void {
		const IO = (this.win as Window & { IntersectionObserver?: typeof IntersectionObserver }).IntersectionObserver;
		if (!IO) {
			cb(true);
			return () => {};
		}
		const io = new IO(
			(entries) => {
				for (const e of entries) cb(e.isIntersecting);
			},
			{ rootMargin },
		);
		io.observe(el);
		return this.add(() => io.disconnect());
	}

	timeout(fn: () => void, ms: number): () => void {
		let cancel: () => void = () => {};
		const id = this.win.setTimeout(() => {
			cancel();
			fn();
		}, ms);
		cancel = this.add(() => this.win.clearTimeout(id));
		return cancel;
	}

	interval(fn: () => void, ms: number): () => void {
		const id = this.win.setInterval(fn, ms);
		return this.add(() => this.win.clearInterval(id));
	}

	/** requestAnimationFrame de un solo disparo, cancelable y registrado. */
	frame(fn: (time: number) => void): () => void {
		const raf = this.win.requestAnimationFrame?.bind(this.win);
		const caf = this.win.cancelAnimationFrame?.bind(this.win);
		let cancel: () => void = () => {};
		if (raf && caf) {
			const id = raf((t) => {
				cancel();
				fn(t);
			});
			cancel = this.add(() => caf(id));
		} else {
			const id = this.win.setTimeout(() => {
				cancel();
				fn(performance.now());
			}, 16);
			cancel = this.add(() => this.win.clearTimeout(id));
		}
		return cancel;
	}

	/** Ámbito hijo que se libera con este. */
	child(): ResourceScope {
		const c = new ResourceScope(this.win);
		this.children.add(c);
		c.add(() => this.children.delete(c));
		return c;
	}

	dispose(): void {
		if (this.disposed) return;
		this.disposed = true;
		for (const c of [...this.children]) c.dispose();
		for (const d of [...this.disposers]) d();
		this.disposers.clear();
	}
}

/**
 * Agrupa peticiones de redibujado en un único frame.
 * `flush()` fuerza el dibujo inmediato (útil en pruebas).
 */
export class FrameScheduler {
	private pending = new Set<string>();
	private cancel: (() => void) | null = null;
	private all = false;

	constructor(
		private readonly scope: ResourceScope,
		private readonly render: (changed: ReadonlySet<string>, full: boolean) => void,
	) {}

	request(changed?: Iterable<string>): void {
		if (this.scope.isDisposed) return;
		if (changed) for (const id of changed) this.pending.add(id);
		else this.all = true;
		if (this.cancel) return;
		this.cancel = this.scope.frame(() => {
			this.cancel = null;
			this.flush();
		});
	}

	flush(): void {
		if (this.cancel) {
			this.cancel();
			this.cancel = null;
		}
		if (this.scope.isDisposed) return;
		const changed = this.pending;
		const full = this.all;
		this.pending = new Set();
		this.all = false;
		if (changed.size === 0 && !full) return;
		this.render(changed, full);
	}
}

/**
 * Reloj de animación. Solo consume frames mientras está en marcha y visible;
 * nunca arranca solo. `onTick(dt, t)` recibe segundos; si devuelve `false`,
 * la animación se detiene.
 */
export class AnimationClock {
	private running = false;
	private visible = true;
	private docHidden = false;
	private last = 0;
	private elapsed = 0;
	private cancelFrame: (() => void) | null = null;
	private readonly listeners = new Set<(playing: boolean) => void>();
	/** Multiplicador de velocidad (1 = tiempo real). */
	speed = 1;

	constructor(
		private readonly scope: ResourceScope,
		private readonly onTick: (dt: number, t: number) => boolean | void,
		doc?: Document,
	) {
		if (doc) {
			scope.listen(doc, 'visibilitychange', () => {
				this.docHidden = doc.visibilityState === 'hidden';
				this.sync();
			});
		}
		scope.add(() => this.stopFrames());
	}

	get playing(): boolean {
		return this.running;
	}

	get time(): number {
		return this.elapsed;
	}

	play(): void {
		if (this.running || this.scope.isDisposed) return;
		this.running = true;
		this.notify();
		this.sync();
	}

	pause(): void {
		if (!this.running) return;
		this.running = false;
		this.stopFrames();
		this.notify();
	}

	toggle(): void {
		if (this.running) this.pause();
		else this.play();
	}

	resetTime(): void {
		this.elapsed = 0;
	}

	/** El laboratorio salió o volvió a la vista (IntersectionObserver). */
	setVisible(v: boolean): void {
		this.visible = v;
		this.sync();
	}

	onChange(cb: (playing: boolean) => void): () => void {
		this.listeners.add(cb);
		return () => this.listeners.delete(cb);
	}

	private notify(): void {
		for (const l of [...this.listeners]) l(this.running);
	}

	private sync(): void {
		const shouldRun = this.running && this.visible && !this.docHidden && !this.scope.isDisposed;
		if (shouldRun && !this.cancelFrame) {
			this.last = 0;
			this.schedule();
		} else if (!shouldRun) {
			this.stopFrames();
		}
	}

	private schedule(): void {
		this.cancelFrame = this.scope.frame((now) => {
			this.cancelFrame = null;
			if (!this.running) return;
			const dt = this.last === 0 ? 0 : Math.min((now - this.last) / 1000, 1 / 20);
			this.last = now;
			this.elapsed += dt * this.speed;
			let keep: boolean | void = true;
			try {
				keep = this.onTick(dt * this.speed, this.elapsed);
			} catch (err) {
				console.error('[PhysicaLab] error en la animación', err);
				keep = false;
			}
			if (keep === false) {
				this.pause();
				return;
			}
			if (this.running && this.visible && !this.docHidden) this.schedule();
		});
	}

	private stopFrames(): void {
		if (this.cancelFrame) {
			this.cancelFrame();
			this.cancelFrame = null;
		}
	}
}
