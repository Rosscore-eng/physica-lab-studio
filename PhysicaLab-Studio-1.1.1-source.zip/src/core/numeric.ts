/** Utilidades numéricas puras (sin DOM). */

export function clamp(v: number, min: number, max: number): number {
	return v < min ? min : v > max ? max : v;
}

export function isFiniteNumber(v: unknown): v is number {
	return typeof v === 'number' && Number.isFinite(v);
}

/** Decimales escritos de un número (0.01 → 2, -2.5 → 1, 5 → 0, 1e-7 → 7). */
export function fractionDigits(n: number): number {
	if (!Number.isFinite(n)) return 0;
	const s = String(Math.abs(n));
	const e = s.indexOf('e-');
	if (e >= 0) {
		const mant = s.slice(0, e);
		const dot = mant.indexOf('.');
		return Number(s.slice(e + 2)) + (dot < 0 ? 0 : mant.length - dot - 1);
	}
	const dot = s.indexOf('.');
	return dot < 0 ? 0 : s.length - dot - 1;
}

/** Número de decimales significativos de un paso (0.01 → 2, 0.5 → 1, 5 → 0). */
export function decimalsOf(step: number): number {
	if (!Number.isFinite(step) || step <= 0) return 6;
	return fractionDigits(step);
}

/** Ajusta `v` a la rejilla `min + k·step` y elimina ruido de coma flotante. */
export function snapToStep(v: number, step: number, min: number): number {
	if (!(step > 0)) return v;
	const k = Math.round((v - min) / step);
	const digits = Math.min(15, Math.max(decimalsOf(step), fractionDigits(min)));
	const r = Number((min + k * step).toFixed(digits));
	return Object.is(r, -0) ? 0 : r;
}

/** Redondea a `n` cifras significativas. */
export function roundSig(v: number, n = 3): number {
	if (v === 0 || !Number.isFinite(v)) return v;
	const d = Math.ceil(Math.log10(Math.abs(v)));
	const p = n - d;
	const m = Math.pow(10, p);
	return Math.round(v * m) / m;
}

/** Interpolación lineal. */
export function lerp(a: number, b: number, t: number): number {
	return a + (b - a) * t;
}

/** Corrige -0 y valores minúsculos para que no aparezca «-0.00». */
function tidy(v: number, decimals: number): number {
	const r = Number(v.toFixed(decimals));
	return Object.is(r, -0) ? 0 : r;
}

/** Texto plano con `decimals` decimales fijos. */
export function fmt(v: number, decimals = 2): string {
	if (!Number.isFinite(v)) return v > 0 ? '∞' : v < 0 ? '−∞' : '—';
	return tidy(v, decimals).toFixed(decimals);
}

/**
 * Número para LaTeX. Usa notación científica (`a\times10^{b}`) fuera de
 * [1e-3, 1e5). Los no finitos se devuelven como `\infty` o `\text{—}`.
 */
export function texNum(v: number, decimals = 2): string {
	if (Number.isNaN(v)) return '\\text{—}';
	if (!Number.isFinite(v)) return v > 0 ? '\\infty' : '-\\infty';
	const a = Math.abs(v);
	if (a !== 0 && (a < 1e-3 || a >= 1e5)) {
		const exp = Math.floor(Math.log10(a));
		let mant = tidy(v / Math.pow(10, exp), decimals);
		let e = exp;
		if (Math.abs(mant) >= 10) {
			mant = tidy(mant / 10, decimals);
			e += 1;
		}
		return `${mant.toFixed(decimals)}\\times 10^{${e}}`;
	}
	return tidy(v, decimals).toFixed(decimals);
}

/**
 * Número para LaTeX con `sig` cifras significativas (no decimales fijos):
 * 0.001427 → `1.43\times 10^{-3}`, 0.01427 → `0.0143`, 2.4569 → `2.46`.
 * Úsalo en las sustituciones para que los valores mostrados reproduzcan el resultado.
 */
export function texSig(v: number, sig = 3): string {
	if (!Number.isFinite(v)) return texNum(v);
	if (v === 0) return '0';
	const a = Math.abs(v);
	if (a < 1e-3 || a >= 1e5) return texNum(v, Math.max(0, sig - 1));
	const decimals = Math.max(0, sig - 1 - Math.floor(Math.log10(a)));
	return texNum(v, decimals);
}

const SI_PREFIXES: Array<[number, string]> = [
	[1e9, 'G'],
	[1e6, 'M'],
	[1e3, 'k'],
	[1, ''],
	[1e-3, 'm'],
	[1e-6, '\\mu '],
	[1e-9, 'n'],
	[1e-12, 'p'],
];

/**
 * Cantidad con prefijo SI en LaTeX: `texSI(0.0025, 's')` → `2.50\,\mathrm{ms}`.
 * `unit` es el símbolo base sin prefijo (texto plano, p. ej. `s`, `V`, `\Omega`).
 */
export function texSI(v: number, unit: string, sig = 3): string {
	if (!Number.isFinite(v)) return `${texNum(v)}\\,\\mathrm{${unit}}`;
	const a = Math.abs(v);
	let chosen: [number, string] = [1, ''];
	if (a !== 0) {
		for (const p of SI_PREFIXES) {
			if (a >= p[0] * 0.9995) {
				chosen = p;
				break;
			}
			chosen = p;
		}
	}
	const scaled = v / chosen[0];
	const intDigits = scaled === 0 ? 1 : Math.max(1, Math.floor(Math.log10(Math.abs(scaled))) + 1);
	const decimals = Math.max(0, sig - intDigits);
	const prefix = chosen[1];
	const u = prefix.startsWith('\\mu') ? `\\mu\\mathrm{${unit}}` : `\\mathrm{${prefix}${unit}}`;
	return `${tidy(scaled, decimals).toFixed(decimals)}\\,${u}`;
}

/** Valor «redondo» ≥ v de la forma {1, 2, 5}·10^n (para ejes). */
export function niceCeil(v: number): number {
	if (!(v > 0) || !Number.isFinite(v)) return 1;
	const e = Math.floor(Math.log10(v));
	const base = Math.pow(10, e);
	for (const m of [1, 2, 5, 10]) {
		if (m * base >= v * (1 - 1e-9)) return m * base;
	}
	return 10 * base;
}

/** Paso «redondo» para unas `count` divisiones en [0, span]. */
export function niceStep(span: number, count = 5): number {
	if (!(span > 0)) return 1;
	const raw = span / count;
	const e = Math.floor(Math.log10(raw));
	const base = Math.pow(10, e);
	const f = raw / base;
	const m = f < 1.5 ? 1 : f < 3 ? 2 : f < 7 ? 5 : 10;
	return m * base;
}

/** Marcas de eje en [min, max] con paso redondo. */
export function ticks(min: number, max: number, count = 5): number[] {
	const step = niceStep(max - min, count);
	const out: number[] = [];
	const start = Math.ceil(min / step - 1e-9) * step;
	for (let v = start; v <= max + step * 1e-9; v += step) {
		out.push(Number(v.toFixed(12)));
		if (out.length > 200) break;
	}
	return out;
}

/** Grados ↔ radianes. */
export const deg2rad = (d: number): number => (d * Math.PI) / 180;
export const rad2deg = (r: number): number => (r * 180) / Math.PI;
