/**
 * Motor de tipografía matemática. En Obsidian se usa el MathJax nativo
 * (`renderMath`/`finishRenderMath`, ver src/obsidian/obsidian-math.ts); en el
 * banco de pruebas visual, KaTeX. El núcleo solo conoce esta interfaz.
 */
export interface MathEngine {
	readonly kind: string;
	/** Devuelve un elemento NUEVO con la expresión tipografiada. */
	render(tex: string, display: boolean): HTMLElement;
	/** Se llama una vez tras un lote de `render` (MathJax inyecta estilos aquí). */
	finish(): void;
}

/** Sin motor disponible: muestra la fuente LaTeX tal cual, sin imitarla con Unicode. */
export class PlainMathEngine implements MathEngine {
	readonly kind = 'plain';
	constructor(private readonly doc: Document = document) {}
	render(tex: string, display: boolean): HTMLElement {
		const el = this.doc.createElement(display ? 'div' : 'span');
		el.className = 'pl-math-fallback';
		el.textContent = tex;
		return el;
	}
	finish(): void {}
}

/**
 * Envoltorio con caché LRU: cada expresión se tipografía una vez y luego se
 * clona. Reduce mucho el coste durante el arrastre.
 */
export class CachedMathEngine implements MathEngine {
	private readonly cache = new Map<string, HTMLElement>();
	private dirty = false;

	constructor(
		private readonly inner: MathEngine,
		private readonly capacity = 400,
	) {}

	get kind(): string {
		return this.inner.kind;
	}

	render(tex: string, display: boolean): HTMLElement {
		const key = (display ? 'D' : 'I') + tex;
		const hit = this.cache.get(key);
		if (hit) {
			this.cache.delete(key);
			this.cache.set(key, hit);
			return hit.cloneNode(true) as HTMLElement;
		}
		let el: HTMLElement;
		try {
			el = this.inner.render(tex, display);
		} catch (err) {
			console.warn('[PhysicaLab] no se pudo tipografiar', tex, err);
			el = new PlainMathEngine(document).render(tex, display);
		}
		this.dirty = true;
		this.cache.set(key, el.cloneNode(true) as HTMLElement);
		if (this.cache.size > this.capacity) {
			const first = this.cache.keys().next().value;
			if (first !== undefined) this.cache.delete(first);
		}
		return el;
	}

	finish(): void {
		if (!this.dirty) return;
		this.dirty = false;
		this.inner.finish();
	}

	clear(): void {
		this.cache.clear();
	}
}

/**
 * Hueco de una expresión que cambia con el estado: solo vuelve a tipografiar
 * cuando cambia el texto LaTeX. Con `throttleMs`, durante cambios rápidos
 * (arrastre) se limita la frecuencia y siempre se pinta el último valor.
 */
export class MathSlot {
	private current: string | null = null;
	private pending: string | null = null;
	private lastRender = 0;
	private timer: number | null = null;

	constructor(
		readonly el: HTMLElement,
		private readonly engine: MathEngine,
		private readonly display: boolean,
		private readonly onRendered: () => void = () => {},
		private readonly throttleMs = 0,
		private readonly win: Window = window,
	) {}

	get tex(): string | null {
		return this.pending ?? this.current;
	}

	set(tex: string): void {
		if (tex === this.current && this.pending === null) return;
		this.pending = tex;
		const now = this.win.performance?.now?.() ?? Date.now();
		if (this.throttleMs <= 0 || now - this.lastRender >= this.throttleMs) {
			this.flush();
		} else if (this.timer === null) {
			this.timer = this.win.setTimeout(() => {
				this.timer = null;
				this.flush();
			}, this.throttleMs - (now - this.lastRender));
		}
	}

	flush(): void {
		if (this.timer !== null) {
			this.win.clearTimeout(this.timer);
			this.timer = null;
		}
		if (this.pending === null || this.pending === this.current) {
			this.pending = null;
			return;
		}
		const tex = this.pending;
		this.pending = null;
		this.current = tex;
		this.lastRender = this.win.performance?.now?.() ?? Date.now();
		const node = this.engine.render(tex, this.display);
		this.el.replaceChildren(node);
		this.el.setAttribute('data-tex', tex);
		this.onRendered();
	}

	dispose(): void {
		if (this.timer !== null) this.win.clearTimeout(this.timer);
		this.timer = null;
	}
}
