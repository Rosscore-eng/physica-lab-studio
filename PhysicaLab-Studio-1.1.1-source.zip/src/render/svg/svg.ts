import type { Point, Rect, WorldBounds } from '../../core/types';

export const SVG_NS = 'http://www.w3.org/2000/svg';

export type AttrValue = string | number | null | undefined | false;
export type Attrs = Record<string, AttrValue>;

/** Crea un elemento SVG en el documento del padre (compatible con ventanas emergentes). */
export function svgEl<K extends keyof SVGElementTagNameMap>(
	parent: Element,
	tag: K,
	attrs: Attrs = {},
): SVGElementTagNameMap[K] {
	const el = parent.ownerDocument.createElementNS(SVG_NS, tag) as SVGElementTagNameMap[K];
	setAttrs(el, attrs);
	parent.appendChild(el);
	return el;
}

/** Asigna atributos; `null`/`undefined`/`false` los elimina. Redondea números a 2 decimales. */
export function setAttrs(el: Element, attrs: Attrs): void {
	for (const [k, v] of Object.entries(attrs)) {
		if (v === null || v === undefined || v === false) el.removeAttribute(k);
		else el.setAttribute(k, typeof v === 'number' ? r2(v) : v);
	}
}

/** Número con 2 decimales como texto, sin ceros sobrantes y sin `-0`. */
export function r2(v: number): string {
	if (!Number.isFinite(v)) return '0';
	const r = Math.round(v * 100) / 100;
	return Object.is(r, -0) ? '0' : String(r);
}

export function show(el: Element, visible: boolean): void {
	if (visible) el.removeAttribute('display');
	else el.setAttribute('display', 'none');
}

/**
 * Transformación mundo ↔ escena. El mundo usa unidades físicas con el eje
 * y hacia arriba; la escena usa las unidades del viewBox con y hacia abajo.
 */
export class Viewport {
	readonly sx: number;
	readonly sy: number;
	readonly ox: number;
	readonly oy: number;

	constructor(
		readonly world: WorldBounds,
		readonly rect: Rect,
		opts: { equalAspect?: boolean } = {},
	) {
		const ww = world.xMax - world.xMin;
		const wh = world.yMax - world.yMin;
		let sx = rect.width / ww;
		let sy = rect.height / wh;
		let ox = rect.x;
		let oy = rect.y;
		if (opts.equalAspect) {
			const s = Math.min(sx, sy);
			ox += (rect.width - ww * s) / 2;
			oy += (rect.height - wh * s) / 2;
			sx = sy = s;
		}
		this.sx = sx;
		this.sy = sy;
		this.ox = ox;
		this.oy = oy;
	}

	/** x del mundo → x de escena. */
	X(x: number): number {
		return this.ox + (x - this.world.xMin) * this.sx;
	}

	/** y del mundo → y de escena. */
	Y(y: number): number {
		return this.oy + (this.world.yMax - y) * this.sy;
	}

	toScene(p: Point): Point {
		return { x: this.X(p.x), y: this.Y(p.y) };
	}

	toWorld(p: Point): Point {
		return {
			x: this.world.xMin + (p.x - this.ox) / this.sx,
			y: this.world.yMax - (p.y - this.oy) / this.sy,
		};
	}

	/** Longitud del mundo (eje x) → longitud de escena. */
	len(d: number): number {
		return d * this.sx;
	}

	contains(p: Point, margin = 0): boolean {
		const w = this.world;
		return p.x >= w.xMin - margin && p.x <= w.xMax + margin && p.y >= w.yMin - margin && p.y <= w.yMax + margin;
	}

	/** Rectángulo de escena ocupado por el mundo. */
	get sceneRect(): Rect {
		return {
			x: this.X(this.world.xMin),
			y: this.Y(this.world.yMax),
			width: (this.world.xMax - this.world.xMin) * this.sx,
			height: (this.world.yMax - this.world.yMin) * this.sy,
		};
	}
}

/**
 * Traza `f` en el viewport como atributo `d` de un path. Interrumpe el trazo
 * donde `f` no es finita o se sale mucho del área (asíntotas).
 */
export function functionPath(vp: Viewport, f: (x: number) => number, x0: number, x1: number, samples = 200): string {
	const parts: string[] = [];
	let pen = false;
	const yPad = (vp.world.yMax - vp.world.yMin) * 4;
	for (let i = 0; i <= samples; i++) {
		const x = x0 + ((x1 - x0) * i) / samples;
		const y = f(x);
		if (!Number.isFinite(y) || y > vp.world.yMax + yPad || y < vp.world.yMin - yPad) {
			pen = false;
			continue;
		}
		parts.push(`${pen ? 'L' : 'M'}${r2(vp.X(x))} ${r2(vp.Y(y))}`);
		pen = true;
	}
	return parts.join('');
}

/** Polilínea en coordenadas de escena → `d`. */
export function polyPath(points: readonly Point[], close = false): string {
	if (points.length === 0) return '';
	let d = `M${r2(points[0]!.x)} ${r2(points[0]!.y)}`;
	for (let i = 1; i < points.length; i++) d += `L${r2(points[i]!.x)} ${r2(points[i]!.y)}`;
	return close ? d + 'Z' : d;
}
