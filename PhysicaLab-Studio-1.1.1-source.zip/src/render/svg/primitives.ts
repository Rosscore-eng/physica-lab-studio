import type { Point } from '../../core/types';
import { ticks as niceTicks, fmt } from '../../core/numeric';
import { r2, setAttrs, show, svgEl, Viewport } from './svg';

/**
 * Primitivas de figuras técnicas. Cada una crea sus elementos una vez y
 * luego solo actualiza atributos (sin recrear nodos en cada frame).
 */

/** Flecha (vector) con punta triangular dibujada como path. */
export class Arrow {
	readonly g: SVGGElement;
	private readonly shaft: SVGLineElement;
	private readonly head: SVGPathElement;

	constructor(
		parent: Element,
		cls: string,
		private readonly headLen = 10,
		private readonly headWidth = 7,
	) {
		this.g = svgEl(parent, 'g', { class: `pl-arrow ${cls}` });
		this.shaft = svgEl(this.g, 'line', { class: 'pl-arrow-shaft' });
		this.head = svgEl(this.g, 'path', { class: 'pl-arrow-head' });
	}

	/** Dibuja de (x1,y1) a (x2,y2) en coordenadas de escena. */
	set(x1: number, y1: number, x2: number, y2: number): this {
		const dx = x2 - x1;
		const dy = y2 - y1;
		const len = Math.hypot(dx, dy);
		if (!(len > 0.5) || !Number.isFinite(len)) {
			show(this.g, false);
			return this;
		}
		show(this.g, true);
		const k = Math.min(1, len / (this.headLen * 1.6));
		const hl = this.headLen * k;
		const hw = this.headWidth * k;
		const ux = dx / len;
		const uy = dy / len;
		const bx = x2 - ux * hl;
		const by = y2 - uy * hl;
		setAttrs(this.shaft, { x1, y1, x2: bx + ux * 0.5, y2: by + uy * 0.5 });
		const px = -uy * (hw / 2);
		const py = ux * (hw / 2);
		this.head.setAttribute('d', `M${r2(x2)} ${r2(y2)}L${r2(bx + px)} ${r2(by + py)}L${r2(bx - px)} ${r2(by - py)}Z`);
		return this;
	}

	visible(v: boolean): this {
		show(this.g, v);
		return this;
	}
}

/**
 * Arco de ángulo en coordenadas de escena. Los ángulos siguen el convenio
 * matemático (antihorario positivo, eje x hacia la derecha) aunque la
 * escena tenga el eje y hacia abajo.
 */
export function arcPath(c: Point, r: number, a0: number, a1: number): string {
	const p0 = { x: c.x + r * Math.cos(a0), y: c.y - r * Math.sin(a0) };
	const p1 = { x: c.x + r * Math.cos(a1), y: c.y - r * Math.sin(a1) };
	const delta = a1 - a0;
	const large = Math.abs(delta) > Math.PI ? 1 : 0;
	const sweep = delta > 0 ? 0 : 1;
	return `M${r2(p0.x)} ${r2(p0.y)}A${r2(r)} ${r2(r)} 0 ${large} ${sweep} ${r2(p1.x)} ${r2(p1.y)}`;
}

/** Cota técnica entre dos puntos, desplazada `offset` en perpendicular. */
export class Dimension {
	readonly g: SVGGElement;
	private readonly ext1: SVGLineElement;
	private readonly ext2: SVGLineElement;
	private readonly line: SVGLineElement;
	private readonly t1: SVGPathElement;
	private readonly t2: SVGPathElement;
	/** Punto medio de la línea de cota (para colocar la etiqueta). */
	mid: Point = { x: 0, y: 0 };
	/** Normal unitaria hacia el lado de la cota. */
	normal: Point = { x: 0, y: 0 };

	constructor(parent: Element, cls = '') {
		this.g = svgEl(parent, 'g', { class: `pl-dim ${cls}` });
		this.ext1 = svgEl(this.g, 'line', { class: 'pl-dim-ext' });
		this.ext2 = svgEl(this.g, 'line', { class: 'pl-dim-ext' });
		this.line = svgEl(this.g, 'line', { class: 'pl-dim-line' });
		this.t1 = svgEl(this.g, 'path', { class: 'pl-dim-tick' });
		this.t2 = svgEl(this.g, 'path', { class: 'pl-dim-tick' });
	}

	set(a: Point, b: Point, offset: number): this {
		const dx = b.x - a.x;
		const dy = b.y - a.y;
		const len = Math.hypot(dx, dy);
		if (!(len > 1)) {
			show(this.g, false);
			return this;
		}
		show(this.g, true);
		const ux = dx / len;
		const uy = dy / len;
		const nx = -uy;
		const ny = ux;
		const s = Math.sign(offset) || 1;
		const a2 = { x: a.x + nx * offset, y: a.y + ny * offset };
		const b2 = { x: b.x + nx * offset, y: b.y + ny * offset };
		const ext = 4 * s;
		setAttrs(this.ext1, { x1: a.x + nx * 3 * s, y1: a.y + ny * 3 * s, x2: a2.x + nx * ext, y2: a2.y + ny * ext });
		setAttrs(this.ext2, { x1: b.x + nx * 3 * s, y1: b.y + ny * 3 * s, x2: b2.x + nx * ext, y2: b2.y + ny * ext });
		setAttrs(this.line, { x1: a2.x, y1: a2.y, x2: b2.x, y2: b2.y });
		const h = 6;
		const w = 2.6;
		const tri = (p: Point, dir: number): string =>
			`M${r2(p.x)} ${r2(p.y)}L${r2(p.x + dir * ux * h + nx * w)} ${r2(p.y + dir * uy * h + ny * w)}L${r2(p.x + dir * ux * h - nx * w)} ${r2(p.y + dir * uy * h - ny * w)}Z`;
		this.t1.setAttribute('d', tri(a2, 1));
		this.t2.setAttribute('d', tri(b2, -1));
		this.mid = { x: (a2.x + b2.x) / 2, y: (a2.y + b2.y) / 2 };
		this.normal = { x: nx * s, y: ny * s };
		return this;
	}

	visible(v: boolean): this {
		show(this.g, v);
		return this;
	}
}

/** Rayado técnico de un soporte (techo, suelo, pared) a lo largo de un segmento. */
export function hatch(parent: Element, a: Point, b: Point, side: 1 | -1 = 1, spacing = 8, depth = 8, cls = 'pl-hatch'): SVGGElement {
	const g = svgEl(parent, 'g', { class: cls });
	const len = Math.hypot(b.x - a.x, b.y - a.y);
	const ux = (b.x - a.x) / len;
	const uy = (b.y - a.y) / len;
	const nx = -uy * side;
	const ny = ux * side;
	svgEl(g, 'line', { class: 'pl-hatch-base', x1: a.x, y1: a.y, x2: b.x, y2: b.y });
	for (let s = spacing / 2; s < len; s += spacing) {
		const p = { x: a.x + ux * s, y: a.y + uy * s };
		svgEl(g, 'line', {
			x1: p.x,
			y1: p.y,
			x2: p.x + nx * depth - ux * depth * 0.7,
			y2: p.y + ny * depth - uy * depth * 0.7,
		});
	}
	return g;
}

export interface AxesOptions {
	xTicks?: number[];
	yTicks?: number[];
	/** Número aproximado de marcas si no se dan explícitas. */
	tickCount?: number;
	grid?: boolean;
	/** Decimales en las marcas. */
	xDecimals?: number;
	yDecimals?: number;
	/** Dibuja los ejes en x=0 / y=0 si están dentro; si no, en el borde. */
	cross?: boolean;
	/** Formateador de marcas (texto plano). */
	xFormat?: (v: number) => string;
	yFormat?: (v: number) => string;
}

/** Ejes cartesianos con marcas y rejilla. Se redibujan solo cuando cambia el rango. */
export class Axes {
	readonly g: SVGGElement;
	private readonly gridG: SVGGElement;
	private signature = '';

	constructor(gridLayer: Element, axisLayer: Element) {
		this.gridG = svgEl(gridLayer, 'g', { class: 'pl-grid' });
		this.g = svgEl(axisLayer, 'g', { class: 'pl-axes' });
	}

	draw(vp: Viewport, opts: AxesOptions = {}): void {
		const w = vp.world;
		const sig = JSON.stringify([w, vp.rect, opts.xTicks, opts.yTicks, opts.grid, opts.cross, opts.tickCount]);
		if (sig === this.signature) return;
		this.signature = sig;
		this.g.replaceChildren();
		this.gridG.replaceChildren();
		const count = opts.tickCount ?? 6;
		const xt = opts.xTicks ?? niceTicks(w.xMin, w.xMax, count);
		const yt = opts.yTicks ?? niceTicks(w.yMin, w.yMax, count);
		const cross = opts.cross ?? true;
		const x0 = cross && w.yMin <= 0 && w.yMax >= 0 ? 0 : w.yMin;
		const y0 = cross && w.xMin <= 0 && w.xMax >= 0 ? 0 : w.xMin;
		const ax = vp.Y(x0);
		const ay = vp.X(y0);
		const xf = opts.xFormat ?? ((v: number) => fmt(v, opts.xDecimals ?? autoDecimals(xt)));
		const yf = opts.yFormat ?? ((v: number) => fmt(v, opts.yDecimals ?? autoDecimals(yt)));

		if (opts.grid !== false) {
			for (const x of xt) {
				svgEl(this.gridG, 'line', { x1: vp.X(x), y1: vp.Y(w.yMin), x2: vp.X(x), y2: vp.Y(w.yMax) });
			}
			for (const y of yt) {
				svgEl(this.gridG, 'line', { x1: vp.X(w.xMin), y1: vp.Y(y), x2: vp.X(w.xMax), y2: vp.Y(y) });
			}
		}
		svgEl(this.g, 'line', { class: 'pl-axis', x1: vp.X(w.xMin), y1: ax, x2: vp.X(w.xMax), y2: ax });
		svgEl(this.g, 'line', { class: 'pl-axis', x1: ay, y1: vp.Y(w.yMin), x2: ay, y2: vp.Y(w.yMax) });
		for (const x of xt) {
			const X = vp.X(x);
			svgEl(this.g, 'line', { class: 'pl-tick', x1: X, y1: ax, x2: X, y2: ax + 4 });
			if (cross && x === y0 && w.yMin < 0) continue;
			const t = svgEl(this.g, 'text', { class: 'pl-tick-label', x: X, y: ax + 15, 'text-anchor': 'middle' });
			t.textContent = xf(x);
		}
		for (const y of yt) {
			const Y = vp.Y(y);
			svgEl(this.g, 'line', { class: 'pl-tick', x1: ay - 4, y1: Y, x2: ay, y2: Y });
			if (cross && y === x0 && w.xMin < 0) continue;
			const t = svgEl(this.g, 'text', { class: 'pl-tick-label', x: ay - 7, y: Y + 3.5, 'text-anchor': 'end' });
			t.textContent = yf(y);
		}
	}
}

function autoDecimals(values: number[]): number {
	if (values.length < 2) return 0;
	const step = Math.abs((values[1] as number) - (values[0] as number));
	if (step >= 1) return 0;
	return Math.min(4, Math.ceil(-Math.log10(step) - 1e-9));
}

/**
 * Asa manipulable: zona táctil invisible amplia + cuerpo visible + halo de
 * selección. El preset añade su geometría dentro de `body`.
 */
export class Handle {
	readonly g: SVGGElement;
	readonly hit: SVGCircleElement;
	readonly halo: SVGCircleElement;
	readonly body: SVGGElement;
	private pos: Point = { x: 0, y: 0 };

	constructor(
		parent: Element,
		cls: string,
		private readonly visualRadius: number,
	) {
		this.g = svgEl(parent, 'g', { class: `pl-handle ${cls}` });
		this.halo = svgEl(this.g, 'circle', { class: 'pl-handle-halo', r: visualRadius + 5 });
		this.body = svgEl(this.g, 'g', { class: 'pl-handle-body' });
		this.hit = svgEl(this.g, 'circle', { class: 'pl-handle-hit', r: visualRadius + 8 });
	}

	moveTo(p: Point): this {
		this.pos = { x: p.x, y: p.y };
		this.g.setAttribute('transform', `translate(${r2(p.x)} ${r2(p.y)})`);
		return this;
	}

	get position(): Point {
		return this.pos;
	}

	/** Ajusta la zona táctil a un mínimo en píxeles reales. */
	setHitRadius(sceneRadius: number): void {
		this.hit.setAttribute('r', r2(Math.max(this.visualRadius + 6, sceneRadius)));
	}

	visible(v: boolean): this {
		show(this.g, v);
		return this;
	}
}
