import type { ResourceScope } from '../../core/lifecycle';
import type { Point, Size } from '../../core/types';
import type { MathEngine } from '../math/math-renderer';
import { MathLabelLayer } from './math-layer';
import { svgEl, SVG_NS } from './svg';

export type LayerName = 'grid' | 'back' | 'main' | 'front' | 'handles';

export interface SceneOptions extends Size {
	/** Descripción accesible de la figura. */
	label: string;
	/** Clase CSS adicional para el contenedor. */
	className?: string;
}

/**
 * Interfaz común de un motor de representación. La V1 implementa SVG; un
 * motor Canvas/WebGL futuro solo tiene que cumplir este contrato para que
 * el anfitrión lo monte y lo libere igual.
 */
export interface RenderSurface {
	readonly kind: 'svg' | 'canvas' | 'webgl';
	readonly stage: HTMLElement;
	readonly size: Size;
	clientToScene(clientX: number, clientY: number): Point;
	readonly pxPerUnit: number;
	onResize(cb: () => void): () => void;
}

/**
 * Escena SVG con viewBox fijo, capas ordenadas y una capa HTML superpuesta
 * para etiquetas LaTeX. Mantiene su relación de aspecto en cualquier ancho.
 */
export class SvgScene implements RenderSurface {
	readonly kind = 'svg' as const;
	readonly stage: HTMLDivElement;
	readonly svg: SVGSVGElement;
	readonly defs: SVGDefsElement;
	readonly layers: Record<LayerName, SVGGElement>;
	readonly labels: MathLabelLayer;
	readonly size: Size;
	private scale = 1;
	private readonly resizeListeners = new Set<() => void>();

	constructor(
		parent: HTMLElement,
		opts: SceneOptions,
		private readonly scope: ResourceScope,
		engine: MathEngine,
		readonly uid: string,
		onMathRendered: () => void,
		mathThrottleMs = 0,
	) {
		this.size = { width: opts.width, height: opts.height };
		const doc = parent.ownerDocument;
		this.stage = doc.createElement('div');
		this.stage.className = 'pl-stage' + (opts.className ? ` ${opts.className}` : '');
		this.stage.style.aspectRatio = `${opts.width} / ${opts.height}`;
		// Varias escenas en fila: anchos proporcionales a su relación de aspecto → misma altura.
		this.stage.style.flexGrow = (opts.width / opts.height).toFixed(4);
		this.stage.style.setProperty('--pl-stage-ratio', String(opts.width / opts.height));
		parent.appendChild(this.stage);

		this.svg = doc.createElementNS(SVG_NS, 'svg');
		this.svg.setAttribute('viewBox', `0 0 ${opts.width} ${opts.height}`);
		this.svg.setAttribute('preserveAspectRatio', 'xMidYMid meet');
		this.svg.setAttribute('role', 'img');
		this.svg.setAttribute('aria-label', opts.label);
		this.svg.classList.add('pl-svg');
		this.stage.appendChild(this.svg);

		this.defs = svgEl(this.svg, 'defs');
		this.layers = {
			grid: svgEl(this.svg, 'g', { class: 'pl-layer-grid' }),
			back: svgEl(this.svg, 'g', { class: 'pl-layer-back' }),
			main: svgEl(this.svg, 'g', { class: 'pl-layer-main' }),
			front: svgEl(this.svg, 'g', { class: 'pl-layer-front' }),
			handles: svgEl(this.svg, 'g', { class: 'pl-layer-handles' }),
		};
		this.labels = new MathLabelLayer(this.stage, engine, this.size, scope, onMathRendered, mathThrottleMs);

		this.measure();
		scope.observeResize(this.stage, () => {
			if (this.measure()) for (const cb of [...this.resizeListeners]) cb();
		});
		scope.add(() => {
			this.resizeListeners.clear();
			this.stage.remove();
		});
	}

	/** Identificador único en el documento (para defs, clipPaths…). */
	id(local: string): string {
		return `${this.uid}-${local}`;
	}

	/** Píxeles CSS por unidad de escena (≈ ancho mostrado / ancho del viewBox). */
	get pxPerUnit(): number {
		return this.scale;
	}

	onResize(cb: () => void): () => void {
		this.resizeListeners.add(cb);
		return () => this.resizeListeners.delete(cb);
	}

	/** Coordenadas de pantalla → coordenadas de escena (viewBox). */
	clientToScene(clientX: number, clientY: number): Point {
		const r = this.svg.getBoundingClientRect();
		const W = this.size.width;
		const H = this.size.height;
		if (!(r.width > 0) || !(r.height > 0)) return { x: clientX - r.left, y: clientY - r.top };
		const s = Math.min(r.width / W, r.height / H);
		const offX = (r.width - W * s) / 2;
		const offY = (r.height - H * s) / 2;
		return { x: (clientX - r.left - offX) / s, y: (clientY - r.top - offY) / s };
	}

	/** Tamaño mínimo (en unidades de escena) para una zona táctil de `px` píxeles. */
	touchRadius(px = 22): number {
		return px / Math.max(this.scale, 0.05);
	}

	private measure(): boolean {
		const r = this.stage.getBoundingClientRect();
		const s = r.width > 0 ? r.width / this.size.width : 1;
		if (Math.abs(s - this.scale) < 1e-3) return false;
		this.scale = s;
		this.stage.style.setProperty('--pl-scale', s.toFixed(4));
		return true;
	}

	/** Releer el tamaño (por ejemplo, al mostrar un laboratorio que estaba oculto). */
	remeasure(): void {
		if (this.measure()) for (const cb of [...this.resizeListeners]) cb();
	}

	get disposed(): boolean {
		return this.scope.isDisposed;
	}
}
