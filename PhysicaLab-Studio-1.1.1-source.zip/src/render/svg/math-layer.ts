import type { MathEngine } from '../math/math-renderer';
import { MathSlot } from '../math/math-renderer';
import type { Point, Size } from '../../core/types';
import type { ResourceScope } from '../../core/lifecycle';

/**
 * Posición de la etiqueta respecto del punto ancla (puntos cardinales):
 * `n` = encima, `e` = a la derecha, `c` = centrada sobre el punto…
 */
export type Place = 'c' | 'n' | 's' | 'e' | 'w' | 'ne' | 'nw' | 'se' | 'sw';

/** Colores semánticos disponibles para figuras y etiquetas. */
export type ColorToken = 'text' | 'muted' | 'blue' | 'green' | 'amber' | 'violet' | 'rose' | 'axis';

const TRANSLATE: Record<Place, [string, string, number, number]> = {
	c: ['-50%', '-50%', 0, 0],
	n: ['-50%', '-100%', 0, -1],
	s: ['-50%', '0%', 0, 1],
	e: ['0%', '-50%', 1, 0],
	w: ['-100%', '-50%', -1, 0],
	ne: ['0%', '-100%', 0.7, -0.7],
	nw: ['-100%', '-100%', -0.7, -0.7],
	se: ['0%', '0%', 0.7, 0.7],
	sw: ['-100%', '0%', -0.7, 0.7],
};

/**
 * Etiqueta matemática superpuesta a la figura SVG. Se posiciona en
 * porcentaje del viewBox, de modo que sigue a la geometría al cambiar el
 * tamaño del contenedor sin recalcular nada en JavaScript.
 */
export class MathLabel {
	readonly el: HTMLDivElement;
	private readonly slot: MathSlot;
	private place: Place = 'c';
	private gap = 6;
	private lastPos: Point = { x: -1e9, y: -1e9 };

	constructor(
		layer: HTMLElement,
		engine: MathEngine,
		private readonly size: Size,
		onRendered: () => void,
		throttleMs: number,
	) {
		this.el = layer.ownerDocument.createElement('div');
		this.el.className = 'pl-label';
		layer.appendChild(this.el);
		this.slot = new MathSlot(this.el, engine, false, onRendered, throttleMs, layer.ownerDocument.defaultView ?? window);
	}

	/** Cambia la expresión (solo re-tipografía si cambia el texto). */
	tex(tex: string): this {
		this.slot.set(tex);
		return this;
	}

	/** Coloca la etiqueta en coordenadas de escena. */
	at(p: Point, place: Place = this.place, gap = this.gap): this {
		if (p.x === this.lastPos.x && p.y === this.lastPos.y && place === this.place && gap === this.gap) return this;
		this.lastPos = { x: p.x, y: p.y };
		this.place = place;
		this.gap = gap;
		const [tx, ty, gx, gy] = TRANSLATE[place];
		const s = this.el.style;
		s.left = `${((p.x / this.size.width) * 100).toFixed(3)}%`;
		s.top = `${((p.y / this.size.height) * 100).toFixed(3)}%`;
		s.transform = `translate(${tx}, ${ty}) translate(${(gx * gap).toFixed(1)}px, ${(gy * gap).toFixed(1)}px)`;
		return this;
	}

	color(token: ColorToken | null): this {
		for (const c of Array.from(this.el.classList)) if (c.startsWith('pl-c-')) this.el.classList.remove(c);
		if (token) this.el.classList.add(`pl-c-${token}`);
		return this;
	}

	/** Tamaño relativo: `sm` para cotas y marcas, `md` normal. */
	fontSize(size: 'sm' | 'md' | 'lg'): this {
		this.el.classList.toggle('pl-label-sm', size === 'sm');
		this.el.classList.toggle('pl-label-lg', size === 'lg');
		return this;
	}

	visible(v: boolean): this {
		this.el.classList.toggle('pl-hidden', !v);
		return this;
	}

	get currentTex(): string | null {
		return this.slot.tex;
	}

	flush(): void {
		this.slot.flush();
	}

	dispose(): void {
		this.slot.dispose();
		this.el.remove();
	}
}

/** Capa HTML que contiene todas las etiquetas matemáticas de una escena. */
export class MathLabelLayer {
	readonly el: HTMLDivElement;
	private readonly labels = new Map<string, MathLabel>();

	constructor(
		stage: HTMLElement,
		private readonly engine: MathEngine,
		private readonly size: Size,
		scope: ResourceScope,
		private readonly onRendered: () => void,
		private readonly throttleMs = 0,
	) {
		this.el = stage.ownerDocument.createElement('div');
		this.el.className = 'pl-math-layer';
		this.el.setAttribute('aria-hidden', 'true');
		stage.appendChild(this.el);
		scope.add(() => this.clear());
	}

	/** Crea (o recupera) la etiqueta `id`. */
	label(id: string, tex?: string): MathLabel {
		let l = this.labels.get(id);
		if (!l) {
			l = new MathLabel(this.el, this.engine, this.size, this.onRendered, this.throttleMs);
			l.el.dataset.label = id;
			this.labels.set(id, l);
		}
		if (tex !== undefined) l.tex(tex);
		return l;
	}

	get(id: string): MathLabel | undefined {
		return this.labels.get(id);
	}

	remove(id: string): void {
		this.labels.get(id)?.dispose();
		this.labels.delete(id);
	}

	/** Fuerza la tipografía pendiente (al soltar un arrastre). */
	flush(): void {
		for (const l of this.labels.values()) l.flush();
	}

	clear(): void {
		for (const l of this.labels.values()) l.dispose();
		this.labels.clear();
	}

	get count(): number {
		return this.labels.size;
	}
}
