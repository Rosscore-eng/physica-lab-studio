export interface RuntimeBlock {
	source: string;
	from: number;
	to: number;
	contentFrom: number;
	contentTo: number;
	id: string;
}

interface SourceManifest {
	data: Record<string, unknown>;
	/** Offset of the first header JSON; undefined for external manifests. */
	headerFrom?: number;
	headerTo?: number;
}

function sourceManifest(source: string): SourceManifest | undefined {
	try {
		const firstLine = source.split(/\r?\n/, 1)[0];
		const header = /^([ \t]*<!--\s*physlab:v1\s+)(\{.*\})([ \t]*-->[ \t]*)$/.exec(firstLine);
		const data: unknown = JSON.parse(header ? header[2] : source);
		if (!data || typeof data !== 'object' || Array.isArray(data)) return undefined;
		const manifest = data as Record<string, unknown>;
		if (typeof manifest.id !== 'string' || !manifest.id.trim() || (!header && manifest.version !== 1)) return undefined;
		return {
			data: manifest,
			...(header ? { headerFrom: header[1].length, headerTo: header[1].length + header[2].length } : {}),
		};
	} catch { return undefined; }
}

/** Finds complete top-level fences while respecting outer code examples and CRLF. */
export function findRuntimeBlocks(markdown: string): RuntimeBlock[] {
	const blocks: RuntimeBlock[] = [];
	let opening: { from: number; contentFrom: number; marker: string; length: number; runtime: boolean } | undefined;
	const lines = /[^\r\n]*(?:\r\n|\n|\r|$)/g;
	for (const line of markdown.matchAll(lines)) {
		if (!line[0].length) continue;
		const text = line[0].replace(/(?:\r\n|\n|\r)$/, '');
		const from = line.index!;
		if (!opening) {
			const fence = /^ {0,3}(`{3,}|~{3,})(.*)$/.exec(text);
			if (!fence || (fence[1][0] === '`' && fence[2].includes('`'))) continue;
			opening = {
				from, contentFrom: from + line[0].length,
				marker: fence[1][0], length: fence[1].length,
				runtime: fence[2].trim() === 'physlab',
			};
			continue;
		}
		const closing = /^ {0,3}(`+|~+)[ \t]*$/.exec(text);
		if (!closing || closing[1][0] !== opening.marker || closing[1].length < opening.length) continue;
		if (opening.runtime) {
			let contentTo = from;
			if (contentTo > opening.contentFrom) {
				if (markdown.slice(contentTo - 2, contentTo) === '\r\n') contentTo -= 2;
				else if (/[\r\n]/.test(markdown[contentTo - 1])) contentTo--;
			}
			const source = markdown.slice(opening.contentFrom, contentTo);
			const manifest = sourceManifest(source);
			if (manifest) blocks.push({
				source, from: opening.from, to: from + line[0].length,
				contentFrom: opening.contentFrom, contentTo, id: manifest.data.id as string,
			});
		}
		opening = undefined;
	}
	return blocks;
}

export function snapshotRuntimeBlock(markdown: string, id: string, expectedSource: string, state: Record<string, unknown>): string {
	const matches = findRuntimeBlocks(markdown).filter((block) => block.id === id);
	if (!matches.length) throw new Error(`No se encontró el laboratorio «${id}» en la nota.`);
	if (matches.length > 1) throw new Error(`El identificador «${id}» está duplicado en la nota.`);
	const block = matches[0];
	if (expectedSource !== block.source && expectedSource.replace(/\r?\n$/, '') !== block.source) {
		throw new Error('El source del laboratorio cambió; vuelve a abrirlo antes de guardar la instantánea.');
	}
	const manifest = sourceManifest(block.source)!;
	const data = { ...manifest.data, initialState: cloneRuntimeState(state) };
	let source: string;
	if (manifest.headerFrom !== undefined && manifest.headerTo !== undefined) {
		source = block.source.slice(0, manifest.headerFrom) + JSON.stringify(data) + block.source.slice(manifest.headerTo);
	} else {
		const eol = /\r\n/.test(block.source) || /\r\n/.test(markdown) ? '\r\n' : '\n';
		source = JSON.stringify(data, null, 2).replace(/\n/g, eol);
	}
	return markdown.slice(0, block.contentFrom) + source + markdown.slice(block.contentTo);
}

export function runtimeCodeBlock(file: string): string {
	const manifest = { version: 1, id: crypto.randomUUID(), file, height: 640, features: ['2d', 'latex'], initialState: {} };
	return '```physlab\n' + JSON.stringify(manifest, null, 2) + '\n```\n';
}
import { cloneRuntimeState } from './state';

