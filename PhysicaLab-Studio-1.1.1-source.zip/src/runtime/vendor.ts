export interface VendorAdapter { read(path: string): Promise<string> }
export interface VendorBundles { katexJs?: string; katexCss?: string; threeJs?: string }

const caches = new WeakMap<VendorAdapter, Map<string, Promise<string>>>();

/** Keep bundle text local to each vault adapter; rejected reads can be repaired. */
function readBundle(adapter: VendorAdapter, path: string): Promise<string> {
	let cache = caches.get(adapter);
	if (!cache) { cache = new Map(); caches.set(adapter, cache); }
	let pending = cache.get(path);
	if (!pending) {
		const currentCache = cache;
		pending = adapter.read(path).catch((error: unknown) => {
			currentCache.delete(path);
			throw new Error(`No se pudo cargar el bundle local ${path}. Reinstala la carpeta vendor del plugin. ${error instanceof Error ? error.message : String(error)}`);
		});
		cache.set(path, pending);
	}
	return pending;
}

export async function loadVendorBundles(adapter: VendorAdapter, pluginDir: string, features: readonly string[]): Promise<VendorBundles> {
	const base = pluginDir.replace(/\\/g, '/').replace(/\/+$/, '');
	const bundles: VendorBundles = {};
	const pending: Promise<void>[] = [];
	if (features.includes('latex')) {
		pending.push(readBundle(adapter, `${base}/vendor/katex.js`).then((value) => { bundles.katexJs = value; }));
		pending.push(readBundle(adapter, `${base}/vendor/katex.css`).then((value) => { bundles.katexCss = value; }));
	}
	if (features.includes('3d')) pending.push(readBundle(adapter, `${base}/vendor/three.js`).then((value) => { bundles.threeJs = value; }));
	await Promise.all(pending);
	return bundles;
}
