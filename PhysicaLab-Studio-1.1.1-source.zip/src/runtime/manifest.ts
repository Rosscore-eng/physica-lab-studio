export type JSONValue = null | boolean | number | string | JSONValue[] | { [key: string]: JSONValue };
export interface RuntimeManifest {
	version: 1;
	id: string;
	file?: string;
	height: number;
	features: ('2d' | '3d' | 'latex')[];
	initialState: Record<string, JSONValue>;
	theme?: 'scientific-dark' | 'scientific-light' | 'obsidian';
}
export const MAX_STATE_BYTES = 32 * 1024;

function isRecord(value: unknown): value is Record<string, unknown> {
	if (!value || typeof value !== 'object' || Array.isArray(value)) return false;
	const prototype = Object.getPrototypeOf(value);
	return prototype === null || prototype === Object.prototype;
}

/** Accept only data representable by JSON, without implicit Date/toJSON conversions. */
export function isJSONRecord(value: unknown, maxBytes = MAX_STATE_BYTES): value is Record<string, JSONValue> {
	if (!isRecord(value)) return false;
	const seen = new Set<object>();
	let entries = 0;
	function valid(item: unknown, depth: number): boolean {
		if (++entries > 8192 || depth > 32) return false;
		if (item === null || typeof item === 'string' || typeof item === 'boolean') return true;
		if (typeof item === 'number') return Number.isFinite(item);
		if (typeof item !== 'object' || !item || seen.has(item)) return false;
		if (!Array.isArray(item) && !isRecord(item)) return false;
		seen.add(item);
		const result = Object.entries(item).every(([key, child]) =>
			!['__proto__', 'prototype', 'constructor'].includes(key) && valid(child, depth + 1));
		seen.delete(item);
		return result;
	}
	try {
		return valid(value, 0) && new TextEncoder().encode(JSON.stringify(value)).byteLength <= maxBytes;
	} catch { return false; }
}

/** Versioned blocks must not silently fall back to a legacy preset parser. */
export function isRuntimeSource(source: string): boolean {
	const text = source.trimStart();
	if (text.startsWith('<!-- physlab:')) return true;
	if (!text.startsWith('{')) return false;
	try {
		const value: unknown = JSON.parse(text);
		return isRecord(value) && Object.prototype.hasOwnProperty.call(value, 'version');
	} catch { return /"version"\s*:/.test(text); }
}

function assertFilePath(value: unknown): asserts value is string {
	if (typeof value !== 'string' || value.length > 1024 || !/\.html$/i.test(value) ||
		value !== value.trim() || /[\\:%?#\x00-\x1f]/.test(value) || value.startsWith('/') ||
		value.split('/').some(segment => !segment || segment !== segment.trim() || segment.endsWith('.'))) {
		throw new Error('file debe ser una ruta relativa del vault a un archivo .html, sin URL ni segmentos . o ...');
	}
}

export function parseRuntimeSource(source: string): { manifest: RuntimeManifest; html?: string } {
	if (source.length > 2 * 1024 * 1024) throw new Error('El bloque physlab supera el límite de 2 MiB. Usa un archivo HTML externo.');
	const text = source.trim();
	let raw: unknown;
	let html: string | undefined;
	try {
		if (text.startsWith('<!--')) {
			const header = /^<!--\s*physlab:v1\s+(\{[^\r\n]*\})\s*-->[ \t]*(?:\r?\n|$)/.exec(text);
			if (!header) throw new Error('Cabecera inline inválida. La primera línea debe ser <!-- physlab:v1 {…} -->.');
			raw = { version: 1, ...JSON.parse(header[1]) };
			html = text.slice(header[0].length);
		} else raw = JSON.parse(text);
	} catch (error) {
		throw new Error(`No se pudo leer el bloque physlab/v1: ${error instanceof Error ? error.message : String(error)}`);
	}
	if (!isRecord(raw) || raw.version !== 1) throw new Error('Versión de runtime no admitida; se requiere version: 1.');
	if (typeof raw.id !== 'string' || !raw.id.trim() || raw.id !== raw.id.trim() || raw.id.length > 128 || /[\x00-\x1f\x7f]/.test(raw.id)) {
		throw new Error('id debe ser un identificador estable no vacío, de hasta 128 caracteres.');
	}
	const height = raw.height ?? 520;
	if (typeof height !== 'number' || !Number.isFinite(height) || height < 200 || height > 1600) throw new Error('height debe estar entre 200 y 1600 píxeles.');
	const features = raw.features ?? [];
	if (!Array.isArray(features) || features.some(value => !['2d', '3d', 'latex'].includes(value))) throw new Error('features solo admite 2d, 3d y latex.');
	const initialState = raw.initialState ?? {};
	if (!isJSONRecord(initialState)) throw new Error('initialState debe ser un objeto JSON de hasta 32 KiB sin valores especiales.');
	if (raw.theme !== undefined && !['scientific-dark', 'scientific-light', 'obsidian'].includes(raw.theme as string)) throw new Error('Tema de laboratorio no válido.');
	if (html === undefined) assertFilePath(raw.file);
	else if (raw.file !== undefined) throw new Error('Un bloque inline no puede declarar file simultáneamente.');
	const manifest: RuntimeManifest = {
		version: 1, id: raw.id, height,
		features: [...new Set(features)] as RuntimeManifest['features'], initialState,
	};
	if (html === undefined) manifest.file = raw.file as string;
	if (raw.theme !== undefined) manifest.theme = raw.theme as RuntimeManifest['theme'];
	return html === undefined ? { manifest } : { manifest, html };
}
