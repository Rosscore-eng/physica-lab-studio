import type { RuntimeManifest } from './manifest';
import type { RuntimeAppearance, VendorBundles } from './document';
import { buildFrameDocument, buildFrameShell, SHELL_CSP } from './document';
import { isJSONRecord, MAX_STATE_BYTES } from './manifest';
export interface RuntimeFrameOptions { html: string; manifest: RuntimeManifest; initialState: Record<string, unknown>; bundles: VendorBundles; appearance?: RuntimeAppearance; onState: (state: Record<string, unknown>) => void; onError?: (message: string) => void }
export class RuntimeFrame {
	readonly iframe: HTMLIFrameElement;
	private readonly options: RuntimeFrameOptions;
	private readonly hostWindow: Window;
	private readonly hostDocument: Document;
	private readonly frameId: string;
	private nonce: string;
	private state: Record<string, unknown>;
	private paused = false;
	private manuallyPaused = false;
	private visible = true;
	private destroyed = false;
	private intersection?: IntersectionObserver;
	private resizeObserver?: ResizeObserver;
	private readonly messageHandler = (event: MessageEvent): void => this.receive(event);
	private readonly visibilityHandler = (): void => this.updatePaused();

	constructor(container: HTMLElement, options: RuntimeFrameOptions) {
		this.options = options;
		this.hostDocument = container.ownerDocument;
		this.hostWindow = this.hostDocument.defaultView ?? window;
		this.frameId = this.makeToken();
		this.nonce = this.makeToken();
		this.state = isJSONRecord(options.initialState) ? this.copy(options.initialState) : this.copy(options.manifest.initialState);
		this.iframe = this.hostDocument.createElement('iframe');
		this.iframe.setAttribute('sandbox', 'allow-scripts');
		this.iframe.setAttribute('csp', SHELL_CSP);
		this.iframe.referrerPolicy = 'no-referrer';
		this.iframe.title = `PhysicaLab · ${options.manifest.id}`;
		this.iframe.style.width = '100%';
		this.iframe.style.height = `${Math.min(1600, Math.max(200, options.manifest.height))}px`;
		this.iframe.style.border = '0';
		this.iframe.style.display = 'block';
		this.hostWindow.addEventListener('message', this.messageHandler);
		this.hostDocument.addEventListener('visibilitychange', this.visibilityHandler);
		this.reload();
		container.appendChild(this.iframe);
		if (typeof IntersectionObserver !== 'undefined') {
			this.intersection = new IntersectionObserver(entries => {
				const entry = entries.find(value => value.target === this.iframe);
				if (entry) { this.visible = entry.isIntersecting; this.updatePaused(); }
			});
			this.intersection.observe(this.iframe);
		}
		if (typeof ResizeObserver !== 'undefined') {
			this.resizeObserver = new ResizeObserver(() => this.sendSize());
			this.resizeObserver.observe(container);
		}
		this.updatePaused();
	}

	private makeToken(): string {
		const bytes = new Uint32Array(4);
		this.hostWindow.crypto.getRandomValues(bytes);
		return Array.from(bytes, value => value.toString(16).padStart(8, '0')).join('');
	}
	private copy(value: Record<string, unknown>): Record<string, unknown> { return JSON.parse(JSON.stringify(value)) as Record<string, unknown>; }
	private reload(): void {
		const document = buildFrameDocument({ ...this.options, initialState: this.state, frameId: this.frameId, nonce: this.nonce });
		this.iframe.srcdoc = buildFrameShell(document, this.frameId, this.nonce);
	}
	private send(type: string, payload?: unknown): void {
		if (!this.destroyed) this.iframe.contentWindow?.postMessage({ ns: 'physlab', v: 1, frameId: this.frameId, nonce: this.nonce, type, payload }, '*');
	}
	private sendSize(): void {
		const bounds = this.iframe.getBoundingClientRect();
		this.send('RESIZE', { width: bounds.width, height: bounds.height });
	}
	private updatePaused(): void {
		const next = this.manuallyPaused || !this.visible || this.hostDocument.visibilityState === 'hidden';
		if (next === this.paused || this.destroyed) return;
		this.paused = next;
		this.send(next ? 'PAUSE' : 'RESUME');
	}
	private receive(event: MessageEvent): void {
		if (this.destroyed || event.source !== this.iframe.contentWindow) return;
		const message: unknown = event.data;
		if (!message || typeof message !== 'object' || Array.isArray(message)) return;
		const data = message as Record<string, unknown>;
		if (data.ns !== 'physlab' || data.v !== 1 || data.frameId !== this.frameId || data.nonce !== this.nonce) return;
		if (Object.keys(data).some(key => !['ns', 'v', 'frameId', 'nonce', 'type', 'payload'].includes(key))) return;
		if (!isJSONRecord(data, MAX_STATE_BYTES + 2048)) return;
		switch (data.type) {
			case 'READY': {
				const bounds = this.iframe.getBoundingClientRect();
				this.send('INIT', { initialState: this.snapshot(), size: { width: bounds.width, height: bounds.height } });
				if (this.paused) this.send('PAUSE');
				break;
			}
			case 'STATE_SAVE':
				if (!isJSONRecord(data.payload)) return;
				this.state = this.copy(data.payload);
				this.options.onState(this.snapshot());
				break;
			case 'ERROR': {
				if (!isJSONRecord(data.payload) || typeof data.payload.message !== 'string') return;
				this.options.onError?.(data.payload.message.slice(0, 2048));
				break;
			}
			case 'RESIZE_REQUEST': {
				if (!isJSONRecord(data.payload) || typeof data.payload.height !== 'number') return;
				this.iframe.style.height = `${Math.min(1600, Math.max(200, data.payload.height))}px`;
				this.sendSize();
				break;
			}
		}
	}

	snapshot(): Record<string, unknown> { return this.copy(this.state); }
	reset(): void {
		if (this.destroyed) return;
		this.send('DESTROY');
		this.state = this.copy(this.options.manifest.initialState);
		this.nonce = this.makeToken();
		this.reload();
		this.options.onState(this.snapshot());
	}
	setPaused(paused: boolean): void { this.manuallyPaused = paused; this.updatePaused(); }
	destroy(): void {
		if (this.destroyed) return;
		this.send('DESTROY');
		this.destroyed = true;
		this.hostWindow.removeEventListener('message', this.messageHandler);
		this.hostDocument.removeEventListener('visibilitychange', this.visibilityHandler);
		this.intersection?.disconnect();
		this.resizeObserver?.disconnect();
		this.iframe.remove();
	}
}
