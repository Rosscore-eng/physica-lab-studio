import { isJSONRecord } from './manifest';

const MAX_STORED_STATES = 256;

function isRecord(value: unknown): value is Record<string, unknown> {
	if (value === null || typeof value !== 'object' || Array.isArray(value)) return false;
	const prototype = Object.getPrototypeOf(value);
	return prototype === Object.prototype || prototype === null;
}

/** Strict JSON validation prevents lossy NaN/undefined/toJSON conversions. */
function validateJson(value: unknown, ancestors: Set<object>, depth: number): void {
	if (value === null || typeof value === 'string' || typeof value === 'boolean') return;
	if (typeof value === 'number' && Number.isFinite(value)) return;
	if (typeof value !== 'object' || value === null || depth > 64) throw new Error('El estado debe contener solo JSON finito.');
	if (!Array.isArray(value) && !isRecord(value)) throw new Error('El estado debe contener solo objetos JSON.');
	if (ancestors.has(value)) throw new Error('El estado no puede contener ciclos.');
	if (Object.getOwnPropertySymbols(value).length) throw new Error('El estado no puede contener símbolos.');
	ancestors.add(value);
	if (Array.isArray(value)) {
		for (let i = 0; i < value.length; i++) {
			const property = Object.getOwnPropertyDescriptor(value, String(i));
			if (!property || !('value' in property)) throw new Error('El estado no puede contener arrays incompletos ni getters.');
			validateJson(property.value, ancestors, depth + 1);
		}
	} else {
		for (const property of Object.values(Object.getOwnPropertyDescriptors(value))) {
			if (!property.enumerable) continue;
			if (!('value' in property)) throw new Error('El estado no puede contener getters.');
			validateJson(property.value, ancestors, depth + 1);
		}
	}
	ancestors.delete(value);
}

/** Shared by local persistence and explicit Markdown snapshots. */
export function cloneRuntimeState(value: unknown): Record<string, unknown> {
	if (!isRecord(value)) throw new Error('El estado debe ser un objeto JSON.');
	validateJson(value, new Set(), 0);
	// Use the exact frame contract for size, depth and prototype-key restrictions.
	if (!isJSONRecord(value)) throw new Error('El estado no cumple el contrato JSON del runtime (máximo 32 KiB).');
	const json = JSON.stringify(value);
	return JSON.parse(json) as Record<string, unknown>;
}

export function runtimeStateKey(notePath: string, id: string): string {
	return JSON.stringify([notePath, id]);
}

function parseStateKey(key: string): [string, string] | undefined {
	try {
		const parsed: unknown = JSON.parse(key);
		if (Array.isArray(parsed) && parsed.length === 2 && parsed.every((v) => typeof v === 'string')
			&& runtimeStateKey(parsed[0], parsed[1]) === key) return parsed as [string, string];
	} catch { /* Ignore corrupt persisted keys. */ }
	return undefined;
}

/** Local-only state; concurrent saves are serialized and failed writes remain dirty. */
export class RuntimeStateStore {
	private readonly states = new Map<string, Record<string, unknown>>();
	private readonly debounceMs: number;
	private timer: ReturnType<typeof setTimeout> | undefined;
	private pending: Promise<void> | undefined;
	private revision = 0;
	private savedRevision = 0;

	constructor(
		initial: unknown,
		private readonly persist: (states: Record<string, Record<string, unknown>>) => Promise<void>,
		debounceMs = 350,
	) {
		this.debounceMs = Number.isFinite(debounceMs) ? Math.max(300, debounceMs) : 350;
		if (!isRecord(initial)) return;
		for (const [key, value] of Object.entries(initial)) {
			if (!parseStateKey(key)) continue;
			try { this.states.set(key, cloneRuntimeState(value)); } catch { /* Ignore corrupt saved entries individually. */ }
			if (this.states.size >= MAX_STORED_STATES) break;
		}
	}

	get(notePath: string, id: string): Record<string, unknown> | undefined {
		const state = this.states.get(runtimeStateKey(notePath, id));
		return state === undefined ? undefined : cloneRuntimeState(state);
	}

	set(notePath: string, id: string, state: Record<string, unknown>): void {
		const copy = cloneRuntimeState(state);
		const key = runtimeStateKey(notePath, id);
		this.states.delete(key);
		this.states.set(key, copy);
		// Bound plugin data to 8 MiB at the maximum per-entry size; evict least-recently-set.
		if (this.states.size > MAX_STORED_STATES) this.states.delete(this.states.keys().next().value!);
		this.changed();
	}

	reset(notePath: string, id: string): void {
		if (this.states.delete(runtimeStateKey(notePath, id))) this.changed();
	}

	renameNote(oldPath: string, newPath: string): void {
		if (oldPath === newPath) return;
		let changed = false;
		for (const [key, state] of [...this.states]) {
			const pair = parseStateKey(key)!;
			if (pair[0] !== oldPath) continue;
			this.states.delete(key);
			this.states.set(runtimeStateKey(newPath, pair[1]), state);
			changed = true;
		}
		if (changed) this.changed();
	}

	flush(): Promise<void> {
		if (this.timer !== undefined) { clearTimeout(this.timer); this.timer = undefined; }
		if (this.pending) return this.pending;
		if (this.revision === this.savedRevision) return Promise.resolve();
		const pending = this.drain();
		this.pending = pending;
		// Attach both handlers without creating a rejected, unobserved finally promise.
		const clearPending = () => { if (this.pending === pending) this.pending = undefined; };
		void pending.then(clearPending, clearPending);
		return pending;
	}

	private changed(): void {
		this.revision++;
		if (this.timer !== undefined) clearTimeout(this.timer);
		this.timer = setTimeout(() => {
			this.timer = undefined;
			void this.flush().catch((error: unknown) => {
				console.warn('[PhysicaLab] No se pudo guardar el estado local; se conserva para reintentar.', error);
			});
		}, this.debounceMs);
	}

	private async drain(): Promise<void> {
		while (this.savedRevision !== this.revision) {
			const writingRevision = this.revision;
			const snapshot = Object.fromEntries([...this.states].map(([key, state]) => [key, cloneRuntimeState(state)]));
			await this.persist(snapshot);
			this.savedRevision = writingRevision;
		}
	}
}
