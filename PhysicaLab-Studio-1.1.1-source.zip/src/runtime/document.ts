import type { RuntimeManifest } from './manifest';
export interface VendorBundles { katexJs?: string; katexCss?: string; threeJs?: string }
export interface RuntimeAppearance { tokens: Record<string, string>; fontFamily: string }
export interface FrameDocumentOptions { html: string; manifest: RuntimeManifest; initialState: Record<string, unknown>; frameId: string; nonce: string; bundles: VendorBundles; appearance?: RuntimeAppearance }

export const FRAME_CSP = "default-src 'none'; script-src 'unsafe-inline' blob:; style-src 'unsafe-inline'; img-src data: blob:; font-src data:; connect-src 'none'; worker-src 'none'; frame-src 'none'; object-src 'none'; base-uri 'none'; form-action 'none'";
// The embedding document's policy also governs an inner frame navigating itself.
// about: permits srcdoc, while denying HTTP(S), data: and blob: frame navigation.
export const SHELL_CSP = FRAME_CSP.replace("frame-src 'none'", 'frame-src about:');

function serialize(value: unknown): string {
	return JSON.stringify(value).replace(/</g, '\\u003c').replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029');
}
function script(source: string): string { return `<script>${source.replace(/<\/script/gi, '<\\/script')}</script>`; }
function style(source: string): string { return `<style>${source.replace(/<\/style/gi, '<\\/style')}</style>`; }

/** The generated code is evaluated only by the opaque-origin iframe, never by the host. */
export function buildFrameDocument(options: FrameDocumentOptions): string {
	const appearance = options.appearance ?? { tokens: {}, fontFamily: '"Latin Modern Roman", "KaTeX_Main", serif' };
	const config = serialize({ frameId: options.frameId, nonce: options.nonce, initialState: options.initialState, theme: appearance });
	const bridge = script(`(() => {
  'use strict';
  const config = ${config};
  const events = new Map();
  let destroyed = false;
  function send(type, payload) {
    if (destroyed) return;
    const message = {ns:'physlab',v:1,frameId:config.frameId,nonce:config.nonce,type};
    if (payload !== undefined) message.payload = payload;
    parent.postMessage(message, '*');
  }
  function emit(type, payload) {
    for (const callback of [...(events.get(type) || [])]) {
      try { callback(payload); } catch (error) { send('ERROR', {message:String(error && error.message || error).slice(0,2048)}); }
    }
  }
  function dispose() {
    if (destroyed) return;
    emit('destroy'); events.clear(); destroyed = true;
  }
  addEventListener('pagehide', dispose, {once:true});
  addEventListener('unload', dispose, {once:true});
  const api = {
    apiVersion: 1, initialState: config.initialState, libs: {}, theme: config.theme,
    saveState(data) {
      try { if (new TextEncoder().encode(JSON.stringify(data)).byteLength <= 32768) send('STATE_SAVE', data); }
      catch (_) { send('ERROR', {message:'El estado no se puede serializar como JSON.'}); }
    },
    on(type, callback) {
      if (!['pause','resume','destroy','resize'].includes(type) || typeof callback !== 'function') return () => {};
      if (!events.has(type)) events.set(type, new Set());
      events.get(type).add(callback);
      return () => events.get(type)?.delete(callback);
    },
    reportError(message) { send('ERROR', {message:String(message).slice(0,2048)}); }
  };
  Object.defineProperty(window, 'PhysLab', {value:api, writable:false, configurable:false});
  addEventListener('message', event => {
    const message = event.data;
    if (destroyed || event.source !== parent || !message || message.ns !== 'physlab' || message.v !== 1 || message.frameId !== config.frameId || message.nonce !== config.nonce) return;
    switch (message.type) {
      case 'PAUSE': emit('pause'); break;
      case 'RESUME': emit('resume'); break;
      case 'RESIZE': emit('resize', message.payload); break;
      case 'INIT': if (message.payload?.size) emit('resize', message.payload.size); break;
      case 'DESTROY': dispose(); break;
    }
  });
  addEventListener('error', event => api.reportError(event.message || 'Error en el laboratorio.'));
  addEventListener('unhandledrejection', event => api.reportError(String(event.reason || 'Promesa rechazada.')));
  send('READY');
})();`);
	const cssTokens = Object.entries(appearance.tokens)
		.filter(([key, value]) => /^[a-z][a-z0-9-]*$/i.test(key) && !/[;{}<>]/.test(value))
		.map(([key, value]) => `--pl-${key}:${value}`).join(';');
	const fontFamily = /[;{}<>]/.test(appearance.fontFamily) ? 'KaTeX_Main, Georgia, serif' : appearance.fontFamily;
	const themeCss = style(`:root{${cssTokens}}*{box-sizing:border-box}body{margin:0;background:var(--pl-bg,#0d1117);color:var(--pl-text,#e6edf3);font-family:${fontFamily};line-height:1.5}input,button,select,textarea{font:inherit}canvas,svg{max-width:100%}`);
	let vendor = '';
	if (options.manifest.features.includes('latex')) {
		if (options.bundles.katexCss) vendor += style(options.bundles.katexCss);
		if (options.bundles.katexJs) vendor += script(options.bundles.katexJs);
		vendor += script('PhysLab.libs.katex=window.katex;');
	}
	if (options.manifest.features.includes('3d')) {
		if (options.bundles.threeJs) vendor += script(options.bundles.threeJs);
		vendor += script('PhysLab.libs.THREE=window.THREE;PhysLab.libs.OrbitControls=window.OrbitControls;');
	}
	// Original complete HTML is parsed only inside the frame. Keeping it intact also
	// avoids parsing untrusted images/resources in the privileged host document.
	return `<!doctype html><html><head><meta http-equiv="Content-Security-Policy" content="${FRAME_CSP}"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">${themeCss}${bridge}${vendor}</head><body>${options.html}</body></html>`;
}

/** Trusted shell: the untrusted document cannot replace its embedding CSP. */
export function buildFrameShell(innerDocument: string, frameId: string, nonce: string): string {
	const config = serialize({ innerDocument, frameId, nonce });
	const shell = script(`(() => {
  'use strict';
  const config = ${config};
  const child = document.createElement('iframe');
  child.setAttribute('sandbox','allow-scripts');
  child.setAttribute('csp',${serialize(FRAME_CSP)});
  child.referrerPolicy = 'no-referrer';
  child.title = 'PhysicaLab · documento del laboratorio';
  child.style.cssText = 'display:block;width:100%;height:100%;border:0';
  const frameTypes = ['READY','STATE_SAVE','ERROR','RESIZE_REQUEST'];
  const hostTypes = ['INIT','PAUSE','RESUME','DESTROY','RESIZE','STATE_RESTORE'];
  function valid(data, types) {
    if (!data || typeof data !== 'object' || Array.isArray(data) || data.ns !== 'physlab' || data.v !== 1 || data.frameId !== config.frameId || data.nonce !== config.nonce || !types.includes(data.type)) return false;
    if (Object.keys(data).some(key => !['ns','v','frameId','nonce','type','payload'].includes(key))) return false;
    try { return new TextEncoder().encode(JSON.stringify(data)).byteLength <= 34816; } catch (_) { return false; }
  }
  addEventListener('message', event => {
    if (event.source === child.contentWindow && valid(event.data, frameTypes)) parent.postMessage(event.data,'*');
    else if (event.source === parent && valid(event.data, hostTypes)) child.contentWindow?.postMessage(event.data,'*');
  });
  child.srcdoc = config.innerDocument;
  document.body.appendChild(child);
})();`);
	return `<!doctype html><html><head><meta http-equiv="Content-Security-Policy" content="${SHELL_CSP}"><meta charset="utf-8"><style>html,body{margin:0;width:100%;height:100%;overflow:hidden}</style></head><body>${shell}</body></html>`;
}
