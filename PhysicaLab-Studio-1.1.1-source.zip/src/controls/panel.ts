import type { ResourceScope, AnimationClock } from '../core/lifecycle';
import { clamp, decimalsOf, fmt } from '../core/numeric';
import type { ParamStore } from '../core/store';
import type { ChangeSource, NumberParamSpec, ParamSpec } from '../core/types';
import type { MathEngine } from '../render/math/math-renderer';
import { iconSvg, type IconName } from './icons';

const LOG_STEPS = 1000;

export interface ButtonOptions {
	icon?: IconName;
	title?: string;
	/** Estilo discreto (secundario). */
	quiet?: boolean;
}

/** API del panel que ven los presets. */
export interface PanelApi {
	/** Botón de acción propio del preset (p. ej. «Animar h → 0»). */
	addButton(label: string, onClick: () => void, opts?: ButtonOptions): HTMLButtonElement;
	/** Controles de reproducción para un reloj de animación. */
	addAnimationControls(clock: AnimationClock, opts?: { label?: string; onRestart?: () => void; speeds?: number[] }): void;
	/** Nota breve bajo los controles (texto plano). */
	addNote(text: string): HTMLElement;
}

interface Binding {
	spec: ParamSpec;
	row: HTMLElement;
	refresh(source: ChangeSource): void;
}

/**
 * Panel de parámetros generado a partir de las especificaciones del
 * almacén. Escribe en el almacén y se actualiza desde él (sincronía
 * bidireccional con el arrastre).
 */
export class ControlPanel implements PanelApi {
	readonly el: HTMLElement;
	private readonly body: HTMLElement;
	private readonly actions: HTMLElement;
	private readonly bindings: Binding[] = [];
	private readonly doc: Document;

	constructor(
		parent: HTMLElement,
		private readonly store: ParamStore,
		private readonly engine: MathEngine,
		private readonly scope: ResourceScope,
		private readonly onMathRendered: () => void,
	) {
		this.doc = parent.ownerDocument;
		this.el = this.make('div', 'pl-panel', parent);
		this.el.setAttribute('role', 'group');
		this.el.setAttribute('aria-label', 'Parámetros del laboratorio');
		this.body = this.make('div', 'pl-panel-body', this.el);
		this.actions = this.make('div', 'pl-panel-actions', this.el);
		this.build();
		scope.add(
			store.subscribe((changed, source) => {
				for (const b of this.bindings) {
					if (changed.has(b.spec.id) || hasRange(b.spec)) b.refresh(source);
				}
			}),
		);
		scope.add(() => this.el.remove());
	}

	/* ── API para presets ────────────────────────────────────── */

	addButton(label: string, onClick: () => void, opts: ButtonOptions = {}): HTMLButtonElement {
		const b = this.make('button', 'pl-btn' + (opts.quiet ? ' pl-btn-quiet' : ''), this.actions) as HTMLButtonElement;
		b.type = 'button';
		if (opts.icon) b.appendChild(iconSvg(this.doc, opts.icon));
		const span = this.make('span', 'pl-btn-label', b);
		span.textContent = label;
		if (opts.title) b.title = opts.title;
		this.scope.listen(b, 'click', (ev: MouseEvent) => {
			ev.preventDefault();
			onClick();
		});
		return b;
	}

	addAnimationControls(clock: AnimationClock, opts: { label?: string; onRestart?: () => void; speeds?: number[] } = {}): void {
		const wrap = this.make('div', 'pl-anim', this.actions);
		const play = this.make('button', 'pl-btn pl-btn-play', wrap) as HTMLButtonElement;
		play.type = 'button';
		const label = opts.label ?? 'Animación';
		const paint = (playing: boolean): void => {
			play.replaceChildren(iconSvg(this.doc, playing ? 'pause' : 'play'));
			const s = this.make('span', 'pl-btn-label', play);
			s.textContent = playing ? 'Pausar' : 'Reproducir';
			play.setAttribute('aria-pressed', String(playing));
			play.title = `${playing ? 'Pausar' : 'Reproducir'}: ${label}`;
		};
		paint(clock.playing);
		this.scope.add(clock.onChange(paint));
		this.scope.listen(play, 'click', () => clock.toggle());
		if (opts.onRestart) {
			const restart = opts.onRestart;
			const rb = this.make('button', 'pl-btn pl-btn-quiet', wrap) as HTMLButtonElement;
			rb.type = 'button';
			rb.title = 'Reiniciar la animación';
			rb.setAttribute('aria-label', 'Reiniciar la animación');
			rb.appendChild(iconSvg(this.doc, 'stepBack'));
			this.scope.listen(rb, 'click', () => restart());
		}
		const speeds = opts.speeds ?? [0.25, 0.5, 1, 2];
		if (speeds.length > 1) {
			const sel = this.make('select', 'pl-select pl-speed', wrap) as HTMLSelectElement;
			sel.title = 'Velocidad de la animación';
			sel.setAttribute('aria-label', 'Velocidad de la animación');
			for (const s of speeds) {
				const o = this.make('option', '', sel) as HTMLOptionElement;
				o.value = String(s);
				o.textContent = `×${s}`;
				if (s === clock.speed) o.selected = true;
			}
			this.scope.listen(sel, 'change', () => {
				const v = Number(sel.value);
				if (Number.isFinite(v) && v > 0) clock.speed = v;
			});
		}
	}

	addNote(text: string): HTMLElement {
		const n = this.make('p', 'pl-panel-note', this.el);
		n.textContent = text;
		return n;
	}

	/** Número de controles generados (pruebas). */
	get controlCount(): number {
		return this.bindings.length;
	}

	/* ── Construcción ────────────────────────────────────────── */

	private build(): void {
		let currentGroup: string | undefined;
		let groupEl: HTMLElement = this.body;
		for (const spec of this.store.specList()) {
			if (spec.control === 'none') continue;
			const pres = this.store.getPresentation(spec.id);
			if (!pres.visible) continue;
			if (spec.group && spec.group !== currentGroup) {
				currentGroup = spec.group;
				groupEl = this.make('div', 'pl-group', this.body);
				const h = this.make('div', 'pl-group-title', groupEl);
				h.textContent = spec.group;
			}
			const b =
				spec.type === 'number'
					? this.numberControl(spec, groupEl)
					: spec.type === 'boolean'
						? this.toggleControl(spec, groupEl)
						: this.selectControl(spec, groupEl);
			if (pres.locked) {
				b.row.classList.add('pl-locked');
				for (const i of Array.from(b.row.querySelectorAll('input,select'))) (i as HTMLInputElement).disabled = true;
			}
			this.bindings.push(b);
		}
	}

	private labelEl(spec: ParamSpec, parent: HTMLElement, forId?: string): HTMLElement {
		const lab = this.make('label', 'pl-ctl-label', parent) as HTMLLabelElement;
		if (forId) lab.htmlFor = forId;
		lab.title = spec.description ? `${spec.name} — ${spec.description}` : spec.name;
		if (spec.label) {
			const m = this.make('span', 'pl-ctl-math', lab);
			m.appendChild(this.engine.render(spec.label, false));
			this.onMathRendered();
			const n = this.make('span', 'pl-ctl-name', lab);
			n.textContent = spec.name;
		} else {
			const n = this.make('span', 'pl-ctl-name pl-ctl-name-only', lab);
			n.textContent = spec.name;
		}
		return lab;
	}

	private numberControl(spec: NumberParamSpec, parent: HTMLElement): Binding {
		const row = this.make('div', 'pl-ctl pl-ctl-number', parent);
		row.dataset.param = spec.id;
		const id = `${uidPrefix()}-${spec.id}`;
		this.labelEl(spec, row, id);
		const line = this.make('div', 'pl-ctl-line', row);
		const slider = this.make('input', 'pl-slider', line) as HTMLInputElement;
		slider.type = 'range';
		slider.id = id;
		slider.setAttribute('aria-label', spec.name);
		const num = this.make('input', 'pl-num', line) as HTMLInputElement;
		// Texto con teclado decimal: admite coma o punto en cualquier configuración regional.
		num.type = 'text';
		num.inputMode = 'decimal';
		num.autocomplete = 'off';
		num.spellcheck = false;
		num.setAttribute('aria-label', `${spec.name} (valor)`);
		if (spec.unit || spec.unitText) {
			const u = this.make('span', 'pl-unit', line);
			if (spec.unit) {
				u.appendChild(this.engine.render(spec.unit, false));
				this.onMathRendered();
			} else u.textContent = spec.unitText ?? '';
		}
		const log = spec.scale === 'log';
		const decimals = spec.precision ?? decimalsOf(spec.step);

		const toSlider = (v: number, min: number, max: number): number =>
			log ? Math.round((LOG_STEPS * Math.log(v / min)) / Math.log(max / min)) : v;
		const fromSlider = (s: number, min: number, max: number): number =>
			log ? min * Math.pow(max / min, s / LOG_STEPS) : s;

		const applyRange = (): { min: number; max: number } => {
			const r = this.store.range(spec.id);
			if (log) {
				slider.min = '0';
				slider.max = String(LOG_STEPS);
				slider.step = '1';
			} else {
				slider.min = String(r.min);
				slider.max = String(r.max);
				slider.step = String(spec.step);
			}
			num.title = `${spec.name}: entre ${fmt(r.min, decimals)} y ${fmt(r.max, decimals)}`;
			return r;
		};

		const refresh = (source: ChangeSource): void => {
			const r = applyRange();
			const v = this.store.num(spec.id);
			slider.value = String(toSlider(v, r.min, r.max));
			const shown = log ? formatSig(v) : fmt(v, decimals);
			if (!(source === 'panel' && this.doc.activeElement === num)) num.value = shown;
			slider.setAttribute('aria-valuetext', `${shown}${spec.unitText ? ' ' + spec.unitText : ''}`);
		};

		this.scope.listen(slider, 'input', () => {
			const r = this.store.range(spec.id);
			const v = fromSlider(Number(slider.value), r.min, r.max);
			this.store.set(spec.id, v, 'panel');
			refresh('init');
		});
		const commit = (): void => {
			const raw = num.value.replace(',', '.');
			const v = Number(raw);
			if (raw.trim() === '' || !Number.isFinite(v)) {
				refresh('init');
				return;
			}
			const r = this.store.range(spec.id);
			this.store.set(spec.id, clamp(v, r.min, r.max), 'panel');
			refresh('init');
		};
		this.scope.listen(num, 'change', commit);
		this.scope.listen(num, 'keydown', (ev: KeyboardEvent) => {
			if (ev.key === 'Enter') {
				ev.preventDefault();
				commit();
			}
		});
		refresh('init');
		return { spec, row, refresh };
	}

	private toggleControl(spec: ParamSpec & { type: 'boolean' }, parent: HTMLElement): Binding {
		const row = this.make('div', 'pl-ctl pl-ctl-toggle', parent);
		row.dataset.param = spec.id;
		const id = `${uidPrefix()}-${spec.id}`;
		const input = this.make('input', 'pl-switch', row) as HTMLInputElement;
		input.type = 'checkbox';
		input.id = id;
		input.setAttribute('role', 'switch');
		this.labelEl(spec, row, id);
		const refresh = (): void => {
			input.checked = this.store.bool(spec.id);
			input.setAttribute('aria-checked', String(input.checked));
		};
		this.scope.listen(input, 'change', () => {
			this.store.set(spec.id, input.checked, 'panel');
			refresh();
		});
		refresh();
		return { spec, row, refresh };
	}

	private selectControl(spec: ParamSpec & { type: 'enum' }, parent: HTMLElement): Binding {
		const row = this.make('div', 'pl-ctl pl-ctl-select', parent);
		row.dataset.param = spec.id;
		const id = `${uidPrefix()}-${spec.id}`;
		this.labelEl(spec, row, id);
		const sel = this.make('select', 'pl-select', row) as HTMLSelectElement;
		sel.id = id;
		for (const o of spec.options) {
			const opt = this.make('option', '', sel) as HTMLOptionElement;
			opt.value = o.value;
			opt.textContent = o.label;
		}
		const refresh = (): void => {
			sel.value = this.store.str(spec.id);
		};
		this.scope.listen(sel, 'change', () => {
			this.store.set(spec.id, sel.value, 'panel');
			refresh();
		});
		refresh();
		return { spec, row, refresh };
	}

	private make(tag: string, cls: string, parent: HTMLElement): HTMLElement {
		const el = this.doc.createElement(tag);
		if (cls) el.className = cls;
		parent.appendChild(el);
		return el;
	}
}

function hasRange(spec: ParamSpec): boolean {
	return spec.type === 'number' && !!spec.range;
}

function formatSig(v: number): string {
	if (v === 0) return '0';
	const a = Math.abs(v);
	const d = a >= 100 ? 0 : a >= 10 ? 1 : a >= 1 ? 2 : Math.min(6, Math.ceil(-Math.log10(a)) + 2);
	return fmt(v, d);
}

let uidCounter = 0;
function uidPrefix(): string {
	uidCounter = (uidCounter + 1) % 1e9;
	return `pl-ctl-${uidCounter}`;
}
