/**
 * Iconos de línea propios (24×24, trazo 2), para no depender de la API de
 * Obsidian dentro del núcleo.
 */
const PATHS = {
	play: 'M8 5.5v13l10-6.5z',
	pause: 'M8 5v14M16 5v14',
	reset: 'M3 12a9 9 0 1 0 3-6.7M3 4v5h5',
	save: 'M5 3h11l3 3v13a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2zM8 3v6h7V3M8 21v-7h8v7',
	expand: 'M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5',
	copy: 'M9 9h11v11H9zM5 15H4V4h11v1',
	panel: 'M4 6h16M4 12h16M4 18h16M9 4v4M15 10v4M7 16v4',
	chevron: 'M6 9l6 6 6-6',
	stepBack: 'M18 5.5v13l-9-6.5zM6 5v14',
	target: 'M12 3v4M12 17v4M3 12h4M17 12h4M12 12h.01',
	flask: 'M9 3h6M10 3v6L4.5 18.5A1.7 1.7 0 0 0 6 21h12a1.7 1.7 0 0 0 1.5-2.5L14 9V3M7.5 15h9',
	info: 'M12 8h.01M11 12h1v5h1M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18z',
} as const;

export type IconName = keyof typeof PATHS;

export function iconSvg(doc: Document, name: IconName): SVGSVGElement {
	const NS = 'http://www.w3.org/2000/svg';
	const svg = doc.createElementNS(NS, 'svg');
	svg.setAttribute('viewBox', '0 0 24 24');
	svg.setAttribute('width', '16');
	svg.setAttribute('height', '16');
	svg.setAttribute('aria-hidden', 'true');
	svg.classList.add('pl-icon');
	const p = doc.createElementNS(NS, 'path');
	p.setAttribute('d', PATHS[name]);
	if (name === 'play' || name === 'stepBack') p.classList.add('pl-icon-fill');
	svg.appendChild(p);
	return svg;
}
