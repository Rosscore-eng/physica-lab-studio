/**
 * Sistema de tokens de color. Las figuras nunca usan colores literales:
 * usan clases CSS que leen estas variables (`--pl-*`).
 */

export type ThemeId = 'scientific-dark' | 'scientific-light' | 'obsidian';

export const THEME_IDS: readonly ThemeId[] = ['scientific-dark', 'scientific-light', 'obsidian'];

export const THEME_LABEL: Record<ThemeId, string> = {
	'scientific-dark': 'Scientific Dark',
	'scientific-light': 'Scientific Light (papel)',
	obsidian: 'Seguir el tema de Obsidian',
};

export interface ThemeTokens {
	bg: string;
	surface: string;
	surface2: string;
	border: string;
	text: string;
	muted: string;
	grid: string;
	axis: string;
	blue: string;
	green: string;
	amber: string;
	violet: string;
	rose: string;
}

export const TOKEN_KEYS: readonly (keyof ThemeTokens)[] = [
	'bg',
	'surface',
	'surface2',
	'border',
	'text',
	'muted',
	'grid',
	'axis',
	'blue',
	'green',
	'amber',
	'violet',
	'rose',
];

export const TOKEN_LABEL: Record<keyof ThemeTokens, string> = {
	bg: 'Fondo de la figura',
	surface: 'Superficie',
	surface2: 'Superficie secundaria',
	border: 'Bordes',
	text: 'Texto principal',
	muted: 'Texto secundario',
	grid: 'Rejilla',
	axis: 'Ejes',
	blue: 'Azul científico',
	green: 'Verde suave',
	amber: 'Ámbar',
	violet: 'Violeta tenue',
	rose: 'Rosa (cargas negativas, alertas)',
};

export const THEMES: Record<Exclude<ThemeId, 'obsidian'>, ThemeTokens> = {
	'scientific-dark': {
		bg: '#0D1117',
		surface: '#161B22',
		surface2: '#1C2230',
		border: '#30363D',
		text: '#E6EDF3',
		muted: '#8B949E',
		grid: '#1F2630',
		axis: '#6E7681',
		blue: '#79B8FF',
		green: '#7EE2A8',
		amber: '#F0C674',
		violet: '#C4A7E7',
		rose: '#F2A7A7',
	},
	'scientific-light': {
		bg: '#FFFFFF',
		surface: '#F6F8FA',
		surface2: '#EEF1F4',
		border: '#D0D7DE',
		text: '#1F2328',
		muted: '#59636E',
		grid: '#EAEEF2',
		axis: '#8C959F',
		blue: '#0A5CC2',
		green: '#1A7F4B',
		amber: '#9A6700',
		violet: '#6E40C9',
		rose: '#B42318',
	},
};

/** Variables de Obsidian equivalentes para el tema «obsidian». */
const OBSIDIAN_VARS: ThemeTokens = {
	bg: 'var(--background-primary)',
	surface: 'var(--background-secondary)',
	surface2: 'var(--background-modifier-hover)',
	border: 'var(--background-modifier-border)',
	text: 'var(--text-normal)',
	muted: 'var(--text-muted)',
	grid: 'var(--background-modifier-border)',
	axis: 'var(--text-faint)',
	blue: 'var(--color-blue)',
	green: 'var(--color-green)',
	amber: 'var(--color-yellow)',
	violet: 'var(--color-purple)',
	rose: 'var(--color-red)',
};

const HEX = /^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/;

export function isHexColor(v: unknown): v is string {
	return typeof v === 'string' && HEX.test(v.trim());
}

export function isThemeId(v: unknown): v is ThemeId {
	return typeof v === 'string' && (THEME_IDS as readonly string[]).includes(v);
}

/** Tokens resueltos para un tema, con reemplazos opcionales (solo colores hex válidos). */
export function resolveTokens(theme: ThemeId, overrides: Partial<Record<keyof ThemeTokens, string>> = {}): ThemeTokens {
	const base = theme === 'obsidian' ? OBSIDIAN_VARS : THEMES[theme];
	const out: ThemeTokens = { ...base };
	for (const k of TOKEN_KEYS) {
		const o = overrides[k];
		if (isHexColor(o)) out[k] = o.trim();
	}
	return out;
}

/** Escribe los tokens como variables CSS en el elemento raíz del laboratorio. */
export function applyTheme(el: HTMLElement, theme: ThemeId, overrides: Partial<Record<keyof ThemeTokens, string>> = {}): void {
	const tokens = resolveTokens(theme, overrides);
	for (const k of TOKEN_KEYS) el.style.setProperty(`--pl-${k}`, tokens[k]);
	for (const id of THEME_IDS) el.classList.toggle(`pl-theme-${id}`, id === theme);
}
