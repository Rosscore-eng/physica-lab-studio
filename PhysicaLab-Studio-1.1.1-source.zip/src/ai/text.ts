/**
 * Utilidades de texto del generador sin IA (funciones puras, sin DOM).
 *
 * `prepare` deja el texto en ASCII legible conservando mayúsculas (los
 * símbolos «C», «m» o «M» importan en las unidades); `fold` además lo pasa
 * a minúsculas para buscar palabras clave.
 */

const GREEK: Record<string, string> = {
	α: 'alpha',
	β: 'beta',
	γ: 'gamma',
	δ: 'delta',
	ε: 'epsilon',
	θ: 'theta',
	λ: 'lambda',
	π: 'pi',
	ρ: 'rho',
	σ: 'sigma',
	τ: 'tau',
	φ: 'phi',
	ω: 'omega',
	Δ: 'Delta',
	Θ: 'Theta',
};

const SUPERSCRIPT: Record<string, string> = {
	'⁰': '0',
	'¹': '1',
	'²': '2',
	'³': '3',
	'⁴': '4',
	'⁵': '5',
	'⁶': '6',
	'⁷': '7',
	'⁸': '8',
	'⁹': '9',
	'⁻': '-',
	'⁺': '+',
};

/** Texto en ASCII con mayúsculas: «µC» → «uC», «kΩ» → «kohm», «θ₀» → «theta0», «10⁻⁶» → «10^-6». */
export function prepare(input: string): string {
	return (
		input
			.replace(/[   \t\r\n]+/g, ' ')
			.replace(/[−‒–—]/g, '-')
			.replace(/[µμ]/g, 'u')
			.replace(/[ΩΩ]/g, 'ohm')
			.replace(/[αβγδεθλπρστφωΔΘ]/g, (c) => GREEK[c] ?? c)
			.replace(/[₀-₉]/g, (c) => String(c.charCodeAt(0) - 0x2080))
			// Una tira de superíndices es un exponente: x² → x^2, 10⁻⁶ → 10^-6.
			.replace(/[⁰¹²³⁴⁵⁶⁷⁸⁹⁻⁺]+/g, (s) => '^' + [...s].map((c) => SUPERSCRIPT[c] ?? c).join(''))
			.replace(/[’‘´`]/g, "'")
			.replace(/[“”«»]/g, '"')
			.normalize('NFD')
			.replace(/[̀-ͯ]/g, '')
	);
}

/** `prepare` en minúsculas, para comparar palabras. */
export function fold(input: string): string {
	return prepare(input).toLowerCase();
}

function escapeRegex(s: string): string {
	return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

const termCache = new Map<string, RegExp>();

/**
 * Expresión de un término de búsqueda (ya en minúsculas y sin tildes):
 * - `pendul*` = prefijo (péndulo, pendulum, pendular);
 * - `carga` = palabra completa con plural opcional (carga, cargas);
 * - los espacios admiten cualquier separador.
 */
export function termRegex(term: string): RegExp {
	const cached = termCache.get(term);
	if (cached) return cached;
	const stem = term.endsWith('*');
	const t = stem ? term.slice(0, -1) : term;
	const body = t
		.split(/\s+/)
		.map(escapeRegex)
		.join('[\\s,;:-]+');
	const pre = /^[a-z0-9]/.test(t) ? '(?<![a-z0-9])' : '';
	// El prefijo abarca la palabra entera (para comparar tramos reconocidos).
	const post = stem ? '[a-z0-9]*' : /[a-z]$/.test(t) ? '(?:s|es)?(?![a-z0-9])' : /[0-9]$/.test(t) ? '(?![a-z0-9])' : '';
	const re = new RegExp(pre + body + post);
	termCache.set(term, re);
	return re;
}

/** ¿Aparece el término en el texto plegado? */
export function hasTerm(folded: string, term: string): boolean {
	return termRegex(term).test(folded);
}

/** Primer tramo [inicio, fin) donde aparece el término, o `null`. */
export function termSpan(folded: string, term: string): [number, number] | null {
	const m = termRegex(term).exec(folded);
	return m ? [m.index, m.index + m[0].length] : null;
}

/** Palabras vacías que no dan pistas sobre el parámetro. */
const STOPWORDS = new Set([
	'de',
	'del',
	'la',
	'el',
	'los',
	'las',
	'lo',
	'un',
	'una',
	'unos',
	'unas',
	'al',
	'es',
	'son',
	'sea',
	'igual',
	'con',
	'en',
	'para',
	'por',
	'que',
	'mide',
	'miden',
	'vale',
	'valen',
	'valor',
	'su',
	'sus',
	'otra',
	'otro',
	'cada',
	'entre',
	'aprox',
	'aproximadamente',
	'unos',
	'of',
	'the',
	'is',
	'are',
	'equal',
	'equals',
	'to',
	'with',
	'and',
	'an',
	'at',
	'on',
	'in',
	'for',
	'its',
	'value',
	'about',
	'around',
	'set',
	'pon',
	'poner',
	'usa',
	'usar',
	'use',
	'quiero',
	'want',
]);

/** Letras sueltas en minúscula que son conectores en español («y», «o», «a»…). */
const LETTER_STOPWORDS = new Set(['y', 'o', 'u', 'e', 'a']);

export function isStopword(token: string): boolean {
	if (token.length === 1) return LETTER_STOPWORDS.has(token);
	return STOPWORDS.has(token.toLowerCase());
}

/** Identificadores del texto (`q1`, `L`, `theta_0`, `longitud`), en orden. */
export function tokens(prepared: string): string[] {
	return prepared.match(/[A-Za-z][A-Za-z0-9_]*/g) ?? [];
}

/** Forma canónica de un símbolo: sin «_», llaves ni barras (`\theta_{0}` → `theta0`). */
export function symbolKey(s: string): string {
	return s
		.replace(/\\(mathrm|text|mathit|operatorname)\s*\{([^}]*)\}/g, '$2')
		.replace(/[\\{}_\s^]/g, '');
}

/** Palabras significativas (minúsculas, sin tildes ni palabras vacías). */
export function words(s: string): string[] {
	return fold(s)
		.split(/[^a-z0-9]+/)
		.filter((w) => w.length > 1 && !isStopword(w));
}

/** Hash FNV-1a de 32 bits (semilla determinista). */
export function hash32(s: string): number {
	let h = 0x811c9dc5;
	for (let i = 0; i < s.length; i++) {
		h ^= s.charCodeAt(i);
		h = Math.imul(h, 0x01000193);
	}
	return h >>> 0;
}

/** Generador pseudoaleatorio determinista en [0, 1) (mulberry32). */
export function seededRandom(seed: number): () => number {
	let a = seed >>> 0;
	return () => {
		a = (a + 0x6d2b79f5) >>> 0;
		let t = a;
		t = Math.imul(t ^ (t >>> 15), t | 1);
		t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
		return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
	};
}

/** Texto seguro para mostrar: sin etiquetas HTML ni caracteres de control, en una línea. */
export function cleanText(s: string, max: number): string {
	const out = s
		.replace(/<[^>]*>/g, '')
		.replace(/[\u0000-\u001F\u007F]+/g, ' ')
		.replace(/`{3,}/g, '')
		.replace(/\s+/g, ' ')
		.trim();
	return out.length > max ? out.slice(0, max - 1).trimEnd() + '…' : out;
}

/** ¿Contiene marcas de código ejecutable (script, manejadores, `javascript:`)? */
export function looksExecutable(s: string): boolean {
	return /<\s*\/?\s*(script|iframe|object|embed|style|link|meta|svg)\b|javascript\s*:|vbscript\s*:|data\s*:\s*text\/html|\bon(load|error|click|dblclick|focus|blur|change|input|submit|toggle|begin|end|mouse[a-z]*|key[a-z]*|pointer[a-z]*|animation[a-z]*)\s*=/i.test(
		s,
	);
}
