import type { PresetRegistry } from '../core/registry';
import { CliProvider } from './cli-provider';
import { DesktopBridge } from './desktop-bridge';
import { OfflineProvider } from './offline';
import type { AiSettings, DesktopEnv, GenerationProvider } from './types';

/**
 * Generación opcional de laboratorios a partir de una descripción (Fase E).
 *
 * - 'offline': reglas locales, sin red ni IA (también en Android).
 * - 'claude-cli' / 'codex-cli': solo escritorio; usan la CLI instalada y
 *   autenticada por el usuario a través de helper/physlab-helper.mjs.
 *   Nunca se piden ni se guardan claves de API.
 *
 * Toda salida pasa por `validateGenerated`: solo datos de un preset existente.
 */

export * from './types';
export { buildCatalog, type CatalogEntry, type CatalogParam } from './catalog';
export { validateGenerated, type ValidateOptions } from './validate';
export { generateOffline, rankPresets, OfflineProvider, MAX_PROMPT_CHARS, type PresetMatch } from './offline';
export { DesktopBridge, loadNodeApi, type DetectInfo, type HelperRequest, type HelperResponse, type NodeApi } from './desktop-bridge';
export { CliProvider } from './cli-provider';

/**
 * Proveedores disponibles. Siempre incluye 'offline'; en escritorio
 * (`desktop` no nulo) añade 'claude-cli' y 'codex-cli', cuyo `detect()`
 * informa si la CLI y Node están disponibles.
 */
export function createProviders(opts: {
	registry: PresetRegistry;
	settings: AiSettings;
	desktop: DesktopEnv | null;
}): GenerationProvider[] {
	const providers: GenerationProvider[] = [new OfflineProvider(opts.registry)];
	if (opts.desktop) {
		const bridge = new DesktopBridge(opts.desktop);
		providers.push(
			new CliProvider('claude-cli', bridge, opts.registry, opts.settings),
			new CliProvider('codex-cli', bridge, opts.registry, opts.settings),
		);
	}
	return providers;
}
