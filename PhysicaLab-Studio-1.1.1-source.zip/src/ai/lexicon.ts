import type { LabFeatures } from '../core/schema';
import type { Dimension } from './units';

/**
 * Conocimiento del generador sin IA: sinónimos (español e inglés) de los
 * presets incluidos, peticiones fuera de alcance y pistas de nombres.
 *
 * Todos los términos van en minúsculas y sin tildes. `pendul*` es un
 * prefijo; los demás son palabras completas con plural opcional.
 * Un preset que no esté en el registro simplemente se ignora.
 */

export interface PresetLexicon {
	/** [término, peso]. Las frases de varias palabras pesan más. */
	terms: Array<[string, number]>;
	/** Magnitudes típicas: su presencia en el texto suma puntos. */
	dims: Dimension[];
}

export const PRESET_LEXICON: Record<string, PresetLexicon> = {
	'math.secant-tangent': {
		terms: [
			['secante', 3],
			['secant', 3],
			['tangente', 3],
			['tangent', 3],
			['recta tangente', 5],
			['tangent line', 5],
			['deriv*', 3],
			['cociente incremental', 6],
			['difference quotient', 6],
			['cociente de diferencias', 6],
			['pendiente', 3],
			['slope', 3],
			['limite', 2],
			['limit', 2],
			['parabola', 3],
			['x^2', 3],
			['f(x) = x^2', 4],
			['tasa de cambio', 4],
			['razon de cambio', 4],
			['rate of change', 4],
			['calculo diferencial', 4],
		],
		dims: [],
	},
	'physics.pendulum': {
		terms: [
			['pendul*', 4],
			['pendulo simple', 6],
			['simple pendulum', 6],
			['oscil*', 2],
			['movimiento armonico', 4],
			['harmonic motion', 4],
			['periodo', 2],
			['period', 2],
			['hilo', 2],
			['cuerda', 1],
			['gravedad', 2],
			['gravity', 2],
			['columpio', 3],
			['swing', 2],
			['lenteja', 2],
			['bob', 2],
			['vaiven', 2],
		],
		dims: ['length', 'angle', 'acceleration', 'mass'],
	},
	'physics.two-charges': {
		terms: [
			['carga', 2],
			['charge', 2],
			['dos cargas', 6],
			['two charges', 6],
			['cargas puntuales', 6],
			['carga puntual', 5],
			['point charge', 5],
			['coulomb', 4],
			['culombio', 3],
			['ley de coulomb', 6],
			['campo electrico', 5],
			['electric field', 5],
			['lineas de campo', 5],
			['field lines', 5],
			['potencial electrico', 4],
			['electric potential', 4],
			['equipotencial', 4],
			['equipotential', 4],
			['dipolo', 5],
			['dipole', 5],
			['electrostat*', 4],
			['fuerza electrica', 4],
			['electric force', 4],
			['cargas electricas', 6],
			['electric charges', 6],
		],
		dims: ['charge'],
	},
	'circuits.rc-charging': {
		terms: [
			['condensador', 4],
			['capacitor', 4],
			['capacitancia', 3],
			['capacitance', 3],
			['capacidad', 2],
			['circuito rc', 7],
			['rc circuit', 7],
			['rc', 4],
			['carga del condensador', 6],
			['carga de un condensador', 6],
			['cargar un condensador', 6],
			['capacitor charging', 6],
			['curva de carga', 5],
			['charging curve', 5],
			['charging', 3],
			['discharging', 3],
			['descarga', 3],
			['constante de tiempo', 6],
			['time constant', 6],
			['tau', 3],
			['resistencia', 2],
			['resistor', 3],
			['circuito', 2],
			['circuit', 2],
			['bateria', 2],
			['battery', 2],
			['fuente de tension', 3],
		],
		dims: ['resistance', 'capacitance', 'voltage', 'time'],
	},
};

/** Petición que la V1 no ofrece. */
export interface ScopeRule {
	id: string;
	terms: string[];
	/** `true` = lo pedido no existe (no se genera bloque); `false` = se genera el más cercano y se avisa. */
	blocking: boolean;
	message: string;
	/** Presets cercanos (se filtran por el registro). */
	alternatives: string[];
	/** Solo se aplica si el preset elegido es este. */
	onlyFor?: string;
}

export const SCOPE_RULES: ScopeRule[] = [
	{
		id: 'inductance',
		terms: ['rlc', 'rl', 'lc', 'inductor', 'inductancia', 'inductance', 'bobina', 'solenoide', 'coil', 'henrio', 'henry'],
		blocking: true,
		message: 'Los circuitos con inductancias (RL, LC, RLC) no están disponibles en la V1: solo carga y descarga de un circuito RC.',
		alternatives: ['circuits.rc-charging'],
	},
	{
		id: 'double-pendulum',
		terms: ['pendulo doble', 'doble pendulo', 'double pendulum', 'pendulos acoplados', 'coupled pendulums', 'caos', 'chaos', 'caotico', 'chaotic'],
		blocking: true,
		message: 'Solo hay péndulo simple: el péndulo doble o acoplado (movimiento caótico) no está disponible.',
		alternatives: ['physics.pendulum'],
	},
	{
		id: 'fluids',
		terms: ['fluido', 'fluid', 'hidrodinam*', 'hydrodynam*', 'hidrostat*', 'hydrostat*', 'bernoulli', 'navier', 'viscos*', 'caudal', 'tuberia', 'empuje', 'buoyancy', 'arquimedes'],
		blocking: true,
		message: 'No hay laboratorios de fluidos (hidrostática, Bernoulli, viscosidad) en la V1.',
		alternatives: [],
	},
	{
		id: 'molecular',
		terms: ['simulacion molecular', 'dinamica molecular', 'molecular dynamics', 'molecular simulation', 'molecul*', 'atomos', 'atoms', 'gas ideal', 'ideal gas', 'muchas particulas', 'many particles'],
		blocking: true,
		message: 'No hay simulaciones moleculares ni de muchas partículas.',
		alternatives: [],
	},
	{
		id: 'magnetism',
		terms: ['campo magnetico', 'magnetic field', 'iman', 'magnet*', 'induccion', 'faraday', 'lorentz'],
		blocking: true,
		message: 'No hay laboratorios de magnetismo (campo magnético, inducción) en la V1.',
		alternatives: ['physics.two-charges'],
	},
	{
		id: 'waves',
		terms: ['onda', 'wave', 'sonido', 'sound', 'interferencia', 'interference', 'difraccion', 'diffraction', 'optica', 'optics', 'lente', 'lens'],
		blocking: true,
		message: 'No hay laboratorios de ondas, sonido u óptica en la V1.',
		alternatives: [],
	},
	{
		id: 'modern',
		terms: ['cuantic*', 'quantum', 'schrodinger', 'relatividad', 'relativity', 'relativista', 'relativistic', 'nuclear', 'radiactiv*'],
		blocking: true,
		message: 'No hay laboratorios de física moderna (cuántica, relatividad, nuclear).',
		alternatives: [],
	},
	{
		id: 'integral',
		terms: ['integral', 'integrales', 'area bajo la curva', 'area under the curve', 'riemann', 'antiderivada'],
		blocking: true,
		message: 'No hay laboratorio de integrales o área bajo la curva; solo derivada como límite de secantes.',
		alternatives: ['math.secant-tangent'],
	},
	{
		id: '3d',
		terms: ['3d', 'tridimensional', 'three dimensional', 'three-dimensional', 'tres dimensiones', 'realidad virtual', 'virtual reality'],
		blocking: false,
		message: 'Las figuras son 2D (SVG): no hay vistas en 3D.',
		alternatives: [],
	},
	{
		id: 'many-charges',
		terms: ['tres cargas', 'three charges', 'cuatro cargas', 'four charges', 'varias cargas', 'several charges', 'muchas cargas', 'many charges', 'n cargas', 'distribucion de carga', 'charge distribution', 'cuadrupolo', 'quadrupole'],
		blocking: false,
		message: 'El laboratorio admite exactamente dos cargas puntuales.',
		alternatives: ['physics.two-charges'],
	},
	{
		id: 'damping',
		terms: ['amortigua*', 'damped', 'damping', 'rozamiento', 'friccion', 'friction', 'resistencia del aire', 'air resistance'],
		blocking: false,
		message: 'El péndulo no modela rozamiento ni amortiguamiento.',
		alternatives: [],
		onlyFor: 'physics.pendulum',
	},
	{
		id: 'other-function',
		terms: ['seno', 'coseno', 'sin(x)', 'cos(x)', 'sen(x)', 'exponencial', 'exponential', 'logaritmo', 'logarithm', 'ln(x)', 'x^3', 'cubica', 'cubic', 'polinomio', 'polynomial'],
		blocking: false,
		message: 'El laboratorio de secante y tangente usa siempre f(x) = x²; no admite otras funciones.',
		alternatives: [],
		onlyFor: 'math.secant-tangent',
	},
	{
		id: 'export',
		terms: ['exportar video', 'export video', 'gif animado', 'animated gif', 'mp4'],
		blocking: false,
		message: 'No se exportan vídeos ni GIF; el laboratorio vive en la nota.',
		alternatives: [],
	},
];

/** Grupos de sinónimos para relacionar palabras del texto con nombres de parámetros. */
export const NAME_GROUPS: string[][] = [
	['longitud', 'largo', 'length', 'hilo', 'cuerda', 'string', 'long'],
	['angulo', 'angle', 'amplitud', 'amplitude', 'theta', 'inclinacion', 'desviacion', 'abertura'],
	['gravedad', 'gravity', 'gravitatoria', 'gravitacional'],
	['masa', 'mass', 'peso'],
	['carga', 'charge'],
	['resistencia', 'resistance', 'resistor'],
	['capacidad', 'capacitancia', 'capacitance', 'condensador', 'capacitor'],
	['tension', 'voltaje', 'voltage', 'fem', 'fuente', 'bateria', 'battery', 'emf', 'potencial'],
	['tiempo', 'time', 'instante'],
	['separacion', 'distancia', 'distance', 'separation'],
	['amortiguamiento', 'damping', 'rozamiento', 'friccion', 'friction'],
	['velocidad', 'velocity', 'speed', 'rapidez'],
	['frecuencia', 'frequency'],
	['abscisa', 'punto', 'point'],
	['corriente', 'current', 'intensidad'],
];

/** Ordinales: «la segunda carga» → segundo parámetro de esa magnitud. */
export const ORDINALS: Record<string, number> = {
	primera: 1,
	primer: 1,
	primero: 1,
	first: 1,
	segunda: 2,
	segundo: 2,
	second: 2,
	otra: 2,
	other: 2,
	tercera: 3,
	tercero: 3,
	third: 3,
};

/** Gravedad en superficie (m/s²) de cuerpos citados por su nombre. */
export const GRAVITY: Array<[string[], number, string]> = [
	[['luna', 'moon'], 1.62, 'la Luna'],
	[['marte', 'mars'], 3.71, 'Marte'],
	[['tierra', 'earth'], 9.81, 'la Tierra'],
	[['jupiter'], 24.79, 'Júpiter'],
	[['venus'], 8.87, 'Venus'],
	[['mercurio', 'mercury'], 3.7, 'Mercurio'],
	[['saturno', 'saturn'], 10.44, 'Saturno'],
];

/** Frases que fijan interruptores del bloque. */
export const FEATURE_PHRASES: Array<[string[], keyof LabFeatures, boolean]> = [
	[['sin ecuaciones', 'sin formulas', 'without equations', 'no equations'], 'equations', false],
	[['sin panel', 'sin controles', 'sin deslizadores', 'without controls', 'no controls'], 'controls', false],
	[['panel plegado', 'controles plegados', 'panel cerrado', 'collapsed panel', 'collapsed controls'], 'controlsCollapsed', true],
	[['sin latex', 'version ligera', 'without latex', 'no latex', 'lightweight'], 'latex', false],
	[['sin animacion', 'without animation', 'no animation'], 'animation', false],
	[['sin arrastre', 'no arrastrable', 'figura fija', 'figura estatica', 'not draggable', 'no dragging', 'static figure'], 'draggable', false],
	[['sin guardar', 'without saving', 'no guardar'], 'saveState', false],
];
