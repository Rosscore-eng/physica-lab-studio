import { fold, isStopword, prepare, symbolKey, tokens } from './text';

/**
 * Extracción de magnitudes con unidades de un texto libre (sin DOM).
 *
 * «q1 = 3 μC», «L = 1,5 m», «longitud 80 cm», «ángulo de 30°», «R = 10 kΩ»,
 * «10k», «C = 220 uF», «g = 1.62», «3×10⁻⁶ C». Los valores se guardan en la
 * unidad base del SI salvo los ángulos, que se guardan en grados.
 */

export type Dimension =
	| 'charge'
	| 'length'
	| 'angle'
	| 'resistance'
	| 'capacitance'
	| 'inductance'
	| 'voltage'
	| 'current'
	| 'time'
	| 'acceleration'
	| 'mass'
	| 'frequency'
	| 'temperature'
	| 'percent';

export interface UnitInfo {
	dim: Dimension;
	/** Unidades base por unidad (ángulos: grados por unidad). */
	factor: number;
}

export interface Quantity {
	/** Valor en la unidad base (ángulos en grados). Sin unidad: tal cual se escribió. */
	value: number;
	dim: Dimension | null;
	/** Unidad tal como se escribió (texto preparado) o `null`. */
	unit: string | null;
	/** Símbolo escrito justo antes de «=» o «:» (`q1`, `L`, `theta0`). */
	symbol: string | null;
	/** Palabras cercanas en minúsculas (`longitud`, `carga`, `segunda`). */
	hints: string[];
	/** Unidad deducida de un sufijo «10k» (probablemente ohmios). */
	guessed: boolean;
	/** Fragmento original reconocido, para mensajes. */
	raw: string;
}

const DEG_PER_RAD = 180 / Math.PI;

/** Símbolos de unidad (sensibles a mayúsculas). */
const SYMBOL_LIST: Array<[string, Dimension, number]> = [
	['m/s^2', 'acceleration', 1],
	['m/s2', 'acceleration', 1],
	['kohm', 'resistance', 1e3],
	['Mohm', 'resistance', 1e6],
	['ohm', 'resistance', 1],
	['Ohm', 'resistance', 1],
	['MHz', 'frequency', 1e6],
	['kHz', 'frequency', 1e3],
	['Hz', 'frequency', 1],
	['pC', 'charge', 1e-12],
	['nC', 'charge', 1e-9],
	['uC', 'charge', 1e-6],
	['mC', 'charge', 1e-3],
	['pc', 'charge', 1e-12],
	['nc', 'charge', 1e-9],
	['uc', 'charge', 1e-6],
	['C', 'charge', 1],
	['pF', 'capacitance', 1e-12],
	['nF', 'capacitance', 1e-9],
	['uF', 'capacitance', 1e-6],
	['mF', 'capacitance', 1e-3],
	['pf', 'capacitance', 1e-12],
	['nf', 'capacitance', 1e-9],
	['uf', 'capacitance', 1e-6],
	['F', 'capacitance', 1],
	['uH', 'inductance', 1e-6],
	['mH', 'inductance', 1e-3],
	['H', 'inductance', 1],
	['kV', 'voltage', 1e3],
	['mV', 'voltage', 1e-3],
	['V', 'voltage', 1],
	['uA', 'current', 1e-6],
	['mA', 'current', 1e-3],
	['A', 'current', 1],
	['min', 'time', 60],
	['ms', 'time', 1e-3],
	['us', 'time', 1e-6],
	['s', 'time', 1],
	['km', 'length', 1e3],
	['cm', 'length', 1e-2],
	['mm', 'length', 1e-3],
	['m', 'length', 1],
	['kg', 'mass', 1],
	['mg', 'mass', 1e-6],
	['g', 'mass', 1e-3],
	['deg', 'angle', 1],
	['rad', 'angle', DEG_PER_RAD],
	['°C', 'temperature', 1],
	['ºC', 'temperature', 1],
	['°', 'angle', 1],
	['º', 'angle', 1],
	['%', 'percent', 1],
];
/** Los más largos primero («mm» antes que «m»). */
const SYMBOLS = [...SYMBOL_LIST].sort((a, b) => b[0].length - a[0].length);

/** Unidades escritas con palabras (minúsculas, sin tildes; plural opcional). */
const WORDS: Array<[string, Dimension, number]> = [
	['microcoulomb', 'charge', 1e-6],
	['microculombio', 'charge', 1e-6],
	['nanocoulomb', 'charge', 1e-9],
	['nanoculombio', 'charge', 1e-9],
	['picocoulomb', 'charge', 1e-12],
	['picoculombio', 'charge', 1e-12],
	['millicoulomb', 'charge', 1e-3],
	['milicoulomb', 'charge', 1e-3],
	['miliculombio', 'charge', 1e-3],
	['coulomb', 'charge', 1],
	['culombio', 'charge', 1],
	['centimetro', 'length', 1e-2],
	['centimeter', 'length', 1e-2],
	['centimetre', 'length', 1e-2],
	['milimetro', 'length', 1e-3],
	['millimeter', 'length', 1e-3],
	['kilometro', 'length', 1e3],
	['kilometer', 'length', 1e3],
	['metro', 'length', 1],
	['meter', 'length', 1],
	['metre', 'length', 1],
	['grado', 'angle', 1],
	['degree', 'angle', 1],
	['radian', 'angle', DEG_PER_RAD],
	['kiloohmio', 'resistance', 1e3],
	['kiloohm', 'resistance', 1e3],
	['kilohm', 'resistance', 1e3],
	['megaohmio', 'resistance', 1e6],
	['megaohm', 'resistance', 1e6],
	['megohm', 'resistance', 1e6],
	['ohmio', 'resistance', 1],
	['microfaradio', 'capacitance', 1e-6],
	['microfarad', 'capacitance', 1e-6],
	['nanofaradio', 'capacitance', 1e-9],
	['nanofarad', 'capacitance', 1e-9],
	['picofaradio', 'capacitance', 1e-12],
	['picofarad', 'capacitance', 1e-12],
	['milifaradio', 'capacitance', 1e-3],
	['faradio', 'capacitance', 1],
	['farad', 'capacitance', 1],
	['milihenrio', 'inductance', 1e-3],
	['henrio', 'inductance', 1],
	['henry', 'inductance', 1],
	['milivoltio', 'voltage', 1e-3],
	['millivolt', 'voltage', 1e-3],
	['kilovoltio', 'voltage', 1e3],
	['voltio', 'voltage', 1],
	['volt', 'voltage', 1],
	['miliamperio', 'current', 1e-3],
	['milliamp', 'current', 1e-3],
	['amperio', 'current', 1],
	['ampere', 'current', 1],
	['milisegundo', 'time', 1e-3],
	['millisecond', 'time', 1e-3],
	['segundo', 'time', 1],
	['second', 'time', 1],
	['minuto', 'time', 60],
	['minute', 'time', 60],
	['kilogramo', 'mass', 1],
	['kilogram', 'mass', 1],
	['gramo', 'mass', 1e-3],
	['gram', 'mass', 1e-3],
	['hercio', 'frequency', 1],
	['hertz', 'frequency', 1],
	['por ciento', 'percent', 1],
	['percent', 'percent', 1],
];

const WORD_RE = new RegExp(`^\\s*(${WORDS.map((w) => w[0].replace(' ', '\\s+')).join('|')})(?:es|s)?(?![a-z0-9])`);
const WORD_MAP = new Map(WORDS.map((w) => [w[0], w] as const));

function escapeRegex(s: string): string {
	return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

const SYMBOL_RE = new RegExp(
	`^\\s*(${SYMBOLS.map(([s]) => escapeRegex(s) + (/[A-Za-z0-9]$/.test(s) ? '(?![A-Za-z0-9])' : '')).join('|')})`,
);
const SYMBOL_MAP = new Map(SYMBOLS.map((s) => [s[0], s] as const));

/** Unidad al principio de `rest` (texto preparado). */
function unitAt(rest: string): { info: UnitInfo; text: string; length: number } | null {
	const w = WORD_RE.exec(rest.toLowerCase());
	if (w) {
		const def = WORD_MAP.get((w[1] as string).replace(/\s+/g, ' '));
		if (def) return { info: { dim: def[1], factor: def[2] }, text: w[1] as string, length: w[0].length };
	}
	const s = SYMBOL_RE.exec(rest);
	if (s) {
		const def = SYMBOL_MAP.get(s[1] as string);
		if (def) return { info: { dim: def[1], factor: def[2] }, text: s[1] as string, length: s[0].length };
	}
	return null;
}

/** Unidad de un ParamSpec (`unitText` o LaTeX como `\mu\mathrm{C}`). */
export function parseUnit(text: string | undefined): UnitInfo | null {
	if (!text) return null;
	const plain = prepare(
		text
			.replace(/\\mu\s*/g, 'u')
			.replace(/\\Omega/g, 'ohm')
			.replace(/\^?\{?\\circ\}?/g, '°')
			.replace(/\\[,;!: ]/g, '')
			.replace(/\\(mathrm|text|mathit|operatorname)\s*/g, '')
			.replace(/[{}\s]/g, ''),
	);
	if (plain === '') return null;
	const u = unitAt(plain);
	return u && u.length === plain.length ? u.info : null;
}

/** Palabras que indican un límite («h tiende a 0»), no un valor. */
const LIMIT_WORDS = new Set(['tiende', 'tienden', 'tendiendo', 'tends', 'tending', 'approaches', 'aproxima', 'acerca']);

const NUMBER_RE =
	/(?<![A-Za-z0-9_.^/])([-+]?)(\d+(?:[.,]\d+)?)(?:[eE]([-+]?\d{1,3})(?![A-Za-z]))?(?:\s*(?:x|\*|·|×)\s*10\s*\^\s*([-+]?\d{1,3}))?/g;

/** Todas las magnitudes del texto, en orden de aparición. */
export function extractQuantities(input: string): Quantity[] {
	const text = prepare(input);
	const out: Quantity[] = [];
	let prevEnd = 0;
	NUMBER_RE.lastIndex = 0;
	let m: RegExpExecArray | null;
	while ((m = NUMBER_RE.exec(text))) {
		const start = m.index;
		let end = start + m[0].length;
		const sign = m[1] === '-' ? -1 : 1;
		let value = sign * Number((m[2] as string).replace(',', '.'));
		if (m[3]) value *= 10 ** Number(m[3]);
		if (m[4]) value *= 10 ** Number(m[4]);
		if (!Number.isFinite(value)) continue;

		let dim: Dimension | null = null;
		let unit: string | null = null;
		let guessed = false;
		const rest = text.slice(end);
		// «10k», «4k7», «2M»: sufijo pegado típico de resistencias.
		const suffix = /^([kKM])(\d+)?(?![A-Za-z0-9])/.exec(rest);
		const u = suffix ? null : unitAt(rest);
		if (suffix) {
			const mult = suffix[1] === 'M' ? 1e6 : 1e3;
			const frac = suffix[2] ? Number(`0.${suffix[2]}`) : 0;
			value = (Math.abs(value) + frac) * mult * Math.sign(value || 1);
			dim = 'resistance';
			unit = suffix[1] as string;
			guessed = true;
			end += suffix[0].length;
		} else if (u) {
			value *= u.info.factor;
			dim = u.info.dim;
			unit = u.text;
			end += u.length;
		} else if (/^[A-Za-z]/.test(rest)) {
			// «3D», «2nd»: el número forma parte de una palabra.
			NUMBER_RE.lastIndex = end;
			continue;
		}

		const before = text.slice(Math.max(prevEnd, start - 48), start);
		const symMatch = /([A-Za-z][A-Za-z0-9_]*)\s*(?:=|:|≈|~)\s*$/.exec(before);
		const symbol = symMatch ? symbolKey(symMatch[1] as string) : null;
		const beforeTokens = tokens(before).filter((t) => !isStopword(t));
		const hints = beforeTokens.slice(-3).map((t) => fold(t));
		// «80 cm de longitud», «3 uC of charge»
		const after = /^\s*(?:de|of)\s+([A-Za-z]+)(?:\s+([A-Za-z]+))?/.exec(text.slice(end, end + 32));
		if (after) {
			for (const t of [after[1], after[2]]) if (t && !isStopword(t)) hints.push(fold(t));
		}
		prevEnd = end;
		NUMBER_RE.lastIndex = end;
		if (hints.some((h) => LIMIT_WORDS.has(h)) || /->\s*$/.test(before)) continue;
		out.push({
			value,
			dim,
			unit,
			symbol,
			hints,
			guessed,
			raw: text.slice(start, end).trim(),
		});
	}
	return out;
}
