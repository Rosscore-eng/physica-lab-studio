import type { PresetDefinition } from '../core/preset';
import type { PresetRegistry } from '../core/registry';
import type { LabFeatures } from '../core/schema';
import { MODE_LABEL, type NumberParamSpec, type ParamSpec, type ParamValue } from '../core/types';
import {
	FEATURE_PHRASES,
	GRAVITY,
	NAME_GROUPS,
	ORDINALS,
	PRESET_LEXICON,
	SCOPE_RULES,
	type ScopeRule,
} from './lexicon';
import { fold, hash32, hasTerm, seededRandom, symbolKey, termSpan, words } from './text';
import { PROVIDER_LABEL, type GenerationProvider, type GenerationRequest, type GenerationResult, type ProviderStatus } from './types';
import { extractQuantities, parseUnit, type Dimension, type Quantity, type UnitInfo } from './units';
import { validateGenerated } from './validate';

/**
 * Generador sin IA: reglas locales, sin red. Funciona igual en escritorio
 * y en Android. Es determinista: la misma descripción produce el mismo
 * bloque (el sufijo del id sale de un hash del texto).
 */

export const MAX_PROMPT_CHARS = 4000;
/** Puntuación mínima para considerar que un preset encaja. */
const THRESHOLD = 3;

export interface PresetMatch {
	id: string;
	score: number;
	/** Términos reconocidos (sin «*»). */
	terms: string[];
}

function paramDim(p: NumberParamSpec): UnitInfo | null {
	return parseUnit(p.unitText) ?? parseUnit(p.unit);
}

/** Texto plegado con todo lo que describe un preset (palabras clave, título y parámetros). */
function presetText(def: PresetDefinition): string {
	return fold(
		[def.id, def.title, ...def.keywords, ...def.params.map((p) => `${p.id} ${p.name} ${p.description ?? ''}`)].join(' · '),
	);
}

/** Puntúa los presets del registro (opcionalmente de un modo), de mayor a menor. */
export function rankPresets(prompt: string, registry: PresetRegistry, mode?: PresetDefinition['mode'] | null): PresetMatch[] {
	const folded = fold(prompt);
	const dimsPresent = new Set(extractQuantities(prompt).map((q) => q.dim).filter((d): d is Dimension => d !== null));
	const out: Array<PresetMatch & { order: number }> = [];
	registry.list(mode ?? undefined).forEach((def, order) => {
		let score = 0;
		const terms: string[] = [];
		const lex = PRESET_LEXICON[def.id];
		// Candidatos: sinónimos propios, palabras clave del preset, título y nombre del id.
		const candidates: Array<[string, number]> = [...(lex?.terms ?? [])];
		for (const kw of def.keywords) {
			const t = fold(kw).trim();
			if (t.length >= 2) candidates.push([t, 2 + 3 * (t.split(/\s+/).length - 1)]);
		}
		for (const w of words(def.title)) if (w.length >= 4) candidates.push([w, 1]);
		const idName = (def.id.split('.')[1] ?? '').replace(/-/g, ' ');
		if (idName) candidates.push([idName, 2 + 3 * (idName.split(' ').length - 1)]);
		// Los términos largos primero; un término dentro de un tramo ya contado no suma
		// («péndulo» no vuelve a contar dentro de «péndulo doble»).
		candidates.sort((a, b) => b[0].length - a[0].length);
		const spans: Array<[number, number]> = [];
		const seen = new Set<string>();
		for (const [term, w] of candidates) {
			if (seen.has(term)) continue;
			seen.add(term);
			const span = termSpan(folded, term);
			if (!span || spans.some(([a, b]) => span[0] >= a && span[1] <= b)) continue;
			spans.push(span);
			score += w;
			terms.push(term.replace(/\*$/, ''));
		}
		if (folded.includes(def.id)) {
			score += 50;
			terms.unshift(def.id);
		}
		// Magnitudes típicas del preset presentes en el texto.
		const dims = new Set<Dimension>(lex?.dims ?? []);
		for (const p of def.params) {
			if (p.type !== 'number') continue;
			const u = paramDim(p);
			if (u) dims.add(u.dim);
		}
		for (const d of dims) if (dimsPresent.has(d)) score += 2;
		out.push({ id: def.id, score, terms, order });
	});
	out.sort((a, b) => b.score - a.score || a.order - b.order);
	return out.map(({ id, score, terms }) => ({ id, score, terms }));
}

/* ── Asignación de magnitudes a parámetros ─────────────────── */

interface ParamInfo {
	spec: NumberParamSpec;
	index: number;
	unit: UnitInfo | null;
	symbols: string[];
	nameWords: Set<string>;
	groups: Set<number>;
	/** Posición entre los parámetros de la misma magnitud (1, 2…). */
	ordinal: number;
}

function groupsOf(ws: Iterable<string>): Set<number> {
	const g = new Set<number>();
	for (const w of ws) {
		NAME_GROUPS.forEach((group, i) => {
			if (group.includes(w)) g.add(i);
		});
	}
	return g;
}

function paramInfos(params: readonly ParamSpec[]): ParamInfo[] {
	const infos: ParamInfo[] = [];
	const perDim = new Map<string, number>();
	params.forEach((spec, index) => {
		if (spec.type !== 'number') return;
		const unit = paramDim(spec);
		const key = unit?.dim ?? `?${index}`;
		const ordinal = (perDim.get(key) ?? 0) + 1;
		perDim.set(key, ordinal);
		const nameWords = new Set(words(`${spec.name} ${spec.description ?? ''}`));
		const symbols = [spec.id, spec.label ? symbolKey(spec.label) : ''].filter((s) => s !== '');
		infos.push({ spec, index, unit, symbols, nameWords, groups: groupsOf([...nameWords, spec.id.toLowerCase()]), ordinal });
	});
	return infos;
}

function matchScore(q: Quantity, p: ParamInfo): number {
	let s = 0;
	if (q.symbol) {
		if (p.symbols.includes(q.symbol)) s += 12;
		else if (p.symbols.some((x) => x.toLowerCase() === q.symbol?.toLowerCase())) s += 9;
	} else if (q.hints.some((h) => p.symbols.some((x) => x.toLowerCase() === h))) {
		s += 8;
	}
	const qGroups = groupsOf(q.hints);
	if ([...qGroups].some((g) => p.groups.has(g))) s += 6;
	else if (q.hints.some((h) => h.length >= 4 && p.nameWords.has(h))) s += 5;
	if (q.dim) {
		if (p.unit) s += p.unit.dim === q.dim ? 5 : -100;
		else s -= 1;
	}
	const ord = q.hints.map((h) => ORDINALS[h]).find((n) => n !== undefined);
	if (ord !== undefined) s += p.ordinal === ord ? 2 : -2;
	return s;
}

function tidy(v: number): number {
	const r = Number.parseFloat(v.toPrecision(12));
	return Object.is(r, -0) ? 0 : r;
}

/** Valor de la magnitud expresado en la unidad del parámetro. */
function convert(q: Quantity, p: ParamInfo): number {
	if (q.dim && p.unit && p.unit.dim === q.dim) return tidy(q.value / p.unit.factor);
	return tidy(q.value);
}

export interface Assignment {
	parameters: Record<string, number>;
	/** Avisos (magnitudes sin parámetro compatible). */
	notes: string[];
	/** Textos «fragmento → parámetro» para la explicación. */
	used: string[];
}

/** Asigna las magnitudes del texto a los parámetros numéricos (voraz, determinista). */
export function assignQuantities(quantities: readonly Quantity[], params: readonly ParamSpec[]): Assignment {
	const infos = paramInfos(params);
	const pairs: Array<{ qi: number; pi: number; s: number }> = [];
	quantities.forEach((q, qi) => {
		infos.forEach((p, pi) => {
			const s = matchScore(q, p);
			if (s >= 5) pairs.push({ qi, pi, s });
		});
	});
	pairs.sort((a, b) => b.s - a.s || a.qi - b.qi || a.pi - b.pi);
	const qUsed = new Set<number>();
	const pUsed = new Set<number>();
	const parameters: Record<string, number> = {};
	const used: string[] = [];
	for (const { qi, pi } of pairs) {
		if (qUsed.has(qi) || pUsed.has(pi)) continue;
		qUsed.add(qi);
		pUsed.add(pi);
		const q = quantities[qi] as Quantity;
		const p = infos[pi] as ParamInfo;
		parameters[p.spec.id] = convert(q, p);
		used.push(`«${q.raw}» → ${p.spec.id}`);
	}
	const notes: string[] = [];
	quantities.forEach((q, qi) => {
		if (!qUsed.has(qi)) notes.push(`No se usó «${q.raw}»: el laboratorio no tiene un parámetro compatible.`);
	});
	return { parameters, notes, used };
}

/** Gravedad de un cuerpo citado («gravedad de la Luna»), si el preset tiene ese parámetro. */
function gravityFromText(folded: string, params: readonly ParamSpec[], already: Record<string, number>): { id: string; value: number; body: string } | null {
	const gravityGroup = NAME_GROUPS.findIndex((g) => g.includes('gravedad'));
	const spec = params.find(
		(p): p is NumberParamSpec =>
			p.type === 'number' && (p.id === 'g' || groupsOf(words(`${p.name} ${p.id}`)).has(gravityGroup)),
	);
	if (!spec || already[spec.id] !== undefined) return null;
	for (const [names, g, body] of GRAVITY) {
		if (names.some((n) => hasTerm(folded, n))) {
			const unit = paramDim(spec);
			const value = unit && unit.dim === 'acceleration' ? tidy(g / unit.factor) : g;
			return { id: spec.id, value, body };
		}
	}
	return null;
}

const GENERIC_WORDS = new Set(['mostrar', 'muestra', 'show', 'recta', 'linea', 'line', 'ver', 'visible', 'activar']);

function escapeRegex(s: string): string {
	return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/** «sin tangente» / «mostrar vectores» → parámetros booleanos. */
function booleansFromText(folded: string, params: readonly ParamSpec[]): Record<string, boolean> {
	const out: Record<string, boolean> = {};
	for (const p of params) {
		if (p.type !== 'boolean') continue;
		const kws = words(p.name).filter((w) => w.length >= 5 && !GENERIC_WORDS.has(w));
		for (const kw of kws) {
			const k = escapeRegex(kw) + '(?:s|es)?(?![a-z0-9])';
			const art = '(?:(?:el|la|los|las|the)\\s+)?';
			if (new RegExp(`(?<![a-z0-9])(?:sin|ocultar|oculta|without|hide|no mostrar)\\s+${art}${k}`).test(folded)) {
				if (p.initial !== false) out[p.id] = false;
				break;
			}
			if (new RegExp(`(?<![a-z0-9])(?:mostrar|muestra|con|show|with|ver)\\s+${art}${k}`).test(folded)) {
				if (p.initial !== true) out[p.id] = true;
				break;
			}
		}
	}
	return out;
}

function featuresFromText(folded: string): Partial<LabFeatures> {
	const out: Partial<LabFeatures> = {};
	for (const [phrases, key, value] of FEATURE_PHRASES) {
		if (phrases.some((ph) => hasTerm(folded, ph))) out[key] = value;
	}
	return out;
}

/** Reglas de alcance que se activan (y no cubre ningún preset del registro). */
function scopeHits(folded: string, registry: PresetRegistry, chosen: string | null): ScopeRule[] {
	const covered = registry.list().map(presetText);
	const hits: ScopeRule[] = [];
	for (const rule of SCOPE_RULES) {
		if (rule.onlyFor && rule.onlyFor !== chosen) continue;
		const term = rule.terms.find((t) => hasTerm(folded, t));
		if (!term) continue;
		// Si algún preset ya lo ofrece (otro agente o plugin lo añadió), no es una limitación.
		if (covered.some((txt) => hasTerm(txt, term))) continue;
		hits.push(rule);
	}
	return hits;
}

function emptyResult(error: string): GenerationResult {
	return {
		ok: false,
		provider: 'offline',
		supported: false,
		config: null,
		block: null,
		explanation: '',
		limitations: [],
		alternatives: [],
		warnings: [],
		error,
	};
}

/** Genera un laboratorio a partir de una descripción, sin IA. */
export function generateOffline(req: GenerationRequest, registry: PresetRegistry): GenerationResult {
	const prompt = typeof req.prompt === 'string' ? req.prompt.trim() : '';
	if (!prompt) return emptyResult('Escribe una descripción del laboratorio.');
	if (prompt.length > MAX_PROMPT_CHARS) return emptyResult(`La descripción es demasiado larga (máximo ${MAX_PROMPT_CHARS} caracteres).`);

	const folded = fold(prompt);
	const notes: string[] = [];
	const modeRanked = rankPresets(prompt, registry, req.mode);
	let ranked = modeRanked;
	if (req.mode && !(ranked[0] && ranked[0].score >= 1)) {
		const all = rankPresets(prompt, registry);
		if (all[0] && all[0].score >= THRESHOLD) {
			ranked = all;
			notes.push(`Ningún laboratorio de ${MODE_LABEL[req.mode]} encaja; se buscó en todos los modos.`);
		}
	}
	// Con un modo elegido basta una pista débil dentro de ese modo.
	const threshold = req.mode && ranked === modeRanked ? 1 : THRESHOLD;
	const best = ranked[0] && ranked[0].score >= threshold ? ranked[0] : null;
	const others = ranked.filter((m) => m !== best && m.score >= THRESHOLD).map((m) => m.id);

	const hits = scopeHits(folded, registry, best?.id ?? null);
	const limitations = hits.map((r) => r.message);
	const ruleAlts = hits.flatMap((r) => r.alternatives).filter((id) => registry.get(id));
	const blocked = hits.some((r) => r.blocking);
	const random = seededRandom(hash32(prompt));

	if (!best || blocked) {
		const alternatives = [...new Set([...ruleAlts, ...(best ? [best.id] : []), ...others])];
		if (!best && limitations.length === 0) {
			limitations.push('La descripción no coincide con ningún laboratorio disponible.');
		}
		if (alternatives.length === 0 && !blocked) alternatives.push(...registry.list(req.mode ?? undefined).map((d) => d.id));
		const closest = alternatives[0] ? registry.get(alternatives[0]) : undefined;
		const explanation = blocked
			? `No se genera un laboratorio que finja lo pedido.${closest ? ` Lo más cercano disponible: «${closest.title}» (${closest.id}).` : ''}`
			: 'No encontré un laboratorio que encaje con la descripción. Prueba con otras palabras o elige una plantilla.';
		const res = validateGenerated({ supported: false, preset: '', explanation, limitations, alternatives }, registry, 'offline', { random });
		res.warnings.unshift(...notes);
		return res;
	}

	const def = registry.get(best.id) as PresetDefinition;
	const quantities = extractQuantities(prompt);
	const assignment = assignQuantities(quantities, def.params);
	const parameters: Record<string, ParamValue> = { ...assignment.parameters };
	const extra: string[] = [];
	const g = gravityFromText(folded, def.params, assignment.parameters);
	if (g) {
		parameters[g.id] = g.value;
		extra.push(`gravedad de ${g.body}`);
	}
	Object.assign(parameters, booleansFromText(folded, def.params));

	const res = validateGenerated(
		{
			supported: true,
			preset: def.id,
			title: def.title,
			parameters,
			features: featuresFromText(folded),
			explanation: '',
			limitations,
			alternatives: [...new Set([...ruleAlts, ...others])].slice(0, 4),
		},
		registry,
		'offline',
		{ random },
	);
	if (res.ok) {
		const terms = best.terms.slice(0, 4).map((t) => `«${t}»`);
		res.explanation += ` Reconocido por ${terms.join(', ')}${extra.length ? `; ${extra.join(', ')}` : ''}.`;
		const runnerUp = ranked[1];
		if (runnerUp && runnerUp.score >= THRESHOLD && best.score - runnerUp.score < 2) {
			const t = registry.get(runnerUp.id)?.title ?? runnerUp.id;
			notes.push(`También podría encajar «${t}» (${runnerUp.id}).`);
		}
	}
	res.warnings.unshift(...notes, ...assignment.notes);
	return res;
}

/** Proveedor «Sin IA (reglas locales)». */
export class OfflineProvider implements GenerationProvider {
	readonly id = 'offline' as const;
	readonly label = PROVIDER_LABEL.offline;

	constructor(private readonly registry: PresetRegistry) {}

	async detect(): Promise<ProviderStatus> {
		return { id: this.id, label: this.label, available: true, detail: 'Reglas locales: sin red ni IA; funciona también en Android.' };
	}

	async generate(req: GenerationRequest, signal?: AbortSignal): Promise<GenerationResult> {
		if (signal?.aborted) return emptyResult('Generación cancelada.');
		return generateOffline(req, this.registry);
	}
}
