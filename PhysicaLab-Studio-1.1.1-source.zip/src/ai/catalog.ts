import type { PresetDefinition } from '../core/preset';
import type { PresetRegistry } from '../core/registry';
import type { LabMode, ParamSpec } from '../core/types';

/**
 * Catálogo de presets en DATOS (sin funciones): es lo único, junto con la
 * descripción del usuario, que se envía a un proveedor de IA.
 */

export interface CatalogParam {
	id: string;
	name: string;
	type: 'number' | 'boolean' | 'enum';
	initial: number | boolean | string;
	min?: number;
	max?: number;
	step?: number;
	/** Unidad en texto plano (`m`, `μC`, `kΩ`). */
	unit?: string;
	/** Valores admitidos de un parámetro de selección. */
	options?: string[];
	description?: string;
}

export interface CatalogEntry {
	id: string;
	mode: LabMode;
	title: string;
	summary: string;
	keywords: string[];
	params: CatalogParam[];
}

const MAX_TEXT = 240;
const MAX_KEYWORDS = 24;
const MAX_PARAMS = 40;

function short(s: string | undefined, max = MAX_TEXT): string {
	const t = (s ?? '').replace(/\s+/g, ' ').trim();
	return t.length > max ? t.slice(0, max - 1) + '…' : t;
}

/** Unidad LaTeX → texto plano aproximado (`\mu\mathrm{C}` → `μC`). */
export function latexUnitText(tex: string): string {
	return tex
		.replace(/\\mu\s*/g, 'μ')
		.replace(/\\Omega/g, 'Ω')
		.replace(/\^?\{?\\circ\}?/g, '°')
		.replace(/\\[,;!: ]/g, '')
		.replace(/\\(mathrm|text|mathit|operatorname)\s*/g, '')
		.replace(/[{}\\]/g, '')
		.trim();
}

function finite(n: number): number | undefined {
	return Number.isFinite(n) ? n : undefined;
}

function paramEntry(p: ParamSpec): CatalogParam {
	const base = { id: p.id, name: short(p.name, 80) };
	const description = p.description ? short(p.description, 160) : undefined;
	if (p.type === 'number') {
		const unit = p.unitText ?? (p.unit ? latexUnitText(p.unit) : '');
		return {
			...base,
			type: 'number',
			initial: p.initial,
			min: finite(p.min),
			max: finite(p.max),
			step: finite(p.step),
			...(unit ? { unit } : {}),
			...(description ? { description } : {}),
		};
	}
	if (p.type === 'boolean') {
		return { ...base, type: 'boolean', initial: p.initial, ...(description ? { description } : {}) };
	}
	return {
		...base,
		type: 'enum',
		initial: p.initial,
		options: p.options.map((o) => o.value),
		...(description ? { description } : {}),
	};
}

export function catalogEntry(def: PresetDefinition): CatalogEntry {
	return {
		id: def.id,
		mode: def.mode,
		title: short(def.title, 120),
		summary: short(def.summary),
		keywords: def.keywords.slice(0, MAX_KEYWORDS).map((k) => short(k, 40)),
		params: def.params.slice(0, MAX_PARAMS).map(paramEntry),
	};
}

/**
 * Descripción en datos de los presets del registro (opcionalmente de un
 * modo). Se serializa y se vuelve a leer para garantizar que no quedan
 * funciones, `undefined` ni referencias compartidas.
 */
export function buildCatalog(registry: PresetRegistry, mode?: LabMode | null): CatalogEntry[] {
	const defs = registry.list(mode ?? undefined);
	return JSON.parse(JSON.stringify(defs.map(catalogEntry))) as CatalogEntry[];
}
