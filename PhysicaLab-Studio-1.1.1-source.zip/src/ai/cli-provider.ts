import type { PresetRegistry } from '../core/registry';
import { buildCatalog } from './catalog';
import type { DesktopBridge } from './desktop-bridge';
import { MAX_PROMPT_CHARS } from './offline';
import {
	PROVIDER_LABEL,
	type AiSettings,
	type GenerationProvider,
	type GenerationRequest,
	type GenerationResult,
	type ProviderStatus,
} from './types';
import { validateGenerated } from './validate';

/**
 * Proveedores «Claude Code (CLI)» y «Codex (CLI)»: solo escritorio.
 * Usan la CLI que el usuario ya tiene instalada y autenticada, a través del
 * programa auxiliar. La salida se valida igual que la del generador local.
 */
export class CliProvider implements GenerationProvider {
	readonly label: string;

	constructor(
		readonly id: 'claude-cli' | 'codex-cli',
		private readonly bridge: DesktopBridge,
		private readonly registry: PresetRegistry,
		/** Se lee en cada llamada: los cambios de ajustes se aplican sin recrear el proveedor. */
		private readonly settings: AiSettings,
	) {
		this.label = PROVIDER_LABEL[id];
	}

	private get cli(): 'claude' | 'codex' {
		return this.id === 'claude-cli' ? 'claude' : 'codex';
	}

	private fail(error: string): GenerationResult {
		return {
			ok: false,
			provider: this.id,
			supported: false,
			config: null,
			block: null,
			explanation: '',
			limitations: [],
			alternatives: [],
			warnings: [],
			error,
		};
	}

	async detect(): Promise<ProviderStatus> {
		const base = { id: this.id, label: this.label };
		try {
			const d = await this.bridge.detect(this.settings);
			if (!d.ok) return { ...base, available: false, detail: d.error ?? d.runtime };
			const c = d.clis[this.cli];
			if (!c || !c.available) return { ...base, available: false, detail: c?.error ?? 'CLI no detectada.' };
			return { ...base, available: true, detail: `${c.version ?? this.cli} · ${d.runtime}` };
		} catch (err) {
			return { ...base, available: false, detail: err instanceof Error ? err.message : String(err) };
		}
	}

	async generate(req: GenerationRequest, signal?: AbortSignal): Promise<GenerationResult> {
		const prompt = typeof req.prompt === 'string' ? req.prompt.trim() : '';
		if (!prompt) return this.fail('Escribe una descripción del laboratorio.');
		if (prompt.length > MAX_PROMPT_CHARS) return this.fail(`La descripción es demasiado larga (máximo ${MAX_PROMPT_CHARS} caracteres).`);
		if (signal?.aborted) return this.fail('Generación cancelada.');

		let catalog = buildCatalog(this.registry, req.mode);
		if (catalog.length === 0) catalog = buildCatalog(this.registry);
		if (catalog.length === 0) return this.fail('No hay laboratorios registrados.');

		const s = this.settings;
		const cliPath = (this.cli === 'claude' ? s.claudePath : s.codexPath).trim();
		const timeoutSec = Math.min(600, Math.max(5, Math.round(Number(s.timeoutSec) || 120)));
		const res = await this.bridge.run(
			{
				version: 1,
				provider: this.cli,
				prompt,
				catalog,
				...(cliPath ? { cliPath } : {}),
				...(s.model.trim() ? { model: s.model.trim() } : {}),
				timeoutSec,
			},
			signal,
		);
		if (!res.ok) return this.fail(res.error ?? 'Error desconocido.');
		const out = validateGenerated(res.data, this.registry, this.id);
		out.warnings.push(`Generado con ${this.label} en ${(res.durationMs / 1000).toFixed(1)} s.`);
		return out;
	}
}
