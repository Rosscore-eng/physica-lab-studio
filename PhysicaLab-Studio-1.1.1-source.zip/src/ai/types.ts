import type { LabConfig } from '../core/schema';
import type { LabMode } from '../core/types';

/**
 * Contrato del generador de laboratorios a partir de una descripción.
 *
 * La IA solo produce DATOS (una configuración declarativa de un preset
 * existente); nunca código. Todo resultado se valida con el mismo esquema
 * que los bloques `physlab` y contra el registro de presets.
 */

export type ProviderId = 'offline' | 'claude-cli' | 'codex-cli';

export const PROVIDER_LABEL: Record<ProviderId, string> = {
	offline: 'Sin IA (reglas locales)',
	'claude-cli': 'Claude Code (CLI)',
	'codex-cli': 'Codex (CLI)',
};

export interface GenerationRequest {
	/** Texto escrito por el usuario. Es lo único que se envía al proveedor. */
	prompt: string;
	/** Modo preferido (filtro opcional). */
	mode?: LabMode | null;
}

export interface GenerationResult {
	ok: boolean;
	provider: ProviderId;
	/** La petición encaja en un preset existente. */
	supported: boolean;
	/** Configuración validada (preset existente, parámetros dentro de rango). */
	config: LabConfig | null;
	/** Bloque ```physlab listo para insertar. */
	block: string | null;
	/** Explicación breve en español: preset elegido y parámetros extraídos. */
	explanation: string;
	/** Capacidades pedidas que la V1 no ofrece (se informan, no se fingen). */
	limitations: string[];
	/** Ids de presets alternativos razonables. */
	alternatives: string[];
	warnings: string[];
	error?: string;
}

export interface ProviderStatus {
	id: ProviderId;
	label: string;
	available: boolean;
	/** Versión detectada, ruta o motivo de no disponibilidad. */
	detail: string;
}

export interface GenerationProvider {
	readonly id: ProviderId;
	readonly label: string;
	detect(): Promise<ProviderStatus>;
	generate(req: GenerationRequest, signal?: AbortSignal): Promise<GenerationResult>;
}

export interface AiSettings {
	/** Proveedor preferido. */
	preferred: ProviderId;
	/** Ruta del ejecutable de Claude Code ('' = buscar «claude» en el PATH). */
	claudePath: string;
	/** Ruta del ejecutable de Codex ('' = buscar «codex» en el PATH). */
	codexPath: string;
	/** Modelo opcional para la CLI ('' = el predeterminado de la CLI). */
	model: string;
	/** Tiempo máximo por generación, en segundos. */
	timeoutSec: number;
	/** Pedir confirmación antes de enviar la descripción a un proveedor externo. */
	confirmBeforeSend: boolean;
}

export const DEFAULT_AI_SETTINGS: AiSettings = {
	preferred: 'offline',
	claudePath: '',
	codexPath: '',
	model: '',
	timeoutSec: 120,
	confirmBeforeSend: true,
};

/** Entorno de escritorio (solo existe en la app de PC). */
export interface DesktopEnv {
	/** Ruta absoluta de la carpeta del plugin (contiene helper/physlab-helper.mjs). */
	pluginDir: string;
	/** Ruta absoluta de la raíz del vault (no se envía a ningún proveedor). */
	vaultDir: string;
}
