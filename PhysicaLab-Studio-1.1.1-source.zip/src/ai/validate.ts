import type { PresetRegistry } from '../core/registry';
import {
	DEFAULT_FEATURES,
	isPlainObject,
	makeLabId,
	normalizeLabObject,
	toCodeBlock,
	type LabFeatures,
} from '../core/schema';
import { ParamStore } from '../core/store';
import type { ParamSpec, ParamValue } from '../core/types';
import { latexUnitText } from './catalog';
import { cleanText, looksExecutable } from './text';
import type { GenerationResult, ProviderId } from './types';

/**
 * Validación de cualquier salida de generación (IA o reglas locales).
 *
 * Solo se aceptan DATOS: un preset del registro, parámetros conocidos del
 * tipo correcto (los numéricos se ajustan al rango con aviso) e
 * interruptores booleanos. Cualquier rastro de código (claves `script`,
 * `html`, `js`…, manejadores o `javascript:`) invalida la respuesta.
 */

export interface ValidateOptions {
	/** Aleatoriedad del sufijo del id (pruebas y generador determinista). */
	random?: () => number;
	/** Id fijo (p. ej. al regenerar el mismo bloque). */
	id?: string;
}

const MAX_RAW_CHARS = 100_000;
const MAX_DEPTH = 6;
const MAX_ARRAY = 64;
const MAX_LIST = 8;

const ALLOWED_KEYS = new Set([
	'supported',
	'preset',
	'title',
	'parameters',
	'params',
	'features',
	'explanation',
	'limitations',
	'alternatives',
]);

/** Claves que delatan código o marcado (se comparan en minúsculas, sin «-», «_» ni espacios). */
const DANGEROUS_KEYS = new Set([
	'script',
	'scripts',
	'html',
	'innerhtml',
	'outerhtml',
	'js',
	'javascript',
	'jsx',
	'ts',
	'typescript',
	'code',
	'sourcecode',
	'eval',
	'function',
	'functions',
	'fn',
	'callback',
	'handler',
	'css',
	'style',
	'styles',
	'stylesheet',
	'iframe',
	'svg',
	'src',
	'href',
	'import',
	'imports',
	'require',
	'exec',
	'command',
	'commands',
	'shell',
	'cmd',
	'bash',
	'powershell',
	'template',
	'__proto__',
	'proto',
	'prototype',
	'constructor',
]);

function isDangerousKey(k: string): boolean {
	const n = k.toLowerCase().replace(/[-\s]/g, '');
	if (n === '__proto__') return true;
	const bare = n.replace(/_/g, '');
	return DANGEROUS_KEYS.has(bare) || /^on(load|error|click|focus|blur|change|input|submit|mouse\w*|key\w*|pointer\w*)$/.test(bare);
}

/** Primer problema de seguridad encontrado (o `null`). */
function findUnsafe(value: unknown, paramIds: ReadonlySet<string>, path: string, depth: number): string | null {
	if (depth > MAX_DEPTH) return `estructura demasiado anidada en «${path}»`;
	switch (typeof value) {
		case 'string':
			return looksExecutable(value) ? `contenido ejecutable en «${path}»` : null;
		case 'number':
		case 'boolean':
		case 'undefined':
			return null;
		case 'object': {
			if (value === null) return null;
			if (Array.isArray(value)) {
				if (value.length > MAX_ARRAY) return `lista demasiado larga en «${path}»`;
				for (let i = 0; i < value.length; i++) {
					const r = findUnsafe(value[i], paramIds, `${path}[${i}]`, depth + 1);
					if (r) return r;
				}
				return null;
			}
			const proto = Object.getPrototypeOf(value) as unknown;
			if (proto !== Object.prototype && proto !== null) return `objeto no plano en «${path}»`;
			const isParams = path === 'parameters' || path === 'params';
			for (const [k, v] of Object.entries(value)) {
				const child = path ? `${path}.${k}` : k;
				if (!(isParams && paramIds.has(k)) && isDangerousKey(k)) return `clave de código «${child}»`;
				const r = findUnsafe(v, paramIds, child, depth + 1);
				if (r) return r;
			}
			return null;
		}
		default:
			return `valor no admitido (${typeof value}) en «${path || 'raíz'}»`;
	}
}

/** Lee JSON de un texto (admite vallas ```json y texto alrededor). */
export function parseJsonText(text: string): unknown {
	const t = text
		.trim()
		.replace(/^```(?:json)?\s*/i, '')
		.replace(/\s*```$/, '')
		.trim();
	try {
		return JSON.parse(t);
	} catch {
		const a = t.indexOf('{');
		const b = t.lastIndexOf('}');
		if (a >= 0 && b > a) {
			try {
				return JSON.parse(t.slice(a, b + 1));
			} catch {
				return undefined;
			}
		}
		return undefined;
	}
}

function textList(v: unknown, field: string, maxLen: number, warnings: string[]): string[] {
	if (v === undefined || v === null) return [];
	const arr = Array.isArray(v) ? v : typeof v === 'string' ? [v] : null;
	if (!arr) {
		warnings.push(`\`${field}\` debe ser una lista de textos; se ignora.`);
		return [];
	}
	const out: string[] = [];
	for (const x of arr) {
		if (typeof x !== 'string') continue;
		const s = cleanText(x, maxLen);
		if (s && !out.includes(s)) out.push(s);
		if (out.length >= MAX_LIST) break;
	}
	return out;
}

/** Pares nombre → valor desde un mapa o desde una lista `[{name, value}]` (esquema estricto de Codex). */
function paramEntries(raw: unknown, warnings: string[]): Array<[string, unknown]> {
	if (raw === undefined || raw === null) return [];
	if (isPlainObject(raw)) return Object.entries(raw);
	if (Array.isArray(raw)) {
		const out: Array<[string, unknown]> = [];
		for (const item of raw) {
			if (isPlainObject(item) && typeof item.name === 'string') out.push([item.name, item.value]);
			else warnings.push('Entrada de `parameters` no válida; se ignora.');
		}
		return out;
	}
	warnings.push('`parameters` debe ser un mapa `nombre: valor`; se ignora.');
	return [];
}

const NUMERIC_TEXT = /^[-+]?\d+(?:[.,]\d+)?(?:e[-+]?\d+)?$/i;

/** Convierte un valor al tipo del parámetro o devuelve `undefined` (con aviso). */
function coerceParam(spec: ParamSpec, v: unknown, warnings: string[]): ParamValue | undefined {
	const k = spec.id;
	switch (spec.type) {
		case 'number': {
			if (typeof v === 'number') {
				if (Number.isFinite(v)) return v;
				warnings.push(`«${k}» no es un número finito; se ignora.`);
				return undefined;
			}
			if (typeof v === 'string' && NUMERIC_TEXT.test(v.trim())) {
				const n = Number(v.trim().replace(',', '.'));
				if (Number.isFinite(n)) {
					warnings.push(`«${k}» llegó como texto («${v}»); se interpreta como ${n}.`);
					return n;
				}
			}
			warnings.push(`«${k}» debe ser numérico; se ignora el valor recibido.`);
			return undefined;
		}
		case 'boolean': {
			if (typeof v === 'boolean') return v;
			if (v === 'true' || v === 'false') {
				warnings.push(`«${k}» llegó como texto; se interpreta como ${v}.`);
				return v === 'true';
			}
			warnings.push(`«${k}» debe ser true o false; se ignora el valor recibido.`);
			return undefined;
		}
		case 'enum': {
			if (typeof v === 'string') {
				const exact = spec.options.find((o) => o.value === v);
				if (exact) return exact.value;
				const lv = v.trim().toLowerCase();
				const loose = spec.options.find((o) => o.value.toLowerCase() === lv || o.label.toLowerCase() === lv);
				if (loose) return loose.value;
			}
			warnings.push(`«${k}» admite: ${spec.options.map((o) => o.value).join(', ')}; se ignora el valor recibido.`);
			return undefined;
		}
	}
}

/** Valor legible con su unidad, para explicaciones (`q1 = 3 μC`). */
export function describeValue(spec: ParamSpec, v: ParamValue): string {
	if (spec.type !== 'number') return `${spec.id} = ${String(v)}`;
	const unit = spec.unitText ?? (spec.unit ? latexUnitText(spec.unit) : '');
	const sep = unit === '°' ? '' : ' ';
	return `${spec.id} = ${String(v)}${unit ? sep + unit : ''}`;
}

/**
 * Valida una salida cruda y la convierte en un resultado listo para la
 * interfaz: configuración normalizada, bloque ```physlab``` y avisos.
 */
export function validateGenerated(
	raw: unknown,
	registry: PresetRegistry,
	provider: ProviderId,
	opts: ValidateOptions = {},
): GenerationResult {
	const warnings: string[] = [];
	const fail = (error: string, extra: Partial<GenerationResult> = {}): GenerationResult => ({
		ok: false,
		provider,
		supported: false,
		config: null,
		block: null,
		explanation: '',
		limitations: [],
		alternatives: [],
		warnings,
		error,
		...extra,
	});

	let data: unknown = raw;
	if (typeof data === 'string') {
		if (data.length > MAX_RAW_CHARS) return fail('La respuesta es demasiado grande.');
		data = parseJsonText(data);
		if (data === undefined) return fail('La respuesta no contiene un objeto JSON válido.');
	}
	if (!isPlainObject(data)) return fail('La respuesta debe ser un objeto JSON con `preset` y `parameters`.');
	let size = 0;
	try {
		size = JSON.stringify(data).length;
	} catch {
		return fail('La respuesta no es serializable como JSON.');
	}
	if (size > MAX_RAW_CHARS) return fail('La respuesta es demasiado grande.');

	const presetId = typeof data.preset === 'string' ? data.preset.trim() : '';
	const def = presetId ? registry.get(presetId) : undefined;
	const paramIds = new Set(def?.params.map((p) => p.id) ?? []);
	const unsafe = findUnsafe(data, paramIds, '', 0);
	if (unsafe) return fail(`Respuesta rechazada: ${unsafe}. Solo se aceptan datos (preset y parámetros), nunca código.`);

	for (const k of Object.keys(data)) {
		if (!ALLOWED_KEYS.has(k)) warnings.push(`Clave desconocida ignorada: «${k}».`);
	}
	if (data.preset !== undefined && typeof data.preset !== 'string') warnings.push('`preset` debe ser texto.');

	const limitations = textList(data.limitations, 'limitations', 200, warnings);
	const altRaw = textList(data.alternatives, 'alternatives', 64, warnings);
	const alternatives: string[] = [];
	for (const a of altRaw) {
		if (a === presetId && def) continue;
		if (registry.get(a)) alternatives.push(a);
		else warnings.push(`Alternativa desconocida ignorada: «${a}».`);
	}
	const explanation = typeof data.explanation === 'string' ? cleanText(data.explanation, 600) : '';

	let supported: boolean;
	if (typeof data.supported === 'boolean') supported = data.supported;
	else {
		if (data.supported !== undefined) warnings.push('`supported` debe ser true o false.');
		supported = presetId !== '';
	}

	if (!supported) {
		if (def && !alternatives.includes(def.id)) alternatives.unshift(def.id);
		return {
			ok: true,
			provider,
			supported: false,
			config: null,
			block: null,
			explanation: explanation || 'La petición no encaja en ningún laboratorio disponible.',
			limitations: limitations.length ? limitations : ['Ningún preset del catálogo representa lo pedido.'],
			alternatives,
			warnings,
		};
	}
	if (!presetId) return fail('La respuesta no indica ningún preset.', { limitations, alternatives });
	if (!def) {
		return fail(`El preset «${cleanText(presetId, 64)}» no existe en esta instalación.`, { limitations, alternatives });
	}

	// Parámetros: solo los del preset, del tipo correcto.
	const byId = new Map(def.params.map((p) => [p.id, p]));
	const provided: Record<string, ParamValue> = {};
	for (const [k, v] of paramEntries(data.parameters ?? data.params, warnings)) {
		let spec = byId.get(k);
		if (!spec) {
			const loose = def.params.filter((p) => p.id.toLowerCase() === k.toLowerCase());
			if (loose.length === 1) spec = loose[0];
		}
		if (!spec) {
			warnings.push(`El preset no tiene el parámetro «${cleanText(k, 40)}»; se ignora.`);
			continue;
		}
		const c = coerceParam(spec, v, warnings);
		if (c !== undefined) provided[spec.id] = c;
	}

	// Rango, paso, rango dinámico y reglas propias: las mismas que el almacén.
	let store: ParamStore;
	try {
		store = new ParamStore(def.params, provided);
	} catch (err) {
		return fail(`El preset «${def.id}» tiene parámetros mal definidos: ${err instanceof Error ? err.message : String(err)}`);
	}
	const values = store.all();
	const parameters: Record<string, ParamValue> = {};
	for (const [k, req] of Object.entries(provided)) {
		const got = values[k] as ParamValue;
		if (typeof req === 'number' && typeof got === 'number' && req !== got) {
			const { min, max } = store.range(k);
			const tol = 1e-9 * Math.max(1, Math.abs(req));
			if (req < min - tol || req > max + tol) warnings.push(`«${k}» = ${req} está fuera de [${min}, ${max}]; se ajusta a ${got}.`);
			else if (Math.abs(req - got) > tol) warnings.push(`«${k}» = ${req} se redondea a ${got}.`);
		}
		parameters[k] = got;
	}

	// Interruptores: solo los conocidos y booleanos (`null` = predeterminado).
	const features: Partial<LabFeatures> = {};
	if (data.features !== undefined && data.features !== null) {
		if (!isPlainObject(data.features)) warnings.push('`features` debe ser un mapa de interruptores; se ignora.');
		else {
			for (const [k, v] of Object.entries(data.features)) {
				if (v === null) continue;
				if (!(k in DEFAULT_FEATURES)) warnings.push(`Opción desconocida en features: «${cleanText(k, 40)}».`);
				else if (typeof v !== 'boolean') warnings.push(`features.${k} debe ser true o false; se ignora.`);
				else features[k as keyof LabFeatures] = v;
			}
		}
	}

	const title = (typeof data.title === 'string' ? cleanText(data.title, 120) : '') || def.title;
	const parsed = normalizeLabObject({ preset: def.id, title, parameters, features });
	if (!parsed.config) return fail(parsed.errors.join(' '));
	for (const w of parsed.warnings) if (!warnings.includes(w)) warnings.push(w);
	const config = { ...parsed.config, id: opts.id ?? makeLabId(title, opts.random) };

	const summary = Object.entries(parameters)
		.map(([k, v]) => describeValue(byId.get(k) as ParamSpec, v))
		.join(', ');
	const fallback = `Laboratorio «${def.title}» (${def.id})${summary ? ` con ${summary}` : ''}.`;

	return {
		ok: true,
		provider,
		supported: true,
		config,
		block: toCodeBlock(config),
		explanation: explanation || fallback,
		limitations,
		alternatives,
		warnings,
	};
}
