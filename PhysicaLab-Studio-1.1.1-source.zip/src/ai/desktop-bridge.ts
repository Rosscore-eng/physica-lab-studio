import type { CatalogEntry } from './catalog';
import type { AiSettings, DesktopEnv } from './types';

/**
 * Puente de escritorio: ejecuta helper/physlab-helper.mjs con Node.
 *
 * Los módulos de Node se cargan con `require` dentro de funciones, nunca al
 * cargar el módulo: el mismo bundle funciona en Android, donde este puente
 * simplemente no se crea. Solo se envían la descripción del usuario y el
 * catálogo de presets (nunca el contenido de las notas ni rutas del vault).
 */

type ChildProcessModule = typeof import('child_process');
type FsModule = typeof import('fs');
type PathModule = typeof import('path');
type OsModule = typeof import('os');
type ChildProcess = import('child_process').ChildProcess;

/** Módulos de Node que usa el puente (inyectables en pruebas). */
export interface NodeApi {
	child_process: ChildProcessModule;
	fs: FsModule;
	path: PathModule;
	os: OsModule;
	/** `process` del anfitrión (Electron en Obsidian). */
	process: NodeJS.Process;
}

/** Carga perezosa de los módulos de Node; `null` fuera del escritorio. */
export function loadNodeApi(): NodeApi | null {
	try {
		const g = globalThis as { require?: (id: string) => unknown; process?: NodeJS.Process };
		const req: ((id: string) => unknown) | undefined = typeof require === 'function' ? require : g.require;
		if (!req || !g.process?.versions?.node) return null;
		return {
			child_process: req('child_process') as ChildProcessModule,
			fs: req('fs') as FsModule,
			path: req('path') as PathModule,
			os: req('os') as OsModule,
			process: g.process,
		};
	} catch {
		return null;
	}
}

export interface HelperRequest {
	version: 1;
	provider: 'claude' | 'codex';
	prompt: string;
	catalog: CatalogEntry[];
	cliPath?: string;
	model?: string;
	timeoutSec: number;
}

export interface HelperResponse {
	ok: boolean;
	data?: unknown;
	error?: string;
	provider: string | null;
	durationMs: number;
}

export interface CliInfo {
	available: boolean;
	path?: string;
	version?: string;
	error?: string;
}

export interface DetectInfo {
	ok: boolean;
	/** Cómo se ejecuta el programa auxiliar (o por qué no se puede). */
	runtime: string;
	clis: Partial<Record<'claude' | 'codex', CliInfo>>;
	error?: string;
}

export interface NodeRuntime {
	command: string;
	/** Variables extra (ELECTRON_RUN_AS_NODE=1 si se usa el Electron de Obsidian). */
	env: Record<string, string>;
	kind: 'path' | 'electron';
	version: string;
}

type RuntimeResult = { ok: true; runtime: NodeRuntime } | { ok: false; reason: string };

interface ExecResult {
	code: number | null;
	stdout: string;
	stderr: string;
	error: string | null;
	timedOut: boolean;
}

const HELPER_FILE = 'physlab-helper.mjs';
const MAX_STDOUT = 8 * 1024 * 1024;
const MAX_STDERR = 64 * 1024;
const DETECT_TTL_MS = 30_000;
/** Marca de los «fuses» de Electron (@electron/fuses); el primer fuse es RunAsNode. */
const FUSE_SENTINEL = 'dL7pKGdnNz796PbbjQWNKmHXBZaB9tsX';

function majorOf(version: string): number {
	return Number(version.replace(/^v/, '').split('.')[0]);
}

function isPlainObject(v: unknown): v is Record<string, unknown> {
	return typeof v === 'object' && v !== null && !Array.isArray(v);
}

function oneLine(s: string, max = 400): string {
	const t = s
		.replace(/\u001b\[[0-9;?]*[A-Za-z]/g, '')
		.replace(/\s+/g, ' ')
		.trim();
	return t.length > max ? t.slice(0, max - 1) + '…' : t;
}

export class DesktopBridge {
	private runtimePromise: Promise<RuntimeResult> | null = null;
	private detectCache: { key: string; at: number; promise: Promise<DetectInfo> } | null = null;

	constructor(
		private readonly env: DesktopEnv,
		private readonly api: NodeApi | null = loadNodeApi(),
	) {}

	/** Ruta del programa auxiliar dentro de la carpeta del plugin. */
	helperPath(): string {
		const p = this.api?.path;
		return p ? p.join(this.env.pluginDir, 'helper', HELPER_FILE) : `${this.env.pluginDir}/helper/${HELPER_FILE}`;
	}

	/* ── Procesos ────────────────────────────────────────────── */

	/** Ejecuta un programa con argumentos fijos, sin shell. */
	private exec(command: string, args: string[], extraEnv: Record<string, string>, timeoutMs: number): Promise<ExecResult> {
		const api = this.api;
		return new Promise((resolve) => {
			if (!api) {
				resolve({ code: null, stdout: '', stderr: '', error: 'Node no disponible.', timedOut: false });
				return;
			}
			let child: ChildProcess;
			try {
				child = api.child_process.spawn(command, args, {
					shell: false,
					windowsHide: true,
					env: { ...api.process.env, ...extraEnv },
					cwd: api.os.tmpdir(),
					stdio: ['ignore', 'pipe', 'pipe'],
				});
			} catch (err) {
				resolve({ code: null, stdout: '', stderr: '', error: err instanceof Error ? err.message : String(err), timedOut: false });
				return;
			}
			let stdout = '';
			let stderr = '';
			let timedOut = false;
			let error: string | null = null;
			child.stdout?.on('data', (d: Buffer) => {
				if (stdout.length < 65536) stdout += d.toString('utf8');
			});
			child.stderr?.on('data', (d: Buffer) => {
				if (stderr.length < 65536) stderr += d.toString('utf8');
			});
			const timer = setTimeout(() => {
				timedOut = true;
				this.killTree(child);
			}, timeoutMs);
			child.on('error', (err) => {
				error = err.message;
			});
			child.on('close', (code) => {
				clearTimeout(timer);
				resolve({ code, stdout, stderr, error, timedOut });
			});
		});
	}

	/** Termina el programa auxiliar y lo que haya lanzado. */
	private killTree(child: ChildProcess): void {
		const api = this.api;
		if (!api || !child.pid || child.exitCode !== null) return;
		if (api.process.platform === 'win32') {
			try {
				const root = api.process.env.SystemRoot || api.process.env.windir || 'C:\\Windows';
				api.child_process.spawn(api.path.join(root, 'System32', 'taskkill.exe'), ['/pid', String(child.pid), '/T', '/F'], {
					windowsHide: true,
					stdio: 'ignore',
				});
			} catch {
				child.kill();
			}
		} else {
			// El programa auxiliar atiende SIGTERM: mata la CLI y borra su carpeta temporal.
			child.kill('SIGTERM');
		}
	}

	/* ── Runtime de Node ─────────────────────────────────────── */

	/** Candidatos a `node`: PATH primero y luego carpetas de instalación habituales. */
	private nodeCandidates(): string[] {
		const api = this.api;
		if (!api) return [];
		const { fs, path, process: proc } = api;
		const win = proc.platform === 'win32';
		const name = win ? 'node.exe' : 'node';
		const dirs = (proc.env.PATH ?? '').split(path.delimiter).filter((d) => d && path.isAbsolute(d));
		const home = api.os.homedir();
		if (win) {
			for (const base of [proc.env.ProgramFiles, proc.env['ProgramFiles(x86)']]) if (base) dirs.push(path.join(base, 'nodejs'));
			if (proc.env.LOCALAPPDATA) dirs.push(path.join(proc.env.LOCALAPPDATA, 'Programs', 'nodejs'));
			dirs.push(path.join(home, '.volta', 'bin'));
		} else {
			dirs.push('/usr/local/bin', '/opt/homebrew/bin', '/usr/bin', path.join(home, '.volta', 'bin'), path.join(home, '.local', 'bin'));
		}
		const out: string[] = [];
		const seen = new Set<string>();
		for (const dir of dirs) {
			const p = path.join(dir, name);
			const key = win ? p.toLowerCase() : p;
			if (seen.has(key)) continue;
			seen.add(key);
			try {
				if (fs.statSync(p).isFile()) out.push(p);
			} catch {
				/* no existe */
			}
			if (out.length >= 6) break;
		}
		return out;
	}

	/** Archivo que contiene los «fuses» de Electron. */
	private fuseFile(execPath: string): string {
		const { path, process: proc } = this.api as NodeApi;
		if (proc.platform === 'darwin') {
			return path.join(path.dirname(execPath), '..', 'Frameworks', 'Electron Framework.framework', 'Electron Framework');
		}
		return execPath;
	}

	/**
	 * ¿Admite el ejecutable de Obsidian ELECTRON_RUN_AS_NODE? Se lee el fuse
	 * RunAsNode del binario SIN ejecutarlo: si estuviera desactivado,
	 * ejecutarlo abriría otra ventana de Obsidian.
	 */
	private runAsNodeFuse(execPath: string): Promise<'on' | 'off' | 'unknown'> {
		const api = this.api;
		if (!api) return Promise.resolve('unknown');
		const file = this.fuseFile(execPath);
		const sentinel = Buffer.from(FUSE_SENTINEL, 'latin1');
		return new Promise((resolve) => {
			let settled = false;
			const done = (v: 'on' | 'off' | 'unknown'): void => {
				if (settled) return;
				settled = true;
				stream?.destroy();
				resolve(v);
			};
			let carry = Buffer.alloc(0);
			let read = 0;
			let stream: ReturnType<FsModule['createReadStream']> | null = null;
			try {
				stream = api.fs.createReadStream(file, { highWaterMark: 1 << 20 });
			} catch {
				done('unknown');
				return;
			}
			stream.on('data', (chunk: Buffer | string) => {
				const c = typeof chunk === 'string' ? Buffer.from(chunk, 'latin1') : chunk;
				read += c.length;
				const buf = Buffer.concat([carry, c]);
				const i = buf.indexOf(sentinel);
				if (i >= 0 && i + sentinel.length + 2 < buf.length) {
					const first = buf[i + sentinel.length + 2];
					done(first === 0x31 ? 'on' : first === 0x30 || first === 0x72 ? 'off' : 'unknown');
					return;
				}
				carry = buf.subarray(Math.max(0, buf.length - sentinel.length - 3));
				if (read > 600 * 1024 * 1024) done('unknown');
			});
			stream.on('error', () => done('unknown'));
			stream.on('end', () => done('unknown'));
		});
	}

	private async resolveRuntime(): Promise<RuntimeResult> {
		const api = this.api;
		if (!api) return { ok: false, reason: 'Node no está disponible en esta plataforma (solo escritorio).' };
		const notes: string[] = [];
		for (const cand of this.nodeCandidates()) {
			const r = await this.exec(cand, ['--version'], {}, 10_000);
			const version = r.stdout.trim().replace(/^v/, '');
			if (r.code === 0 && majorOf(version) >= 18) {
				return { ok: true, runtime: { command: cand, env: {}, kind: 'path', version } };
			}
			notes.push(r.code === 0 ? `${cand} es v${version} (se necesita ≥ 18)` : `${cand} no respondió`);
		}
		const execPath = api.process.execPath;
		const fuse = execPath ? await this.runAsNodeFuse(execPath) : 'unknown';
		if (fuse === 'on') {
			const r = await this.exec(execPath, ['-e', 'process.stdout.write(process.versions.node)'], { ELECTRON_RUN_AS_NODE: '1' }, 10_000);
			const version = r.stdout.trim();
			if (r.code === 0 && majorOf(version) >= 18) {
				return { ok: true, runtime: { command: execPath, env: { ELECTRON_RUN_AS_NODE: '1' }, kind: 'electron', version } };
			}
			notes.push('el Electron de Obsidian no se pudo usar como Node');
		} else {
			notes.push(
				fuse === 'off'
					? 'el ejecutable de Obsidian tiene desactivado ELECTRON_RUN_AS_NODE'
					: 'no se pudo comprobar si Obsidian admite ELECTRON_RUN_AS_NODE (no se ejecuta por precaución)',
			);
		}
		return {
			ok: false,
			reason: `No se encontró Node.js 18 o superior en el PATH${notes.length ? ` (${notes.join('; ')})` : ''}. Instala Node.js para usar las CLI.`,
		};
	}

	/** Runtime de Node elegido (se calcula una vez). */
	runtime(): Promise<RuntimeResult> {
		if (!this.runtimePromise) this.runtimePromise = this.resolveRuntime();
		return this.runtimePromise;
	}

	private static runtimeLabel(rt: NodeRuntime): string {
		return rt.kind === 'path' ? `Node v${rt.version} (PATH)` : `Node v${rt.version} (Electron de Obsidian)`;
	}

	/* ── Programa auxiliar ───────────────────────────────────── */

	/** Lanza el programa auxiliar con `args`, escribe `input` y lee una línea JSON. */
	private async runHelper(
		args: string[],
		input: string | null,
		timeoutMs: number,
		signal?: AbortSignal,
	): Promise<{ ok: true; value: Record<string, unknown> } | { ok: false; error: string; aborted?: boolean }> {
		const api = this.api;
		if (!api) return { ok: false, error: 'Node no está disponible en esta plataforma (solo escritorio).' };
		const rt = await this.runtime();
		if (!rt.ok) return { ok: false, error: rt.reason };
		const helper = this.helperPath();
		if (!api.fs.existsSync(helper)) {
			return { ok: false, error: `Falta el programa auxiliar: ${helper}. Reinstala el plugin con la carpeta helper/.` };
		}
		if (signal?.aborted) return { ok: false, error: 'Generación cancelada.', aborted: true };

		return new Promise((resolve) => {
			let child: ChildProcess;
			try {
				child = api.child_process.spawn(rt.runtime.command, [helper, ...args], {
					shell: false,
					windowsHide: true,
					cwd: api.os.tmpdir(),
					env: { ...api.process.env, ...rt.runtime.env },
					stdio: ['pipe', 'pipe', 'pipe'],
				});
			} catch (err) {
				resolve({ ok: false, error: `No se pudo iniciar el programa auxiliar: ${err instanceof Error ? err.message : String(err)}` });
				return;
			}
			let stdout = '';
			let stderr = '';
			let aborted = false;
			let timedOut = false;
			let spawnError: string | null = null;
			child.stdout?.on('data', (d: Buffer) => {
				if (stdout.length < MAX_STDOUT) stdout += d.toString('utf8');
			});
			child.stderr?.on('data', (d: Buffer) => {
				if (stderr.length < MAX_STDERR) stderr += d.toString('utf8');
			});
			const timer = setTimeout(() => {
				timedOut = true;
				this.killTree(child);
			}, timeoutMs);
			const onAbort = (): void => {
				aborted = true;
				this.killTree(child);
			};
			signal?.addEventListener('abort', onAbort, { once: true });
			child.on('error', (err) => {
				spawnError = err.message;
			});
			child.on('close', (code) => {
				clearTimeout(timer);
				signal?.removeEventListener('abort', onAbort);
				if (aborted) return resolve({ ok: false, error: 'Generación cancelada.', aborted: true });
				if (timedOut) return resolve({ ok: false, error: 'El programa auxiliar no respondió a tiempo; se detuvo.' });
				if (spawnError) return resolve({ ok: false, error: `No se pudo ejecutar el programa auxiliar: ${spawnError}` });
				const line = stdout
					.split(/\r?\n/)
					.map((l) => l.trim())
					.filter((l) => l !== '')
					.pop();
				let value: unknown;
				try {
					value = line ? JSON.parse(line) : undefined;
				} catch {
					value = undefined;
				}
				if (!isPlainObject(value) || typeof value.ok !== 'boolean') {
					const detail = oneLine(stderr) || oneLine(stdout) || `código ${String(code)}`;
					return resolve({ ok: false, error: `Respuesta no válida del programa auxiliar: ${detail}` });
				}
				resolve({ ok: true, value });
			});
			child.stdin?.on('error', () => {
				/* el auxiliar terminó antes de leer */
			});
			if (input !== null) child.stdin?.end(input, 'utf8');
			else child.stdin?.end();
			if (signal?.aborted) onAbort();
		});
	}

	/** Detecta runtime y CLIs (resultado compartido unos segundos entre proveedores). */
	detect(settings: Pick<AiSettings, 'claudePath' | 'codexPath'>, refresh = false): Promise<DetectInfo> {
		const key = `${settings.claudePath}\u0000${settings.codexPath}`;
		const now = Date.now();
		if (!refresh && this.detectCache && this.detectCache.key === key && now - this.detectCache.at < DETECT_TTL_MS) {
			return this.detectCache.promise;
		}
		const promise = this.detectNow(settings);
		this.detectCache = { key, at: now, promise };
		return promise;
	}

	private async detectNow(settings: Pick<AiSettings, 'claudePath' | 'codexPath'>): Promise<DetectInfo> {
		const rt = await this.runtime();
		if (!rt.ok) return { ok: false, runtime: rt.reason, clis: {}, error: rt.reason };
		const args = ['--detect'];
		if (settings.claudePath.trim()) args.push('--claude-path', settings.claudePath.trim());
		if (settings.codexPath.trim()) args.push('--codex-path', settings.codexPath.trim());
		const r = await this.runHelper(args, null, 45_000);
		const runtime = DesktopBridge.runtimeLabel(rt.runtime);
		if (!r.ok) return { ok: false, runtime, clis: {}, error: r.error };
		const clis: DetectInfo['clis'] = {};
		const raw = isPlainObject(r.value.clis) ? r.value.clis : {};
		for (const k of ['claude', 'codex'] as const) {
			const c = raw[k];
			if (!isPlainObject(c)) continue;
			clis[k] = {
				available: c.available === true,
				path: typeof c.path === 'string' ? c.path : undefined,
				version: typeof c.version === 'string' ? oneLine(c.version, 120) : undefined,
				error: typeof c.error === 'string' ? oneLine(c.error) : undefined,
			};
		}
		return { ok: true, runtime, clis };
	}

	/** Envía una petición de generación al programa auxiliar. */
	async run(req: HelperRequest, signal?: AbortSignal): Promise<HelperResponse & { aborted?: boolean }> {
		const started = Date.now();
		const r = await this.runHelper([], JSON.stringify(req), (req.timeoutSec + 20) * 1000, signal);
		if (!r.ok) return { ok: false, error: r.error, provider: req.provider, durationMs: Date.now() - started, aborted: r.aborted };
		const v = r.value;
		return {
			ok: v.ok === true,
			data: v.data,
			error: typeof v.error === 'string' ? oneLine(v.error, 800) : v.ok === true ? undefined : 'Error desconocido del programa auxiliar.',
			provider: typeof v.provider === 'string' ? v.provider : req.provider,
			durationMs: typeof v.durationMs === 'number' ? v.durationMs : Date.now() - started,
		};
	}
}
