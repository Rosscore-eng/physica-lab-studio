import { FileSystemAdapter, MarkdownView, Notice, Platform, Plugin, type WorkspaceLeaf } from 'obsidian';
import { liveInstances, type LabInstance } from './core/lab-host';
import type { PresetDefinition } from './core/preset';
import type { PresetRegistry } from './core/registry';
import { LabFiles } from './persistence/lab-files';
import { createBuiltinRegistry } from './presets/index';
import { CachedMathEngine, type MathEngine } from './render/math/math-renderer';
import type { PhysLabHost } from './obsidian/host';
import { LabRenderChild } from './obsidian/lab-child';
import { ExpandedLabModal } from './obsidian/modals';
import { InsertRuntimeModal, RuntimeSourceModal, runtimeBlockAtCursor } from './obsidian/runtime-commands';
import { RuntimeRenderChild, type RuntimeHost } from './obsidian/runtime-child';
import { ensureMathJax, ObsidianMathEngine } from './obsidian/obsidian-math';
import { sanitizeSettings, type PhysLabSettings } from './obsidian/settings';
import { PhysLabSettingTab } from './obsidian/settings-tab';
import { STUDIO_VIEW, StudioView } from './obsidian/studio-view';
import { VaultFileAdapter } from './obsidian/vault-adapter';
import { isRuntimeSource, parseRuntimeSource } from './runtime/manifest';
import { snapshotRuntimeBlock, findRuntimeBlocks } from './runtime/editor';
import { RuntimeStateStore } from './runtime/state';
import { loadVendorBundles } from './runtime/vendor';

export interface PhysLabApi {version:string;registerPreset(def:PresetDefinition):void;listPresets():string[];}

export default class PhysicaLabPlugin extends Plugin implements PhysLabHost,RuntimeHost {
 override settings!:PhysLabSettings;
 registry!:PresetRegistry;
 engine!:MathEngine;
 files!:LabFiles;
 api!:PhysLabApi;
 runtimeStates!:RuntimeStateStore;
 private readonly children=new Set<LabRenderChild>();
 private readonly runtimeChildren=new Set<RuntimeRenderChild>();
 private lastMarkdownLeaf:WorkspaceLeaf|null=null;
 private data:Record<string,unknown>={};
 private saving:Promise<void>=Promise.resolve();

 override async onload():Promise<void>{
  const raw:unknown=await this.loadData();
  this.data=raw&&typeof raw==='object'&&!Array.isArray(raw)?raw as Record<string,unknown>:{};
  this.settings=sanitizeSettings(raw);
  this.runtimeStates=new RuntimeStateStore(this.data.runtimeStates,async states=>{this.data.runtimeStates=states;await this.saveSettings();});
  this.registry=createBuiltinRegistry();this.engine=new CachedMathEngine(new ObsidianMathEngine());
  this.files=new LabFiles(new VaultFileAdapter(this.app.vault,this.app.fileManager),()=>this.settings.paths);
  this.api={version:this.manifest.version,registerPreset:def=>this.registry.register(def),listPresets:()=>this.registry.ids()};
  this.registerMarkdownCodeBlockProcessor('physlab',(source,el,ctx)=>{
   ctx.addChild(isRuntimeSource(source)?new RuntimeRenderChild(el,this,source,ctx.sourcePath,this.runtimeChildren,()=>ctx.getSectionInfo(el)?.lineStart??null):new LabRenderChild(el,this,source,this.children));
  });
  this.registerView(STUDIO_VIEW,leaf=>new StudioView(leaf,this));
  this.addRibbonIcon('flask-conical','Abrir PhysicaLab Studio',()=>void this.openStudio());
  this.addCommand({id:'insert-lab',name:'Insertar laboratorio desde archivo HTML',editorCallback:editor=>new InsertRuntimeModal(this.app,editor).open()});
  this.addCommand({id:'open-studio',name:'Abrir el Studio',callback:()=>void this.openStudio()});
  this.addCommand({id:'reload-labs',name:'Recargar los laboratorios abiertos',callback:()=>this.refreshLabs()});
  this.addCommand({id:'open-lab-source',name:'Abrir código HTML del bloque actual',editorCallback:editor=>{
   const block=runtimeBlockAtCursor(editor);
   if(!block){new Notice('Coloca el cursor dentro de un bloque physlab/v1.');return;}
   const {manifest}=parseRuntimeSource(block.source);
   if(manifest.file)void this.openRuntimeSource(manifest.file).catch(err=>new Notice(String(err)));
   else new Notice('El código HTML está dentro de este mismo bloque.');
  }});
  this.addCommand({id:'snapshot-lab',name:'Guardar parámetros como snapshot en el bloque actual',editorCallback:(editor,view)=>{
   const block=runtimeBlockAtCursor(editor);
   if(!block||!view.file){new Notice('Coloca el cursor dentro de un bloque physlab/v1.');return;}
   const state=this.runtimeStates.get(view.file.path,block.id);
   if(!state){new Notice('Abre el laboratorio y ajusta sus controles primero.');return;}
   try{
    const before=editor.getValue(),after=snapshotRuntimeBlock(before,block.id,block.source,state);
    editor.replaceRange(updatedBlock(before,after,block.from,block.to),editor.offsetToPos(block.from),editor.offsetToPos(block.to));
    new Notice('Snapshot guardado en la nota.');
   }catch(err){new Notice(String(err));}
  }});
  this.registerEvent(this.app.workspace.on('active-leaf-change',leaf=>{if(leaf?.view instanceof MarkdownView)this.lastMarkdownLeaf=leaf;}));
  this.registerEvent(this.app.vault.on('modify',file=>{
   if(file.path.endsWith('.html'))for(const child of this.runtimeChildren)if(child.manifest?.file===file.path)void child.remount();
  }));
  this.registerEvent(this.app.vault.on('rename',(file,oldPath)=>{
   this.runtimeStates.renameNote(oldPath,file.path);
   for(const child of this.runtimeChildren)if(child.notePath===oldPath)child.notePath=file.path;
  }));
  this.registerEvent(this.app.workspace.on('css-change',()=>this.refreshLabs()));
  this.addSettingTab(new PhysLabSettingTab(this.app,this,this));
 }
 override onunload():void{
  for(const child of [...this.runtimeChildren])child.unload();
  for(const child of [...this.children])child.unload();
  for(const lab of [...liveInstances])lab.destroy();
  void this.runtimeStates.flush().catch(err=>console.error('[PhysicaLab] No se pudo guardar el estado',err));
 }
 ensureMath():Promise<void>{return ensureMathJax();}
 async saveSettings():Promise<void>{
  const record:Record<string,unknown>={...this.data,...this.settings};delete record.ai;
  const snapshot=JSON.parse(JSON.stringify(record)) as Record<string,unknown>;
  this.saving=this.saving.catch(()=>{}).then(()=>this.saveData(snapshot));await this.saving;
 }
 async saveLabState(lab:LabInstance):Promise<void>{
  if(!lab.config.id)throw new Error('El laboratorio no tiene id.');
  const state=await this.files.saveState(lab.config.id,lab.preset.id,lab.preset.version,lab.store.snapshot().values);
  lab.markSaved(state.savedAt);new Notice('Estado guardado.');
 }
 openExpanded(lab:LabInstance):void{new ExpandedLabModal(this.app,this,lab).open();}
 insertIntoActiveNote(text:string):boolean{
  const leaf=this.app.workspace.getActiveViewOfType(MarkdownView)?.leaf??this.lastMarkdownLeaf;
  if(!(leaf?.view instanceof MarkdownView)||leaf.view.getMode()!=='source')return false;
  leaf.view.editor.replaceSelection(text);return true;
 }
 refreshLabs():void{for(const child of [...this.children,...this.runtimeChildren])void child.remount();}
 async readRuntimeNote(path:string):Promise<string>{
  const file=this.app.vault.getFileByPath(path);if(!file)throw new Error('No se encuentra la nota del laboratorio.');
  const active=this.editableView(path);return active?active.editor.getValue():this.app.vault.cachedRead(file);
 }
 async readRuntimeHTML(path:string):Promise<string>{
  parseRuntimeSource(JSON.stringify({version:1,id:'path-check',file:path}));
  const file=this.app.vault.getFileByPath(path);if(!file||file.extension!=='html')throw new Error(`No se encuentra el HTML: ${path}`);
  if(file.stat.size>2_000_000)throw new Error('El laboratorio supera el límite de 2 MB.');
  const adapter=this.app.vault.adapter;
  if(Platform.isDesktopApp&&adapter instanceof FileSystemAdapter){
   const fs=require('node:fs/promises') as typeof import('node:fs/promises');
   const paths=require('node:path') as typeof import('node:path');
   const [base,target]=await Promise.all([fs.realpath(adapter.getBasePath()),fs.realpath(paths.join(adapter.getBasePath(),path))]);
   const relative=paths.relative(base,target);
   if(relative==='..'||relative.startsWith('..'+paths.sep)||paths.isAbsolute(relative))throw new Error('El HTML apunta fuera del vault mediante un enlace.');
  }
  const html=await this.app.vault.read(file);if(html.length>2_000_000)throw new Error('El laboratorio supera el límite de 2 MB.');return html;
 }
 runtimeVendors(features:readonly string[]){return loadVendorBundles(this.app.vault.adapter,this.manifest.dir??`${this.app.vault.configDir}/plugins/${this.manifest.id}`,features);}
 async openRuntimeSource(path:string):Promise<void>{
  const html=await this.readRuntimeHTML(path),file=this.app.vault.getFileByPath(path);if(file)new RuntimeSourceModal(this.app,file,html).open();
 }
 async saveRuntimeSnapshot(notePath:string,id:string,source:string,state:Record<string,unknown>):Promise<void>{
  const file=this.app.vault.getFileByPath(notePath);if(!file)throw new Error('No se encuentra la nota.');
  const active=this.editableView(notePath);
  if(active){
   const before=active.editor.getValue(),after=snapshotRuntimeBlock(before,id,source,state),block=findRuntimeBlocks(before).find(b=>b.id===id)!;
   active.editor.replaceRange(updatedBlock(before,after,block.from,block.to),active.editor.offsetToPos(block.from),active.editor.offsetToPos(block.to));
  }else await this.app.vault.process(file,text=>snapshotRuntimeBlock(text,id,source,state));
 }
 private editableView(path:string):MarkdownView|undefined{
  return this.app.workspace.getLeavesOfType('markdown').map(leaf=>leaf.view).find((view):view is MarkdownView=>view instanceof MarkdownView&&view.file?.path===path&&view.getMode()==='source');
 }
 private async openStudio():Promise<void>{
  let leaf=this.app.workspace.getLeavesOfType(STUDIO_VIEW)[0];
  if(!leaf){leaf=Platform.isMobile?this.app.workspace.getLeaf(true):(this.app.workspace.getRightLeaf(false)??this.app.workspace.getLeaf(true));await leaf.setViewState({type:STUDIO_VIEW,active:true});}
  await this.app.workspace.revealLeaf(leaf);
 }
}

function updatedBlock(before:string,after:string,from:number,to:number):string{return after.slice(from,after.length-(before.length-to));}
