import { normalizePath, TFile, type DataAdapter, type FileManager, type Vault } from 'obsidian';
import type { FileAdapter } from '../persistence/lab-files';

/**
 * Persistencia con la API del Vault (la recomendada por las pautas de
 * Obsidian: usa la caché del vault y serializa las escrituras). Funciona
 * igual en escritorio y Android. Las rutas dentro de carpetas ocultas
 * («.algo/…»), que el Vault no indexa, se delegan en el adaptador.
 */
export class VaultFileAdapter implements FileAdapter {
	constructor(
		private readonly vault: Vault,
		private readonly fileManager?: FileManager,
	) {}

	private get adapter(): DataAdapter {
		return this.vault.adapter;
	}

	private static hidden(path: string): boolean {
		return path.split('/').some((seg) => seg.startsWith('.'));
	}

	async exists(path: string): Promise<boolean> {
		const p = normalizePath(path);
		if (VaultFileAdapter.hidden(p)) return this.adapter.exists(p);
		return this.vault.getAbstractFileByPath(p) !== null;
	}

	async read(path: string): Promise<string> {
		const p = normalizePath(path);
		if (VaultFileAdapter.hidden(p)) return this.adapter.read(p);
		const file = this.vault.getFileByPath(p);
		if (!file) throw new Error(`No existe ${p}`);
		return this.vault.read(file);
	}

	async write(path: string, data: string): Promise<void> {
		const p = normalizePath(path);
		if (VaultFileAdapter.hidden(p)) return this.adapter.write(p, data);
		const file = this.vault.getFileByPath(p);
		if (file) await this.vault.modify(file, data);
		else await this.vault.create(p, data);
	}

	async mkdir(path: string): Promise<void> {
		const p = normalizePath(path);
		if (VaultFileAdapter.hidden(p)) return this.adapter.mkdir(p);
		if (!this.vault.getAbstractFileByPath(p)) await this.vault.createFolder(p);
	}

	async listFiles(dir: string): Promise<string[]> {
		const p = normalizePath(dir);
		if (VaultFileAdapter.hidden(p)) return (await this.adapter.list(p)).files;
		const folder = this.vault.getFolderByPath(p);
		if (!folder) return [];
		return folder.children.filter((c): c is TFile => c instanceof TFile).map((c) => c.path);
	}

	async remove(path: string): Promise<void> {
		const p = normalizePath(path);
		if (VaultFileAdapter.hidden(p)) return this.adapter.remove(p);
		const file = this.vault.getFileByPath(p);
		if (!file) return;
		// A la papelera (recuperable), respetando la preferencia del usuario.
		if (this.fileManager) await this.fileManager.trashFile(file);
		else await this.vault.trash(file, true);
	}
}
