import { MarkdownRenderChild } from 'obsidian';
import type { LabInstance } from '../core/lab-host';
import type { ParamValues } from '../core/types';
import type { PhysLabHost } from './host';
import { isResolveError, mountResolved, renderBlockError, resolveLabSource } from './mount';

/**
 * Ciclo de vida de un bloque `physlab` en una nota. Obsidian llama a
 * `onunload` cuando el bloque sale del documento (edición, cierre de la
 * nota o recarga); entonces se libera todo el laboratorio.
 */
export class LabRenderChild extends MarkdownRenderChild {
	private lab: LabInstance | null = null;
	private alive = false;
	private mounting = false;
	/** Observador de la carga diferida mientras el bloque espera a entrar en vista. */
	private pending: IntersectionObserver | null = null;

	constructor(
		containerEl: HTMLElement,
		private readonly host: PhysLabHost,
		private readonly source: string,
		private readonly registry: Set<LabRenderChild>,
	) {
		super(containerEl);
	}

	override onload(): void {
		this.alive = true;
		this.registry.add(this);
		const el = this.containerEl;
		el.empty();
		el.addClass('physlab-block');
		// IntersectionObserver de la ventana del bloque (Obsidian admite ventanas emergentes).
		const win = (el.ownerDocument.defaultView ?? window) as Window & { IntersectionObserver?: typeof IntersectionObserver };
		const IO = win.IntersectionObserver;
		if (!this.host.settings.lazyLoad || !IO) {
			void this.mount();
			return;
		}
		// Carga diferida: el laboratorio se crea al acercarse a la vista.
		el.createDiv({ cls: 'physlab-placeholder', text: 'PhysicaLab: preparando el laboratorio…' });
		const io = new IO(
			(entries) => {
				if (entries.some((e) => e.isIntersecting)) {
					this.stopWaiting();
					void this.mount();
				}
			},
			{ rootMargin: '400px 0px' },
		);
		this.pending = io;
		io.observe(el);
		this.register(() => this.stopWaiting());
	}

	override onunload(): void {
		this.alive = false;
		this.registry.delete(this);
		this.stopWaiting();
		this.lab?.destroy();
		this.lab = null;
	}

	/**
	 * Vuelve a montar con los ajustes actuales (tema, decimales…) conservando
	 * los valores que el usuario aún no ha guardado. Un bloque que todavía
	 * espera a entrar en vista no se monta aquí: lo hará la carga diferida.
	 */
	async remount(): Promise<void> {
		if (!this.alive || this.pending) return;
		const carry = this.lab ? { ...this.lab.store.snapshot().values } : null;
		this.lab?.destroy();
		this.lab = null;
		await this.mount(carry);
	}

	get instance(): LabInstance | null {
		return this.lab;
	}

	private stopWaiting(): void {
		this.pending?.disconnect();
		this.pending = null;
	}

	private async mount(carry: ParamValues | null = null): Promise<void> {
		if (this.mounting || !this.alive) return;
		this.mounting = true;
		try {
			const resolved = await resolveLabSource(this.host, this.source);
			if (!this.alive) return;
			if (isResolveError(resolved)) {
				renderBlockError(this.containerEl, this.host, resolved.errors, resolved.warnings);
				return;
			}
			const lab = await mountResolved(
				this.host,
				this.containerEl,
				resolved,
				() => this.alive,
				() => {
					// Nunca dos instancias para el mismo bloque.
					this.lab?.destroy();
					this.lab = null;
					this.containerEl.empty();
				},
			);
			if (!this.alive || !lab) {
				lab?.destroy();
				return;
			}
			this.lab = lab;
			// Los valores sin guardar sobreviven al remontaje y siguen marcados como «sin guardar».
			if (carry) lab.store.load(carry, 'load');
			lab.flush();
		} catch (err) {
			console.error('[PhysicaLab] error al montar el laboratorio', err);
			if (this.alive) renderBlockError(this.containerEl, this.host, [err instanceof Error ? err.message : String(err)]);
		} finally {
			this.mounting = false;
		}
	}
}
