import type { App } from 'obsidian';
import type { LabInstance } from '../core/lab-host';
import type { PresetRegistry } from '../core/registry';
import type { MathEngine } from '../render/math/math-renderer';
import type { LabFiles } from '../persistence/lab-files';
import type { PhysLabSettings } from './settings';

/**
 * Lo que las vistas, modales y bloques necesitan del plugin. Evita
 * dependencias circulares con main.ts.
 */
export interface PhysLabHost {
	readonly app: App;
	readonly settings: PhysLabSettings;
	readonly registry: PresetRegistry;
	readonly engine: MathEngine;
	readonly files: LabFiles;
	ensureMath(): Promise<void>;
	saveSettings(): Promise<void>;
	/** Guarda el estado de un laboratorio en PhysicaLab/states/<id>.json. */
	saveLabState(lab: LabInstance): Promise<void>;
	/** Abre la vista ampliada compartiendo el estado del laboratorio. */
	openExpanded(lab: LabInstance): void;
	/** Inserta texto en el último editor Markdown activo. Devuelve `false` si no hay ninguno. */
	insertIntoActiveNote(text: string): boolean;
	/** Notifica a los laboratorios montados que cambió el tema o los ajustes. */
	refreshLabs(): void;
}
