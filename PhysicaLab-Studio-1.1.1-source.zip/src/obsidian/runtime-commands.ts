import { Modal, Notice, SuggestModal, type App, type Editor, type TFile } from 'obsidian';
import { runtimeCodeBlock, findRuntimeBlocks } from '../runtime/editor';

export class InsertRuntimeModal extends SuggestModal<TFile> {
 constructor(app:App,private readonly editor:Editor){super(app);this.setPlaceholder('Elige un laboratorio HTML del vault…');}
 getSuggestions(query:string):TFile[]{return this.app.vault.getFiles().filter(f=>f.extension==='html'&&f.path.toLocaleLowerCase().includes(query.toLocaleLowerCase())).slice(0,100);}
 renderSuggestion(file:TFile,el:HTMLElement):void{el.setText(file.path);}
 async onChooseSuggestion(file:TFile):Promise<void>{
  const html=await this.app.vault.read(file);
  const position=this.editor.getCursor(),prefix=this.editor.getLine(position.line).trim()?'\n\n':'';
  let block=runtimeCodeBlock(file.path);
  if(/\bTHREE\b|\bOrbitControls\b/.test(html))block=block.replace('"2d",','"2d",\n    "3d",');
  this.editor.replaceSelection(prefix+block);
  new Notice('Laboratorio insertado en la nota.');
 }
}

/** HTML is edited as text here; opening source never executes it. */
export class RuntimeSourceModal extends Modal {
 constructor(app:App,private readonly file:TFile,private readonly original:string){super(app);}
 override onOpen():void{
  this.titleEl.setText(this.file.path);this.modalEl.addClass('physlab-source-modal');
  const editor=this.contentEl.createEl('textarea',{attr:{'aria-label':'Código fuente HTML',spellcheck:'false'}});
  editor.value=this.original;editor.style.cssText='width:100%;height:60vh;font-family:monospace;font-size:13px;white-space:pre;tab-size:2';
  const status=this.contentEl.createDiv({attr:{'aria-live':'polite'}});
  const save=this.contentEl.createEl('button',{text:'Guardar HTML',cls:'mod-cta'});
  save.addEventListener('click',()=>void (async()=>{
   save.disabled=true;
   try{
    await this.app.vault.process(this.file,current=>{if(current!==this.original)throw new Error('El HTML cambió en otro editor. Cierra y vuelve a abrir el código.');return editor.value;});
    this.close();new Notice('HTML guardado; los laboratorios se recargan automáticamente.');
   }catch(error){status.textContent=String(error);save.disabled=false;}
  })());
 }
 override onClose():void{this.contentEl.empty();}
}

export function runtimeBlockAtCursor(editor:Editor):ReturnType<typeof findRuntimeBlocks>[number]|undefined{
 const offset=editor.posToOffset(editor.getCursor());
 return findRuntimeBlocks(editor.getValue()).find(block=>offset>=block.from&&offset<=block.to);
}
