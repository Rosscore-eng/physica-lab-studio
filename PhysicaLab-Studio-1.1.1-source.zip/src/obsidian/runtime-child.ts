import { MarkdownRenderChild } from 'obsidian';
import { findRuntimeBlocks } from '../runtime/editor';
import { RuntimeFrame } from '../runtime/frame';
import { parseRuntimeSource, type RuntimeManifest } from '../runtime/manifest';
import type { VendorBundles } from '../runtime/document';
import type { RuntimeStateStore } from '../runtime/state';
import { applyTheme, THEMES, TOKEN_KEYS, type ThemeId, type ThemeTokens } from '../theme/tokens';

export interface RuntimeHost {
 settings: {lazyLoad: boolean; theme: ThemeId; tokenOverrides: Partial<Record<keyof ThemeTokens,string>>};
 runtimeStates: RuntimeStateStore;
 readRuntimeNote(path: string): Promise<string>;
 readRuntimeHTML(path: string): Promise<string>;
 runtimeVendors(features: readonly string[]): Promise<VendorBundles>;
 openRuntimeSource(path: string): Promise<void>;
 saveRuntimeSnapshot(notePath: string,id: string,expectedSource: string,state: Record<string,unknown>): Promise<void>;
}

/** One frame per rendered block, owned by Obsidian's Markdown lifecycle. */
export class RuntimeRenderChild extends MarkdownRenderChild {
 frame: RuntimeFrame | null = null;
 manifest: RuntimeManifest | null = null;
 private alive = false;
 private revision = 0;
 private pending: IntersectionObserver | null = null;
 private status: HTMLElement | null = null;
 private expanded = false;
 private fullscreenCleanup: (()=>void) | null = null;

 constructor(container: HTMLElement,private readonly host: RuntimeHost,private readonly source: string,public notePath: string,private readonly registry: Set<RuntimeRenderChild>,private readonly sourceLine?:()=>number|null) {super(container);}

 override onload(): void {
  this.alive = true; this.registry.add(this);
  this.containerEl.classList.add('physlab-runtime');
  const win = this.containerEl.ownerDocument.defaultView as (Window & typeof globalThis) | null;
  if(this.host.settings.lazyLoad && win?.IntersectionObserver) {
   this.containerEl.textContent = 'PhysicaLab: preparando laboratorio…';
   this.pending = new win.IntersectionObserver(entries => {
    if(entries.some(e=>e.isIntersecting)) {this.pending?.disconnect();this.pending=null;void this.mount();}
   },{rootMargin:'400px'});
   this.pending.observe(this.containerEl);
  } else void this.mount();
 }
 override onunload(): void {
  this.alive=false;this.revision++;this.registry.delete(this);
  this.pending?.disconnect();this.pending=null;
  this.frame?.destroy();this.frame=null;this.leaveExpanded();this.containerEl.replaceChildren();
 }
 async remount(): Promise<void> {
  if(!this.alive||this.pending) return;
  if(this.frame&&this.manifest) this.host.runtimeStates.set(this.notePath,this.manifest.id,this.frame.snapshot());
  await this.mount();
 }
 private async mount(): Promise<void> {
  const revision=++this.revision, current=()=>this.alive&&revision===this.revision;
  this.leaveExpanded();
  this.frame?.destroy();this.frame=null;
  try {
   const parsed=parseRuntimeSource(this.source), manifest=parsed.manifest;
   this.manifest=manifest;
   const note=await this.host.readRuntimeNote(this.notePath);
   if(!current()) return;
   const line=this.sourceLine?.();
   if(line!==undefined&&line!==null&&!/^ {0,3}(?:`{3,}|~{3,})physlab\s*$/.test(note.split(/\r?\n/)[line]??'')) throw new Error('Coloca el bloque physlab al nivel principal de la nota, fuera de listas y callouts.');
   if(!findRuntimeBlocks(note).some(b=>b.id===manifest.id)) throw new Error('Coloca el bloque physlab al nivel principal de la nota.');
   if(findRuntimeBlocks(note).filter(b=>b.id===manifest.id).length>1) throw new Error(`ID duplicado «${manifest.id}» en esta nota. Asigna un id diferente a cada bloque.`);
   const html=parsed.html??await this.host.readRuntimeHTML(manifest.file!);
   const bundles=await this.host.runtimeVendors(manifest.features);
   if(!current()) return;
   this.containerEl.replaceChildren();
   const theme=manifest.theme??this.host.settings.theme;
   applyTheme(this.containerEl,theme,this.host.settings.tokenOverrides);
   const tokens:Record<string,string>={};
   const css=this.containerEl.ownerDocument.defaultView?.getComputedStyle(this.containerEl);
   for(const key of TOKEN_KEYS) {
    const value=css?.getPropertyValue('--pl-'+key).trim();
    tokens[key]=value&&!value.includes('var(')?value:THEMES[theme==='scientific-light'?'scientific-light':'scientific-dark'][key];
   }
   const bar=this.containerEl.createDiv({cls:'pl-runtime-toolbar'});
   bar.createSpan({cls:'pl-runtime-title',text:manifest.id});
   const button=(label:string,cls:string,action:()=>void)=>{
    const b=bar.createEl('button',{text:label,cls,attr:{type:'button'}});b.addEventListener('click',action);return b;
   };
   button('↺ Reiniciar','pl-runtime-reset',()=>{
    this.host.runtimeStates.reset(this.notePath,manifest.id);this.frame?.reset();this.setStatus('Parámetros iniciales restaurados');
   });
   button('Guardar','pl-runtime-save',()=>void this.action(async()=>{
    if(this.frame) this.host.runtimeStates.set(this.notePath,manifest.id,this.frame.snapshot());
    await this.host.runtimeStates.flush();this.setStatus('Estado guardado');
   }));
   button('Snapshot','pl-runtime-snapshot',()=>void this.action(async()=>{
    await this.host.saveRuntimeSnapshot(this.notePath,manifest.id,this.source,this.frame?.snapshot()??{});
    this.setStatus('Snapshot guardado en la nota');
   }));
   if(manifest.file) button('Código HTML','pl-runtime-source',()=>void this.action(()=>this.host.openRuntimeSource(manifest.file!)));
   button('Copiar bloque','pl-runtime-copy',()=>void this.action(async()=>{
    const copy={...manifest,id:manifest.id.slice(0,119)+'-'+crypto.randomUUID().slice(0,8),initialState:this.frame?.snapshot()??manifest.initialState};
    const source=parsed.html===undefined?JSON.stringify(copy,null,2):`<!-- physlab:v1 ${JSON.stringify(copy)} -->\n${parsed.html}`;
    const fence='`'.repeat(Math.max(3,...[...source.matchAll(/`+/g)].map(m=>m[0].length+1)));
    await navigator.clipboard.writeText(`${fence}physlab\n${source}\n${fence}\n`);this.setStatus('Bloque copiado con un ID nuevo');
   }));
   const expand=button('Ampliar','pl-runtime-expand',()=>void this.action(()=>this.toggleExpanded(expand)));
   this.status=this.containerEl.createDiv({cls:'pl-runtime-status',attr:{'aria-live':'polite'}});
   this.setStatus('Los parámetros se guardan automáticamente; Snapshot los incorpora a la nota.');
   const stage=this.containerEl.createDiv({cls:'pl-runtime-stage'});
   const saved=this.host.runtimeStates.get(this.notePath,manifest.id);
   this.frame=new RuntimeFrame(stage,{html,manifest,bundles,initialState:{...manifest.initialState,...saved},appearance:{tokens,fontFamily:"'Latin Modern Roman', 'KaTeX_Main', serif"},
    onState:state=>{try{this.host.runtimeStates.set(this.notePath,manifest.id,state);this.setStatus('Parámetros actualizados');}catch(error){this.setStatus(String(error),true);}},
    onError:message=>this.setStatus(message,true),
   });
  } catch(error) {
   if(!current()) return;
   this.containerEl.replaceChildren();
   this.containerEl.createDiv({cls:'physlab-error',text:`PhysicaLab: ${error instanceof Error?error.message:String(error)}`});
  }
 }
 private async toggleExpanded(button:HTMLButtonElement):Promise<void> {
  const doc=this.containerEl.ownerDocument;
  if(doc.fullscreenElement===this.containerEl){await doc.exitFullscreen();this.leaveExpanded();return;}
  if(typeof this.containerEl.requestFullscreen!=='function')throw new Error('Esta ventana no admite pantalla completa.');
  button.disabled=true;
  const sync=()=>{
   this.expanded=doc.fullscreenElement===this.containerEl;
   this.containerEl.classList.toggle('pl-runtime-expanded',this.expanded);
   button.textContent=this.expanded?'Cerrar ampliación':'Ampliar';
   if(!this.expanded){this.fullscreenCleanup?.();this.fullscreenCleanup=null;}
  };
  this.fullscreenCleanup?.();
  this.fullscreenCleanup=()=>{doc.removeEventListener('fullscreenchange',sync);button.textContent='Ampliar';};
  doc.addEventListener('fullscreenchange',sync);
  try{
   // Native fullscreen uses the browser's top layer, outside CodeMirror's clipping.
   // The iframe stays in place, so the simulation and unsaved parameters survive.
   await this.containerEl.requestFullscreen();
   if(this.alive)sync();else this.leaveExpanded();
  }catch(error){this.leaveExpanded();throw error;}
  finally{button.disabled=false;}
 }
 private leaveExpanded():void {
  const doc=this.containerEl.ownerDocument;
  this.fullscreenCleanup?.();this.fullscreenCleanup=null;
  this.expanded=false;this.containerEl.classList.remove('pl-runtime-expanded');
  if(doc.fullscreenElement===this.containerEl&&typeof doc.exitFullscreen==='function')void doc.exitFullscreen().catch(()=>{});
 }
 private setStatus(text:string,error=false):void {if(this.status){this.status.textContent=text;this.status.classList.toggle('is-error',error);}}
 private async action(run:()=>Promise<void>):Promise<void> {try{await run();}catch(error){this.setStatus(error instanceof Error?error.message:String(error),true);}}
}
