import { Modal, type App, type Editor } from 'obsidian';
import { LabInstance } from '../core/lab-host';
import type { PhysLabHost } from './host';
import { blockFor, collectLibrary, filterLibrary, renderCards, renderModeTabs, type LibraryItem, type ModeFilter } from './library';
import { hostServices } from './mount';

/** Vista ampliada: segunda vista del MISMO estado (comparte el almacén). */
export class ExpandedLabModal extends Modal {
	private view: LabInstance | null = null;

	constructor(
		app: App,
		private readonly host: PhysLabHost,
		private readonly source: LabInstance,
	) {
		super(app);
	}

	override onOpen(): void {
		this.modalEl.addClass('physlab-modal');
		// Un solo reloj por estado: la animación del bloque se pausa y se controla desde aquí.
		this.source.pauseAnimations();
		const s = this.host.settings;
		this.view = new LabInstance(this.contentEl, {
			preset: this.source.preset,
			config: this.source.config,
			engine: this.host.engine,
			services: hostServices(this.host, false),
			store: this.source.store,
			variant: 'expanded',
			theme: this.source.config.theme ?? s.theme,
			tokenOverrides: s.tokenOverrides,
			decimals: s.decimals,
			savedAt: this.source.lastSaved,
			mathThrottleMs: s.mathThrottleMs,
		});
		this.view.flush();
	}

	override onClose(): void {
		this.view?.destroy();
		this.view = null;
		this.contentEl.empty();
	}
}

/** «Insertar laboratorio»: biblioteca por modos y plantillas; inserta el bloque en el cursor. */
export class InsertLabModal extends Modal {
	private filter: ModeFilter = 'math';
	private items: LibraryItem[] = [];

	constructor(
		app: App,
		private readonly host: PhysLabHost,
		private readonly editor: Editor,
	) {
		super(app);
	}

	override async onOpen(): Promise<void> {
		this.titleEl.setText('Insertar laboratorio');
		this.modalEl.addClass('physlab-insert-modal');
		this.items = await collectLibrary(this.host);
		this.draw();
	}

	override onClose(): void {
		this.contentEl.empty();
	}

	private draw(): void {
		const el = this.contentEl;
		el.empty();
		renderModeTabs(el, this.filter, (m) => {
			this.filter = m;
			this.draw();
		});
		renderCards(el, filterLibrary(this.items, this.filter), (item) => {
			const block = blockFor(item, this.host);
			const cur = this.editor.getCursor();
			const line = this.editor.getLine(cur.line);
			const prefix = line.trim() === '' ? '' : '\n\n';
			this.editor.replaceSelection(prefix + block);
			this.close();
		});
		el.createEl('p', {
			cls: 'physlab-card-summary',
			text: 'El bloque se inserta con un «id» nuevo para poder guardar su estado. Puedes editar sus parámetros en la nota.',
		});
	}
}

/** Confirmación simple (sí/no). */
export class ConfirmModal extends Modal {
	private resolved = false;

	constructor(
		app: App,
		private readonly title: string,
		private readonly message: string,
		private readonly confirmText: string,
		private readonly resolve: (ok: boolean) => void,
	) {
		super(app);
	}

	override onOpen(): void {
		this.titleEl.setText(this.title);
		this.contentEl.createEl('p', { text: this.message });
		const row = this.contentEl.createDiv({ cls: 'modal-button-container' });
		const ok = row.createEl('button', { text: this.confirmText, cls: 'mod-cta' });
		ok.addEventListener('click', () => this.finish(true));
		const cancel = row.createEl('button', { text: 'Cancelar' });
		cancel.addEventListener('click', () => this.finish(false));
	}

	override onClose(): void {
		if (!this.resolved) this.resolve(false);
		this.contentEl.empty();
	}

	private finish(ok: boolean): void {
		this.resolved = true;
		this.resolve(ok);
		this.close();
	}

	static ask(app: App, title: string, message: string, confirmText = 'Continuar'): Promise<boolean> {
		return new Promise((resolve) => new ConfirmModal(app, title, message, confirmText, resolve).open());
	}
}
