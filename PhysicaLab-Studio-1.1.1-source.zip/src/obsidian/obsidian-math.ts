import { finishRenderMath, loadMathJax, renderMath } from 'obsidian';
import type { MathEngine } from '../render/math/math-renderer';

/** Motor matemático nativo de Obsidian (MathJax incluido en la app; funciona sin conexión). */
export class ObsidianMathEngine implements MathEngine {
	readonly kind = 'obsidian-mathjax';

	render(tex: string, display: boolean): HTMLElement {
		return renderMath(tex, display);
	}

	finish(): void {
		void finishRenderMath();
	}
}

let loading: Promise<void> | null = null;

/** Carga MathJax una sola vez, cuando el primer laboratorio lo necesita (no al arrancar). */
export function ensureMathJax(): Promise<void> {
	if (!loading) {
		loading = loadMathJax().catch((err: unknown) => {
			loading = null;
			throw err;
		});
	}
	return loading;
}
