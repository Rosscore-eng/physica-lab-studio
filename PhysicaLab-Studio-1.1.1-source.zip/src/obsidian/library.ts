import { parseYaml } from 'obsidian';
import { makeLabId, normalizeLabObject, toCodeBlock, type LabConfig } from '../core/schema';
import { LAB_MODES, MODE_LABEL, type LabMode, type ParamValue } from '../core/types';
import type { PhysLabHost } from './host';

/** Elemento de la biblioteca: preset base, ejemplo de un preset o plantilla del usuario. */
export interface LibraryItem {
	key: string;
	kind: 'preset' | 'example' | 'template';
	mode: LabMode;
	presetId: string;
	title: string;
	summary: string;
	parameters: Record<string, ParamValue>;
	/** Configuración completa (plantillas). */
	config?: LabConfig;
}

export type ModeFilter = LabMode | 'templates';

export async function collectLibrary(host: PhysLabHost): Promise<LibraryItem[]> {
	const items: LibraryItem[] = [];
	for (const p of host.registry.list()) {
		items.push({ key: p.id, kind: 'preset', mode: p.mode, presetId: p.id, title: p.title, summary: p.summary, parameters: {} });
		for (const [i, ex] of (p.examples ?? []).entries()) {
			items.push({
				key: `${p.id}#${i}`,
				kind: 'example',
				mode: p.mode,
				presetId: p.id,
				title: ex.title,
				summary: `${p.title} · ejemplo`,
				parameters: ex.parameters,
			});
		}
	}
	try {
		for (const t of await host.files.listTemplates(parseYaml)) {
			if (t.error) continue;
			const parsed = normalizeLabObject(t.raw);
			const preset = parsed.config ? host.registry.get(parsed.config.preset) : undefined;
			if (!parsed.config || !preset) continue;
			items.push({
				key: `tpl:${t.path}`,
				kind: 'template',
				mode: preset.mode,
				presetId: preset.id,
				title: parsed.config.title ?? t.name,
				summary: `Plantilla · ${t.path}`,
				parameters: parsed.config.parameters,
				config: parsed.config,
			});
		}
	} catch (err) {
		console.warn('[PhysicaLab] no se pudieron leer las plantillas', err);
	}
	return items;
}

export function filterLibrary(items: LibraryItem[], filter: ModeFilter): LibraryItem[] {
	return filter === 'templates' ? items.filter((i) => i.kind === 'template') : items.filter((i) => i.mode === filter && i.kind !== 'template');
}

/** Bloque Markdown para un elemento de la biblioteca, con un id nuevo. */
export function blockFor(item: LibraryItem, host: PhysLabHost): string {
	const preset = host.registry.get(item.presetId);
	const base = item.config;
	return toCodeBlock({
		...(base ?? {}),
		id: makeLabId(preset?.title ?? item.presetId),
		preset: item.presetId,
		title: base?.title ?? (item.kind === 'preset' ? null : item.title),
		parameters: item.parameters,
	});
}

/** Selector Math / Physics / Circuits (+ Plantillas). */
export function renderModeTabs(parent: HTMLElement, current: ModeFilter, onChange: (m: ModeFilter) => void, withTemplates = true): void {
	const bar = parent.createDiv({ cls: 'physlab-modes' });
	bar.setAttr('role', 'tablist');
	const modes: ModeFilter[] = [...LAB_MODES, ...(withTemplates ? (['templates'] as const) : [])];
	for (const m of modes) {
		const b = bar.createEl('button', { text: m === 'templates' ? 'Plantillas' : MODE_LABEL[m] });
		b.setAttr('role', 'tab');
		b.setAttr('aria-selected', String(m === current));
		if (m === current) b.addClass('is-active');
		b.addEventListener('click', () => onChange(m));
	}
}

export function renderCards(parent: HTMLElement, items: LibraryItem[], onPick: (item: LibraryItem) => void, selectedKey?: string): void {
	const grid = parent.createDiv({ cls: 'physlab-library' });
	if (items.length === 0) {
		grid.createDiv({ cls: 'physlab-card-summary', text: 'No hay elementos. Las plantillas propias se guardan en la carpeta de plantillas (Ajustes → PhysicaLab Studio).' });
		return;
	}
	for (const item of items) {
		const card = grid.createEl('button', { cls: 'physlab-card' });
		if (item.key === selectedKey) card.addClass('is-selected');
		card.createDiv({ cls: 'physlab-card-title', text: item.title });
		card.createDiv({ cls: 'physlab-card-summary', text: item.summary });
		card.createDiv({ cls: 'physlab-card-meta', text: item.presetId });
		card.addEventListener('click', () => onPick(item));
	}
}
