import { PluginSettingTab, Setting, type App, type Plugin } from 'obsidian';
import { DEFAULT_PATHS } from '../persistence/lab-files';
import { THEME_IDS, THEME_LABEL, THEMES, TOKEN_KEYS, TOKEN_LABEL, type ThemeId } from '../theme/tokens';
import type { PhysLabHost } from './host';

export class PhysLabSettingTab extends PluginSettingTab {
	constructor(
		app: App,
		plugin: Plugin,
		private readonly host: PhysLabHost,
	) {
		super(app, plugin);
	}

	override display(): void {
		const { containerEl } = this;
		const s = this.host.settings;
		const save = async (refresh = false): Promise<void> => {
			await this.host.saveSettings();
			if (refresh) this.host.refreshLabs();
		};
		containerEl.empty();

		new Setting(containerEl).setName('Apariencia').setHeading();
		new Setting(containerEl)
			.setName('Tema de los laboratorios')
			.setDesc('Cada bloque puede elegir otro con «theme:».')
			.addDropdown((d) => {
				for (const id of THEME_IDS) d.addOption(id, THEME_LABEL[id]);
				d.setValue(s.theme).onChange(async (v) => {
					s.theme = v as ThemeId;
					await save(true);
				});
			});
		new Setting(containerEl)
			.setName('Decimales')
			.setDesc('Cifras decimales en lecturas y ecuaciones.')
			.addSlider((sl) =>
				sl
					.setLimits(0, 5, 1)
					.setValue(s.decimals)
					.setDynamicTooltip()
					.onChange(async (v) => {
						s.decimals = v;
						await save(true);
					}),
			);

		const palette = s.theme === 'scientific-light' ? THEMES['scientific-light'] : THEMES['scientific-dark'];
		const details = containerEl.createEl('details');
		details.createEl('summary', { text: 'Colores (tokens del tema)' });
		for (const k of TOKEN_KEYS) {
			new Setting(details)
				.setName(TOKEN_LABEL[k])
				.setDesc(s.tokenOverrides[k] ? `Personalizado: ${s.tokenOverrides[k]}` : `Por defecto: ${palette[k]}`)
				.addColorPicker((c) =>
					c.setValue(s.tokenOverrides[k] ?? palette[k]).onChange(async (v) => {
						s.tokenOverrides[k] = v;
						await save(true);
					}),
				)
				.addExtraButton((b) =>
					b
						.setIcon('rotate-ccw')
						.setTooltip('Restablecer')
						.onClick(async () => {
							delete s.tokenOverrides[k];
							await save(true);
							this.display();
						}),
				);
		}

		new Setting(containerEl).setName('Archivos').setHeading();
		const pathSetting = (key: 'labs' | 'states' | 'templates', name: string, desc: string): void => {
			new Setting(containerEl)
				.setName(name)
				.setDesc(desc)
				.addText((t) =>
					t
						.setPlaceholder(DEFAULT_PATHS[key])
						.setValue(s.paths[key])
						.onChange(async (v) => {
							s.paths[key] = v.trim() || DEFAULT_PATHS[key];
							await save();
						}),
				);
		};
		pathSetting('labs', 'Carpeta de laboratorios', 'Definiciones reutilizables (YAML/JSON) que un bloque puede cargar con «file:».');
		pathSetting('states', 'Carpeta de estados', 'Un JSON por laboratorio, solo al pulsar «Guardar estado».');
		pathSetting('templates', 'Carpeta de plantillas', 'Plantillas propias que aparecen en la biblioteca.');

		new Setting(containerEl).setName('Rendimiento y móvil').setHeading();
		new Setting(containerEl)
			.setName('Carga diferida')
			.setDesc('Crear cada laboratorio solo cuando se acerca a la pantalla (recomendado en notas largas).')
			.addToggle((t) =>
				t.setValue(s.lazyLoad).onChange(async (v) => {
					s.lazyLoad = v;
					await save();
				}),
			);
		new Setting(containerEl)
			.setName('Panel plegado en el móvil')
			.setDesc('Muestra primero la figura; el panel se abre con el botón de la cabecera.')
			.addToggle((t) =>
				t.setValue(s.collapsePanelOnMobile).onChange(async (v) => {
					s.collapsePanelOnMobile = v;
					await save();
				}),
			);
		new Setting(containerEl)
			.setName('Frecuencia de ecuaciones durante el arrastre')
			.setDesc('Intervalo mínimo (ms) entre actualizaciones de LaTeX mientras arrastras. Súbelo si un móvil va lento.')
			.addSlider((sl) =>
				sl
					.setLimits(0, 250, 10)
					.setValue(s.mathThrottleMs)
					.setDynamicTooltip()
					.onChange(async (v) => {
						s.mathThrottleMs = v;
						await save(true);
					}),
			);

	}
}
