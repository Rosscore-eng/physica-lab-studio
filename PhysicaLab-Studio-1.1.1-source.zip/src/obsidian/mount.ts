import { Notice, parseYaml, Platform } from 'obsidian';
import { LabInstance, type HostServices } from '../core/lab-host';
import {
	checkParameters,
	isPlainObject,
	mergeRawLabObjects,
	normalizeLabObject,
	parseLabSource,
	type LabConfig,
} from '../core/schema';
import { MODE_LABEL } from '../core/types';
import type { PhysLabHost } from './host';

export interface ResolvedLab {
	config: LabConfig;
	warnings: string[];
}

export interface ResolveError {
	errors: string[];
	warnings: string[];
}

/** Lee el bloque, fusiona `file:` si existe y lo valida contra el registro. */
export async function resolveLabSource(host: PhysLabHost, source: string): Promise<ResolvedLab | ResolveError> {
	const first = parseLabSource(source, parseYaml);
	if (!first.config) return { errors: first.errors, warnings: first.warnings };
	let config = first.config;
	const warnings = [...first.warnings];

	if (config.file) {
		try {
			const external = await host.files.loadLabFile(config.file, parseYaml);
			const blockRaw: unknown = source.trim().startsWith('{') ? JSON.parse(source) : parseYaml(source);
			const merged = normalizeLabObject(mergeRawLabObjects(external, isPlainObject(blockRaw) ? blockRaw : {}));
			if (!merged.config) return { errors: merged.errors, warnings: [...warnings, ...merged.warnings] };
			config = merged.config;
			warnings.push(...merged.warnings.filter((w) => !warnings.includes(w)));
		} catch (err) {
			return { errors: [err instanceof Error ? err.message : String(err)], warnings };
		}
	}

	const preset = host.registry.get(config.preset);
	if (!preset) {
		return {
			errors: [`No existe el preset «${config.preset}».`],
			warnings,
		};
	}
	warnings.push(...checkParameters(config, preset.params));
	return { config, warnings };
}

export function isResolveError(r: ResolvedLab | ResolveError): r is ResolveError {
	return 'errors' in r;
}

export function hostServices(host: PhysLabHost, withExpand = true): HostServices {
	return {
		notify: (msg, kind) => new Notice(kind === 'error' ? `PhysicaLab: ${msg}` : msg, kind === 'error' ? 8000 : 3000),
		save: (lab) => host.saveLabState(lab),
		copy: async (text) => {
			await navigator.clipboard.writeText(text);
		},
		expand: withExpand ? (lab) => host.openExpanded(lab) : undefined,
	};
}

/**
 * Monta un laboratorio ya resuelto: carga el estado guardado (si existe) y
 * aplica los ajustes del plugin. Comprueba `isAlive` tras cada espera.
 */
export async function mountResolved(
	host: PhysLabHost,
	container: HTMLElement,
	resolved: ResolvedLab,
	isAlive: () => boolean = () => true,
	beforeCreate: () => void = () => {},
): Promise<LabInstance | null> {
	const preset = host.registry.get(resolved.config.preset);
	if (!preset) return null;
	await host.ensureMath().catch((err: unknown) => console.warn('[PhysicaLab] MathJax no disponible', err));
	if (!isAlive()) return null;

	let saved: Awaited<ReturnType<typeof host.files.loadState>> = null;
	const warnings = [...resolved.warnings];
	const canSave = resolved.config.features.saveState && !!resolved.config.id;
	if (canSave && resolved.config.id) {
		try {
			saved = await host.files.loadState(resolved.config.id);
		} catch (err) {
			warnings.push(`Estado guardado ilegible: ${err instanceof Error ? err.message : String(err)}`);
		}
		if (!isAlive()) return null;
		if (saved && saved.preset && saved.preset !== preset.id) {
			warnings.push(`El estado guardado de «${resolved.config.id}» pertenece a otro preset (${saved.preset}); se ignora.`);
			saved = null;
		}
	}

	const s = host.settings;
	beforeCreate();
	const lab = new LabInstance(container, {
		preset,
		config: resolved.config,
		engine: host.engine,
		services: hostServices(host),
		theme: resolved.config.theme ?? s.theme,
		tokenOverrides: s.tokenOverrides,
		decimals: s.decimals,
		warnings,
		savedAt: saved?.savedAt ?? null,
		mathThrottleMs: s.mathThrottleMs,
		collapsePanel: resolved.config.explicitFeatures.controlsCollapsed ?? (Platform.isMobile && s.collapsePanelOnMobile ? true : undefined),
	});
	if (saved) {
		const ignored = lab.store.load(saved.values, 'load');
		lab.markSaved(saved.savedAt);
		if (ignored.length) console.info('[PhysicaLab] parámetros guardados ignorados:', ignored);
	}
	return lab;
}

/** Caja de error legible para un bloque inválido. */
export function renderBlockError(el: HTMLElement, host: PhysLabHost, errors: string[], warnings: string[] = []): void {
	el.empty();
	const box = el.createDiv({ cls: 'physlab-error' });
	box.createEl('strong', { text: 'PhysicaLab: no se pudo crear el laboratorio' });
	const ul = box.createEl('ul');
	for (const e of errors) ul.createEl('li', { text: e });
	for (const w of warnings) ul.createEl('li', { text: `Aviso: ${w}` });
	const list = host.registry
		.list()
		.map((p) => `${p.id} (${MODE_LABEL[p.mode]}: ${p.title})`)
		.join('\n');
	box.createEl('div', { text: `Presets disponibles:\n${list}` });
}
