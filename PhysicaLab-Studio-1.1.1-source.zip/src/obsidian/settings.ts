import { DEFAULT_PATHS, type LabPaths } from '../persistence/lab-files';
import { isHexColor, isThemeId, TOKEN_KEYS, type ThemeId, type ThemeTokens } from '../theme/tokens';

export interface PhysLabSettings {
	settingsVersion: 1;
	theme: ThemeId;
	tokenOverrides: Partial<Record<keyof ThemeTokens, string>>;
	paths: LabPaths;
	/** Decimales en lecturas y ecuaciones. */
	decimals: number;
	/** Montar cada laboratorio solo cuando se acerca a la vista. */
	lazyLoad: boolean;
	/** Panel de parámetros plegado al abrir en el móvil. */
	collapsePanelOnMobile: boolean;
	/** Intervalo mínimo entre re-tipografías durante el arrastre (ms). */
	mathThrottleMs: number;
}

export const DEFAULT_SETTINGS: PhysLabSettings = {
	settingsVersion: 1,
	theme: 'scientific-dark',
	tokenOverrides: {},
	paths: { ...DEFAULT_PATHS },
	decimals: 2,
	lazyLoad: true,
	collapsePanelOnMobile: false,
	mathThrottleMs: 60,
};

/** Fusiona datos guardados con los valores por defecto, validando cada campo. */
export function sanitizeSettings(raw: unknown): PhysLabSettings {
	const d = (typeof raw === 'object' && raw !== null ? raw : {}) as Record<string, unknown>;
	const s: PhysLabSettings = structuredClone(DEFAULT_SETTINGS);
	if (isThemeId(d.theme)) s.theme = d.theme;
	if (typeof d.tokenOverrides === 'object' && d.tokenOverrides !== null) {
		for (const k of TOKEN_KEYS) {
			const v = (d.tokenOverrides as Record<string, unknown>)[k];
			if (isHexColor(v)) s.tokenOverrides[k] = v;
		}
	}
	if (typeof d.paths === 'object' && d.paths !== null) {
		const p = d.paths as Record<string, unknown>;
		for (const k of ['labs', 'states', 'templates'] as const) {
			if (typeof p[k] === 'string' && (p[k] as string).trim() !== '') s.paths[k] = (p[k] as string).trim();
		}
	}
	if (typeof d.decimals === 'number' && d.decimals >= 0 && d.decimals <= 6) s.decimals = Math.round(d.decimals);
	if (typeof d.lazyLoad === 'boolean') s.lazyLoad = d.lazyLoad;
	if (typeof d.collapsePanelOnMobile === 'boolean') s.collapsePanelOnMobile = d.collapsePanelOnMobile;
	if (typeof d.mathThrottleMs === 'number' && d.mathThrottleMs >= 0 && d.mathThrottleMs <= 500) s.mathThrottleMs = d.mathThrottleMs;
	return s;
}
