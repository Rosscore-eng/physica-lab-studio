import { ItemView, type WorkspaceLeaf } from 'obsidian';
import type { PhysLabHost } from './host';

export const STUDIO_VIEW='physlab-studio';
export class StudioView extends ItemView {
 constructor(leaf:WorkspaceLeaf,private readonly host:PhysLabHost){super(leaf);}
 getViewType():string{return STUDIO_VIEW;}
 getDisplayText():string{return 'PhysicaLab Studio';}
 override getIcon():string{return 'flask-conical';}
 override async onOpen():Promise<void>{
  const root=this.contentEl;root.empty();root.addClass('physlab-studio');
  root.createEl('h2',{text:'PhysicaLab Studio'});
  root.createEl('p',{text:'Describe tu laboratorio a la IA en Copilot, Codex o Claude. El agente escribe un HTML con el modelo, las figuras y sus controles. PhysicaLab lo reproduce en tu nota.'});
  const steps=root.createEl('ol');
  for(const text of ['Pide un HTML original siguiendo SKILL.md y RUNTIME_ARCHITECTURE.md del plugin.','Guarda el HTML dentro del vault (por ejemplo, PhysicaLab/labs/mi-laboratorio.html).','En la nota, ejecuta «PhysicaLab Studio: Insertar laboratorio desde archivo HTML».','Arrastra las figuras o usa los controles. El estado se guarda automáticamente; Snapshot copia los parámetros a la nota.'])steps.createEl('li',{text});
  root.createEl('h3',{text:'Temas y ecuaciones'});
  root.createEl('p',{text:'El tema se elige en los ajustes: Scientific Dark, Scientific Light o seguir Obsidian. Las ecuaciones usan KaTeX y fuentes LaTeX locales. Cada laboratorio puede mostrar el código LaTeX de sus fórmulas.'});
  root.createEl('h3',{text:'Manifiesto de ejemplo'});
  root.createEl('pre',{text:JSON.stringify({version:1,id:'mi-laboratorio',file:'PhysicaLab/labs/mi-laboratorio.html',height:640,features:['2d','latex'],initialState:{}},null,2)});
  root.createEl('p',{text:`Tema actual: ${this.host.settings.theme}. Los bloques antiguos siguen disponibles por compatibilidad.`});
 }
 override async onClose():Promise<void>{this.contentEl.empty();}
}
