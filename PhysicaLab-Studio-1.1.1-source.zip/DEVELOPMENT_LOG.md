# DEVELOPMENT_LOG — PhysicaLab Studio V1.0

Registro de progreso: tareas completadas, pruebas, problemas pendientes y siguiente paso. Las fechas usan America/Lima.

## 2026-10-20

### Fase 0 — Inspección del entorno
- Windows 11, Node 24.15.0, npm 11.12.1, Obsidian 1.14.4 (instalador 1.8.10), Claude Code CLI 2.1.300. Codex CLI y Ollama no están instalados. Edge y Chrome están disponibles para las pruebas de interfaz.
- Se inspeccionó un vault de desarrollo con tema oscuro y otros complementos activos, sin modificar su configuración.
- Posible interacción: `siyuan-code-blocks` decora bloques de código. `physlab` se registra como procesador propio, así que Obsidian no lo pinta como código. Pendiente de confirmar en el vault real.
- El proyecto se desarrolló en un repositorio local aislado. Las dependencias son locales (devDependencies); no se instaló nada global.
- API consultada en `node_modules/obsidian/obsidian.d.ts` 1.14.4: `registerMarkdownCodeBlockProcessor`, `MarkdownRenderChild`, `renderMath`/`finishRenderMath`/`loadMathJax`, `Platform`, `FileSystemAdapter`. Plantilla de referencia: `obsidianmd/obsidian-sample-plugin` (esbuild + tsc).

### Fase A — Fundamentos ✅
- Arquitectura modular: `core` (tipos, almacén, esquema, ciclo de vida, anfitrión), `render` (SVG, capa LaTeX, primitivas), `interaction` (arrastre), `controls` (panel), `theme` (tokens), `presets`, `persistence`, `obsidian` (integración), `ai`.
- Almacén reactivo por laboratorio (`ParamStore`): es la única fuente de verdad. Valida tipo, límites, paso, escala log, rangos dinámicos y reglas propias, y bloquea parámetros desde el bloque (`lock`/`hide`).
- Motor SVG con `viewBox` fijo y una capa HTML de etiquetas LaTeX posicionadas en porcentaje: siguen a la geometría al cambiar el tamaño sin recalcular nada.
- Arrastre con Pointer Events: captura de puntero, conversión de coordenadas, `touch-action: none` solo en las asas, zona táctil mínima de 22 px y teclado.
- Tokens del tema Scientific Dark / Light / «seguir Obsidian», configurables y solo con colores hexadecimales validados.
- `ResourceScope`: registra listeners, observadores, temporizadores y frames; `ResourceScope.live` permite detectar fugas.

### Fase B — Secante y tangente ✅
- `math.secant-tangent`: A y B se arrastran sobre la parábola, con un imán que lleva a h = 0. Hay un inserto con m_sec(h) y su hueco en h = 0, la animación «h → 0» y el botón «h = 0». Las ecuaciones se actualizan en vivo.
- Caso h = 0: el cociente 0/0 aparece como **no definido** (nunca como el límite), se oculta la secante, se muestra la tangente y una nota de estado.
- **Pruebas:** 32 unitarias superadas, y en Edge: arrastre con ratón y táctil real (CDP), sin desbordamiento a 390 px, sin desplazamiento de la página al arrastrar, sin errores de consola y recursos vivos 138 → 0 al cerrar.
- Problemas corregidos: el campo numérico no aceptaba coma decimal (ahora es de texto con teclado decimal) y la animación se atascaba por el redondeo al paso.

### Fase D — Integración en Obsidian ✅ (pendiente de prueba en la app real)
- `physlab` se registra con `registerMarkdownCodeBlockProcessor`. El ciclo de vida usa `MarkdownRenderChild` (`LabRenderChild`) con carga diferida (IntersectionObserver), y el laboratorio se libera en `onunload` y al desactivar el plugin.
- Comandos: «Insertar laboratorio» (biblioteca por modos y plantillas), «Abrir PhysicaLab Studio», «Generar laboratorio desde una descripción» y «Recargar los laboratorios abiertos». También hay un icono en la cinta.
- Studio (`ItemView`): selector Math / Physics / Circuits / Plantillas, vista previa en vivo, insertar en la nota, copiar el bloque, guardar como plantilla y generador.
- La vista ampliada (modal) comparte el **mismo** almacén que el bloque.
- Persistencia en archivos legibles: `PhysicaLab/states/<id>.json`, que solo se escribe al pulsar «Guardar» y nunca al mover un deslizador; `PhysicaLab/labs/` (clave `file:`) y `PhysicaLab/templates/`. Las rutas se pueden configurar. Se ignoran las copias en conflicto de Syncthing.
- Ajustes: tema, decimales, colores, rutas, carga diferida, panel plegado en el móvil, frecuencia de LaTeX durante el arrastre y proveedores de IA.
- **Pruebas de integración (jsdom + simulación de la API):** guardado explícito, restauración al reabrir, «Restablecer» vuelve a los valores del bloque, `file:`, varios laboratorios en la misma nota y cierre de la nota durante el montaje sin fugas.

### En curso
- Fase C (péndulo, dos cargas, circuito RC) y Fase E (generador sin IA, programa auxiliar CLI y puente de escritorio): se desarrollan en paralelo, cada parte con sus pruebas y capturas.
- **Incidencia:** la primera ejecución en paralelo falló por el límite de sesión de la cuenta (se reinicia a las 14:40). Se relanzó tras el reinicio; no quedaron archivos a medias.

### Siguiente paso
Integrar y revisar la Fase C/E, escribir las notas de demostración del vault de pruebas, compilar, hacer la revisión adversarial y las pruebas completas (Fase F), y preparar la documentación y la publicación en GitHub.
