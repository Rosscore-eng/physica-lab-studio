# Latin Modern Roman

`lmroman10-regular.otf` is the unmodified Latin Modern Roman 10 Regular font by
Bogusław Jackowski and Janusz M. Nowacki (GUST e-foundry), copied from this
computer's existing user font installation on 2026-10-24.

Publisher: https://www.gust.org.pl/projects/e-foundry/latin-modern

SHA-256: `1aa18cfefa58132c52ce5de70db1fd1154201c19cd2b2cdaffba4906a33e6852`

The original font name and file are preserved. The build embeds its original
bytes in a CSS data URL; it does not alter or rename the font. The font is for
scientific prose; KaTeX keeps its own matched math fonts for layout accuracy.

License: GUST Font License 1.0, with LPPL 1.3c (both included here and copied to
the plugin's `vendor/` distribution). License files were retrieved from the
publisher's GUST license URL and https://www.latex-project.org/lppl/lppl-1-3c.txt.
