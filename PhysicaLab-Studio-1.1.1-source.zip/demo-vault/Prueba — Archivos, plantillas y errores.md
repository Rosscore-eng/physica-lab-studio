# Archivos, plantillas y errores

## Bloque con avisos (parámetros fuera de rango y claves desconocidas)

```physlab
id: avisos-01
preset: physics.pendulum
parameters:
  theta0: 140
  longitud: 2
color: rojo
```

## Preset inexistente (error legible)

```physlab
preset: physics.cohete
```

## YAML roto

```physlab
preset: [physics.pendulum
```

## Sin id: se puede usar, pero no guardar estado

```physlab
preset: math.secant-tangent
```

## Bloques de código normales: no cambian

```python
print("hola")
```
