# Secante y tangente

La pendiente de la recta secante que pasa por $A=(x_0,f(x_0))$ y $B=(x_0+h,f(x_0+h))$ es el cociente incremental. Cuando $B\to A$ ($h\to 0$), esa pendiente tiende a la derivada $f'(x_0)$.

```physlab
id: demo-secante-01
preset: math.secant-tangent
title: Secante y tangente de f(x) = x²
parameters:
  x0: 1
  h: 0.75
```

**Prueba esto:**

1. Arrastra **B** hacia **A**. La gráfica de la derecha muestra $m_{\text{sec}}(h)=2x_0+h$ con un hueco en $h=0$.
2. Pulsa **Reproducir** para acercar B a A automáticamente.
3. Pulsa **h = 0**. El cociente $0/0$ no está definido, pero su límite sí existe.

## El mismo laboratorio, cerca del límite y sin panel

```physlab
id: demo-secante-02
preset: math.secant-tangent
title: Casi tangente
parameters:
  x0: -1.5
  h: 0.05
features:
  controls: false
```
