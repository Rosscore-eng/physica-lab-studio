# Varios laboratorios en una nota

Cada laboratorio tiene su propio estado. Mover uno no afecta a los demás. Al cerrar la nota se liberan todos (carga diferida: se crean al acercarse a la pantalla).

```physlab
id: multi-sec
preset: math.secant-tangent
parameters:
  x0: 0.5
```

```physlab
id: multi-pend
preset: physics.pendulum
parameters:
  theta0: 60
  L: 1
```

```physlab
id: multi-cargas
preset: physics.two-charges
parameters:
  q1: 3
  q2: 3
```

```physlab
id: multi-rc
preset: circuits.rc-charging
features:
  controlsCollapsed: true
```

Texto normal después de los laboratorios, para comprobar que el resto de la nota no cambia.
