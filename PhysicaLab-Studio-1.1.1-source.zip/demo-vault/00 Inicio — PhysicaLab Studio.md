# PhysicaLab Studio — vault de pruebas

Vault aislado para probar el plugin sin tocar tu vault principal.

## Laboratorios de demostración

- [[MathLab — Secante y tangente]]
- [[PhysicsLab — Péndulo simple]]
- [[PhysicsLab — Dos cargas eléctricas]]
- [[CircuitLab — Circuito RC]]

## Pruebas

- [[Prueba — Varios laboratorios en una nota]]
- [[Prueba — Archivos, plantillas y errores]]

## Cómo usarlo

1. Abre una nota de laboratorio en **modo lectura** o en **Live Preview**.
2. Arrastra los puntos, las masas, las cargas o los componentes con el ratón o el dedo, o usa el panel de parámetros. Las dos vías están sincronizadas.
3. Los iconos de la cabecera hacen, por orden:
   - ↺ restablece los valores del bloque;
   - 💾 guarda el estado en `PhysicaLab/states/<id>.json`;
   - ⧉ copia el bloque con los parámetros actuales;
   - ⛶ abre la vista ampliada;
   - ☰ muestra u oculta el panel.
4. Comandos (`Ctrl+P`):
   - **Insertar laboratorio**
   - **Abrir PhysicaLab Studio**
   - **Generar laboratorio desde una descripción**
