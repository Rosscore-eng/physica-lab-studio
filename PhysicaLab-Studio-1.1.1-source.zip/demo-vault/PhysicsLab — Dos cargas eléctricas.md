# Campo eléctrico de dos cargas

Ley de Coulomb: $F = k\dfrac{|q_1q_2|}{r^2}$. El campo total en un punto es la superposición de los campos de cada carga.

```physlab
id: demo-cargas-01
preset: physics.two-charges
title: Dos cargas puntuales
parameters:
  q1: 3
  q2: -2
  fieldView: lines
```

**Prueba esto:**

- Arrastra las cargas y el punto de prueba **P**.
- Cambia el signo de $q_2$ con el deslizador: las líneas de campo se reorganizan.
- Cambia la representación a **vectores** o **ambos**.

## Dipolo (vista de vectores)

```physlab
id: demo-dipolo-01
preset: physics.two-charges
title: Dipolo eléctrico
parameters:
  q1: 2
  q2: -2
  x1: -0.7
  x2: 0.7
  fieldView: both
theme: scientific-light
```
