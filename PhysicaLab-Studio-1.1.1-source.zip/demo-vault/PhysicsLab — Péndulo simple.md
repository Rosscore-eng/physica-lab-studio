# Péndulo simple

Para pequeñas oscilaciones, $T_0 = 2\pi\sqrt{L/g}$. Con amplitudes grandes, el período exacto es $T = 4\sqrt{L/g}\,K\!\left(\sin\frac{\theta_0}{2}\right)$.

```physlab
id: demo-pendulo-01
preset: physics.pendulum
title: Péndulo simple
parameters:
  theta0: 30
  L: 1.5
  m: 1
  g: 9.81
```

**Prueba esto:**

1. Arrastra la masa: el ángulo $\theta_0$ del panel cambia, y la masa no se separa de la circunferencia de radio $L$.
2. Sube $\theta_0$ por encima de 15°. El aviso indica que la aproximación $\sin\theta\approx\theta$ deja de ser buena.
3. Pulsa **Reproducir**. La animación integra la ecuación no lineal con RK4.

## En la Luna (definición en un archivo)

Este bloque carga `PhysicaLab/labs/pendulo-luna.yaml` y cambia solo la amplitud:

```physlab
file: pendulo-luna.yaml
parameters:
  theta0: 45
```
