# Carga de un condensador (RC serie)

$V_C(t) = V_s\left(1-e^{-t/\tau}\right)$, con $\tau = RC$.

```physlab
id: demo-rc-01
preset: circuits.rc-charging
title: Circuito RC — carga
parameters:
  Vs: 12
  R: 10
  C: 100
  t: 1
```

**Prueba esto:**

1. Arrastra la resistencia, el condensador o la fuente: los cables siguen conectados a los mismos terminales.
2. Arrastra el punto de la curva para cambiar $t$, o pulsa **Reproducir**.
3. Cambia $R$ o $C$ y observa cómo cambia la forma de la curva. Activa **Fijar la ventana de tiempo** para comparar entre valores.

## Carga rápida

```physlab
id: demo-rc-02
preset: circuits.rc-charging
parameters:
  Vs: 5
  R: 4.7
  C: 1
  t: 0.005
lock: [Vs]
```
