# SKILL — Crear laboratorios científicos para PhysicaLab Studio

**Destinatarios:** agentes de desarrollo Codex/Claude manejados **manualmente desde Copilot de Obsidian**. **Propósito:** construir desde cero un laboratorio científico fiable, interactivo y compatible con el reproductor PhysicaLab. **No** configurar integraciones de API/CLI/agentes dentro de PhysicaLab.

> **Compatibilidad importante:** el contrato `physlab/v1` detallado aquí es una **especificación objetivo**. Antes de editar la nota, inspecciona el plugin instalado, sus archivos reales y su README; comprueba qué partes del contrato están efectivamente implementadas. Si no están implementadas, no declares que el laboratorio puede ejecutarse: explica la brecha o implementa el runtime solo si el usuario te encargó expresamente modificar el plugin.

## 1. Orden obligatorio de trabajo

1. **Leer:** este `SKILL.md`, `README.md` y el contrato del runtime (`RUNTIME_ARCHITECTURE.md`), y examinar las rutas reales del vault y del plugin. Comprobar que no se está confundiendo PhysicaLab con otros proyectos de ObsidianRoss.
2. **Aclarar el fenómeno:** determinar magnitudes, unidades, parámetros, rangos, hipótesis, condiciones iniciales/de frontera y nivel de aproximación. Priorizar modelos académicos estudiados. No resolver un modelo distinto al pedido ni presentar una aproximación como solución exacta.
3. **Derivar antes de dibujar:** construir ecuaciones y solución analítica, simbólica o numérica. Si procede, usar Python/SymPy/NumPy/SciPy **en fase de desarrollo**, nunca imponer Python al usuario en la reproducción de problemas simples.
4. **Verificar:** implementar pruebas independientes con valores conocidos, casos límite, conservación/identidades, verificación de unidades y muestreo de parámetros. Guardar evidencia reproducible.
5. **Implementar modelo runtime:** traducir cálculo a JS/TS compilado (o WASM permitido si está comprobado); implementar una función pura `compute(params)` o equivalente. El mismo cálculo controla números, gráficas, ecuaciones, vectores, circuitos y animación.
6. **Construir interfaz original:** añadir SVG/Canvas para 2D, Three.js/WebGL para 3D cuando corresponda, KaTeX para LaTeX dinámico, controles sincronizados, entrada táctil y accesibilidad básica. Presets y ejemplos disponibles son solo referencias; jamás constituyen límites de fenómenos posibles.
7. **Aislar y empaquetar:** HTML autosuficiente sin CDN ni scripts remotos; utilizar las librerías locales del sandbox si el runtime las ofrece. No pedir acceso a Obsidian, a la red ni a otros archivos desde el iframe.
8. **Probar y colocar:** ejecutar tests del modelo, comprobar sintaxis de JS, abrir el laboratorio con el runtime real en una nota de prueba, y luego insertar en la nota solicitada mediante edición autorizada o comando de inserción. No presuponer acceso al cursor.
9. **Entregar:** ruta de archivo y nota modificada, modelo elegido, pruebas realizadas y limitaciones relevantes. No informar falsamente que se probó Android o WebGL si no ocurrió.

## 2. Invariantes científicos obligatorios

- Todo control que cambie una magnitud física/matemática produce un nuevo cálculo real y su representación correspondiente.
- No hay resultados numéricos independientes del modelo: texto, LaTeX, SVG, Canvas y 3D comparten **el mismo estado y resultado**.
- Las fórmulas reflejan el modelo implementado, con variables y unidades consistentes.
- En problemas numéricos registrar algoritmo/integrador, discretización, estabilidad, dominio y error estimado cuando corresponda.
- Tratar entradas no válidas, singularidades, límites de simulación y NaN/Infinity sin dibujar soluciones ficticias.
- La cámara 3D solo cambia la vista; **arrastrar un objeto físico** modifica parámetros mediante la restricción geométrica del problema.
- Animación temporal: el tiempo simulado y la integración numérica deben ser consistentes con las ecuaciones; separar timestep de FPS visual.
- Si no puede verificarse un resultado científico, no declararlo validado. Documentar su alcance con precisión.

## 3. Contrato del bloque Markdown

**Preferencia: archivo HTML externo.** Crear `PhysicaLab/labs/<slug>.html` dentro del vault y añadir en la nota:

~~~markdown
```physlab
{
  "version": 1,
  "id": "slug-id-unico",
  "file": "PhysicaLab/labs/slug.html",
  "height": 520,
  "features": ["2d", "latex"],
  "initialState": {}
}
```
~~~

Para 3D usar `"features": ["3d", "latex"]`; una misma implementación puede combinar 2D y 3D. Estas `features` cargan bibliotecas, **no seleccionan un tipo de problema**.

**Alternativa inline para laboratorios pequeños:**

~~~markdown
```physlab
<!-- physlab:v1 {"id":"slug-inline","height":520,"features":["2d","latex"],"initialState":{}} -->
<div id="app"></div>
<style>/* estilos propios */</style>
<script>/* modelo y render propios */</script>
```
~~~

No reescribir accidentalmente el resto de la nota. Evitar IDs duplicados en el mismo Markdown. Si el runtime real aún no reconoce alguna de estas formas, usar el formato que **sí esté implementado** o reportar el cambio de runtime necesario.

## 4. API mínima esperada dentro del frame

Si el runtime `physlab/v1` la tiene implementada, usar `window.PhysLab`:

```js
const defaults = { n: 4, method: 'left' };
let state = { ...defaults, ...(window.PhysLab?.initialState || {}) };

function compute(params) { /* calcular resultados comprobados */ }
function render(results, params) { /* actualizar todas las vistas */ }
function update(patch) {
  state = validate({ ...state, ...patch });
  const results = compute(state);
  render(results, state);
  window.PhysLab?.saveState(state);
}

update({}); // render inicial
window.PhysLab?.on('pause', () => { /* pausar animación */ });
window.PhysLab?.on('destroy', () => { /* limpiar listeners y GPU */ });
```

La función `validate` es específica del modelo; el agente debe escribirla. No inventar servicios o endpoints `PhysLab` que no figuren en el contrato.

## 5. Elección de representación

**SVG:** circuitos, mecanismos, ejes y diagramas geométricos con puntos arrastrables. **Canvas 2D:** trazado de funciones y grandes cantidades de muestras. **Three.js/WebGL:** superficies, campos, sólidos, órbitas, espacios de configuración y geometría 3D. **KaTeX:** ecuaciones, etiquetas y resultados; actualizar después del cálculo.

### Reglas 3D adicionales

- Comprobar WebGL2, mostrar estado de error o fallback si no existe.
- Preferir `PhysLab.libs.THREE` y `PhysLab.libs.OrbitControls` del bundle offline si el host los inyecta. No importar Three.js de un CDN en el HTML del laboratorio.
- Inicializar cámara, ejes, escala y leyenda de unidades; permitir orbit/zoom/pan en ratón y táctil.
- Para arrastre de parámetros: `Raycaster` para selección, plano o superficie de restricción para movimiento, conversión a parámetro, `compute()` y actualización de todos los paneles. Deshabilitar temporalmente OrbitControls durante el arrastre para evitar conflictos táctiles.
- Los labels matemáticos pueden ser elementos DOM con KaTeX cuya posición se proyecta desde coordenadas de mundo cada vez que cambia cámara.
- Actualizar buffer/geometría si cambia el fenómeno. Destruir `geometry`, `material`, `texture`, `controls`, `renderer` y listeners al desmontar.
- Si la nota contiene varios laboratorios 3D, no activar todos en bucle de 60 FPS. Render por cambios y suspensión por invisibilidad.

## 6. Procedimiento de validación

Crear `tests/<slug>.mjs` (o `.py` cuando sea la vía más apropiada), ejecutarlo y registrar resultados. Las pruebas deben ser **independientes** de la rutina de dibujo: una captura bonita nunca sustituye un test.

**Riemann, aceptación de referencia:** `f(x)=x²`, `[0,2]`, `n=4`: izquierda `1.75`, derecha `3.75`, punto medio `2.625`; valor exacto `8/3`. Probar también n=1, crecimiento de n, método elegido, error, borde del dominio, sincronización de rectángulos y fórmulas.

**Circuitos:** usar formulación nodal/mallas, comprobar KCL/KVL, balance de potencia, límites de resistencia/carga. Indicar modelo de los diodos (ideal o caída fija o no lineal), sentido de conducción y dinámica de condensador si existe.

**Sistemas mecánicos:** consistencia de unidades, constraints, energía/otras invariantes según modelo y método de integración. Para 3D verificar proyección y retrotransformación de parámetros al arrastrar.

**Calidad técnica:** no red, no APIs de Obsidian, ninguna dependencia no empaquetada, inicialización segura, responsivo, etiquetas legibles y comportamiento móvil comprobado cuando sea posible.

## 7. Inserción, edición y persistencia

- Si el agente tiene autorización y herramientas para editar Markdown, insertar el bloque donde el usuario lo pidió, sin modificar secciones no relacionadas, y abrir/verificar la nota.
- Si carece de acceso al cursor, generar la ruta HTML y el bloque `physlab` para que el usuario emplee el comando de PhysicaLab **Insertar laboratorio desde archivo** (si existe); no afirmar haber insertado contenido sin haberlo hecho.
- Mantener el HTML como fuente editable. Cambios de parámetros durante la interacción se guardan por API `saveState` si existe, pero no se deben reescribir miles de veces en la nota.
- Para valores congelados en Markdown, usar el comando explícito de snapshot, verificando que el bloque no haya cambiado entretanto.

## 8. Lista de verificación final

- [ ] Contrato realmente soportado por el plugin inspeccionado.
- [ ] Modelo y unidades identificados correctamente.
- [ ] Cálculos y casos límite contrastados de forma independiente.
- [ ] La visualización se alimenta del resultado calculado, no de una animación ficticia.
- [ ] Cada control y arrastre recalcula el fenómeno y sincroniza fórmulas/valores/gráficas.
- [ ] LaTeX renderizado y expresiones con significado correcto.
- [ ] 3D incorporado si el fenómeno lo necesita, con órbita, zoom, táctil y limpieza.
- [ ] Offline y aislamiento respetados; no se añadieron scripts CDN.
- [ ] Inserción confirmada en la nota real o bloque listo para usar, sin afirmaciones inventadas.
- [ ] Pruebas de escritorio/móvil declaradas con su alcance real.

## 9. Errores que debes evitar

No sustituir generación original con menú de cuatro presets. No devolver `supported: false` porque un fenómeno no aparece en un catálogo. No integrar modelos ni CLI dentro del plugin. No confundir una animación con un cálculo. No simular coeficientes o datos como si se hubieran medido. No construir una API de capacidades privilegiadas para los iframes. No usar Pyodide/NumPy en tiempo de reproducción sin necesidad y sin comprobar soporte. No afirmar que PhysicaLab actual soporta `physlab/v1` hasta verificarlo.
