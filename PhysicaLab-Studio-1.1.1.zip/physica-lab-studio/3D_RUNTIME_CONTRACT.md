# PhysicaLab — Diseño específico de soporte 3D (contrato V1 propuesto)

**Estado:** guía de implementación pendiente de contrastar con el código real y el dispositivo Android. Esta es una **capacidad genérica WebGL**, no un motor de fenómenos predefinidos.

## 1. Separar cuatro planos de responsabilidad

| Plano | Responsable | Contenido |
|---|---|---|
| Ciencia | Agente autor del laboratorio | Derivaciones, `compute(params)`, sistema de unidades, error y pruebas independientes |
| Estado del laboratorio | Código propio del laboratorio | Parámetros y evolución física: `setParameter()` → `compute()` → actualización de todas las vistas |
| Render 3D | Código propio del laboratorio + Three.js | Cámaras, geometrías, materiales, raycasting, ejes, etiquetas y controles |
| Seguridad / ciclo de vida | PhysicaLab anfitrión | Frame aislado, bibliotecas locales, carga diferida, pausa/limpieza, persistencia y manejo de errores |

Ninguno de estos planos requiere que PhysicaLab sepa previamente qué es un péndulo, campo, superficie o circuito. **El plugin no incluye una tabla de temas aceptados.**

## 2. Dependencias y orden de carga

Al detectar `"features": ["3d", "latex"]` el host prepara un iframe aislado; inserta CSP restrictiva, bridge `PhysLab` y bundles locales de Three.js, `OrbitControls`, KaTeX/CSS/fonts (si se solicita). Solo después inicia el script original del agente.

Los bundles se fijan a versiones concretas y se construyen por separado con esbuild/Rollup como scripts clásicos IIFE, exponiendo **exclusivamente dentro del frame** `PhysLab.libs.THREE`, `PhysLab.libs.OrbitControls` y `PhysLab.libs.katex`. Si el host detecta insuficiencia de WebGL2, emite error visible y muestra contenido alternativo que el laboratorio proporcione. No CDN ni import dinámico desde repositorios externos.

La API es propuesta y necesita implementación efectiva: un archivo HTML de ejemplo que haga `const THREE = PhysLab.libs.THREE` **no es standalone** a menos que también incluya explícitamente un bundle local compatible.

## 3. Escena técnica reutilizable, sin imponer física

1. Crear un `<canvas>` dentro de la zona gráfica y `new THREE.WebGLRenderer({canvas, antialias: true, powerPreference: 'low-power'})` si WebGL2 está disponible.
2. Crear `THREE.Scene`, `PerspectiveCamera` u `OrthographicCamera` según tipo de información, luz cuando corresponda y `OrbitControls(camera, canvas)`.
3. Incorporar ejes `x,y,z`, retícula, límites y anotaciones de **unidades físicas**. Un `AxesHelper` no reemplaza por sí mismo etiquetas ni escala.
4. El agente calcula mallas: para `z=f(x,y;a)` evalúa `f` con el valor real del parámetro `a` sobre un dominio declarado. Crea `BufferGeometry` y recalcula `position`/normales o reemplaza buffers cuando `a` cambie.
5. Representar campos: evaluar `F(x,y,z;params)` desde el modelo, muestrear posiciones, normalizar solo para dibujar cuando se indique explícitamente; magnitud indicada en escala/leyenda. No confundir flechas normalizadas con fuerzas idénticas.
6. Instalar `ResizeObserver`, realizar ajuste `renderer.setSize(width,height,false)`, actualizar aspecto y `camera.updateProjectionMatrix()`. Limitar pixel ratio con `renderer.setPixelRatio(Math.min(window.devicePixelRatio, cap))`.
7. Activar render solo al mutar escena o controles si la física es estática. Para simulación temporal, usar lazo controlado y pausa visible.

## 4. Direct manipulation: del gesto a la magnitud

Implementar dos estados de puntero disjuntos: **navegación de cámara** y **manipulación de objeto físico**.

- En `pointerdown`, intersecar objetos manipulables mediante `THREE.Raycaster.setFromCamera(pointerNDC,camera)` e `intersectObjects(...)`. Si no hay intersección, se mantiene OrbitControls.
- Si hay selección, establecer `dragMode`, deshabilitar temporalmente `controls.enabled`, capturar el puntero con `canvas.setPointerCapture(pointerId)` y construir la restricción matemática: plano, trayectoria, superficie paramétrica o distancia fija.
- En cada `pointermove`, intersecar rayo con la restricción y aplicar un mapa inverso a parámetros, por ejemplo `x = clamp(intersection.x, xmin, xmax)`; **no limitarse a mover visualmente el mesh**.
- Llamar `setParams({x})` → validar → `compute(params)` → actualizar geometrías, valores y LaTeX. Si la cinemática impone restricciones, resolverlas antes de renderizar.
- En `pointerup`, `pointercancel` o pérdida de foco, restaurar controles, liberar captura y limpiar modo arrastre.
- Usar `touch-action: none` en canvas específico (no toda la nota) y `PointerEvent` para ratón, stylus y táctil. Probar colisiones de gestos con scroll de Obsidian y con pinch de cámara en Android real.

## 5. Etiquetas matemáticas ancladas en 3D

El modelo suministra una posición de mundo `P=(x,y,z)` para cada etiqueta y una cadena TeX consistente. La vista calcula `P.project(camera)` para pasar a coordenadas normalizadas y después a píxeles del overlay HTML sobre el canvas. Renderizar la cadena con KaTeX, `pointer-events:none`, ocultando u atenuando elementos fuera del frustum o detrás de superficies cuando sea necesario. Reposicionar al rotar, hacer zoom, redimensionar o cambiar la geometría.

Las etiquetas científicas no son simples texturas rotatorias arbitrarias; deben mantener relación geométrica definida con el objeto y unidades claras.

## 6. Animación física: separación de relojes

No identificar FPS con pasos de integración. Mantener `simTime` y un acumulador: `accumulator += min(realDelta, maxFrameDelta)`, integrar con `while accumulator >= dt` y un número máximo de pasos por frame. La visualización puede interpolar entre estados consecutivos sin modificar el método físico. Cada laboratorio define su integrador apropiado (analítico, RK4, simpléctico, etc.) y las pruebas científicas relacionadas. El frame de Obsidian solo solicita `PAUSE/RESUME` por visibilidad.

## 7. Ciclo de vida y recursos

- Inicializar WebGL solo para un laboratorio visible o tras interacción si hay varios 3D; prioridad a evitar saturación de contextos en Android.
- Suspender animación con `intersection`/visibilidad de documento; reanudar una sola vez, sin duplicar listeners ni loops.
- Capturar `webglcontextlost`, cancelar render y mostrar aviso; en `webglcontextrestored`, reconstruir los recursos cuando la implementación lo permita.
- En `destroy`: `renderer.setAnimationLoop(null)`; `controls.dispose()`; recorrer escena y liberar cada geometría, material (incluidos arrays), texturas y render targets; `renderer.dispose()`; limpiar `ResizeObserver`, `PointerEvent` listeners, overlays y referencias de estado.
- Dar fallback de tabla 2D/resultados si 3D no funciona; preservar cálculo ya verificado.

## 8. Caso 3D nuevo para aceptación

**Superficie:** `z(x,y;a)=a sin(x) cos(y)`, `x,y ∈ [-π, π]`, `a ∈ [0,2]`. El agente deriva, calcula y genera **desde cero** la malla con `a`, incluye un slider, un control directo manipulable para `a` si puede describir y programar una restricción inversa válida, etiquetas `z`, `a` y una vista 2D de corte que comparta el mismo cálculo. No hace falta añadir un preset `surface-sine` al plugin.

Pruebas independientes: `z(0,y;a)=0`, `z(π/2,0;a)=a`, `z(π/2,π;a)=-a`; valor absoluto máximo no mayor que `|a|`; al hacer `a=0` la superficie debe ser plana. Rotar la cámara no altera ninguna de estas invariantes. Comprobar malla, controles, memoria y Android.

## 9. Estado de implementación

Este documento especifica comportamiento futuro del runtime. Se han consultado las APIs públicas de Three.js y Obsidian, pero **no se ha ejecutado todavía un prototipo Three.js dentro del plugin real de Obsidian del usuario**. No contabilizar la demo 2D como prueba de 3D.
