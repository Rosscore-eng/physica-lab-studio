# PhysicaLab Studio 1.1.1 — runtime abierto

La IA escribe el laboratorio HTML/JS y lo guarda en el vault. PhysicaLab lo reproduce dentro de la nota: controles, figuras arrastrables, cálculos y ecuaciones. Un tema nuevo no requiere compilar ni registrar un preset. El plugin no incorpora proveedores de IA, claves de API ni ejecuta CLI.

## Usar un laboratorio

1. Pide a Copilot, Codex o Claude que lea `SKILL.md` y los contratos de esta carpeta.
2. El agente genera un `.html` original dentro del vault, con un modelo verificado y controles sincronizados.
3. En la nota ejecuta **PhysicaLab Studio: Insertar laboratorio desde archivo HTML** o escribe:

```physlab
{
  "version": 1,
  "id": "mi-laboratorio",
  "file": "PhysicaLab/labs/mi-laboratorio.html",
  "height": 640,
  "features": ["2d", "latex"],
  "initialState": {}
}
```

También acepta HTML inline: primera línea `<!-- physlab:v1 {"id":"ejemplo","features":["2d","latex"]} -->`, seguida del HTML, dentro de una cerca `physlab`. Escribe bloques al nivel principal de la nota. Cada `id` es único dentro de esa nota.

- **Reiniciar:** parámetros iniciales del manifiesto/HTML.
- **Guardar:** fuerza el guardado local; los cambios ya se agrupan automáticamente.
- **Snapshot:** incorpora los parámetros actuales solo a la cabecera de ese bloque y detecta cambios de edición.
- **Código HTML:** editor de texto del archivo, con comprobación de conflictos al guardar.
- **Copiar bloque:** crea un ID nuevo y copia los parámetros actuales.
- **Ampliar:** solicita pantalla completa nativa sobre el mismo laboratorio y conserva su estado; Escape vuelve a la nota. El botón requiere que Obsidian permita la API de pantalla completa.

El estado local está en `data.json` del plugin, con clave nota + ID; mover controles no modifica Markdown. Snapshot permite conservar valores explícitos en la nota. No se presupone sincronización de `data.json` entre dispositivos. Los bloques antiguos de presets continúan funcionando.

## API dentro del HTML

`window.PhysLab` existe antes del código del laboratorio:

```js
const bridge = window.PhysLab;
let state = { x: 1, ...bridge?.initialState };
const katex = bridge?.libs.katex;
const THREE = bridge?.libs.THREE;
const OrbitControls = bridge?.libs.OrbitControls;
// Validar state → compute(state) → todas las vistas y ecuaciones.
bridge?.saveState(state);
const unsubscribe = bridge?.on('destroy', () => { /* liberar recursos */ });
```

Eventos: `pause`, `resume`, `resize` (ancho/alto), `destroy`. Usa `reportError(mensaje)` para errores legibles. El estado debe ser JSON finito, sin claves de prototipo, hasta 32 KiB; se conservan hasta 256 laboratorios locales recientes. Los valores por defecto del HTML deben funcionar sin bridge.

Las dependencias se habilitan por `features`: `2d` (SVG/Canvas), `latex` (KaTeX), `3d` (Three.js + OrbitControls). Todos los bundles/fuentes son locales; no uses CDN ni imports remotos. Three.js/OrbitControls: 0.186.1. KaTeX: 0.16.47. Se incluye Latin Modern Roman original con licencia GUST y las fuentes matemáticas de KaTeX.

## Apariencia

Ajustes: **Scientific Dark**, **Scientific Light (papel)** y **seguir Obsidian**, además de la paleta personalizable. Se transmiten al documento aislado mediante variables `--pl-bg`, `--pl-surface`, `--pl-surface2`, `--pl-border`, `--pl-text`, `--pl-muted`, `--pl-grid`, `--pl-axis`, `--pl-blue`, `--pl-green`, `--pl-amber`, `--pl-violet`, `--pl-rose`. Usa estas variables en HTML/SVG; `PhysLab.theme.tokens` permite leer colores en Three.js. Las ecuaciones se renderizan con KaTeX y los ejemplos muestran su fuente LaTeX en un desplegable.

## Ejemplos y desarrollo

`demo-vault/PhysicaLab Runtime V1.md` contiene Riemann, Thévenin/Norton, puente de cuatro diodos y superficie 3D. Son archivos HTML independientes, no un catálogo de temas del runtime.

La [guía para crear laboratorios](docs/crear-laboratorios.md) incluye un pedido reutilizable para la IA y un bloque listo para insertar. El ejemplo [sistema de tres masas y resortes](demo-vault/PhysicaLab/labs/sistema-tres-masas-resortes.html) también es un HTML editable e independiente.

```powershell
npm ci
npm test
npm run build
node tests/visual/runtime-examples.mjs
node tests/visual/security-runtime.mjs
node scripts/install.mjs "C:\ruta\del\vault"
```

La instalación copia `main.js`, `styles.css`, `manifest.json`, documentación y **vendor/**. Conserva `data.json`. Los materiales previos de IA/CLI son históricos y no forman parte del bundle ni se distribuyen en instalaciones nuevas.

Para instalar una versión publicada, descarga el ZIP completo y copia su carpeta `physica-lab-studio` a `.obsidian/plugins/` de tu vault. Conserva `vendor/`: contiene las bibliotecas y fuentes necesarias para trabajar sin conexión. Activa el plugin en los ajustes de complementos de Obsidian.

El contrato del ZIP se conserva como referencia de diseño. El estado exacto de las pruebas realizadas y sus límites se registra en `docs/VALIDACION-RUNTIME.md`; una ventana móvil del navegador no equivale a una prueba en Android físico.

En 1.1.1, dos pruebas de integración simulada, TypeScript y la compilación comprueban el cambio de **Ampliar**. También se comprobó manualmente en Obsidian Windows la entrada en pantalla completa nativa con el mismo laboratorio, conservando su estado y la animación en marcha.
