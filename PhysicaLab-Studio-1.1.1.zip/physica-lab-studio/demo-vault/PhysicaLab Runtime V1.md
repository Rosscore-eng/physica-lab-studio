# PhysicaLab · Runtime abierto V1

Cada bloque ejecuta un HTML original del vault. La matemática y la interacción están en ese archivo: estos ejemplos no registran presets en el plugin. El código puede escribirlo una IA externa; no se necesita una clave de API dentro de PhysicaLab.

Los controles y los puntos dorados modifican el mismo estado científico. **Restablecer** vuelve al `initialState` del bloque. La fuente LaTeX se puede desplegar bajo cada figura. KaTeX, sus fuentes matemáticas, Latin Modern Roman, Three.js y OrbitControls se cargan desde `vendor/` del plugin, sin CDN.

## 1. Sumas de Riemann

Suma izquierda, derecha y media para ∫₀² x² dx. Arrastra la sonda para evaluar f(x). Valores de comprobación con n = 4: 1.75, 3.75 y 2.625; integral exacta 8/3.

```physlab
{
  "version": 1,
  "id": "runtime-riemann-x2",
  "file": "PhysicaLab/labs/riemann-x2.html",
  "height": 720,
  "features": ["2d", "latex"],
  "initialState": {"n": 4, "method": "left", "probeX": 1}
}
```

## 2. Equivalentes de Thévenin y Norton

Divisor con Vs = 12 V, R1 = 1 kΩ, R2 = 2 kΩ. Vth = 8 V, Rth = 666.6667 Ω, IN = 12 mA. Para RL = 1 kΩ, los circuitos original, Thévenin y Norton dan VL = 4.8 V. Arrastrar la carga modifica RL; el botón de máxima potencia la iguala a Rth.

```physlab
{
  "version": 1,
  "id": "runtime-thevenin-norton",
  "file": "PhysicaLab/labs/thevenin-norton.html",
  "height": 900,
  "features": ["2d", "latex"],
  "initialState": {"vs": 12, "r1": 1000, "r2": 2000, "rl": 1000}
}
```

## 3. Puente rectificador de cuatro diodos

La sonda temporal activa D1 + D4 o D2 + D3 cuando el puente conduce. Sin condensador, vout = max(0, |vin| − 2 Vf). Con C > 0 se calcula un régimen periódico de retención de pico, con descarga RC exponencial y pasos Δt = T/800. El modelo declara fuente ideal sin impedancia, caída de diodo constante, R y C ideales; no simula corriente de irrupción, ESR ni recuperación del diodo. La corriente indicada es la de la carga R.

```physlab
{
  "version": 1,
  "id": "runtime-four-diode-bridge",
  "file": "PhysicaLab/labs/bridge-rectifier.html",
  "height": 1050,
  "features": ["2d", "latex"],
  "initialState": {"peak": 10, "frequency": 50, "vf": 0.7, "resistance": 1000, "capacitance": 0, "phase": 0.25}
}
```

## 4. Superficie original 3D

z(x,y;a) = a sin(x) cos(y) en [−π, π]², a ∈ [0,2]. La esfera P = (π/2,0,a) controla a por inversión a = z. El fondo controla órbita y zoom sin cambiar a. El corte y la tabla funcionan también sin WebGL2. La malla se actualiza desde el mismo modelo, y la escena se dibuja bajo demanda.

```physlab
{
  "version": 1,
  "id": "runtime-sine-surface-original",
  "file": "PhysicaLab/labs/sine-surface-3d.html",
  "height": 950,
  "features": ["2d", "3d", "latex"],
  "initialState": {"a": 1}
}
```

Los ejemplos siguen el tema elegido en los ajustes de PhysicaLab. Para fijar uno por bloque añade `"theme": "scientific-dark"`, `"scientific-light"` u `"obsidian"`. Con el tema Obsidian, los colores se resuelven desde el tema de la aplicación y pasan al iframe mediante variables `--pl-*` y `PhysLab.theme`.

En móvil, cada HTML reorganiza sus paneles a una sola columna. Las pruebas táctiles automatizadas usan un navegador de escritorio con emulación táctil a 390 px; la compatibilidad con el dispositivo Android real debe comprobarse allí.
