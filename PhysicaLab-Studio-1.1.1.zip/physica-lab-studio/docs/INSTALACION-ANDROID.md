# Instalación en Android

El manifiesto declara `isDesktopOnly: false`. La interfaz se comprobó mediante emulación táctil a 390 px en Edge; **no se comprobó en un teléfono Android físico**. La pantalla completa de 1.1.1 también requiere comprobar el soporte de la API en Obsidian móvil.

## Vault sincronizado

1. Instala el plugin en el PC siguiendo [Instalación en Windows](INSTALACION-WINDOWS.md).
2. Asegúrate de que tu método de sincronización incluye `.obsidian/plugins/physica-lab-studio/`, especialmente **vendor/**, y los HTML de los laboratorios del vault.
3. En el móvil abre **Ajustes → Complementos de la comunidad** y activa **PhysicaLab Studio**.

## Copia manual

Extrae la carpeta `physica-lab-studio` del ZIP completo en `<vault>/.obsidian/plugins/` en el teléfono. Conserva `main.js`, `manifest.json`, `styles.css`, **vendor/** y la documentación. Reinicia Obsidian y activa el plugin. Copia también los HTML que quieras insertar al vault.

## Estado entre dispositivos

Los bloques HTML guardan automáticamente parámetros en `data.json` del plugin. No se presupone que ese archivo se sincronice entre dispositivos. **Snapshot** escribe explícitamente los valores actuales en el bloque Markdown para conservarlos con la nota. Los laboratorios antiguos basados en presets mantienen su compatibilidad y pueden usar archivos de estado propios.

## Comprobaciones pendientes en teléfono

- El laboratorio cabe en vertical y sus controles responden al tacto.
- Arrastrar las figuras no desplaza la nota y las ecuaciones siguen siendo legibles.
- Las bibliotecas 2D, LaTeX y 3D se cargan sin conexión.
- Los parámetros se restauran al reabrir la nota.
- La animación se pausa al salir de la vista y se libera al cerrar.
- **Ampliar** entra y sale de pantalla completa cuando la plataforma lo permite.
