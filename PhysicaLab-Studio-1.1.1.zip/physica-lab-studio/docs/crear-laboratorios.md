# Cómo crear un laboratorio

PhysicaLab reproduce dentro de una nota el HTML científico que crea la IA. Puedes pedir fenómenos nuevos; no necesitas registrar presets, ejecutar una CLI ni configurar claves de API en el plugin.

1. **Pide el laboratorio a la IA.** Indícale que lea `SKILL.md`, `README.md` y `RUNTIME_ARCHITECTURE.md` del plugin. Describe el fenómeno, parámetros, unidades y qué quieres manipular. Este pedido sirve como punto de partida:

   > Crea un laboratorio original de péndulo doble no lineal para PhysicaLab. Guarda un HTML offline en `PhysicaLab/labs/pendulo-doble.html`. Deriva las ecuaciones acopladas completas, con ángulos medidos desde la vertical inferior, masas puntuales, varillas rígidas sin masa y gravedad uniforme. Usa RK4 con paso físico independiente de los FPS. Incluye sliders para masas, longitudes, gravedad y condiciones iniciales; permite arrastrar ambas masas respetando las longitudes y actualizar ambos ángulos con esa geometría. Al soltar, fija explícitamente las velocidades iniciales. Sincroniza dibujo, trayectorias, valores, energía y LaTeX desde un único modelo. Muestra unidades SI, energía cinética y potencial con referencia definida, deriva numérica de energía y fuente LaTeX desplegable. Verifica equilibrio, conservación aproximada y convergencia al reducir el paso. Usa las bibliotecas locales, restaura `PhysLab.initialState`, persiste con `saveState` y gestiona `pause`, `resume` y `destroy`. Entrega el HTML, el bloque physlab y las comprobaciones realizadas.

2. **Insértalo en una nota.** Abre la nota en modo Edición, coloca el cursor y pulsa **Ctrl+P → PhysicaLab Studio: Insertar laboratorio desde archivo HTML**. Selecciona el archivo del vault. El comando necesita un editor activo. También puedes pegar este bloque después de copiar el ejemplo de tres masas de `demo-vault/PhysicaLab/labs/` a `PhysicaLab/labs/` en tu vault:

   ````markdown
   ```physlab
   {
     "version": 1,
     "id": "tres-masas-ejemplo-01",
     "file": "PhysicaLab/labs/sistema-tres-masas-resortes.html",
     "height": 900,
     "features": ["2d", "latex"],
     "initialState": {}
   }
   ```
   ````

   Pega el bloque al nivel principal, fuera de listas y callouts. Para otro HTML cambia `file` y usa un `id` único en esa nota. `features` habilita bibliotecas: añade `3d` cuando el laboratorio use Three.js.

3. **Experimenta y guarda.** En lectura o vista previa, mueve sliders y arrastra las figuras. En las tres masas puedes cambiar masas, resortes y fuerza, y comparar movimientos y energía. Abre **Ecuaciones, hipótesis e integración → Ver fuente LaTeX del modelo actual**. **Código HTML** permite editar la fuente; al guardar se recarga. Los parámetros se guardan automáticamente; **Guardar** fuerza ese guardado local y **Snapshot** escribe los valores actuales en el bloque de la nota. **Ampliar** solicita pantalla completa; **Escape** permite volver a la nota.

Regla científica: **un solo estado → calcular → actualizar todas las vistas**. La animación, las fórmulas y los números deben representar la misma física.
