# Ampliar en Live Preview — 1.1.1

El contenedor de CodeMirror recortaba el laboratorio al usar position:fixed. El botón ahora solicita fullscreen nativo sobre el mismo elemento. No mueve ni clona el iframe, y fullscreenchange mantiene el botón y la clase sincronizados con Escape, cierre y remontaje.

Comprobación acotada: dos casos de integración simulada (pantalla completa/salida sin reemplazar estado ni frame, y remontaje de laboratorio ampliado), TypeScript y compilación de producción. No se ejecutó la suite completa ni pruebas de otros fenómenos.

Comprobación manual posterior en Obsidian Windows: tras desactivar y activar el plugin para cargar la versión nueva, Ampliar entró en pantalla completa nativa, mantuvo el mismo estado y la simulación siguió avanzando. El contenido se ajustó tras el aviso de redimensionado; el ejemplo de tres masas centra su contenido con un ancho máximo de 1260 px.
