# Instalación en Windows

1. Descarga el ZIP completo de la versión publicada y extrae la carpeta `physica-lab-studio`.
2. Copia esa carpeta a `<tu vault>/.obsidian/plugins/`. Debe incluir `main.js`, `manifest.json`, `styles.css` y **vendor/**; las bibliotecas y fuentes locales del runtime necesitan esta última carpeta.
3. En Obsidian abre **Ajustes → Complementos de la comunidad**, recarga la lista y activa **PhysicaLab Studio**. Si aparece el modo restringido, desactívalo para permitir complementos de comunidad.

Para actualizar, cierra Obsidian y sustituye los archivos del plugin conservando `data.json`, que contiene los ajustes y el estado local. Las notas y los HTML del vault se conservan por separado.

## Compilar desde el repositorio

Con Node.js y npm disponibles:

```powershell
npm ci
npm run build
node scripts/install.mjs "C:\ruta\a\tu\vault"
```

`npm run build` compila y copia la versión al `demo-vault` del repositorio. El último comando la copia al vault elegido y conserva su `data.json`. `npm run dist` prepara `dist/physica-lab-studio/` para distribuir.

## Primer laboratorio

Consulta [Cómo crear un laboratorio](crear-laboratorios.md). Copia los ejemplos de `demo-vault/PhysicaLab/labs/` a `PhysicaLab/labs/` de tu vault y la nota `demo-vault/PhysicaLab Runtime V1.md` a la carpeta de notas que prefieras. Para insertar otro HTML, abre una nota en modo Edición y usa **Ctrl+P → PhysicaLab Studio: Insertar laboratorio desde archivo HTML**.

El plugin reproduce HTML local; la IA crea el archivo fuera del plugin. No necesitas configurar claves de API ni un ejecutable de IA dentro de Obsidian.

## Desinstalar

Desactiva el plugin y elimina `.obsidian/plugins/physica-lab-studio/`. Los bloques `physlab` quedan como código en las notas; los HTML del vault siguen disponibles. Si quieres conservar ajustes o estados locales, guarda antes una copia de `data.json`.
