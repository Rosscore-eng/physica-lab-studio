# Validación del runtime PhysicaLab 1.1.1

2026-10-24. Continuación del ZIP y de la rama physlab-v1-runtime.

- Compilación de producción y TypeScript comprobados.
- Última suite completa: 274 pruebas aprobadas; incluye contratos del runtime, integración simulada de Obsidian, estado/snapshot y modelos científicos. Se detuvieron pruebas adicionales a petición del usuario.
- Navegador Edge real: cuatro HTML en temas oscuro/claro, controles y arrastre, tipografía Latin Modern local, KaTeX y fuente LaTeX. Emulación táctil a 390 px, interacción 3D y fallback sin WebGL comprobados.
- Aislamiento: 16 comprobaciones en Edge, incluidas denegación de DOM padre/Node/eval, mensajes falsificados, estado JSON, recursos HTTP y navegación HTTP. Se añadió una envoltura de confianza con CSP alrededor del iframe del laboratorio para cerrar la navegación que permitía el diseño de un solo iframe. Esto no prueba toda API de red ni resistencia a consumo excesivo de CPU/GPU.
- Obsidian Windows 1.14.5: el plugin carga y registra sus cinco comandos en un perfil/vault independientes. La prueba automatizada de los cuatro bloques en la vista real agotó la espera, sin errores capturados; no se declara validada la vista real Lectura/Live Preview. Los mismos cuatro bloques sí funcionan en el navegador de pruebas del runtime.
- No se ejecutaron pruebas en un dispositivo Android físico.
- Tras la revisión final se añadieron liberadores pagehide/unload al documento aislado, para que los recursos se liberen también cuando el navegador retira el iframe antes de entregar DESTROY. Esta última defensa se compiló; no se abrió una nueva ronda de pruebas.

Para 1.1.1 se comprobaron dos casos de integración simulada del botón Ampliar (entrada/salida sin sustituir el iframe ni perder el estado, y remontaje), TypeScript y la compilación de producción. No se repitió la suite completa. Una comprobación manual posterior en Obsidian Windows confirmó la entrada en pantalla completa nativa con el mismo laboratorio, su estado conservado y el tiempo de simulación avanzando. Para cargar el código nuevo fue necesario desactivar y activar el plugin; la recarga mediante CLI no lo había aplicado. El ajuste al ancho completo llegó tras el aviso de redimensionado.

Uso: abrir `demo-vault/PhysicaLab Runtime V1.md` en un vault de demostración con el plugin instalado. Los cuatro HTML son editables y funcionan sin registrar nuevos presets. Los bloques nuevos deben ir al nivel principal de la nota, fuera de listas/callouts.
