# PhysicaLab Studio — Arquitectura técnica del runtime abierto (V1 propuesta)

**Estado:** especificación de diseño, 20 de octubre de 2026. **No es una auditoría ni una implementación validada del plugin existente.** Antes de desarrollar, inspeccionar el repositorio real y conservar los componentes aprovechables. Este documento es subordinado a las decisiones definitivas del contexto de continuidad.

## 1. Objetivo y límites

PhysicaLab Studio ejecuta laboratorios científicos creados manualmente por un agente desde Copilot de Obsidian. El agente lee `SKILL.md` y `README.md`, deriva/verifica el modelo científico, genera código original HTML/CSS/JavaScript (o TypeScript previamente compilado) y lo incrusta o enlaza en una nota Markdown. **PhysicaLab no consulta ni administra agentes, APIs, modelos ni CLI** y **no filtra temas científicos por una lista de presets**.

El plugin debe proveer: descubrimiento de bloques `physlab`, carga y aislamiento del documento, librerías visuales locales opcionales, un puente mínimo de estado/ciclo de vida, comandos de inserción, persistencia, manejo de errores y pruebas. El código de cada laboratorio provee su **propio modelo físico/matemático**, cálculos, controles y vistas; no es una animación decorativa.

## 2. Contrato de archivo y Markdown (`physlab/v1`)

Existen dos formas; ambas producen exactamente el mismo runtime. Especificación **propuesta para implementar**, no soporte ya confirmado.

### A. Referencia a HTML externo — opción preferida

~~~markdown
```physlab
{
  "version": 1,
  "id": "riemann-x2-001",
  "file": "PhysicaLab/labs/riemann-x2.html",
  "height": 520,
  "features": ["latex", "2d"],
  "initialState": {"n": 4, "method": "left"}
}
```
~~~

- `file`: ruta relativa a la raíz del vault, resuelta exclusivamente con las APIs de Obsidian; solo archivo existente `.html`; rechazar URL externa, rutas absolutas, `..`, enlaces ambiguos y symlinks hacia afuera si el adaptador los permite.
- `id`: identificador estable y único **dentro de la nota**; la clave del estado local es `rutaNota + id`. Si hay duplicados, mostrar error comprensible y no fusionar estados.
- `features`: lista de **dependencias del entorno** (`2d`, `3d`, `latex`) que habilitan librerías, nunca una lista de fenómenos admitidos. Un laboratorio de un tema nuevo es válido sin registrar un preset.
- `height`: píxeles CSS iniciales; el contenedor tiene diseño responsive.
- `initialState`: JSON pequeño con parámetros iniciales; las llaves deben coincidir con la semántica del laboratorio.

### B. Contenido autocontenido directamente en la nota

~~~markdown
```physlab
<!-- physlab:v1 {"id":"riemann-inline-001","height":520,"features":["2d","latex"],"initialState":{"n":4}} -->
<div id="app"></div>
<style>/* estilos locales */</style>
<script>/* modelo + vista original del laboratorio */</script>
```
~~~

La primera línea es obligatoria y se interpreta como cabecera de metadatos JSON; las líneas restantes son HTML íntegro dentro del frame, no dentro del DOM de Obsidian. Si aparecen fences Markdown internos, usar una cerca externa más larga. Para código extenso preferir HTML externo a fin de no aumentar el peso de la nota ni ralentizar el editor.

**Alcance V1:** no ejecutar TypeScript crudo en tiempo de visualización. El agente transpila/empaqueta a JS compatible antes de insertar. Permitir JS arbitrario **dentro del frame** es compatible con generación abierta; prohibirlo en el contexto principal del plugin.

## 3. Arquitectura mínima propuesta

```text
Obsidian Markdown note
    └── MarkdownCodeBlockProcessor('physlab')
           ├── parser + validación de manifiesto
           ├── resolvedor de archivo / código embebido
           ├── FrameHost (iframe y CSP restringida)
           │      ├── shim PhysLab v1
           │      ├── librerías locales (opcionales)
           │      └── código HTML/JS independiente del laboratorio
           ├── FrameBridge (mensajes de capacidad mínima)
           └── StateStore (parámetros locales + snapshot explícito)
```

Módulos de referencia, sujetos a auditoría: `src/main.ts`; `src/markdown/processor.ts`; `src/runtime/parser.ts`; `src/runtime/frame-host.ts`; `src/runtime/frame-bridge.ts`; `src/runtime/vendor-bundles.ts`; `src/storage/state-store.ts`; `src/editor/commands.ts`; `src/styles.css`; pruebas contractuales. No justificar docenas de subsistemas nuevos si el flujo puede resolverse con menos.

El procesador debe registrar un hijo con ciclo de vida (`MarkdownRenderChild` o equivalente soportado) y destruir el frame al retirarse de la vista. El modo Lectura puede implementarse inicialmente con el procesador Markdown; Live Preview requiere comprobación específica o una extensión de editor posterior. No confundir que un bloque se vea en Lectura con que funcione en todos los modos.

## 4. Aislamiento de ejecución y amenaza

Objetivo: evitar que HTML/JS generado tenga acceso al DOM del Obsidian anfitrión, sus APIs privilegiadas, archivos del vault o red arbitraria. El padre **no** debe usar `eval`, `new Function`, insertar `<script>` de laboratorio en su DOM ni conceder APIs de archivos en `postMessage`.

Candidato de implementación: `iframe.srcdoc` creado por el plugin, con `sandbox="allow-scripts"` **sin** `allow-same-origin`, y una CSP restrictiva declarada **por el padre al comienzo del `<head>`**, por ejemplo:

```html
<meta http-equiv="Content-Security-Policy"
      content="default-src 'none'; script-src 'unsafe-inline' blob:;
               style-src 'unsafe-inline'; img-src data: blob:;
               font-src data:; connect-src 'none';
               worker-src 'none'; frame-src 'none'; object-src 'none';
               base-uri 'none'; form-action 'none'">
```

Esta política es una **base que debe probarse**, no una garantía universal en todos los WebViews. Los scripts de laboratorios, bridge y vendor se inyectan como bundles clásicos **dentro del frame** (p. ej. IIFE) y se empaquetan localmente; no depender de CDN ni de `file://` remoto. Sin `unsafe-eval`, `eval` dentro del frame queda restringido por CSP; WASM/Pyodide exigiría un perfil optativo distinto, evaluado aparte. Evitar que un archivo referenciado se abra con un `src` directo sin imponer CSP, porque se perdería control sobre conexiones de ese documento.

**Caveat crítico:** `allow-scripts` sin `allow-same-origin` aísla el origen pero no impide por sí solo consumo excesivo de CPU/GPU, mensajes masivos u otros abusos. Defender con límites de payload, gestión de visibilidad, descarga/destrucción de frames, pruebas adversariales y política CSP efectiva en Windows/Android. No venderlo como sandbox perfecto.

## 5. API de sandbox `window.PhysLab` v1

API mínima y estable, inyectada antes del script del laboratorio:

```ts
interface PhysLabAPI {
  readonly apiVersion: 1;
  readonly initialState: Record<string, JSONValue>;
  readonly libs: {
    katex?: { render: (...args: any[]) => void };
    THREE?: unknown;             // namespace empaquetado, solo con feature "3d"
    OrbitControls?: unknown;    // clase compatible con THREE incluido
  };
  saveState(data: Record<string, JSONValue>): void;
  on(event: 'pause' | 'resume' | 'destroy' | 'resize', cb: (value?: any) => void): () => void;
  reportError(message: string): void;
}
```

**No se exige** que el agente implemente una clase o motor de fenómeno. Para cada laboratorio basta una función propia `compute(parameters)` y funciones de dibujo que lean **sus resultados**. El runtime no determina qué temas están soportados. Las vistas y los controles dentro del frame comparten el único estado administrado por el laboratorio.

Ejemplo de flujo: `cambio de slider/arrastre → validate(patch) → state actualizado → compute(state) → renderSVG/render3D/renderLaTeX/renderNumbers → PhysLab.saveState(state)`.

`saveState` **solicita** persistencia; no escribe archivos directamente. `initialState` se compone desde los valores del bloque y, si el usuario eligió continuar una sesión, desde la memoria local. En ausencia del bridge, el laboratorio debe poder correr en HTML standalone con sus valores por defecto.

## 6. Puente de mensajes y persistencia

Mensajes entre `iframe` y plugin:

```json
{"ns":"physlab","v":1,"frameId":"...","nonce":"...","type":"STATE_SAVE","payload":{"n":4,"method":"left"}}
```

Frame → host: `READY`, `STATE_SAVE`, `ERROR`, `RESIZE_REQUEST`. Host → frame: `INIT`, `PAUSE`, `RESUME`, `DESTROY`, `STATE_RESTORE`. En cada mensaje verificar: `event.source === iframe.contentWindow`, `frameId`, `nonce`, versión, tipo permitido, forma JSON y límite de tamaño (propuesta inicial: 32 KiB para estado). `event.origin` puede ser `"null"` por el origen opaco y **no basta** como autenticación; el nonce tampoco es una autorización para realizar operaciones no expuestas. No incluir nunca `readFile`, `writeFile`, `fetch` u operaciones generales de Obsidian en la interfaz del frame.

Persistencia inicial: `loadData/saveData` del plugin, con escritura agrupada/debounced (p. ej. >=300 ms). No editar el Markdown al mover cada slider. Un comando independiente **Guardar parámetros como snapshot en la nota** actualiza únicamente la cabecera del bloque identificado, después de verificar archivo, bloque y conflicto de edición. El botón **Restaurar predeterminados** reinicia estado; **Deshacer inserción** usa el historial de edición de Obsidian o elimina solo el bloque seleccionado mediante comando explícito. No prometer sincronización multiplataforma a través del almacenamiento local sin probarla.

## 7. Soporte 2D y 3D

### 2D

SVG para diagramas vectoriales y geometría arrastrable; Canvas 2D para trazados densos; KaTeX local para matemáticas tipografiadas. Todos los componentes leen los mismos resultados computados.

### 3D (capacidad obligatoria, no preset)

- Distribuir localmente un bundle fijado de Three.js y `OrbitControls` como feature `"3d"`. En releases actuales Three.js `WebGLRenderer` utiliza WebGL2; comprobar soporte en cada dispositivo antes de instanciarlo.
- El agente define nuevas superficies, funciones paramétricas, campos vectoriales, trayectorias o mallas con código original. PhysicaLab únicamente ofrece bibliotecas y contenedor.
- Rotar, zoom, pan con mouse y gestos táctiles; Raycaster + plano/restricción geométrica para arrastrar puntos. Durante arrastre, suspender OrbitControls, convertir el punto 3D arrastrado a **parámetros físicos del modelo** y recalcular todas las vistas; reactivar OrbitControls al terminar.
- Ejes y escala explícitos; etiquetas matemáticas como overlays DOM KaTeX proyectados mediante cámara, evitando falsificar la posición espacial; leyendas de unidades y parámetros físicos.
- `ResizeObserver` y DPR limitado configurable (propuesta: máximo 2 escritorio / 1.5 Android). Rendereo por demanda si la escena no cambia; para simulación temporal usar un reloj de integración numérica coherente, independiente de FPS visual.
- Suspender al perder visibilidad (`IntersectionObserver` / `visibilitychange`), eliminar listeners, `geometry.dispose()`, `material.dispose()`, `texture.dispose()`, `controls.dispose()` y `renderer.dispose()` al destruir; reinstanciar con criterios de visibilidad. Limitar número de contextos 3D activos en Android y dar botón de activación diferida cuando hay muchos laboratorios.
- Manejar pérdida de contexto WebGL y mostrar explicación/fallback 2D o tabla calculada. No declarar Android validado sin pruebas en dispositivo físico.

### Separación visual/física

Un único estado observable y un `compute(state)` que produce valores de solución, mallas, puntos o trayectorias. Para casos numéricos, documentar integrador, paso, dominio, condiciones iniciales y error/tolerancias. La rotación de cámara nunca altera ecuaciones físicas; solo el gesto sobre objeto físico modifica parámetros.

## 8. Inserción y edición desde Copilot

**Ruta preferida:** el agente autorizado escribe el archivo HTML en el vault y edita directamente la nota activa **si dispone de acceso real a esa nota**. No afirmar que Copilot conoce el cursor por defecto. Si no tiene acceso fiable al editor, PhysicaLab ofrecerá comando `Insertar laboratorio desde archivo` con `editorCallback`, `editor.replaceSelection`/`replaceRange` y selección de archivo `*.html` del vault. El agente puede generar el manifiesto para copiarlo/insertarlo con ese comando. Esta solución no requiere API de agentes ni CLI dentro de PhysicaLab.

Preservar fuente editable: `Abrir código fuente`, `Duplicar laboratorio`, `Editar manifiesto`, `Guardar snapshot`, `Reiniciar parámetros`, `Eliminar bloque` como comandos de edición específicos. Empezar por inserción y abrir código; resto puede ampliarse después de validar el flujo.

## 9. Rendimiento en vault grande

- Sin exploraciones recursivas de miles de notas al iniciar: procesar únicamente bloques visibles y archivos referenciados.
- Carga bajo demanda de 3D y KaTeX; no incluir Three.js en un laboratorio puramente SVG.
- Validación y parseo acotados; registro de frames por vista y eliminación al cerrar/cambiar nota.
- Reuso de bibliotecas empaquetadas y control de memoria. Evitar muchos frames animados a la vez; estado y render por evento en vez de 60 FPS permanente.
- Medir FPS, uso de memoria y tiempos de apertura en notas con 1, 5 y 20 laboratorios, en PC y Android. Los presupuestos concretos deben fijarse con benchmarks, no inventarse.

## 10. Plan de pruebas y condición de salida

**Prueba 0 — Auditoría:** inventario real del plugin, APIs, dependencias, scripts, pruebas existentes, comportamiento actual; conservar lo útil sin asumir lo reportado por otros agentes.

**Prueba 1 — Riemann sin preset:** dado `f(x)=x²` en `[0,2]`, con `n=4`: izquierda `1.75`, derecha `3.75`, medio `2.625`; exacto `8/3`. Al modificar `n` y método, los rectángulos, suma, error y ecuación deben cambiar desde el mismo resultado. Comprobar con pruebas analíticas y numéricas.

**Prueba 2 — Thévenin/Norton sin preset:** tensión y resistencia equivalentes calculadas mediante leyes de Kirchhoff, verificadas al cambiar carga; evitar esquemas que no reflejen corriente/voltajes reales.

**Prueba 3 — puente rectificador sin preset:** cuatro diodos y estados de conducción coherentes con modelo declarado; `Vin(t)` y `Vout(t)` medidos del mismo cálculo. Si incluye condensador, resolver su dinámica, no solo dibujarlo.

**Prueba 4 — superficie 3D sin preset:** geometría paramétrica, parámetros en controles y arrastre, rotación/zoom, etiquetas LaTeX, cambios correspondientes de valores y malla; evitar recalcular física solo porque se movió la cámara.

**Prueba 5 — aislamiento:** HTML que intenta DOM de Obsidian, acceso al vault, red o mensajes host no autorizados debe fallar; CSP y sandbox efectivos en desktop y Android; pruebas de estado grande/malformado, IDs duplicados y fuga de contextos GPU.

**Prueba 6 — UX real:** copia de código/archivo, inserción en nota, Lectura, volver a editar, snapshot/restaurar, reiniciar, móvil táctil, offline con dependencias locales.

Criterio de aceptación superior: un agente capaz de escribir JS/HTML debe poder generar y reproducir **otro tema no previsto** leyendo solo `SKILL.md` + `README.md`, sin tocar el runtime ni registrar `supported: true`.

## 11. Orden de ejecución sugerido

1. Auditar repositorio y obtener baseline de tests.
2. Implementar parser para ambos formatos, aislamiento de frame y contrato `PhysLab` sin librerías voluminosas.
3. Cargar Riemann y probar estado + SVG/Canvas + LaTeX + inserción.
4. Añadir bundle Three.js/OrbitControls, gesto táctil, recursos y escena 3D nueva.
5. Completar otras dos pruebas físicas; verificar Windows y Android, CSP real y fuga de recursos.
6. Actualizar `SKILL.md` a partir de errores encontrados; agregar documentación de desarrollo y migración.

## 12. Fuentes técnicas consultadas (no equivalen a pruebas en nuestro plugin)

- Obsidian Markdown post-processing: https://github.com/obsidianmd/obsidian-developer-docs/blob/main/en/Plugins/Editor/Markdown%20post%20processing.md
- Obsidian Editor API: https://docs.obsidian.md/Plugins/Editor/Editor
- Obsidian mobile development: https://docs.obsidian.md/Plugins/Getting%20started/Mobile%20development
- MDN iframe sandbox: https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements/iframe
- MDN srcdoc security: https://developer.mozilla.org/en-US/docs/Web/API/HTMLIFrameElement/srcdoc
- Three.js WebGLRenderer: https://threejs.org/docs/pages/WebGLRenderer
- Three.js OrbitControls: https://threejs.org/docs/pages/OrbitControls.html
